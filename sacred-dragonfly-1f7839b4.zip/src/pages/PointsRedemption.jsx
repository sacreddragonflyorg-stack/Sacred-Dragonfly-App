import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Award, Gift, DollarSign, Loader2, TrendingUp, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

export default function PointsRedemption() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [discountAmount, setDiscountAmount] = useState(10);

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      if (u.role !== 'user') {
        window.location.href = '/';
      }
    }).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  const { data: transactions = [] } = useQuery({
    queryKey: ['point-transactions', user?.email],
    queryFn: () => user ? base44.entities.PointTransaction.filter({ user_email: user.email }, '-transaction_date', 50) : [],
    enabled: !!user,
  });

  const redeemForDiscountMutation = useMutation({
    mutationFn: async (amount) => {
      const pointsCost = amount * 10;
      const currentPoints = user.learning_points || 0;

      if (currentPoints < pointsCost) {
        throw new Error("Not enough points");
      }

      await base44.auth.updateMe({
        learning_points: currentPoints - pointsCost
      });

      await base44.entities.PointTransaction.create({
        user_email: user.email,
        points: -pointsCost,
        type: "spent",
        reason: `Redeemed $${amount} session discount`,
        transaction_date: new Date().toISOString()
      });

      return { ...user, learning_points: currentPoints - pointsCost };
    },
    onSuccess: (updatedUser) => {
      setUser(updatedUser);
      queryClient.invalidateQueries(['point-transactions']);
      toast.success(`Discount code generated! Check your email for details.`);
    },
    onError: (error) => {
      toast.error(error.message === "Not enough points" ? "You don't have enough points" : "Failed to redeem points");
    }
  });

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-purple-600" />
      </div>
    );
  }

  const points = user.learning_points || 0;

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Redeem Your <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Points</span>
          </h1>
          <p className="text-lg text-gray-600">Turn your learning into rewards</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <Card className="bg-gradient-to-br from-purple-600 to-pink-600 text-white">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100 mb-1">Your Balance</p>
                    <div className="flex items-baseline gap-2">
                      <span className="text-5xl font-bold">{points}</span>
                      <span className="text-xl text-purple-100">points</span>
                    </div>
                  </div>
                  <Award className="w-16 h-16 text-purple-200" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gift className="w-6 h-6 text-purple-600" />
                  Session Discount
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600">
                  Redeem your points for discounts on healing sessions. Rate: 100 points = $10 discount
                </p>
                
                <div className="grid grid-cols-3 gap-3">
                  {[10, 25, 50].map(amount => {
                    const cost = amount * 10;
                    const canAfford = points >= cost;
                    return (
                      <Button
                        key={amount}
                        onClick={() => setDiscountAmount(amount)}
                        variant={discountAmount === amount ? "default" : "outline"}
                        disabled={!canAfford}
                        className={discountAmount === amount ? "bg-purple-600" : ""}
                      >
                        <div className="text-center">
                          <p className="font-bold">${amount}</p>
                          <p className="text-xs">{cost} pts</p>
                        </div>
                      </Button>
                    );
                  })}
                </div>

                <div className="bg-purple-50 rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-700">Discount Amount:</span>
                    <span className="text-2xl font-bold text-purple-600">${discountAmount}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm text-gray-600">
                    <span>Points Required:</span>
                    <span className="font-semibold">{discountAmount * 10} points</span>
                  </div>
                </div>

                <Button
                  onClick={() => redeemForDiscountMutation.mutate(discountAmount)}
                  disabled={redeemForDiscountMutation.isPending || points < (discountAmount * 10)}
                  size="lg"
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600"
                >
                  {redeemForDiscountMutation.isPending ? (
                    <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Processing...</>
                  ) : (
                    <>
                      <DollarSign className="w-5 h-5 mr-2" />
                      Redeem ${discountAmount} Discount
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </>
                  )}
                </Button>
                {points < (discountAmount * 10) && (
                  <p className="text-sm text-red-600 text-center">
                    You need {(discountAmount * 10) - points} more points
                  </p>
                )}
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-purple-600" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {transactions.length === 0 ? (
                    <p className="text-center text-gray-500 py-8">No transactions yet</p>
                  ) : (
                    transactions.map((transaction) => (
                      <div key={transaction.id} className="p-3 bg-gray-50 rounded-lg">
                        <div className="flex justify-between items-start mb-1">
                          <span className="text-sm font-medium text-gray-900">
                            {transaction.reason}
                          </span>
                          <span className={`font-bold ${transaction.points > 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {transaction.points > 0 ? '+' : ''}{transaction.points}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <Badge variant="outline" className="text-xs">
                            {transaction.type}
                          </Badge>
                          <span className="text-xs text-gray-500">
                            {format(new Date(transaction.transaction_date), 'MMM d, h:mm a')}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}