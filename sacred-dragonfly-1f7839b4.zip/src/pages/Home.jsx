import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Sparkles, Heart, Zap, Star, ArrowRight, Calendar, Users, Phone, Mail } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-purple-100 via-pink-50 to-amber-50">
          <div className="absolute inset-0 opacity-30">
            <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-400 rounded-full mix-blend-multiply filter blur-3xl animate-pulse"></div>
            <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-pink-400 rounded-full mix-blend-multiply filter blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
            <div className="absolute bottom-1/4 left-1/3 w-96 h-96 bg-amber-400 rounded-full mix-blend-multiply filter blur-3xl animate-pulse" style={{animationDelay: '4s'}}></div>
          </div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/50 backdrop-blur-sm rounded-full mb-8 border border-purple-200">
              <Sparkles className="w-4 h-4 text-purple-600" />
              <span className="text-sm font-medium text-purple-900">Distance Healing • Reiki • Tarot</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              <span className="bg-gradient-to-r from-purple-600 via-pink-600 to-amber-600 bg-clip-text text-transparent">
                Heal Without Boundaries
              </span>
              <br />
              <span className="text-gray-800">Mind, Body & Soul</span>
            </h1>

            <p className="text-xl md:text-2xl text-gray-700 mb-6 max-w-4xl mx-auto leading-relaxed">
              Transform your life through distance healing, muscle testing, energy work, and spiritual guidance. 
              All sessions conducted remotely—healing that comes to you, wherever you are.
            </p>
            
            <p className="text-lg text-gray-600 mb-12 max-w-3xl mx-auto">
              Specialized in addiction recovery, depression, anxiety, PTSD, chronic pain, abandonment issues, 
              and emotional healing—without revisiting trauma.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to={createPageUrl("Booking")}>
                <Button size="lg" className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-6 text-lg rounded-full shadow-xl hover:shadow-2xl transition-all duration-300 glow-effect">
                  <Calendar className="w-5 h-5 mr-2" />
                  Book Your Distance Session
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Link to={createPageUrl("Services")}>
                <Button size="lg" variant="outline" className="px-8 py-6 text-lg rounded-full border-2 border-purple-600 text-purple-600 hover:bg-purple-50">
                  Explore Healing Modalities
                </Button>
              </Link>
            </div>
          </motion.div>

          {/* Floating Icons */}
          <div className="absolute inset-0 pointer-events-none">
            <Sparkles className="absolute top-1/4 left-1/4 w-8 h-8 text-purple-400 float-animation" style={{animationDelay: '0s'}} />
            <Star className="absolute top-1/3 right-1/4 w-6 h-6 text-pink-400 float-animation" style={{animationDelay: '1s'}} />
            <Heart className="absolute bottom-1/3 left-1/3 w-7 h-7 text-amber-400 float-animation" style={{animationDelay: '2s'}} />
            <Zap className="absolute top-2/3 right-1/3 w-6 h-6 text-purple-400 float-animation" style={{animationDelay: '3s'}} />
          </div>
        </div>
      </section>

      {/* Distance Healing Methods */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Healing From Anywhere
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Choose your preferred method of distance healing—all equally powerful and effective
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Live Video Session",
                description: "Real-time healing sessions via secure video call. Experience guided healing with direct practitioner interaction.",
                icon: "🎥",
                color: "from-purple-500 to-pink-500"
              },
              {
                title: "Email Healing",
                description: "Receive personalized healing work through detailed email correspondence and energy transmission.",
                icon: "📧",
                color: "from-pink-500 to-amber-500"
              },
              {
                title: "Text/Message Healing",
                description: "Quick, convenient healing sessions through text messaging for on-the-go support and guidance.",
                icon: "💬",
                color: "from-amber-500 to-purple-500"
              }
            ].map((method, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2 }}
                className="group relative bg-gradient-to-br from-purple-50 to-pink-50 rounded-3xl p-8 hover:shadow-2xl transition-all duration-300"
              >
                <div className="text-6xl mb-6">{method.icon}</div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">{method.title}</h3>
                <p className="text-gray-600 leading-relaxed">{method.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Core Healing Modalities */}
      <section className="py-24 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Our Healing Modalities
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Comprehensive healing approaches for deep transformation
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Muscle Testing & Emotion Release",
                description: "Release trapped emotions without revisiting trauma. Gentle, effective healing for deep emotional wounds.",
                icon: "💪",
                specialties: ["Addiction", "Depression", "Anxiety", "PTSD"]
              },
              {
                title: "Distance Reiki Healing",
                description: "Powerful energy healing for you and your beloved pets. Universal life force energy knows no distance.",
                icon: "✨",
                specialties: ["For Humans", "For Pets", "Energy Balance"]
              },
              {
                title: "Tarot Guidance",
                description: "Insightful readings to guide your healing journey and provide clarity on your path forward.",
                icon: "🔮",
                specialties: ["Life Guidance", "Healing Support", "Decision Making"]
              },
              {
                title: "Crystal Healing",
                description: "Harness the power of crystals to enhance any healing method and support your journey.",
                icon: "💎",
                specialties: ["Energy Amplification", "Chakra Support", "Vibrational Healing"]
              },
              {
                title: "Chakra Work & Meditation",
                description: "Opening, balancing, and aligning your energy centers. Pre-session prep and aftercare support.",
                icon: "🧘",
                specialties: ["Chakra Opening", "Energy Balancing", "Guided Meditation"]
              },
              {
                title: "Specialized Techniques",
                description: "Hand mudras, cord cutting, color therapy, art healing, and positive thought transformation.",
                icon: "🌈",
                specialties: ["Mudras", "Cord Cutting", "Color Therapy", "Art Healing"]
              }
            ].map((modality, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-6 hover:shadow-xl transition-all duration-300"
              >
                <div className="text-5xl mb-4">{modality.icon}</div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{modality.title}</h3>
                <p className="text-gray-600 mb-4 leading-relaxed">{modality.description}</p>
                <div className="flex flex-wrap gap-2">
                  {modality.specialties.map((spec, idx) => (
                    <span key={idx} className="text-xs bg-purple-100 text-purple-700 px-3 py-1 rounded-full">
                      {spec}
                    </span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* What We Help With */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Healing for Every Challenge
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Specialized support for a wide range of emotional and physical concerns
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { title: "Addiction Recovery", icon: "🔗", color: "purple" },
              { title: "Depression & Mood", icon: "🌤️", color: "blue" },
              { title: "Anxiety Relief", icon: "🕊️", color: "green" },
              { title: "PTSD Healing", icon: "💚", color: "teal" },
              { title: "Chronic Pain", icon: "🌸", color: "pink" },
              { title: "Abandonment Issues", icon: "❤️", color: "red" },
              { title: "Emotional Trauma", icon: "🦋", color: "indigo" },
              { title: "General Wellness", icon: "✨", color: "amber" }
            ].map((area, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className={`bg-gradient-to-br from-${area.color}-50 to-${area.color}-100 rounded-xl p-6 text-center hover:scale-105 transition-transform duration-300`}
              >
                <div className="text-4xl mb-3">{area.icon}</div>
                <h3 className="font-semibold text-gray-900">{area.title}</h3>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Trending Hashtags */}
      <section className="py-16 bg-white border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-8 flex items-center justify-center gap-2">
              <span className="text-purple-600">#</span> Trending Topics
            </h3>
            <div className="flex flex-wrap justify-center gap-3 max-w-4xl mx-auto">
              {[
                "#SacredDragonfly", "#DistanceHealing", "#Reiki", "#TarotReading", 
                "#EnergyWork", "#CrystalHealing", "#ChakraBalancing", "#SelfCare",
                "#MentalWellness", "#SpiritualGrowth", "#InnerPeace", "#HealerLife",
                "#TraumaRecovery", "#PetHealing", "#LightWorker", "#MindBodySoul"
              ].map((tag, index) => (
                <span key={index} className="px-6 py-3 bg-gradient-to-r from-purple-50 to-pink-50 text-purple-700 rounded-full text-sm font-medium hover:from-purple-100 hover:to-pink-100 transition-all cursor-default shadow-sm hover:shadow-md border border-purple-100">
                  {tag}
                </span>
              ))}
            </div>
        </div>
      </section>

      {/* Why Distance Healing Works */}
      <section className="py-24 bg-gradient-to-r from-purple-900 via-pink-900 to-purple-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                Why Distance Healing Is Powerful
              </h2>
              <div className="space-y-6">
                {[
                  {
                    title: "Energy Has No Boundaries",
                    description: "Healing energy transcends physical distance. The universe operates on quantum principles where intention and energy connect beyond space and time."
                  },
                  {
                    title: "Comfort of Your Space",
                    description: "Receive healing in your own safe, comfortable environment. No travel required, no waiting rooms—just pure healing energy."
                  },
                  {
                    title: "Trauma-Free Approach",
                    description: "Our muscle testing and energy work release trapped emotions without making you relive painful memories. Gentle, effective, transformative."
                  },
                  {
                    title: "Proven Results",
                    description: "Thousands have experienced profound healing through our distance sessions. Real transformation, real results, real healing."
                  }
                ].map((reason, index) => (
                  <div key={index} className="flex items-start gap-4">
                    <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <Star className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-xl mb-2">{reason.title}</h3>
                      <p className="text-purple-200">{reason.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square bg-gradient-to-br from-purple-400 via-pink-400 to-amber-400 rounded-3xl opacity-20"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <Users className="w-32 h-32 mx-auto mb-6 float-animation" />
                  <p className="text-3xl font-bold">Healing Without Limits</p>
                  <p className="text-purple-200 mt-2">Distance • Time • Space</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Get In Touch
            </h2>
            <p className="text-xl text-gray-600">
              Ready to start your healing journey? Contact us today
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="hover:shadow-xl transition-shadow">
              <CardContent className="pt-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Phone className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Call Us</h3>
                <a href="tel:+12077195798" className="text-2xl font-bold text-purple-600 hover:text-purple-700 transition-colors">
                  (207) 719-5798
                </a>
                <p className="text-gray-600 mt-2 text-sm">Available for appointments and inquiries</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-shadow">
              <CardContent className="pt-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-pink-600 to-amber-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Mail className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Email Us</h3>
                <a href="mailto:info@sacred-dragonfly.org" className="text-2xl font-bold text-purple-600 hover:text-purple-700 transition-colors break-all">
                  info@sacred-dragonfly.org
                </a>
                <p className="text-gray-600 mt-2 text-sm">We'll respond within 24 hours</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Begin Your Healing Journey Today
          </h2>
          <p className="text-xl text-gray-600 mb-10">
            Choose your healing method and experience transformation from the comfort of your space
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("Booking")}>
              <Button size="lg" className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 px-12 py-6 text-lg rounded-full shadow-xl">
                <Calendar className="w-5 h-5 mr-2" />
                Book Distance Session
              </Button>
            </Link>
            <Link to={createPageUrl("Tarot")}>
              <Button size="lg" variant="outline" className="px-12 py-6 text-lg rounded-full border-2 border-purple-600 text-purple-600 hover:bg-purple-50">
                Get AI Tarot Reading
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}