import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Calendar, Clock, Heart, Sparkles, DollarSign, Users, Zap } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import StripePaymentForm from "../components/payment/StripePaymentForm";

export default function Subscriptions() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [showPayment, setShowPayment] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  const { data: plans, isLoading } = useQuery({
    queryKey: ['subscription-plans'],
    queryFn: () => base44.entities.SubscriptionPlan.filter({ is_active: true }),
    initialData: [],
  });

  const { data: mySubscriptions } = useQuery({
    queryKey: ['my-subscriptions', user?.email],
    queryFn: () => {
      if (!user) return [];
      return base44.entities.ClientSubscription.filter({ client_email: user.email });
    },
    enabled: !!user,
    initialData: [],
  });

  const subscribeToPatronMutation = useMutation({
    mutationFn: async ({ plan, paymentData }) => {
      // Create subscription record
      const subscription = await base44.entities.ClientSubscription.create({
        client_email: user.email,
        client_name: user.full_name,
        plan_id: plan.id,
        plan_name: plan.name,
        stripe_subscription_id: paymentData.subscriptionId, // Real subscription ID from Stripe
        status: 'active',
        current_period_start: new Date().toISOString(),
        current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // Should ideally fetch from Stripe invoice
        sessions_used: 0,
        sessions_total: plan.sessions_per_interval,
        price: plan.price,
        billing_interval: plan.billing_interval
      });

      return subscription;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['my-subscriptions']);
      toast.success("Successfully subscribed! Welcome to ongoing healing.");
      setShowPayment(false);
      setSelectedPlan(null);
    },
  });

  const cancelSubscriptionMutation = useMutation({
    mutationFn: async (subscription) => {
      // In production, call CancelStripeSubscription function
      return base44.entities.ClientSubscription.update(subscription.id, {
        status: 'canceled',
        cancel_at_period_end: true,
        canceled_at: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['my-subscriptions']);
      toast.success("Subscription canceled. Access continues until period end.");
    },
  });

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  const activeSubscriptions = mySubscriptions.filter(s => s.status === 'active');

  if (showPayment && selectedPlan) {
    return (
      <div className="min-h-screen py-12">
        <div className="max-w-2xl mx-auto px-4">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">Subscribe to {selectedPlan.name}</h1>
            <p className="text-gray-600">Complete your subscription payment</p>
          </div>
          
          <StripePaymentForm
            amount={selectedPlan.price}
            mode="subscription"
            planDetails={selectedPlan}
            description={`${selectedPlan.name} - ${selectedPlan.billing_interval} subscription`}
            metadata={{
              plan_id: selectedPlan.id,
              client_email: user.email,
              type: 'subscription'
            }}
            onSuccess={(paymentData) => subscribeToPatronMutation.mutate({ plan: selectedPlan, paymentData })}
            onCancel={() => {
              setShowPayment(false);
              setSelectedPlan(null);
            }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full mb-6 border border-purple-200">
            <Sparkles className="w-4 h-4 text-purple-600" />
            <span className="text-sm font-medium text-purple-900">Ongoing Healing Programs</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Subscribe to <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Continuous Healing</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Regular healing sessions for sustained transformation and growth
          </p>
        </div>

        {/* Active Subscriptions */}
        {activeSubscriptions.length > 0 && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6">Your Active Subscriptions</h2>
            <div className="grid gap-6">
              {activeSubscriptions.map((sub) => (
                <Card key={sub.id} className="border-2 border-purple-300 bg-gradient-to-r from-purple-50 to-pink-50">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-2xl">{sub.plan_name}</CardTitle>
                        <Badge className="mt-2 bg-green-600">Active</Badge>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-purple-700">${sub.price}</p>
                        <p className="text-sm text-gray-600">per {sub.billing_interval}</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="p-3 bg-white rounded-lg">
                          <p className="text-sm text-gray-600">Sessions This Period</p>
                          <p className="text-xl font-semibold">{sub.sessions_used} / {sub.sessions_total}</p>
                        </div>
                        <div className="p-3 bg-white rounded-lg">
                          <p className="text-sm text-gray-600">Renews On</p>
                          <p className="text-xl font-semibold">
                            {format(new Date(sub.current_period_end), 'MMM d, yyyy')}
                          </p>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        onClick={() => cancelSubscriptionMutation.mutate(sub)}
                        className="text-red-600 border-red-300 hover:bg-red-50"
                      >
                        Cancel Subscription
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Available Plans */}
        <div>
          <h2 className="text-2xl font-bold mb-6">Available Subscription Plans</h2>
          {isLoading ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
            </div>
          ) : plans.length === 0 ? (
            <Card className="text-center py-16">
              <CardContent>
                <Sparkles className="w-16 h-16 text-purple-300 mx-auto mb-4" />
                <h3 className="text-2xl font-semibold text-gray-700 mb-2">No Plans Available Yet</h3>
                <p className="text-gray-500">Check back soon for subscription options</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {plans.map((plan) => {
                const isSubscribed = activeSubscriptions.some(s => s.plan_id === plan.id);
                return (
                  <Card key={plan.id} className={`hover:shadow-2xl transition-all duration-300 ${isSubscribed ? 'border-2 border-purple-400' : ''}`}>
                    <CardHeader className="bg-gradient-to-br from-purple-600 to-pink-600 text-white">
                      <div className="text-center">
                        <CardTitle className="text-2xl mb-2">{plan.name}</CardTitle>
                        <div className="text-4xl font-bold mb-1">${plan.price}</div>
                        <p className="text-purple-100">per {plan.billing_interval}</p>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-6">
                      <p className="text-gray-700 mb-4">{plan.description}</p>
                      
                      <div className="space-y-3 mb-6">
                        <div className="flex items-center gap-2 text-gray-700">
                          <Calendar className="w-5 h-5 text-purple-600" />
                          <span>{plan.sessions_per_interval} sessions per {plan.billing_interval}</span>
                        </div>
                        <div className="flex items-center gap-2 text-gray-700">
                          <Clock className="w-5 h-5 text-purple-600" />
                          <span>{plan.session_duration_minutes} minutes each</span>
                        </div>
                      </div>

                      {plan.benefits && plan.benefits.length > 0 && (
                        <div className="mb-6">
                          <p className="font-semibold mb-2">Includes:</p>
                          <ul className="space-y-2">
                            {plan.benefits.map((benefit, idx) => (
                              <li key={idx} className="flex items-start gap-2 text-sm">
                                <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                <span>{benefit}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      <Button
                        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                        onClick={() => {
                          setSelectedPlan(plan);
                          setShowPayment(true);
                        }}
                        disabled={isSubscribed}
                      >
                        {isSubscribed ? (
                          <>
                            <CheckCircle2 className="w-4 h-4 mr-2" />
                            Already Subscribed
                          </>
                        ) : (
                          <>
                            <Zap className="w-4 h-4 mr-2" />
                            Subscribe Now
                          </>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}