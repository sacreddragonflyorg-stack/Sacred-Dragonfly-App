import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { User, Mail, Save, Loader2, CheckCircle2, Calendar, Settings, Crown, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import AvailabilityManager from "../components/practitioner/AvailabilityManager";
import PremiumBranding from "../components/practitioner/PremiumBranding";

export default function PractitionerProfile() {
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({
    full_name: "",
    phone: "",
    bio: "",
    specialties: "",
    certifications: "",
    years_experience: "",
    preferred_contact_method: "email",
    payment_handles: {}
  });

  useEffect(() => {
    base44.auth.me().then((u) => {
      if (u.role !== 'admin') {
        window.location.href = createPageUrl("ClientProfile");
        return;
      }
      setUser(u);
      setFormData({
        full_name: u.full_name || "",
        phone: u.phone || "",
        bio: u.bio || "",
        specialties: u.specialties || "",
        certifications: u.certifications || "",
        years_experience: u.years_experience || "",
        preferred_contact_method: u.preferred_contact_method || "email",
        payment_handles: u.payment_handles || {}
      });
    }).catch((e) => {
      console.error(e);
      // Don't redirect if it's just a fetch error, only if unauthorized
      // base44.auth.redirectToLogin();
    });
  }, []);

  const updateProfileMutation = useMutation({
    mutationFn: async (data) => {
      // Update User entity
      const updatedUser = await base44.auth.updateMe(data);
      
      // Also update Practitioner entity if it exists
      const practitioners = await base44.entities.Practitioner.filter({ user_email: user.email });
      if (practitioners.length > 0) {
        await base44.entities.Practitioner.update(practitioners[0].id, {
          display_name: data.full_name, // Sync display name
          payment_handles: data.payment_handles
        });
      }
      return updatedUser;
    },
    onSuccess: (updatedUser) => {
      setUser(updatedUser);
      toast.success("Profile updated successfully!");
    },
    onError: () => {
      toast.error("Failed to update profile");
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    updateProfileMutation.mutate(formData);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Practitioner <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Profile</span>
          </h1>
          <p className="text-lg text-gray-600">Manage your practice settings and availability</p>
        </div>

        <Tabs defaultValue="personal" className="space-y-6">
          <TabsList className="bg-white p-1 rounded-lg shadow">
            <TabsTrigger value="personal">Personal Info</TabsTrigger>
            <TabsTrigger value="branding">
              <Crown className="w-4 h-4 mr-2" />
              Branding
            </TabsTrigger>
            <TabsTrigger value="availability">Availability</TabsTrigger>
            <TabsTrigger value="quick-links">Quick Links</TabsTrigger>
          </TabsList>

          {/* Personal Information Tab */}
          <TabsContent value="personal" className="space-y-6">
            {/* Account Info */}
            <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
              <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Account Information
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="flex items-center gap-3 p-4 bg-purple-50 rounded-lg">
                    <Mail className="w-5 h-5 text-purple-600" />
                    <div>
                      <p className="text-sm text-gray-600">Email</p>
                      <p className="font-semibold text-gray-900">{user.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-purple-50 rounded-lg">
                    <Calendar className="w-5 h-5 text-purple-600" />
                    <div>
                      <p className="text-sm text-gray-600">Member Since</p>
                      <p className="font-semibold text-gray-900">
                        {format(new Date(user.created_date), 'MMM d, yyyy')}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Profile Form */}
            <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
              <CardHeader>
                <CardTitle className="text-2xl">Professional Information</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="full_name">Full Name *</Label>
                      <Input
                        id="full_name"
                        value={formData.full_name}
                        onChange={(e) => handleChange('full_name', e.target.value)}
                        placeholder="Your full name"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => handleChange('phone', e.target.value)}
                        placeholder="+1 (555) 123-4567"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bio">Professional Bio</Label>
                    <Textarea
                      id="bio"
                      value={formData.bio}
                      onChange={(e) => handleChange('bio', e.target.value)}
                      placeholder="Share your healing philosophy and experience..."
                      rows={6}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="specialties">Specialties & Modalities</Label>
                    <Textarea
                      id="specialties"
                      value={formData.specialties}
                      onChange={(e) => handleChange('specialties', e.target.value)}
                      placeholder="E.g., Reiki, Tarot, Energy Healing, Chakra Balancing..."
                      rows={4}
                    />
                  </div>

                  {/* Payment Handles Section */}
                  <div className="pt-6 border-t space-y-4">
                    <h3 className="text-lg font-medium text-gray-900">Payment Methods & Handles</h3>
                    <p className="text-sm text-gray-500">
                      Provide your details so clients know where to send payments for manual booking methods.
                    </p>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>PayPal Link/Email</Label>
                        <Input 
                          value={formData.payment_handles?.paypal_link || ''}
                          onChange={(e) => setFormData(prev => ({ 
                            ...prev, 
                            payment_handles: { ...prev.payment_handles, paypal_link: e.target.value } 
                          }))}
                          placeholder="paypal.me/username"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Cash App Tag</Label>
                        <Input 
                          value={formData.payment_handles?.cashapp_tag || ''}
                          onChange={(e) => setFormData(prev => ({ 
                            ...prev, 
                            payment_handles: { ...prev.payment_handles, cashapp_tag: e.target.value } 
                          }))}
                          placeholder="$Cashtag"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Venmo Handle</Label>
                        <Input 
                          value={formData.payment_handles?.venmo_handle || ''}
                          onChange={(e) => setFormData(prev => ({ 
                            ...prev, 
                            payment_handles: { ...prev.payment_handles, venmo_handle: e.target.value } 
                          }))}
                          placeholder="@username"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Chime Sign</Label>
                        <Input 
                          value={formData.payment_handles?.chime_sign || ''}
                          onChange={(e) => setFormData(prev => ({ 
                            ...prev, 
                            payment_handles: { ...prev.payment_handles, chime_sign: e.target.value } 
                          }))}
                          placeholder="$ChimeSign"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Dave Bank Tag/Link</Label>
                        <Input 
                          value={formData.payment_handles?.dave_link || ''}
                          onChange={(e) => setFormData(prev => ({ 
                            ...prev, 
                            payment_handles: { ...prev.payment_handles, dave_link: e.target.value } 
                          }))}
                          placeholder="Dave ID"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>One Bank Link</Label>
                        <Input 
                          value={formData.payment_handles?.one_link || ''}
                          onChange={(e) => setFormData(prev => ({ 
                            ...prev, 
                            payment_handles: { ...prev.payment_handles, one_link: e.target.value } 
                          }))}
                          placeholder="Pay Link"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Google Pay Info</Label>
                        <Input 
                          value={formData.payment_handles?.google_pay_link || ''}
                          onChange={(e) => setFormData(prev => ({ 
                            ...prev, 
                            payment_handles: { ...prev.payment_handles, google_pay_link: e.target.value } 
                          }))}
                          placeholder="Phone or Email"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="certifications">Certifications</Label>
                      <Textarea
                        id="certifications"
                        value={formData.certifications}
                        onChange={(e) => handleChange('certifications', e.target.value)}
                        placeholder="List your certifications..."
                        rows={3}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="years_experience">Years of Experience</Label>
                      <Input
                        id="years_experience"
                        type="number"
                        value={formData.years_experience}
                        onChange={(e) => handleChange('years_experience', e.target.value)}
                        placeholder="e.g., 10"
                      />
                    </div>
                  </div>

                  <div className="pt-6 border-t">
                    <Button
                      type="submit"
                      disabled={updateProfileMutation.isPending}
                      size="lg"
                      className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                    >
                      {updateProfileMutation.isPending ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Saving Changes...
                        </>
                      ) : (
                        <>
                          <Save className="w-5 h-5 mr-2" />
                          Save Profile
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Branding Tab */}
          <TabsContent value="branding">
            <PremiumBranding user={user} onUpdate={setUser} />
          </TabsContent>

          {/* Availability Tab */}
          <TabsContent value="availability">
            <AvailabilityManager />
          </TabsContent>

          {/* Quick Links Tab */}
          <TabsContent value="quick-links" className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-6 h-6" />
                  Practice Management
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Link to={createPageUrl("Dashboard")}>
                  <Button variant="outline" size="lg" className="w-full justify-start">
                    <Calendar className="w-5 h-5 mr-3" />
                    Dashboard & Appointments
                  </Button>
                </Link>
                <Link to={createPageUrl("ClientManagement")}>
                  <Button variant="outline" size="lg" className="w-full justify-start">
                    <User className="w-5 h-5 mr-3" />
                    Client Management
                  </Button>
                </Link>
                <Link to={createPageUrl("PractitionerSubscription")}>
                  <Button variant="outline" size="lg" className="w-full justify-start">
                    <Crown className="w-5 h-5 mr-3" />
                    My Subscription
                  </Button>
                </Link>
                <p className="text-sm text-gray-600 mt-4">
                  Manage your services, view client information, and track appointments from your dashboard.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-purple-50 border-purple-200">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-purple-600 mt-0.5" />
                  <div className="text-sm text-gray-700">
                    <p className="font-semibold mb-1">Professional Practice</p>
                    <p>Your profile and availability settings help clients understand your expertise and book sessions at convenient times.</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}