import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Circle, Search, MessageCircle } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function PractitionerChat() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [selectedClient, setSelectedClient] = useState(null);
  const [messageText, setMessageText] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const messagesEndRef = useRef(null);

  useEffect(() => {
    base44.auth.me().then((u) => {
      if (u.role !== 'admin') window.location.href = '/';
      setUser(u);
      updateOnlineStatus(u.email);
    }).catch(() => base44.auth.redirectToLogin());
  }, []);

  const updateOnlineStatus = async (email) => {
    try {
      const statuses = await base44.entities.UserStatus.filter({ user_email: email });
      if (statuses.length > 0) {
        await base44.entities.UserStatus.update(statuses[0].id, {
          is_online: true,
          last_seen: new Date().toISOString()
        });
      } else {
        await base44.entities.UserStatus.create({
          user_email: email,
          is_online: true,
          last_seen: new Date().toISOString()
        });
      }
    } catch (error) {
      console.error("Status update error:", error);
    }
  };

  useEffect(() => {
    if (!user) return;
    const interval = setInterval(() => updateOnlineStatus(user.email), 30000);
    return () => clearInterval(interval);
  }, [user]);

  const { data: appointments } = useQuery({
    queryKey: ['client-appointments'],
    queryFn: () => base44.entities.Appointment.list(),
    initialData: [],
  });

  const clients = Array.from(new Map(
    appointments.map(apt => [apt.client_email, { email: apt.client_email, name: apt.client_name }])
  ).values());

  const filteredClients = clients.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const conversationId = selectedClient ? `admin_${selectedClient.email}` : null;

  const { data: messages } = useQuery({
    queryKey: ['chat-messages', conversationId],
    queryFn: () => {
      if (!conversationId) return [];
      return base44.entities.ChatMessage.filter({ conversation_id: conversationId }, 'created_date');
    },
    enabled: !!conversationId,
    initialData: [],
  });

  const { data: statuses } = useQuery({
    queryKey: ['user-statuses'],
    queryFn: () => base44.entities.UserStatus.list(),
    initialData: [],
  });

  const { data: allMessages } = useQuery({
    queryKey: ['all-chat-messages'],
    queryFn: () => base44.entities.ChatMessage.list(),
    initialData: [],
  });

  useEffect(() => {
    const interval = setInterval(() => {
      queryClient.invalidateQueries(['chat-messages']);
      queryClient.invalidateQueries(['user-statuses']);
      queryClient.invalidateQueries(['all-chat-messages']);
    }, 3000);
    return () => clearInterval(interval);
  }, [queryClient]);

  const getUnreadCount = (clientEmail) => {
    return allMessages.filter(m => 
      m.conversation_id === `admin_${clientEmail}` && 
      !m.read && 
      m.sender_email === clientEmail
    ).length;
  };

  const sendMessageMutation = useMutation({
    mutationFn: async (message) => {
      return base44.entities.ChatMessage.create({
        conversation_id: conversationId,
        sender_email: user.email,
        sender_name: user.full_name,
        sender_role: 'admin',
        recipient_email: selectedClient.email,
        message: message
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['chat-messages']);
      setMessageText("");
      scrollToBottom();
    },
  });

  const markAsReadMutation = useMutation({
    mutationFn: async (messageIds) => {
      for (const id of messageIds) {
        await base44.entities.ChatMessage.update(id, {
          read: true,
          read_at: new Date().toISOString()
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['chat-messages']);
      queryClient.invalidateQueries(['all-chat-messages']);
    },
  });

  useEffect(() => {
    if (messages.length > 0) {
      const unread = messages.filter(m => !m.read && m.sender_email === selectedClient?.email);
      if (unread.length > 0) {
        markAsReadMutation.mutate(unread.map(m => m.id));
      }
    }
  }, [messages, selectedClient]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = (e) => {
    e.preventDefault();
    if (messageText.trim()) {
      sendMessageMutation.mutate(messageText.trim());
    }
  };

  const isOnline = (email) => {
    const status = statuses.find(s => s.user_email === email);
    if (!status) return false;
    const lastSeen = new Date(status.last_seen);
    return status.is_online && (new Date() - lastSeen) < 60000;
  };

  if (!user) {
    return <div className="min-h-screen flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
    </div>;
  }

  return (
    <div className="min-h-screen py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <h1 className="text-3xl font-bold mb-8">Client Messages</h1>

        <div className="grid md:grid-cols-3 gap-6" style={{ height: 'calc(100vh - 200px)' }}>
          <Card className="flex flex-col">
            <CardHeader>
              <CardTitle>Clients</CardTitle>
              <div className="relative mt-2">
                <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search clients..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </CardHeader>
            <CardContent className="flex-1 overflow-hidden p-0">
              <ScrollArea className="h-full">
                <div className="p-4 space-y-2">
                  {filteredClients.map((client) => {
                    const unread = getUnreadCount(client.email);
                    return (
                      <button
                        key={client.email}
                        onClick={() => setSelectedClient(client)}
                        className={`w-full p-3 rounded-lg text-left transition-colors ${
                          selectedClient?.email === client.email
                            ? 'bg-purple-100 border-2 border-purple-300'
                            : 'bg-white hover:bg-gray-50 border border-gray-200'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2 flex-1">
                            <Circle className={`w-2 h-2 ${isOnline(client.email) ? 'fill-green-500 text-green-500' : 'fill-gray-300 text-gray-300'}`} />
                            <div className="flex-1">
                              <p className="font-semibold text-sm">{client.name}</p>
                              <p className="text-xs text-gray-500 truncate">{client.email}</p>
                            </div>
                          </div>
                          {unread > 0 && (
                            <Badge className="bg-red-500 text-white">{unread}</Badge>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          <Card className="md:col-span-2 flex flex-col">
            {selectedClient ? (
              <>
                <CardHeader className="border-b">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Circle className={`w-3 h-3 ${isOnline(selectedClient.email) ? 'fill-green-500 text-green-500' : 'fill-gray-300 text-gray-300'}`} />
                      <div>
                        <CardTitle className="text-lg">{selectedClient.name}</CardTitle>
                        <p className="text-xs text-gray-500">
                          {isOnline(selectedClient.email) ? 'Online' : 'Offline'}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="flex-1 overflow-hidden p-0">
                  <ScrollArea className="h-full p-4">
                    <div className="space-y-4">
                      {messages.map((msg) => (
                        <div
                          key={msg.id}
                          className={`flex ${msg.sender_email === user.email ? 'justify-end' : 'justify-start'}`}
                        >
                          <div className={`max-w-[70%] rounded-lg p-3 ${
                            msg.sender_email === user.email
                              ? 'bg-purple-600 text-white'
                              : 'bg-gray-100 text-gray-900'
                          }`}>
                            <p className="text-sm">{msg.message}</p>
                            <p className={`text-xs mt-1 ${
                              msg.sender_email === user.email ? 'text-purple-200' : 'text-gray-500'
                            }`}>
                              {format(new Date(msg.created_date), 'h:mm a')}
                            </p>
                          </div>
                        </div>
                      ))}
                      <div ref={messagesEndRef} />
                    </div>
                  </ScrollArea>
                </CardContent>

                <div className="p-4 border-t">
                  <form onSubmit={handleSend} className="flex gap-2">
                    <Input
                      value={messageText}
                      onChange={(e) => setMessageText(e.target.value)}
                      placeholder="Type a message..."
                      className="flex-1"
                    />
                    <Button type="submit" disabled={!messageText.trim() || sendMessageMutation.isPending}>
                      <Send className="w-4 h-4" />
                    </Button>
                  </form>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-gray-500">
                <div className="text-center">
                  <MessageCircle className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                  <p>Select a client to start messaging</p>
                </div>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}