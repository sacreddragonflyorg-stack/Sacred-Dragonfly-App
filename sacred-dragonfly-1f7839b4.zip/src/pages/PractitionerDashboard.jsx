import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, Clock, User, DollarSign, Briefcase, Star, Settings, CheckCircle } from "lucide-react";
import { toast } from "sonner";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { format, isToday, isTomorrow, startOfWeek, endOfWeek } from "date-fns";
import AvailabilityManager from "../components/practitioner/AvailabilityManager";
import AISessionAssistant from "../components/practitioner/AISessionAssistant";
import PractitionerCourseManager from "../components/practitioner/PractitionerCourseManager";
import PractitionerPerformanceDashboard from "../components/practitioner/analytics/PractitionerPerformanceDashboard";
import PractitionerAnalytics from "../components/practitioner/PractitionerAnalytics";
import PractitionerServiceManager from "../components/practitioner/PractitionerServiceManager";
import PractitionerPackageManager from "../components/practitioner/PractitionerPackageManager";
import PractitionerPayouts from "../components/practitioner/PractitionerPayouts";
import CourseAnalytics from "../components/practitioner/CourseAnalytics";
import MarketingTools from "../components/practitioner/MarketingTools";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";

export default function PractitionerDashboard() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => base44.auth.redirectToLogin());
  }, []);

  // Fetch appointments for this practitioner
  // Note: We need to filter by practitioner_id or similar. 
  // Assuming the user's email links them to a practitioner entity or appointments directly.
  const { data: practitionerRecord } = useQuery({
    queryKey: ['practitioner-profile', user?.email],
    queryFn: async () => {
      if (!user) return null;
      const recs = await base44.entities.Practitioner.filter({ user_email: user.email });
      return recs[0] || null;
    },
    enabled: !!user
  });

  const { data: appointments = [] } = useQuery({
    queryKey: ['practitioner-appointments', practitionerRecord?.id],
    queryFn: () => practitionerRecord 
      ? base44.entities.Appointment.filter({ practitioner_id: practitionerRecord.id }) 
      : [],
    enabled: !!practitionerRecord
  });

  const queryClient = useQueryClient();

  const completeSessionMutation = useMutation({
    mutationFn: async (appointmentId) => {
        const { data } = await base44.functions.invoke('completeSession', { appointmentId });
        if (data.error) throw new Error(data.error);
        return data;
    },
    onSuccess: (data) => {
        toast.success(data.payout_processed ? "Session completed & payout sent!" : "Session marked as completed.");
        queryClient.invalidateQueries(['practitioner-appointments']);
        queryClient.invalidateQueries(['practitioner-payouts']);
    },
    onError: (err) => {
        toast.error(err.message || "Failed to complete session");
    }
  });

  if (!user) return <div className="p-8 text-center">Loading...</div>;

  const upcomingAppointments = appointments.filter(a => new Date(a.appointment_date) >= new Date() && a.status !== 'cancelled');
  const todayAppointments = upcomingAppointments.filter(a => isToday(new Date(a.appointment_date)));

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Practitioner Dashboard</h1>
            <p className="text-gray-600">Welcome back, {user.full_name}</p>
          </div>
          <Link to={createPageUrl("PractitionerProfile")}>
            <Button variant="outline">
              <Settings className="w-4 h-4 mr-2" /> Profile Settings
            </Button>
          </Link>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Today's Sessions</CardTitle>
              <Calendar className="w-4 h-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{todayAppointments.length}</div>
              <p className="text-xs text-gray-500">appointments today</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Total Clients</CardTitle>
              <User className="w-4 h-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{new Set(appointments.map(a => a.client_email)).size}</div>
              <p className="text-xs text-gray-500">unique clients served</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">Rating</CardTitle>
              <Star className="w-4 h-4 text-yellow-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{practitionerRecord?.average_rating || "N/A"}</div>
              <p className="text-xs text-gray-500">average client rating</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="calendar" className="space-y-6">
          <TabsList className="bg-white p-1 rounded-lg shadow overflow-x-auto justify-start md:justify-center">
            <TabsTrigger value="calendar">Calendar</TabsTrigger>
            <TabsTrigger value="appointments">Appointments</TabsTrigger>
            <TabsTrigger value="services">Services</TabsTrigger>
            <TabsTrigger value="packages">Packages</TabsTrigger>
            <TabsTrigger value="courses">Courses</TabsTrigger>
            <TabsTrigger value="payouts">Payouts</TabsTrigger>
            <TabsTrigger value="marketing">Marketing</TabsTrigger>
            <TabsTrigger value="ai-assistant">AI Assistant</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="marketing">
            <MarketingTools practitioner={practitionerRecord} />
          </TabsContent>

          <TabsContent value="student-progress">
            <CourseAnalytics practitionerEmail={user?.email} />
          </TabsContent>

          <TabsContent value="payouts">
            <PractitionerPayouts practitioner={practitionerRecord} />
          </TabsContent>

          <TabsContent value="calendar">
            <AvailabilityManager />
          </TabsContent>

          <TabsContent value="ai-assistant">
            <AISessionAssistant />
          </TabsContent>

          <TabsContent value="services">
            <PractitionerServiceManager />
          </TabsContent>

          <TabsContent value="packages">
            <PractitionerPackageManager user={user} />
          </TabsContent>

          <TabsContent value="courses">
            <PractitionerCourseManager />
          </TabsContent>

          <TabsContent value="analytics">
            <PractitionerPerformanceDashboard />
          </TabsContent>

          <TabsContent value="appointments">
            <Card>
              <CardHeader>
                <CardTitle>Appointment History</CardTitle>
              </CardHeader>
              <CardContent>
                {appointments.length === 0 ? (
                  <p className="text-center py-8 text-gray-500">No appointments found.</p>
                ) : (
                  <div className="space-y-4">
                    {appointments.sort((a, b) => new Date(b.appointment_date) - new Date(a.appointment_date)).map(apt => (
                      <div key={apt.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                        <div className="flex items-center gap-4">
                          <div className="bg-purple-100 p-2 rounded-full">
                            <User className="w-5 h-5 text-purple-600" />
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">{apt.client_name}</p>
                            <p className="text-sm text-gray-500">{apt.service_name}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-gray-900">{format(new Date(apt.appointment_date), 'MMM d, yyyy')}</p>
                          <p className="text-sm text-gray-500">{format(new Date(apt.appointment_date), 'h:mm a')}</p>
                          <div className="flex flex-col items-end gap-1 mt-1">
                            <span className={`inline-block px-2 py-0.5 rounded text-xs ${
                                apt.status === 'confirmed' ? 'bg-green-100 text-green-800' :
                                apt.status === 'completed' ? 'bg-blue-100 text-blue-800' :
                                apt.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                                'bg-yellow-100 text-yellow-800'
                            }`}>
                                {apt.status}
                            </span>
                            {apt.status === 'confirmed' && (
                                <Button 
                                    size="sm" 
                                    className="h-7 text-xs bg-green-600 hover:bg-green-700 mt-1"
                                    onClick={() => {
                                        if (window.confirm("Mark session as completed and process payout?")) {
                                            completeSessionMutation.mutate(apt.id);
                                        }
                                    }}
                                    disabled={completeSessionMutation.isPending}
                                >
                                    {completeSessionMutation.isPending ? "Processing..." : "Complete & Payout"}
                                </Button>
                            )}
                            {apt.status === 'completed' && apt.payout_status === 'paid' && (
                                <span className="text-xs text-green-600 flex items-center">
                                    <CheckCircle className="w-3 h-3 mr-1" /> Paid
                                </span>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}