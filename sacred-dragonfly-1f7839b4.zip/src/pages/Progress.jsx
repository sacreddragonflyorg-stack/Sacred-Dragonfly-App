import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Plus, TrendingUp, BookOpen, Activity, Moon } from "lucide-react";

import ProgressEntryForm from "../components/progress/ProgressEntryForm";
import ProgressJournal from "../components/progress/ProgressJournal";
import ProgressCharts from "../components/progress/ProgressCharts";
import ProgressInsights from "../components/progress/ProgressInsights";
import ShadowWorkPrompts from "../components/progress/ShadowWorkPrompts";

export default function Progress() {
  const [user, setUser] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editingEntry, setEditingEntry] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  const { data: entries, isLoading } = useQuery({
    queryKey: ['progress-entries', user?.email],
    queryFn: () => {
      if (!user) return [];
      return base44.entities.ProgressEntry.filter({ created_by: user.email }, '-entry_date');
    },
    enabled: !!user,
    initialData: [],
  });

  const { data: appointments } = useQuery({
    queryKey: ['my-appointments-progress', user?.email],
    queryFn: () => {
      if (!user) return [];
      return base44.entities.Appointment.filter({ client_email: user.email }, '-appointment_date');
    },
    enabled: !!user,
    initialData: [],
  });

  const handleEdit = (entry) => {
    setEditingEntry(entry);
    setShowForm(true);
  };

  const handleSelectShadowPrompt = (promptText) => {
    setEditingEntry({ shadow_work: `**Prompt:** ${promptText}\n\n**Reflection:**\n` });
    setShowForm(true);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingEntry(null);
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your progress...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-2">
                My <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Healing Journey</span>
              </h1>
              <p className="text-lg text-gray-600">
                Track your progress, reflect on your growth, and share insights with your practitioner
              </p>
            </div>
            <Button
              onClick={() => setShowForm(true)}
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full shadow-lg"
            >
              <Plus className="w-5 h-5 mr-2" />
              New Entry
            </Button>
          </div>
        </div>

        {/* Entry Form Modal */}
        {showForm && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 overflow-y-auto">
            <div className="bg-white rounded-2xl max-w-4xl w-full my-8">
              <ProgressEntryForm
                entry={editingEntry}
                onClose={handleCloseForm}
                user={user}
                appointments={appointments}
              />
            </div>
          </div>
        )}

        {/* Main Content */}
        <Tabs defaultValue="journal" className="space-y-6">
          <TabsList className="bg-white/80 backdrop-blur-sm p-1 rounded-xl shadow-md">
            <TabsTrigger value="journal" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600 data-[state=active]:text-white">
              <BookOpen className="w-4 h-4 mr-2" />
              Journal
            </TabsTrigger>
            <TabsTrigger value="insights" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600 data-[state=active]:text-white">
              <TrendingUp className="w-4 h-4 mr-2" />
              Insights
            </TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600 data-[state=active]:text-white">
              <Activity className="w-4 h-4 mr-2" />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="shadow-work" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-600 data-[state=active]:to-blue-600 data-[state=active]:text-white">
              <Moon className="w-4 h-4 mr-2" />
              Shadow Work
            </TabsTrigger>
          </TabsList>

          <TabsContent value="journal">
            <ProgressJournal
              entries={entries}
              isLoading={isLoading}
              onEdit={handleEdit}
              user={user}
            />
          </TabsContent>

          <TabsContent value="insights">
            <ProgressInsights entries={entries} isLoading={isLoading} />
          </TabsContent>

          <TabsContent value="analytics">
            <ProgressCharts entries={entries} isLoading={isLoading} />
          </TabsContent>

          <TabsContent value="shadow-work">
            <ShadowWorkPrompts onSelectPrompt={handleSelectShadowPrompt} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}