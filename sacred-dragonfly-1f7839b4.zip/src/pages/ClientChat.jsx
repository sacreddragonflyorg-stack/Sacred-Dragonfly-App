import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Circle, MessageCircle, Sparkles } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function ClientChat() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [messageText, setMessageText] = useState("");
  const messagesEndRef = useRef(null);

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      updateOnlineStatus(u.email);
    }).catch(() => base44.auth.redirectToLogin());
  }, []);

  const updateOnlineStatus = async (email) => {
    try {
      const statuses = await base44.entities.UserStatus.filter({ user_email: email });
      if (statuses.length > 0) {
        await base44.entities.UserStatus.update(statuses[0].id, {
          is_online: true,
          last_seen: new Date().toISOString()
        });
      } else {
        await base44.entities.UserStatus.create({
          user_email: email,
          is_online: true,
          last_seen: new Date().toISOString()
        });
      }
    } catch (error) {
      console.error("Status update error:", error);
    }
  };

  useEffect(() => {
    if (!user) return;
    const interval = setInterval(() => updateOnlineStatus(user.email), 30000);
    return () => clearInterval(interval);
  }, [user]);

  const conversationId = user ? `admin_${user.email}` : null;

  const { data: messages } = useQuery({
    queryKey: ['chat-messages', conversationId],
    queryFn: () => {
      if (!conversationId) return [];
      return base44.entities.ChatMessage.filter({ conversation_id: conversationId }, 'created_date');
    },
    enabled: !!conversationId,
    initialData: [],
  });

  const { data: statuses } = useQuery({
    queryKey: ['practitioner-status'],
    queryFn: async () => {
      const allStatuses = await base44.entities.UserStatus.list();
      return allStatuses;
    },
    initialData: [],
  });

  useEffect(() => {
    if (!conversationId) return;
    const interval = setInterval(() => {
      queryClient.invalidateQueries(['chat-messages', conversationId]);
      queryClient.invalidateQueries(['practitioner-status']);
    }, 3000);
    return () => clearInterval(interval);
  }, [conversationId, queryClient]);

  const sendMessageMutation = useMutation({
    mutationFn: async (message) => {
      const users = await base44.entities.User.list();
      const practitioner = users.find(u => u.role === 'admin');
      
      return base44.entities.ChatMessage.create({
        conversation_id: conversationId,
        sender_email: user.email,
        sender_name: user.full_name,
        sender_role: 'user',
        recipient_email: practitioner?.email || 'admin@example.com',
        message: message
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['chat-messages']);
      setMessageText("");
      scrollToBottom();
    },
  });

  const markAsReadMutation = useMutation({
    mutationFn: async (messageIds) => {
      for (const id of messageIds) {
        await base44.entities.ChatMessage.update(id, {
          read: true,
          read_at: new Date().toISOString()
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['chat-messages']);
    },
  });

  useEffect(() => {
    if (messages.length > 0) {
      const unread = messages.filter(m => !m.read && m.sender_role === 'admin');
      if (unread.length > 0) {
        markAsReadMutation.mutate(unread.map(m => m.id));
      }
    }
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = (e) => {
    e.preventDefault();
    if (messageText.trim()) {
      sendMessageMutation.mutate(messageText.trim());
    }
  };

  const isPractitionerOnline = () => {
    const practitionerStatus = statuses.find(s => s.user_email !== user?.email);
    if (!practitionerStatus) return false;
    const lastSeen = new Date(practitionerStatus.last_seen);
    return practitionerStatus.is_online && (new Date() - lastSeen) < 60000;
  };

  if (!user) {
    return <div className="min-h-screen flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
    </div>;
  }

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Message Your Practitioner</h1>
          <p className="text-gray-600">Get guidance and support anytime</p>
        </div>

        <Card className="flex flex-col" style={{ height: 'calc(100vh - 250px)' }}>
          <CardHeader className="border-b bg-gradient-to-r from-purple-50 to-pink-50">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-full flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle>Sacred Healing Practitioner</CardTitle>
                <div className="flex items-center gap-2 text-sm">
                  <Circle className={`w-2 h-2 ${isPractitionerOnline() ? 'fill-green-500 text-green-500' : 'fill-gray-300 text-gray-300'}`} />
                  <span className="text-gray-600">
                    {isPractitionerOnline() ? 'Online now' : 'Offline'}
                  </span>
                </div>
              </div>
            </div>
          </CardHeader>

          <CardContent className="flex-1 overflow-hidden p-0">
            <ScrollArea className="h-full p-4">
              {messages.length === 0 ? (
                <div className="flex items-center justify-center h-full text-gray-500">
                  <div className="text-center">
                    <MessageCircle className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                    <p className="mb-2">Start a conversation</p>
                    <p className="text-sm">Send a message to connect with your practitioner</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex ${msg.sender_email === user.email ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[70%] rounded-lg p-3 ${
                        msg.sender_email === user.email
                          ? 'bg-purple-600 text-white'
                          : 'bg-gray-100 text-gray-900'
                      }`}>
                        <p className="text-sm">{msg.message}</p>
                        <p className={`text-xs mt-1 ${
                          msg.sender_email === user.email ? 'text-purple-200' : 'text-gray-500'
                        }`}>
                          {format(new Date(msg.created_date), 'h:mm a')}
                        </p>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              )}
            </ScrollArea>
          </CardContent>

          <div className="p-4 border-t bg-gray-50">
            <form onSubmit={handleSend} className="flex gap-2">
              <Input
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                placeholder="Type your message..."
                className="flex-1 bg-white"
              />
              <Button 
                type="submit" 
                disabled={!messageText.trim() || sendMessageMutation.isPending}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                <Send className="w-4 h-4" />
              </Button>
            </form>
            <p className="text-xs text-gray-500 mt-2">
              Messages are typically answered within 24 hours
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}