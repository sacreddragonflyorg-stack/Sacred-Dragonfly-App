import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Video, Clock, CheckCircle, Calendar } from "lucide-react";

import UpcomingSessions from "../components/live-sessions/UpcomingSessions";
import ActiveSession from "../components/live-sessions/ActiveSession";
import SessionHistory from "../components/live-sessions/SessionHistory";

export default function LiveSessions() {
  const [user, setUser] = useState(null);
  const [activeSessionId, setActiveSessionId] = useState(null);
  const [showVideoCall, setShowVideoCall] = useState(false);
  const [videoCallSession, setVideoCallSession] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  const { data: sessions, refetch } = useQuery({
    queryKey: ['live-sessions', user?.email],
    queryFn: () => {
      if (!user) return [];
      const isAdmin = user.role === 'admin';
      if (isAdmin) {
        return base44.entities.LiveSession.list('-scheduled_start');
      }
      return base44.entities.LiveSession.filter({ client_email: user.email }, '-scheduled_start');
    },
    enabled: !!user,
    initialData: [],
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  const upcomingSessions = sessions.filter(s => 
    s.status === 'scheduled' && new Date(s.scheduled_start) >= new Date()
  );

  const activeSessions = sessions.filter(s => 
    s.status === 'in_progress' || s.status === 'waiting'
  );

  const completedSessions = sessions.filter(s => 
    s.status === 'completed' || s.status === 'cancelled'
  );

  const isPractitioner = user.role === 'admin';

  // If there's an active session, show it
  if (activeSessionId) {
    const activeSession = sessions.find(s => s.id === activeSessionId);
    if (activeSession) {
      return (
        <ActiveSession
          session={activeSession}
          user={user}
          onEndSession={() => {
            setActiveSessionId(null);
            refetch();
          }}
          refetchSessions={refetch}
        />
      );
    }
  }

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-2">
            {isPractitioner ? 'Live Sessions' : 'My Sessions'}
          </h1>
          <p className="text-lg text-gray-600">
            {isPractitioner ? 'Manage your healing sessions' : 'Your healing journey sessions'}
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-gray-900">{upcomingSessions.length}</div>
                  <div className="text-sm text-gray-600">Upcoming</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <Video className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-gray-900">{activeSessions.length}</div>
                  <div className="text-sm text-gray-600">Active Now</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-gray-900">{completedSessions.length}</div>
                  <div className="text-sm text-gray-600">Completed</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                  <Clock className="w-6 h-6 text-amber-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-gray-900">
                    {completedSessions.reduce((sum, s) => {
                      if (s.actual_start && s.actual_end) {
                        const duration = (new Date(s.actual_end) - new Date(s.actual_start)) / (1000 * 60);
                        return sum + duration;
                      }
                      return sum;
                    }, 0).toFixed(0)}
                  </div>
                  <div className="text-sm text-gray-600">Total Minutes</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="upcoming" className="space-y-6">
          <TabsList className="bg-white p-1 rounded-lg shadow-md">
            <TabsTrigger value="upcoming">
              <Calendar className="w-4 h-4 mr-2" />
              Upcoming ({upcomingSessions.length})
            </TabsTrigger>
            <TabsTrigger value="active">
              <Video className="w-4 h-4 mr-2" />
              Active ({activeSessions.length})
            </TabsTrigger>
            <TabsTrigger value="history">
              <Clock className="w-4 h-4 mr-2" />
              History
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming">
            <UpcomingSessions
              sessions={upcomingSessions}
              user={user}
              onStartSession={setActiveSessionId}
              refetchSessions={refetch}
            />
          </TabsContent>

          <TabsContent value="active">
            <div className="space-y-4">
              {activeSessions.length === 0 ? (
                <Card>
                  <CardContent className="text-center py-16">
                    <Video className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-gray-700 mb-2">No Active Sessions</h3>
                    <p className="text-gray-500">Active sessions will appear here</p>
                  </CardContent>
                </Card>
              ) : (
                activeSessions.map((session) => (
                  <Card key={session.id} className="border-l-4 border-l-green-600">
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold text-lg">{session.service_name}</h3>
                          <p className="text-gray-600">
                            {isPractitioner ? session.client_name : 'With Practitioner'}
                          </p>
                          <p className="text-sm text-green-600 font-medium mt-1">● Live Now</p>
                        </div>
                        <button
                          onClick={() => setActiveSessionId(session.id)}
                          className="px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-full hover:from-green-700 hover:to-emerald-700 transition-all shadow-lg"
                        >
                          Join Session
                        </button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="history">
            <SessionHistory sessions={completedSessions} user={user} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}