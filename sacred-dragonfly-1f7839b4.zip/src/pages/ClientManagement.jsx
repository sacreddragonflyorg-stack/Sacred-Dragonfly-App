import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Search, User, Calendar, FileText, TrendingUp, Mail, Phone, Heart, Clock } from "lucide-react";
import { format } from "date-fns";

export default function ClientManagement() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedClient, setSelectedClient] = useState(null);

  const { data: appointments } = useQuery({
    queryKey: ['all-appointments'],
    queryFn: () => base44.entities.Appointment.list('-appointment_date'),
    initialData: [],
  });

  const { data: progressEntries } = useQuery({
    queryKey: ['all-progress'],
    queryFn: () => base44.entities.ProgressEntry.filter({ is_private: false }),
    initialData: [],
  });

  const { data: liveSessions } = useQuery({
    queryKey: ['all-sessions'],
    queryFn: () => base44.entities.LiveSession.list('-scheduled_start'),
    initialData: [],
  });

  const { data: subscriptions } = useQuery({
    queryKey: ['client-subscriptions'],
    queryFn: () => base44.entities.ClientSubscription.list(),
    initialData: [],
  });

  // Get unique clients from appointments
  const clients = Array.from(
    new Map(
      appointments.map(apt => [
        apt.client_email,
        {
          email: apt.client_email,
          name: apt.client_name,
          phone: apt.phone || 'N/A',
          firstAppointment: appointments
            .filter(a => a.client_email === apt.client_email)
            .sort((a, b) => new Date(a.appointment_date) - new Date(b.appointment_date))[0]?.appointment_date,
          totalSessions: appointments.filter(a => a.client_email === apt.client_email).length,
          completedSessions: appointments.filter(a => a.client_email === apt.client_email && a.status === 'completed').length,
          upcomingSessions: appointments.filter(a => 
            a.client_email === apt.client_email && 
            new Date(a.appointment_date) >= new Date() && 
            a.status !== 'cancelled'
          ).length,
          totalRevenue: appointments
            .filter(a => a.client_email === apt.client_email && a.payment_status === 'paid')
            .reduce((sum, a) => sum + (a.price || 0), 0),
          progressEntries: progressEntries.filter(p => p.created_by === apt.client_email).length,
          hasActiveSubscription: subscriptions.some(s => s.client_email === apt.client_email && s.status === 'active')
        }
      ])
    ).values()
  );

  const filteredClients = clients.filter(c =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const sortedClients = filteredClients.sort((a, b) => 
    new Date(b.firstAppointment) - new Date(a.firstAppointment)
  );

  const getClientAppointments = (email) => 
    appointments.filter(a => a.client_email === email).sort((a, b) => 
      new Date(b.appointment_date) - new Date(a.appointment_date)
    );

  const getClientProgress = (email) =>
    progressEntries.filter(p => p.created_by === email).sort((a, b) =>
      new Date(b.entry_date) - new Date(a.entry_date)
    );

  const getClientSessions = (email) =>
    liveSessions.filter(s => s.client_email === email).sort((a, b) =>
      new Date(b.scheduled_start) - new Date(a.scheduled_start)
    );

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Client Management</h1>
          <p className="text-gray-600">View and manage all your clients in one place</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Clients</p>
                  <p className="text-3xl font-bold text-purple-600">{clients.length}</p>
                </div>
                <User className="w-10 h-10 text-purple-600 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Subscribers</p>
                  <p className="text-3xl font-bold text-green-600">
                    {clients.filter(c => c.hasActiveSubscription).length}
                  </p>
                </div>
                <Heart className="w-10 h-10 text-green-600 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Sessions</p>
                  <p className="text-3xl font-bold text-blue-600">
                    {clients.reduce((sum, c) => sum + c.totalSessions, 0)}
                  </p>
                </div>
                <Calendar className="w-10 h-10 text-blue-600 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Progress Entries</p>
                  <p className="text-3xl font-bold text-amber-600">
                    {progressEntries.length}
                  </p>
                </div>
                <TrendingUp className="w-10 h-10 text-amber-600 opacity-20" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="relative">
              <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search clients by name or email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 text-lg"
              />
            </div>
          </CardContent>
        </Card>

        {/* Clients List */}
        <div className="grid gap-4">
          {sortedClients.map((client) => (
            <Card key={client.email} className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setSelectedClient(client)}>
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-full flex items-center justify-center">
                        <User className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">{client.name}</h3>
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          <span className="flex items-center gap-1">
                            <Mail className="w-4 h-4" />
                            {client.email}
                          </span>
                          <span className="flex items-center gap-1">
                            <Phone className="w-4 h-4" />
                            {client.phone}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                      <div className="bg-blue-50 rounded-lg p-3">
                        <p className="text-xs text-gray-600">Total Sessions</p>
                        <p className="text-2xl font-bold text-blue-600">{client.totalSessions}</p>
                      </div>
                      <div className="bg-green-50 rounded-lg p-3">
                        <p className="text-xs text-gray-600">Completed</p>
                        <p className="text-2xl font-bold text-green-600">{client.completedSessions}</p>
                      </div>
                      <div className="bg-purple-50 rounded-lg p-3">
                        <p className="text-xs text-gray-600">Upcoming</p>
                        <p className="text-2xl font-bold text-purple-600">{client.upcomingSessions}</p>
                      </div>
                      <div className="bg-amber-50 rounded-lg p-3">
                        <p className="text-xs text-gray-600">Progress Entries</p>
                        <p className="text-2xl font-bold text-amber-600">{client.progressEntries}</p>
                      </div>
                      <div className="bg-pink-50 rounded-lg p-3">
                        <p className="text-xs text-gray-600">Revenue</p>
                        <p className="text-2xl font-bold text-pink-600">${client.totalRevenue}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2 ml-4">
                    {client.hasActiveSubscription && (
                      <Badge className="bg-green-100 text-green-800">Active Subscriber</Badge>
                    )}
                    <Badge variant="outline">
                      Member since {format(new Date(client.firstAppointment), 'MMM yyyy')}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Client Details Dialog */}
        {selectedClient && (
          <Dialog open={!!selectedClient} onOpenChange={() => setSelectedClient(null)}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-2xl">{selectedClient.name}</DialogTitle>
              </DialogHeader>

              <Tabs defaultValue="appointments" className="mt-4">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="appointments">Appointments</TabsTrigger>
                  <TabsTrigger value="progress">Progress</TabsTrigger>
                  <TabsTrigger value="sessions">Live Sessions</TabsTrigger>
                </TabsList>

                <TabsContent value="appointments" className="space-y-4">
                  {getClientAppointments(selectedClient.email).map((apt) => (
                    <Card key={apt.id}>
                      <CardContent className="pt-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-semibold">{apt.service_name}</h4>
                            <p className="text-sm text-gray-600 flex items-center gap-2 mt-1">
                              <Calendar className="w-4 h-4" />
                              {format(new Date(apt.appointment_date), 'MMM d, yyyy h:mm a')}
                            </p>
                            {apt.notes && (
                              <p className="text-sm text-gray-700 mt-2">{apt.notes}</p>
                            )}
                          </div>
                          <div className="flex flex-col gap-2">
                            <Badge className={
                              apt.status === 'completed' ? 'bg-green-100 text-green-800' :
                              apt.status === 'confirmed' ? 'bg-blue-100 text-blue-800' :
                              apt.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                              'bg-yellow-100 text-yellow-800'
                            }>
                              {apt.status}
                            </Badge>
                            <Badge variant="outline">${apt.price}</Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </TabsContent>

                <TabsContent value="progress" className="space-y-4">
                  {getClientProgress(selectedClient.email).length === 0 ? (
                    <p className="text-center text-gray-500 py-8">No progress entries shared</p>
                  ) : (
                    getClientProgress(selectedClient.email).map((entry) => (
                      <Card key={entry.id}>
                        <CardContent className="pt-4">
                          <div className="flex justify-between items-start mb-2">
                            <p className="text-sm text-gray-600">
                              {format(new Date(entry.entry_date), 'MMM d, yyyy')}
                            </p>
                            {entry.mood && (
                              <Badge>{entry.mood.replace(/_/g, ' ')}</Badge>
                            )}
                          </div>
                          {entry.journal_entry && (
                            <p className="text-sm text-gray-700 mt-2">{entry.journal_entry}</p>
                          )}
                          {entry.practitioner_feedback && (
                            <div className="mt-3 p-3 bg-purple-50 rounded-lg">
                              <p className="text-xs text-purple-700 font-semibold mb-1">Your Feedback:</p>
                              <p className="text-sm">{entry.practitioner_feedback}</p>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))
                  )}
                </TabsContent>

                <TabsContent value="sessions" className="space-y-4">
                  {getClientSessions(selectedClient.email).map((session) => (
                    <Card key={session.id}>
                      <CardContent className="pt-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-semibold">{session.service_name}</h4>
                            <p className="text-sm text-gray-600 flex items-center gap-2 mt-1">
                              <Clock className="w-4 h-4" />
                              {format(new Date(session.scheduled_start), 'MMM d, yyyy h:mm a')}
                            </p>
                            {session.session_notes && (
                              <p className="text-sm text-gray-700 mt-2">{session.session_notes}</p>
                            )}
                          </div>
                          <Badge className={
                            session.status === 'completed' ? 'bg-green-100 text-green-800' :
                            session.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                            'bg-gray-100 text-gray-800'
                          }>
                            {session.status}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </TabsContent>
              </Tabs>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  );
}