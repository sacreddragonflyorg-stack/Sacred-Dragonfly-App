import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, History, Plus } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

import SpreadSelector from "../components/tarot/SpreadSelector";
import CardSpread from "../components/tarot/CardSpread";
import ReadingResult from "../components/tarot/ReadingResult";
import ReadingHistory from "../components/tarot/ReadingHistory";

export default function Tarot() {
  const [user, setUser] = useState(null);
  const [currentView, setCurrentView] = useState('welcome'); // welcome, spread-select, reading, result, history
  const [selectedSpread, setSelectedSpread] = useState(null);
  const [currentReading, setCurrentReading] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  const { data: readings, refetch: refetchReadings } = useQuery({
    queryKey: ['tarot-readings', user?.email],
    queryFn: () => {
      if (!user) return [];
      return base44.entities.TarotReading.filter({ created_by: user.email }, '-created_date');
    },
    enabled: !!user,
    initialData: [],
  });

  const handleStartNewReading = () => {
    setCurrentView('spread-select');
    setSelectedSpread(null);
    setCurrentReading(null);
  };

  const handleSpreadSelected = (spread) => {
    setSelectedSpread(spread);
    setCurrentView('reading');
  };

  const handleReadingComplete = (reading) => {
    setCurrentReading(reading);
    setCurrentView('result');
    refetchReadings();
  };

  const handleViewHistory = () => {
    setCurrentView('history');
  };

  const handleBackToWelcome = () => {
    setCurrentView('welcome');
    setSelectedSpread(null);
    setCurrentReading(null);
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12 relative overflow-hidden">
      {/* Mystical Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 opacity-95"></div>
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-pink-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse" style={{animationDelay: '2s'}}></div>
        <div className="absolute bottom-1/4 left-1/3 w-96 h-96 bg-indigo-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse" style={{animationDelay: '4s'}}></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full mb-6 border border-white/20"
          >
            <Sparkles className="w-4 h-4 text-purple-300" />
            <span className="text-sm font-medium text-purple-200">AI-Powered Tarot Guidance</span>
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-6xl font-bold text-white mb-4"
          >
            Divine <span className="bg-gradient-to-r from-purple-300 to-pink-300 bg-clip-text text-transparent">Tarot</span> Readings
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-purple-200"
          >
            Seek guidance from the ancient wisdom of the cards
          </motion.p>
        </div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="flex justify-center gap-4 mb-12"
        >
          <Button
            onClick={handleStartNewReading}
            size="lg"
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full shadow-2xl"
          >
            <Plus className="w-5 h-5 mr-2" />
            New Reading
          </Button>
          <Button
            onClick={handleViewHistory}
            size="lg"
            variant="outline"
            className="border-2 border-white/30 text-white hover:bg-white/10 rounded-full backdrop-blur-sm"
          >
            <History className="w-5 h-5 mr-2" />
            Past Readings
          </Button>
        </motion.div>

        {/* Main Content */}
        <AnimatePresence mode="wait">
          {currentView === 'welcome' && (
            <motion.div
              key="welcome"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
            >
              <WelcomeView onStartReading={handleStartNewReading} recentReadings={readings.slice(0, 3)} />
            </motion.div>
          )}

          {currentView === 'spread-select' && (
            <motion.div
              key="spread-select"
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
            >
              <SpreadSelector
                onSelectSpread={handleSpreadSelected}
                onBack={handleBackToWelcome}
              />
            </motion.div>
          )}

          {currentView === 'reading' && selectedSpread && (
            <motion.div
              key="reading"
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
            >
              <CardSpread
                spread={selectedSpread}
                user={user}
                onReadingComplete={handleReadingComplete}
                onBack={() => setCurrentView('spread-select')}
              />
            </motion.div>
          )}

          {currentView === 'result' && currentReading && (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
            >
              <ReadingResult
                reading={currentReading}
                onNewReading={handleStartNewReading}
                onBackToHome={handleBackToWelcome}
                refetchReadings={refetchReadings}
              />
            </motion.div>
          )}

          {currentView === 'history' && (
            <motion.div
              key="history"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
            >
              <ReadingHistory
                readings={readings}
                onBack={handleBackToWelcome}
                onViewReading={(reading) => {
                  setCurrentReading(reading);
                  setCurrentView('result');
                }}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

// Welcome View Component
function WelcomeView({ onStartReading, recentReadings }) {
  return (
    <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
      <Card className="md:col-span-3 bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle className="text-2xl">Welcome to Divine Tarot</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-purple-200 leading-relaxed mb-4">
            The tarot is a sacred tool for divination and self-reflection. Each card carries deep symbolism 
            and meaning that can provide guidance on your life's journey. Our AI-powered readings combine 
            traditional tarot wisdom with modern insights to offer you personalized guidance.
          </p>
          <p className="text-purple-200 leading-relaxed">
            Choose a spread that resonates with your question, draw your cards, and receive a detailed 
            interpretation. You can ask follow-up questions to dive deeper into the reading.
          </p>
        </CardContent>
      </Card>

      {recentReadings.length > 0 && (
        <Card className="md:col-span-3 bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <History className="w-5 h-5" />
              Recent Readings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {recentReadings.map((reading) => (
                <div key={reading.id} className="p-3 bg-white/5 rounded-lg">
                  <div className="font-medium">{reading.spread_type.replace(/_/g, ' ').toUpperCase()}</div>
                  <div className="text-sm text-purple-200 line-clamp-1">{reading.user_question}</div>
                  <div className="text-xs text-purple-300 mt-1">
                    {new Date(reading.created_date).toLocaleDateString()}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}