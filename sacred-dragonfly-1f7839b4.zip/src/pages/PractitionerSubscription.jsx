import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, X, Crown, Zap, Sparkles, TrendingUp, Shield, Code } from "lucide-react";
import { toast } from "sonner";
import StripePaymentForm from "../components/payment/StripePaymentForm";

const SUBSCRIPTION_TIERS = {
  free: {
    name: "Free",
    price: 0,
    icon: Sparkles,
    color: "from-gray-400 to-gray-600",
    features: {
      max_services: 2,
      advanced_analytics: false,
      priority_support: false,
      enhanced_profile: false,
      custom_branding: false,
      api_access: false
    },
    benefits: [
      "Up to 2 services",
      "Basic profile",
      "Standard support",
      "Basic analytics"
    ]
  },
  basic: {
    name: "Basic",
    price: 29,
    icon: Zap,
    color: "from-blue-500 to-indigo-600",
    features: {
      max_services: 10,
      advanced_analytics: true,
      priority_support: false,
      enhanced_profile: true,
      custom_branding: false,
      api_access: false
    },
    benefits: [
      "Up to 10 services",
      "Enhanced profile customization",
      "Advanced analytics & insights",
      "Priority email support",
      "Custom service descriptions",
      "Client management tools"
    ]
  },
  premium: {
    name: "Premium",
    price: 79,
    icon: Crown,
    color: "from-purple-500 to-pink-600",
    features: {
      max_services: 999,
      advanced_analytics: true,
      priority_support: true,
      enhanced_profile: true,
      custom_branding: true,
      api_access: true
    },
    benefits: [
      "Unlimited services",
      "Full profile customization",
      "Advanced analytics & reporting",
      "Priority phone & email support",
      "Custom branding & colors",
      "API access for integrations",
      "White-label options",
      "Dedicated account manager"
    ]
  }
};

export default function PractitionerSubscription() {
  const [user, setUser] = useState(null);
  const [selectedTier, setSelectedTier] = useState(null);
  const [showPayment, setShowPayment] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then((u) => {
      if (u.role !== 'admin') {
        window.location.href = '/';
      }
      setUser(u);
    }).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  const { data: subscription } = useQuery({
    queryKey: ['practitioner-subscription', user?.email],
    queryFn: () => {
      if (!user) return null;
      // Grant free premium access to Carol L Andrews
      if (user.email === 'carol.andrews@example.com') {
        return {
          plan_tier: 'premium',
          status: 'active',
          features: SUBSCRIPTION_TIERS.premium.features,
          monthly_price: 0,
          current_period_start: new Date().toISOString(),
          current_period_end: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString() // 1 year
        };
      }
      return base44.entities.PractitionerSubscription.filter({ practitioner_email: user.email })
        .then(subs => subs[0] || null);
    },
    enabled: !!user,
  });

  const { data: services = [] } = useQuery({
    queryKey: ['services'],
    queryFn: () => base44.entities.Service.list(),
    enabled: !!user,
  });

  const createSubscriptionMutation = useMutation({
    mutationFn: async (tier) => {
      const tierConfig = SUBSCRIPTION_TIERS[tier];
      return base44.entities.PractitionerSubscription.create({
        practitioner_email: user.email,
        plan_tier: tier,
        status: tier === 'free' ? 'active' : 'trialing',
        monthly_price: tierConfig.price,
        features: tierConfig.features,
        current_period_start: new Date().toISOString(),
        current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        trial_end: tier !== 'free' ? new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString() : null
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['practitioner-subscription']);
      toast.success("Subscription activated!");
      setShowPayment(false);
    }
  });

  const updateSubscriptionMutation = useMutation({
    mutationFn: async ({ tier, paymentData }) => {
      const tierConfig = SUBSCRIPTION_TIERS[tier];
      return base44.entities.PractitionerSubscription.update(subscription.id, {
        plan_tier: tier,
        status: 'active',
        monthly_price: tierConfig.price,
        features: tierConfig.features,
        stripe_subscription_id: paymentData?.subscription_id || subscription.stripe_subscription_id,
        stripe_customer_id: paymentData?.customer_id || subscription.stripe_customer_id,
        current_period_start: new Date().toISOString(),
        current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['practitioner-subscription']);
      toast.success("Subscription updated!");
      setShowPayment(false);
      setSelectedTier(null);
    }
  });

  const cancelSubscriptionMutation = useMutation({
    mutationFn: async () => {
      return base44.entities.PractitionerSubscription.update(subscription.id, {
        cancel_at_period_end: true
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['practitioner-subscription']);
      toast.success("Subscription will cancel at period end");
    }
  });

  const handleSelectTier = (tier) => {
    if (!subscription) {
      if (tier === 'free') {
        createSubscriptionMutation.mutate(tier);
      } else {
        setSelectedTier(tier);
        setShowPayment(true);
      }
    } else {
      if (tier === 'free') {
        updateSubscriptionMutation.mutate({ tier });
      } else {
        setSelectedTier(tier);
        setShowPayment(true);
      }
    }
  };

  const handlePaymentSuccess = (paymentData) => {
    if (!subscription) {
      createSubscriptionMutation.mutate(selectedTier);
    } else {
      updateSubscriptionMutation.mutate({ tier: selectedTier, paymentData });
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (showPayment && selectedTier) {
    const tierConfig = SUBSCRIPTION_TIERS[selectedTier];
    return (
      <div className="min-h-screen py-12">
        <div className="max-w-2xl mx-auto px-4">
          <h1 className="text-3xl font-bold mb-8">Complete Your Subscription</h1>
          <StripePaymentForm
            amount={tierConfig.price}
            description={`${tierConfig.name} Plan - Monthly Subscription`}
            metadata={{
              subscription_tier: selectedTier,
              practitioner_email: user.email,
              type: 'practitioner_subscription'
            }}
            onSuccess={handlePaymentSuccess}
            onCancel={() => {
              setShowPayment(false);
              setSelectedTier(null);
            }}
          />
        </div>
      </div>
    );
  }

  const currentTier = subscription?.plan_tier || 'free';
  const currentConfig = SUBSCRIPTION_TIERS[currentTier];
  const servicesCount = services.length;

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Practitioner <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Subscription Plans</span>
          </h1>
          <p className="text-lg text-gray-600">Choose the plan that fits your practice needs</p>
        </div>

        {/* Current Plan Status */}
        {subscription && (
          <Card className="mb-8 border-2 border-purple-200 bg-purple-50">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 bg-gradient-to-br ${currentConfig.color} rounded-full flex items-center justify-center`}>
                    {React.createElement(currentConfig.icon, { className: "w-6 h-6 text-white" })}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">
                      Current Plan: {currentConfig.name}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {servicesCount} / {subscription.features.max_services === 999 ? '∞' : subscription.features.max_services} services used
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-gray-900">${currentConfig.price}<span className="text-sm font-normal">/month</span></p>
                  {subscription.status === 'trialing' && subscription.trial_end && (
                    <Badge className="mt-2 bg-green-600">14-Day Free Trial</Badge>
                  )}
                  {subscription.cancel_at_period_end && (
                    <Badge className="mt-2 bg-red-600">Canceling at period end</Badge>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {Object.entries(SUBSCRIPTION_TIERS).map(([tier, config]) => {
            const Icon = config.icon;
            const isCurrentPlan = currentTier === tier;
            const isUpgrade = ['free', 'basic', 'premium'].indexOf(tier) > ['free', 'basic', 'premium'].indexOf(currentTier);
            
            return (
              <Card 
                key={tier} 
                className={`relative overflow-hidden transition-all duration-300 hover:shadow-2xl ${
                  isCurrentPlan ? 'border-4 border-purple-600 shadow-xl' : 'border-2'
                } ${tier === 'premium' ? 'transform md:scale-105' : ''}`}
              >
                {tier === 'premium' && (
                  <div className="absolute top-0 right-0 bg-gradient-to-br from-purple-600 to-pink-600 text-white text-xs font-bold px-3 py-1 rounded-bl-lg">
                    POPULAR
                  </div>
                )}
                
                <CardHeader className="text-center pb-8">
                  <div className={`w-16 h-16 mx-auto mb-4 bg-gradient-to-br ${config.color} rounded-2xl flex items-center justify-center`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl mb-2">{config.name}</CardTitle>
                  <div className="text-4xl font-bold text-gray-900">
                    ${config.price}
                    <span className="text-lg font-normal text-gray-600">/month</span>
                  </div>
                </CardHeader>

                <CardContent>
                  <ul className="space-y-3 mb-8">
                    {config.benefits.map((benefit, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                        <span className="text-sm text-gray-700">{benefit}</span>
                      </li>
                    ))}
                  </ul>

                  <Button
                    onClick={() => handleSelectTier(tier)}
                    disabled={isCurrentPlan || createSubscriptionMutation.isPending || updateSubscriptionMutation.isPending}
                    className={`w-full ${
                      tier === 'premium' 
                        ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700' 
                        : tier === 'basic'
                        ? 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700'
                        : 'bg-gray-600 hover:bg-gray-700'
                    }`}
                  >
                    {isCurrentPlan ? 'Current Plan' : isUpgrade ? 'Upgrade' : 'Downgrade'}
                  </Button>

                  {tier !== 'free' && !subscription && (
                    <p className="text-xs text-center text-gray-500 mt-2">14-day free trial included</p>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Feature Comparison Table */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Feature Comparison</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b-2">
                    <th className="text-left py-4 px-4 font-semibold">Feature</th>
                    {Object.entries(SUBSCRIPTION_TIERS).map(([tier, config]) => (
                      <th key={tier} className="text-center py-4 px-4 font-semibold">{config.name}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b">
                    <td className="py-4 px-4">Maximum Services</td>
                    {Object.entries(SUBSCRIPTION_TIERS).map(([tier, config]) => (
                      <td key={tier} className="text-center py-4 px-4">
                        {config.features.max_services === 999 ? 'Unlimited' : config.features.max_services}
                      </td>
                    ))}
                  </tr>
                  <tr className="border-b">
                    <td className="py-4 px-4">Advanced Analytics</td>
                    {Object.entries(SUBSCRIPTION_TIERS).map(([tier, config]) => (
                      <td key={tier} className="text-center py-4 px-4">
                        {config.features.advanced_analytics ? (
                          <CheckCircle2 className="w-5 h-5 text-green-600 mx-auto" />
                        ) : (
                          <X className="w-5 h-5 text-gray-400 mx-auto" />
                        )}
                      </td>
                    ))}
                  </tr>
                  <tr className="border-b">
                    <td className="py-4 px-4">Priority Support</td>
                    {Object.entries(SUBSCRIPTION_TIERS).map(([tier, config]) => (
                      <td key={tier} className="text-center py-4 px-4">
                        {config.features.priority_support ? (
                          <CheckCircle2 className="w-5 h-5 text-green-600 mx-auto" />
                        ) : (
                          <X className="w-5 h-5 text-gray-400 mx-auto" />
                        )}
                      </td>
                    ))}
                  </tr>
                  <tr className="border-b">
                    <td className="py-4 px-4">Enhanced Profile</td>
                    {Object.entries(SUBSCRIPTION_TIERS).map(([tier, config]) => (
                      <td key={tier} className="text-center py-4 px-4">
                        {config.features.enhanced_profile ? (
                          <CheckCircle2 className="w-5 h-5 text-green-600 mx-auto" />
                        ) : (
                          <X className="w-5 h-5 text-gray-400 mx-auto" />
                        )}
                      </td>
                    ))}
                  </tr>
                  <tr className="border-b">
                    <td className="py-4 px-4">Custom Branding</td>
                    {Object.entries(SUBSCRIPTION_TIERS).map(([tier, config]) => (
                      <td key={tier} className="text-center py-4 px-4">
                        {config.features.custom_branding ? (
                          <CheckCircle2 className="w-5 h-5 text-green-600 mx-auto" />
                        ) : (
                          <X className="w-5 h-5 text-gray-400 mx-auto" />
                        )}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="py-4 px-4">API Access</td>
                    {Object.entries(SUBSCRIPTION_TIERS).map(([tier, config]) => (
                      <td key={tier} className="text-center py-4 px-4">
                        {config.features.api_access ? (
                          <CheckCircle2 className="w-5 h-5 text-green-600 mx-auto" />
                        ) : (
                          <X className="w-5 h-5 text-gray-400 mx-auto" />
                        )}
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Cancel Subscription */}
        {subscription && currentTier !== 'free' && !subscription.cancel_at_period_end && (
          <div className="mt-8 text-center">
            <Button
              variant="outline"
              onClick={() => {
                if (confirm('Are you sure you want to cancel your subscription? You will retain access until the end of your billing period.')) {
                  cancelSubscriptionMutation.mutate();
                }
              }}
              disabled={cancelSubscriptionMutation.isPending}
              className="text-red-600 border-red-600 hover:bg-red-50"
            >
              Cancel Subscription
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}