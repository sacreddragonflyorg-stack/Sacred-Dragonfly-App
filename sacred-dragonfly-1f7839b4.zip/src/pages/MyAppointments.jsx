import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Mail, Phone, FileText, Heart, Video, ExternalLink } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

const statusColors = {
  pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
  confirmed: "bg-blue-100 text-blue-800 border-blue-200",
  completed: "bg-green-100 text-green-800 border-green-200",
  cancelled: "bg-red-100 text-red-800 border-red-200"
};

export default function MyAppointments() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  const { data: appointments, isLoading } = useQuery({
    queryKey: ['my-appointments', user?.email],
    queryFn: () => {
      if (!user) return [];
      return base44.entities.Appointment.filter({ client_email: user.email }, '-appointment_date');
    },
    enabled: !!user,
    initialData: [],
  });

  const upcomingAppointments = appointments.filter(
    apt => new Date(apt.appointment_date) >= new Date() && apt.status !== 'cancelled'
  );
  
  const pastAppointments = appointments.filter(
    apt => new Date(apt.appointment_date) < new Date() || apt.status === 'cancelled' || apt.status === 'completed'
  );

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your sessions...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            My <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Healing Sessions</span>
          </h1>
          <p className="text-lg text-gray-600">
            View and track your distance healing journey
          </p>
        </div>

        {isLoading ? (
          <div className="space-y-6">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-8 w-2/3 mb-2" />
                  <Skeleton className="h-4 w-1/2" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-20 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : appointments.length === 0 ? (
          <Card className="text-center py-16 border-dashed border-2">
            <CardContent>
              <Calendar className="w-16 h-16 text-purple-300 mx-auto mb-4" />
              <h3 className="text-2xl font-semibold text-gray-700 mb-2">No Sessions Yet</h3>
              <p className="text-gray-500 mb-6">Start your healing journey by requesting your first session</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-12">
            {/* Upcoming Appointments */}
            {upcomingAppointments.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <Calendar className="w-6 h-6 text-purple-600" />
                  Upcoming Sessions
                </h2>
                <div className="grid gap-6">
                  {upcomingAppointments.map((appointment) => (
                    <Card key={appointment.id} className="border-l-4 border-l-purple-600 hover:shadow-xl transition-shadow duration-300">
                      <CardHeader>
                        <div className="flex flex-wrap items-start justify-between gap-4">
                          <div>
                            <CardTitle className="text-2xl mb-2">{appointment.service_name}</CardTitle>
                            <div className="flex flex-wrap gap-2">
                              <Badge className={`${statusColors[appointment.status]} border`}>
                                {appointment.status.toUpperCase()}
                              </Badge>
                              <Badge className="bg-purple-100 text-purple-800">
                                Distance Healing
                              </Badge>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 text-purple-600">
                            <Heart className="w-5 h-5" />
                            <span className="text-sm font-medium">Energy Exchange</span>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid md:grid-cols-2 gap-6">
                          <div className="space-y-3">
                            <div className="flex items-center gap-3 text-gray-700">
                              <Calendar className="w-5 h-5 text-purple-600" />
                              <span className="font-medium">
                                {format(new Date(appointment.appointment_date), 'EEEE, MMMM d, yyyy')}
                              </span>
                            </div>
                            <div className="flex items-center gap-3 text-gray-700">
                              <Clock className="w-5 h-5 text-purple-600" />
                              <span className="font-medium">
                                {format(new Date(appointment.appointment_date), 'h:mm a')}
                              </span>
                            </div>
                            <div className="flex items-center gap-3 text-gray-700">
                              <Mail className="w-5 h-5 text-purple-600" />
                              <span>{appointment.client_email}</span>
                            </div>
                            {appointment.phone && (
                              <div className="flex items-center gap-3 text-gray-700">
                                <Phone className="w-5 h-5 text-purple-600" />
                                <span>{appointment.phone}</span>
                              </div>
                            )}
                          </div>
                          <div>
                            {appointment.notes && (
                              <div className="bg-purple-50 rounded-lg p-4">
                                <div className="flex items-start gap-2 mb-2">
                                  <FileText className="w-4 h-4 text-purple-600 mt-0.5" />
                                  <span className="text-sm font-medium text-purple-900">Session Details:</span>
                                </div>
                                <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap">{appointment.notes}</p>
                              </div>
                            )}
                            {appointment.status === 'confirmed' && (
                              <div className="mt-3 p-3 bg-green-50 rounded-lg border border-green-200">
                                <p className="text-sm text-green-900 font-medium">
                                  ✓ Confirmed! You will receive connection details via email before your session.
                                </p>
                              </div>
                            )}
                            {appointment.status === 'pending' && (
                              <div className="mt-3 p-3 bg-amber-50 rounded-lg border border-amber-200">
                                <p className="text-sm text-amber-900">
                                  Awaiting confirmation. You'll receive an email with session details and energy exchange arrangements.
                                </p>
                              </div>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {/* Past Appointments */}
            {pastAppointments.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <Clock className="w-6 h-6 text-gray-600" />
                  Past Sessions
                </h2>
                <div className="grid gap-6">
                  {pastAppointments.map((appointment) => (
                    <Card key={appointment.id} className="opacity-75 hover:opacity-100 transition-opacity">
                      <CardHeader>
                        <div className="flex flex-wrap items-start justify-between gap-4">
                          <div>
                            <CardTitle className="text-xl mb-2">{appointment.service_name}</CardTitle>
                            <div className="flex flex-wrap gap-2">
                              <Badge className={`${statusColors[appointment.status]} border`}>
                                {appointment.status.toUpperCase()}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          <span>{format(new Date(appointment.appointment_date), 'MMM d, yyyy')}</span>
                          <span>•</span>
                          <span>{format(new Date(appointment.appointment_date), 'h:mm a')}</span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}