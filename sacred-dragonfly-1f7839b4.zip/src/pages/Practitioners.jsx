import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Star, Award, Calendar, Users, Filter, Play } from "lucide-react";

export default function Practitioners() {
  const [searchQuery, setSearchQuery] = useState("");
  const [specialtyFilter, setSpecialtyFilter] = useState("all");
  const [serviceFilter, setServiceFilter] = useState("all");

  const { data: practitioners = [], isLoading } = useQuery({
    queryKey: ['practitioners'],
    queryFn: () => base44.entities.Practitioner.filter({ is_active: true }),
  });

  const { data: services = [] } = useQuery({
    queryKey: ['services'],
    queryFn: () => base44.entities.Service.filter({ is_active: true }),
  });

  // Get unique specialties
  const allSpecialties = [...new Set(practitioners.flatMap(p => p.specialties || []))];

  // Filter practitioners
  const filteredPractitioners = practitioners.filter(p => {
    const matchesSearch = searchQuery === "" ||
      p.display_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.bio?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.specialties?.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesSpecialty = specialtyFilter === "all" ||
      p.specialties?.includes(specialtyFilter);

    const matchesService = serviceFilter === "all" ||
      p.service_ids?.includes(serviceFilter);

    return matchesSearch && matchesSpecialty && matchesService;
  });

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full mb-6 border border-purple-200">
            <Users className="w-4 h-4 text-purple-600" />
            <span className="text-sm font-medium text-purple-900">Our Healers</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Meet Our <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Practitioners</span>
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Connect with experienced healers who specialize in various modalities
          </p>
        </div>

        {/* Filters */}
        <Card className="mb-8 bg-white/80 backdrop-blur-sm">
          <CardContent className="pt-6">
            <div className="grid md:grid-cols-4 gap-4">
              <div className="md:col-span-2 relative">
                <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                <Input
                  placeholder="Search by name, specialty, or bio..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={specialtyFilter} onValueChange={setSpecialtyFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Specialty" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Specialties</SelectItem>
                  {allSpecialties.map(s => (
                    <SelectItem key={s} value={s}>{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={serviceFilter} onValueChange={setServiceFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Service" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Services</SelectItem>
                  {services.map(s => (
                    <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Practitioners Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map(i => (
              <Card key={i} className="animate-pulse">
                <div className="h-64 bg-gray-200 rounded-t-lg" />
                <CardContent className="pt-6 space-y-3">
                  <div className="h-6 bg-gray-200 rounded w-3/4" />
                  <div className="h-4 bg-gray-200 rounded w-1/2" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredPractitioners.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600">No practitioners found matching your criteria</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPractitioners.map(practitioner => (
              <PractitionerCard key={practitioner.id} practitioner={practitioner} services={services} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function PractitionerCard({ practitioner, services }) {
  const practitionerServices = services.filter(s => practitioner.service_ids?.includes(s.id));

  return (
    <Card className="overflow-hidden hover:shadow-2xl transition-all duration-300 group">
      {/* Photo */}
      <div className="relative h-64 overflow-hidden">
        {practitioner.photo_url ? (
          <img
            src={practitioner.photo_url}
            alt={practitioner.display_name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center">
            <span className="text-6xl text-white font-bold">
              {practitioner.display_name?.charAt(0) || 'P'}
            </span>
          </div>
        )}
        {practitioner.video_intro_url && (
          <div className="absolute bottom-3 right-3">
            <Badge className="bg-black/70 hover:bg-black/80 flex items-center gap-1">
              <Play className="w-3 h-3" /> Video Intro
            </Badge>
          </div>
        )}
        {practitioner.is_featured && (
          <div className="absolute top-3 left-3">
            <Badge className="bg-amber-500">Featured</Badge>
          </div>
        )}
      </div>

      <CardContent className="pt-6 space-y-4">
        {/* Name & Title */}
        <div>
          <h3 className="text-xl font-bold text-gray-900">{practitioner.display_name}</h3>
          <p className="text-purple-600 font-medium">{practitioner.title}</p>
        </div>

        {/* Stats */}
        <div className="flex items-center gap-4 text-sm">
          {practitioner.average_rating && (
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
              <span className="font-semibold">{practitioner.average_rating.toFixed(1)}</span>
              <span className="text-gray-500">({practitioner.total_reviews})</span>
            </div>
          )}
          {practitioner.years_experience && (
            <div className="flex items-center gap-1 text-gray-600">
              <Award className="w-4 h-4" />
              <span>{practitioner.years_experience}+ years</span>
            </div>
          )}
        </div>

        {/* Bio */}
        <p className="text-gray-600 text-sm line-clamp-2">{practitioner.bio}</p>

        {/* Specialties */}
        {practitioner.specialties?.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {practitioner.specialties.slice(0, 3).map(specialty => (
              <Badge key={specialty} variant="outline" className="text-xs">
                {specialty}
              </Badge>
            ))}
            {practitioner.specialties.length > 3 && (
              <Badge variant="outline" className="text-xs">+{practitioner.specialties.length - 3}</Badge>
            )}
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-2 pt-2">
          <Link 
            to={`${createPageUrl("PractitionerDetail")}?id=${practitioner.id}&name=${encodeURIComponent(practitioner.display_name?.toLowerCase().replace(/\s+/g, '-'))}`} 
            className="flex-1"
          >
            <Button variant="outline" className="w-full">View Profile</Button>
          </Link>
          <Link to={`${createPageUrl("Booking")}?practitioner=${practitioner.id}`} className="flex-1">
            <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600">
              <Calendar className="w-4 h-4 mr-2" /> Book
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}