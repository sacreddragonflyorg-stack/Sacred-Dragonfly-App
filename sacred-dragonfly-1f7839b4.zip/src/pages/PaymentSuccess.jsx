import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Calendar, Mail, Loader2, Home, ArrowRight } from "lucide-react";
import { format } from "date-fns";

export default function PaymentSuccess() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [appointment, setAppointment] = useState(null);
  const [paymentDetails, setPaymentDetails] = useState(null);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const appointmentId = urlParams.get('appointment_id');
    const paymentIntentId = urlParams.get('payment_intent_id');

    if (!appointmentId || !paymentIntentId) {
      navigate(createPageUrl("Home"));
      return;
    }

    loadPaymentDetails(appointmentId, paymentIntentId);
  }, []);

  const loadPaymentDetails = async (appointmentId, paymentIntentId) => {
    try {
      // Load appointment details
      const appointments = await base44.entities.Appointment.list();
      const apt = appointments.find(a => a.id === appointmentId);
      
      if (!apt) {
        throw new Error("Appointment not found");
      }

      setAppointment(apt);
      setPaymentDetails({ payment_intent_id: paymentIntentId });

      // Send confirmation email
      await base44.integrations.Core.SendEmail({
        to: apt.client_email,
        subject: `Payment Confirmed - ${apt.service_name}`,
        body: `
Hello ${apt.client_name},

Thank you for your payment! Your healing session has been confirmed.

Session Details:
🌟 Service: ${apt.service_name}
📅 Date: ${format(new Date(apt.appointment_date), 'EEEE, MMMM d, yyyy')}
⏰ Time: ${format(new Date(apt.appointment_date), 'h:mm a')}
💰 Amount Paid: $${apt.price}

Payment ID: ${paymentIntentId}

You will receive a reminder before your session with connection details.

We're looking forward to supporting you on your healing journey!

Blessings and light,
Sacred Healing Team
        `.trim()
      });

    } catch (error) {
      console.error("Error loading payment details:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
        <div className="text-center">
          <Loader2 className="w-16 h-16 animate-spin text-purple-600 mx-auto mb-4" />
          <p className="text-gray-600">Confirming your payment...</p>
        </div>
      </div>
    );
  }

  if (!appointment) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50 p-4">
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <p className="text-gray-600 mb-4">Unable to load payment details</p>
            <Link to={createPageUrl("Home")}>
              <Button>Return Home</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Success Message */}
        <Card className="mb-8 border-2 border-green-400 shadow-2xl overflow-hidden">
          <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-8 text-white text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-white rounded-full mb-4">
              <CheckCircle2 className="w-12 h-12 text-green-600" />
            </div>
            <h1 className="text-3xl font-bold mb-2">Payment Successful!</h1>
            <p className="text-green-100 text-lg">Your healing session is confirmed</p>
          </div>
        </Card>

        {/* Session Details */}
        <Card className="mb-8 shadow-xl">
          <CardHeader className="bg-purple-50">
            <CardTitle className="text-2xl">Your Healing Session</CardTitle>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <div className="grid gap-4">
              <div className="flex items-start gap-3 p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg">
                <Calendar className="w-6 h-6 text-purple-600 mt-1 flex-shrink-0" />
                <div className="flex-1">
                  <p className="text-sm text-gray-600 mb-1">Scheduled For</p>
                  <p className="text-xl font-bold text-gray-900">
                    {format(new Date(appointment.appointment_date), 'EEEE, MMMM d, yyyy')}
                  </p>
                  <p className="text-lg text-purple-600 font-semibold">
                    {format(new Date(appointment.appointment_date), 'h:mm a')}
                  </p>
                </div>
              </div>

              <div className="p-4 bg-purple-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Service</p>
                <p className="text-lg font-semibold text-gray-900">{appointment.service_name}</p>
              </div>

              <div className="p-4 bg-purple-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Amount Paid</p>
                <p className="text-2xl font-bold text-green-700">${appointment.price.toFixed(2)}</p>
              </div>

              {paymentDetails && (
                <div className="p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-600 mb-1">Payment ID</p>
                  <p className="text-xs font-mono text-gray-700">{paymentDetails.payment_intent_id}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* What's Next */}
        <Card className="mb-8 shadow-xl">
          <CardHeader>
            <CardTitle>What Happens Next?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Mail className="w-4 h-4 text-purple-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Confirmation Email Sent</p>
                  <p className="text-sm text-gray-600">
                    Check your inbox at <strong>{appointment.client_email}</strong> for your booking confirmation and receipt.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Calendar className="w-4 h-4 text-purple-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Session Reminder</p>
                  <p className="text-sm text-gray-600">
                    You'll receive a reminder 24 hours before your session with connection details and preparation instructions.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <CheckCircle2 className="w-4 h-4 text-purple-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Prepare for Your Session</p>
                  <p className="text-sm text-gray-600">
                    Find a quiet, comfortable space where you won't be disturbed during your healing session.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="grid md:grid-cols-2 gap-4">
          <Link to={createPageUrl("MyAppointments")}>
            <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700" size="lg">
              <Calendar className="w-5 h-5 mr-2" />
              View My Sessions
            </Button>
          </Link>
          <Link to={createPageUrl("Home")}>
            <Button variant="outline" className="w-full" size="lg">
              <Home className="w-5 h-5 mr-2" />
              Return Home
            </Button>
          </Link>
        </div>

        {/* Support */}
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-600">
            Questions about your session? Contact us at{" "}
            <a href="mailto:info@sacredhealing.com" className="text-purple-600 hover:underline">
              info@sacredhealing.com
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}