import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Star, Award, Calendar, Clock, CheckCircle2, Play, 
  MapPin, Mail, Users, Heart, Sparkles, ArrowRight, Quote
} from "lucide-react";
import { format } from "date-fns";

export default function PractitionerDetail() {
  const [showVideo, setShowVideo] = useState(false);
  
  const urlParams = new URLSearchParams(window.location.search);
  const practitionerId = urlParams.get('id');

  const { data: practitioner, isLoading } = useQuery({
    queryKey: ['practitioner', practitionerId],
    queryFn: () => base44.entities.Practitioner.filter({ id: practitionerId }).then(r => r[0]),
    enabled: !!practitionerId,
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ['practitioner-reviews', practitionerId],
    queryFn: () => base44.entities.PractitionerReview.filter({ practitioner_id: practitionerId, is_public: true }, '-created_date'),
    enabled: !!practitionerId,
  });

  const { data: services = [] } = useQuery({
    queryKey: ['practitioner-services', practitioner?.service_ids],
    queryFn: () => base44.entities.Service.filter({ is_active: true }),
    enabled: !!practitioner,
  });

  const practitionerServices = services.filter(s => practitioner?.service_ids?.includes(s.id));

  // SEO & Schema Markup
  useEffect(() => {
    if (practitioner) {
      document.title = `${practitioner.display_name} - ${practitioner.title} | Sacred Healing`;

      const descContent = `Book a session with ${practitioner.display_name}, ${practitioner.title}. Specialties: ${practitioner.specialties?.join(', ')}. ${practitioner.bio?.substring(0, 155)}...`;
      let metaDesc = document.querySelector('meta[name="description"]');
      if (!metaDesc) {
        metaDesc = document.createElement('meta');
        metaDesc.name = 'description';
        document.head.appendChild(metaDesc);
      }
      metaDesc.setAttribute('content', descContent);

      const schema = {
        "@context": "https://schema.org",
        "@type": ["Person", "Physician"],
        "name": practitioner.display_name,
        "jobTitle": practitioner.title,
        "description": practitioner.bio,
        "image": practitioner.photo_url,
        "url": window.location.href,
        "knowsAbout": practitioner.specialties,
        "hasCredential": practitioner.certifications?.map(c => ({
            "@type": "EducationalOccupationalCredential",
            "credentialCategory": "certification",
            "name": c.name,
            "recognizedBy": c.issuer
        })),
        "makesOffer": practitionerServices.map(s => ({
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": s.name,
            "description": s.description
          },
          "price": s.price,
          "priceCurrency": "USD",
          "availability": "https://schema.org/InStock"
        })),
        "aggregateRating": practitioner.average_rating ? {
            "@type": "AggregateRating",
            "ratingValue": practitioner.average_rating,
            "reviewCount": practitioner.total_reviews
        } : undefined
      };

      let script = document.querySelector('#practitioner-schema');
      if (!script) {
        script = document.createElement('script');
        script.id = 'practitioner-schema';
        script.type = 'application/ld+json';
        document.head.appendChild(script);
      }
      script.text = JSON.stringify(schema);

      return () => {
        document.title = "Sacred Healing"; 
        if (script) script.remove();
      };
    }
  }, [practitioner, practitionerServices]);

  if (isLoading || !practitioner) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Header */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-6xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8 items-start">
            {/* Photo & Video */}
            <div className="md:col-span-1">
              <div className="relative aspect-square rounded-2xl overflow-hidden shadow-xl">
                {practitioner.photo_url ? (
                  <img
                    src={practitioner.photo_url}
                    alt={practitioner.display_name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center">
                    <span className="text-8xl text-white font-bold">
                      {practitioner.display_name?.charAt(0) || 'P'}
                    </span>
                  </div>
                )}
                {practitioner.video_intro_url && (
                  <button
                    onClick={() => setShowVideo(true)}
                    className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/40 transition-colors group"
                  >
                    <div className="w-16 h-16 bg-white/90 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
                      <Play className="w-6 h-6 text-purple-600 ml-1" />
                    </div>
                  </button>
                )}
              </div>
              {practitioner.video_intro_url && (
                <div className="mt-4 text-center">
                  <Button
                    onClick={() => setShowVideo(true)}
                    variant="outline"
                    className="w-full gap-2"
                  >
                    <Play className="w-4 h-4" /> Watch Introduction
                  </Button>
                </div>
              )}
            </div>

            {/* Practitioner Info */}
            <div className="md:col-span-2 space-y-6">
              <div>
                <div className="flex flex-wrap items-center gap-3 mb-3">
                  {practitioner.is_featured && (
                    <Badge className="bg-amber-500 hover:bg-amber-600">Featured Healer</Badge>
                  )}
                  {practitioner.years_experience && (
                    <Badge variant="secondary" className="bg-purple-100 text-purple-700">
                      {practitioner.years_experience}+ Years Experience
                    </Badge>
                  )}
                </div>
                <h1 className="text-4xl font-bold text-gray-900 mb-2">{practitioner.display_name}</h1>
                <p className="text-xl text-purple-600 font-medium">{practitioner.title}</p>
              </div>

              <div className="flex flex-wrap gap-6 text-sm text-gray-600">
                {practitioner.average_rating && (
                  <div className="flex items-center gap-2">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map(star => (
                        <Star
                          key={star}
                          className={`w-5 h-5 ${star <= practitioner.average_rating ? 'text-amber-500 fill-amber-500' : 'text-gray-300'}`}
                        />
                      ))}
                    </div>
                    <span className="font-bold text-gray-900">{practitioner.average_rating.toFixed(1)}</span>
                    <span>({practitioner.total_reviews} reviews)</span>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-purple-500" />
                  <span>{practitioner.total_sessions}+ Sessions Completed</span>
                </div>
              </div>

              <p className="text-lg text-gray-700 leading-relaxed max-w-2xl">
                {practitioner.bio}
              </p>

              <div className="flex flex-wrap gap-2">
                {practitioner.specialties?.map(specialty => (
                  <Badge key={specialty} variant="outline" className="text-sm py-1 px-3 border-purple-200 text-purple-700">
                    {specialty}
                  </Badge>
                ))}
              </div>

              <div className="pt-4 flex gap-4">
                <Link to={`${createPageUrl("Booking")}?practitioner=${practitioner.id}`}>
                  <Button size="lg" className="bg-gradient-to-r from-purple-600 to-pink-600 shadow-lg shadow-purple-200">
                    <Calendar className="w-5 h-5 mr-2" /> Book a Session
                  </Button>
                </Link>
                <Button variant="outline" size="lg" onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}>
                  Learn More
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Sections */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-3 gap-12">
          
          {/* Left Column - Content */}
          <div className="lg:col-span-2 space-y-16">
            
            {/* About & Certifications Section */}
            <section id="about" className="scroll-mt-24">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                <Users className="w-6 h-6 text-purple-600" />
                About {practitioner.display_name.split(' ')[0]}
              </h2>
              <div className="prose prose-purple max-w-none text-gray-700 leading-relaxed whitespace-pre-line mb-8">
                {practitioner.full_bio || practitioner.bio}
              </div>

              {practitioner.certifications?.length > 0 && (
                <div className="bg-white rounded-xl border border-gray-100 p-6 shadow-sm">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <Award className="w-5 h-5 text-purple-600" />
                    Certifications & Credentials
                  </h3>
                  <div className="grid sm:grid-cols-2 gap-4">
                    {practitioner.certifications.map((cert, idx) => (
                      <div key={idx} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                        <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="font-medium text-gray-900">{cert.name}</p>
                          <p className="text-sm text-gray-500">{cert.issuer} • {cert.year}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </section>

            {/* Services Section */}
            <section id="services" className="scroll-mt-24">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-purple-600" />
                Services Offered
              </h2>
              <div className="space-y-6">
                {practitionerServices.length > 0 ? practitionerServices.map(service => (
                  <Card key={service.id} className="hover:shadow-lg transition-shadow border-purple-100">
                    <CardContent className="p-6">
                      <div className="flex flex-col sm:flex-row gap-6">
                        {service.image_url && (
                          <div className="sm:w-48 h-32 flex-shrink-0 rounded-lg overflow-hidden">
                            <img src={service.image_url} alt={service.name} className="w-full h-full object-cover" />
                          </div>
                        )}
                        <div className="flex-1">
                          <div className="flex justify-between items-start mb-2">
                            <h3 className="text-xl font-bold text-gray-900">{service.name}</h3>
                            <Badge className="bg-green-100 text-green-800 text-lg px-3">
                              ${service.price}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-gray-500 mb-3">
                            <Clock className="w-4 h-4" />
                            <span>{service.duration_minutes} minutes</span>
                            <span>•</span>
                            <span className="capitalize">{service.type.replace(/_/g, ' ')}</span>
                          </div>
                          <p className="text-gray-600 mb-4 line-clamp-2">{service.description}</p>
                          <Link to={`${createPageUrl("Booking")}?service=${service.id}&practitioner=${practitioner.id}`}>
                            <Button className="w-full sm:w-auto bg-white text-purple-600 border border-purple-200 hover:bg-purple-50">
                              Book This Service <ArrowRight className="w-4 h-4 ml-2" />
                            </Button>
                          </Link>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )) : (
                  <div className="text-center py-8 bg-gray-50 rounded-xl">
                    <p className="text-gray-500">No specific services listed. Please contact for details.</p>
                  </div>
                )}
              </div>
            </section>

            {/* Reviews Section */}
            <section id="reviews" className="scroll-mt-24">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                  <Heart className="w-6 h-6 text-purple-600" />
                  Client Testimonials
                </h2>
                <Badge variant="outline" className="text-base px-3 py-1">
                  {reviews.length} Reviews
                </Badge>
              </div>

              <div className="grid gap-6">
                {reviews.length > 0 ? reviews.map(review => (
                  <Card key={review.id} className="bg-white">
                    <CardContent className="p-6">
                      <div className="flex gap-4">
                        <div className="flex-shrink-0">
                          <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                            <span className="text-xl font-bold text-purple-600">
                              {review.client_name.charAt(0)}
                            </span>
                          </div>
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <h4 className="font-bold text-gray-900">{review.client_name}</h4>
                              <p className="text-sm text-gray-500">{review.service_name}</p>
                            </div>
                            <div className="flex text-amber-500">
                              {[1, 2, 3, 4, 5].map(s => (
                                <Star key={s} className={`w-4 h-4 ${s <= review.rating ? 'fill-current' : 'text-gray-300'}`} />
                              ))}
                            </div>
                          </div>
                          <div className="relative">
                            <Quote className="w-8 h-8 text-purple-100 absolute -top-2 -left-2 -z-10" />
                            <p className="text-gray-700 italic relative z-10">{review.content}</p>
                          </div>
                          {review.practitioner_response && (
                            <div className="mt-4 pl-4 border-l-2 border-purple-200">
                              <p className="text-sm font-semibold text-purple-900">Response from {practitioner.display_name}</p>
                              <p className="text-sm text-gray-600">{review.practitioner_response}</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )) : (
                  <div className="text-center py-12 bg-gray-50 rounded-xl">
                    <Star className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500">No reviews yet. Be the first to share your experience!</p>
                  </div>
                )}
              </div>
            </section>
          </div>

          {/* Right Column - Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 space-y-6">
              {/* Availability Card */}
              <Card className="shadow-lg border-t-4 border-t-purple-600">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-purple-600" />
                    Availability
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {practitioner.availability ? (
                    <div className="space-y-3">
                      {['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'].map(day => {
                        const slots = practitioner.availability[day];
                        if (!slots || slots.length === 0) return null;
                        return (
                          <div key={day} className="flex justify-between items-start text-sm border-b border-gray-100 last:border-0 pb-2 last:pb-0">
                            <span className="font-medium capitalize text-gray-700 w-24">{day}</span>
                            <div className="text-right text-purple-600">
                              {slots[0]} - {slots[slots.length - 1]}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500">Contact for custom availability</p>
                  )}
                  <div className="mt-6">
                    <Link to={`${createPageUrl("Booking")}?practitioner=${practitioner.id}`}>
                      <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600">
                        Check All Slots
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Links */}
              <Card>
                <CardContent className="p-4 space-y-2">
                  <Button variant="ghost" className="w-full justify-start text-gray-600" onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}>
                    <Users className="w-4 h-4 mr-2" /> About Me
                  </Button>
                  <Button variant="ghost" className="w-full justify-start text-gray-600" onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })}>
                    <Sparkles className="w-4 h-4 mr-2" /> Services
                  </Button>
                  <Button variant="ghost" className="w-full justify-start text-gray-600" onClick={() => document.getElementById('reviews')?.scrollIntoView({ behavior: 'smooth' })}>
                    <Heart className="w-4 h-4 mr-2" /> Reviews
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>

        </div>
      </div>

      {/* Video Dialog */}
      <Dialog open={showVideo} onOpenChange={setShowVideo}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden bg-black">
          <DialogHeader className="sr-only">
            <DialogTitle>Practitioner Introduction Video</DialogTitle>
          </DialogHeader>
          {practitioner.video_intro_url && (
            <div className="aspect-video">
              <iframe
                src={practitioner.video_intro_url}
                className="w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}