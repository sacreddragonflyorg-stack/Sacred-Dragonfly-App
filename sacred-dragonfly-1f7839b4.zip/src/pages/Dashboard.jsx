import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, DollarSign, Users, TrendingUp, Video, Heart, BookOpen, AlertCircle, Clock, MessageSquare, Crown, Gift, BarChart3 } from "lucide-react";
import { format, startOfMonth, endOfMonth, isWithinInterval, subMonths } from "date-fns";

import AppointmentsList from "../components/dashboard/AppointmentsList";
import ServicesManager from "../components/dashboard/ServicesManager";
import LearningManager from "../components/dashboard/LearningManager";
import LiveSessionsManager from "../components/dashboard/LiveSessionsManager";
import ClientProgressManager from "../components/dashboard/ClientProgressManager";
import EnergyExchangeManager from "../components/dashboard/EnergyExchangeManager";
import AppointmentReminders from "../components/dashboard/AppointmentReminders";
import SubscriptionPlansManager from "../components/dashboard/SubscriptionPlansManager";
import DashboardOverview from "../components/dashboard/DashboardOverview";
import WeeklyCalendar from "../components/dashboard/WeeklyCalendar";
import DailyAgenda from "../components/dashboard/DailyAgenda";
import PractitionerManagement from "../components/dashboard/PractitionerManagement";
import ClientManagement from "../components/dashboard/ClientManagement";
import ReferralProgramOversight from "../components/dashboard/ReferralProgramOversight";
import SubscriptionAnalytics from "../components/dashboard/SubscriptionAnalytics";
import ServicePackagesManager from "../components/dashboard/ServicePackagesManager";
import PlatformSettings from "../components/dashboard/PlatformSettings";

export default function Dashboard() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then((u) => {
      if (u.role !== 'admin') {
        window.location.href = '/';
      }
      setUser(u);
    }).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  const { data: appointments } = useQuery({
    queryKey: ['all-appointments'],
    queryFn: () => base44.entities.Appointment.list('-appointment_date'),
    initialData: [],
  });

  const { data: services } = useQuery({
    queryKey: ['services'],
    queryFn: () => base44.entities.Service.list(),
    initialData: [],
  });

  const { data: liveSessions } = useQuery({
    queryKey: ['live-sessions'],
    queryFn: () => base44.entities.LiveSession.list('-scheduled_start'),
    initialData: [],
  });

  const { data: sharedEntries } = useQuery({
    queryKey: ['shared-progress-count'],
    queryFn: () => base44.entities.ProgressEntry.filter({ is_private: false }),
    initialData: [],
  });

  const { data: exchangeRequests } = useQuery({
    queryKey: ['exchange-requests-count'],
    queryFn: () => base44.entities.EnergyExchangeRequest.list(),
    initialData: [],
  });

  const { data: payments } = useQuery({
    queryKey: ['payments'],
    queryFn: () => base44.entities.Payment.list('-payment_date'),
    initialData: [],
  });

  const { data: subscriptions } = useQuery({
    queryKey: ['all-subscriptions'],
    queryFn: () => base44.entities.ClientSubscription.list(),
    initialData: [],
  });

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  const upcomingAppointments = appointments.filter(
    apt => new Date(apt.appointment_date) >= new Date() && apt.status !== 'cancelled'
  );

  const completedAppointments = appointments.filter(apt => apt.status === 'completed');

  const activeSessions = liveSessions.filter(s => 
    s.status === 'in_progress' || s.status === 'waiting'
  );

  const newProgressEntries = sharedEntries.filter(e => !e.practitioner_viewed).length;
  const pendingExchanges = exchangeRequests.filter(r => r.status === 'sent').length;

  // Revenue calculations
  const thisMonth = payments.filter(p => 
    p.payment_date && 
    p.status === 'completed' &&
    isWithinInterval(new Date(p.payment_date), {
      start: startOfMonth(new Date()),
      end: endOfMonth(new Date())
    })
  );

  const lastMonth = payments.filter(p => 
    p.payment_date && 
    p.status === 'completed' &&
    isWithinInterval(new Date(p.payment_date), {
      start: startOfMonth(subMonths(new Date(), 1)),
      end: endOfMonth(subMonths(new Date(), 1))
    })
  );

  const monthlyRevenue = thisMonth.reduce((sum, p) => sum + (p.amount || 0), 0);
  const lastMonthRevenue = lastMonth.reduce((sum, p) => sum + (p.amount || 0), 0);
  const revenueGrowth = lastMonthRevenue > 0 
    ? ((monthlyRevenue - lastMonthRevenue) / lastMonthRevenue * 100).toFixed(1)
    : 0;

  const activeSubscribers = subscriptions.filter(s => s.status === 'active').length;
  const monthlyRecurring = subscriptions
    .filter(s => s.status === 'active')
    .reduce((sum, s) => sum + (s.price || 0), 0);

  // Pending actions
  const pendingActions = [
    upcomingAppointments.filter(a => a.status === 'pending').length,
    newProgressEntries,
    pendingExchanges,
    appointments.filter(a => !a.reminder_sent && new Date(a.appointment_date) - new Date() < 24 * 60 * 60 * 1000).length
  ].reduce((a, b) => a + b, 0);

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Welcome back, {user.full_name}
          </h1>
          <p className="text-gray-600">Here's what's happening with your healing practice</p>
        </div>

        {/* Alert for pending actions */}
        {pendingActions > 0 && (
          <Card className="mb-8 border-2 border-amber-400 bg-amber-50">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <AlertCircle className="w-6 h-6 text-amber-600" />
                <div>
                  <p className="font-semibold text-amber-900">
                    You have {pendingActions} item{pendingActions !== 1 ? 's' : ''} requiring attention
                  </p>
                  <p className="text-sm text-amber-700">
                    Check your appointments, progress entries, and reminders
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-blue-100">
                This Month
              </CardTitle>
              <DollarSign className="w-5 h-5 text-blue-100" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                ${monthlyRevenue.toFixed(0)}
              </div>
              <p className="text-xs text-blue-100 mt-1 flex items-center gap-1">
                {revenueGrowth > 0 ? '↑' : '↓'} {Math.abs(revenueGrowth)}% from last month
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-purple-100">
                Recurring Revenue
              </CardTitle>
              <TrendingUp className="w-5 h-5 text-purple-100" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                ${monthlyRecurring.toFixed(0)}
              </div>
              <p className="text-xs text-purple-100 mt-1">
                {activeSubscribers} active subscriber{activeSubscribers !== 1 ? 's' : ''}
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-green-100">
                Upcoming
              </CardTitle>
              <Calendar className="w-5 h-5 text-green-100" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {upcomingAppointments.length}
              </div>
              <p className="text-xs text-green-100 mt-1">
                Scheduled sessions
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-pink-500 to-pink-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-pink-100">
                Total Clients
              </CardTitle>
              <Users className="w-5 h-5 text-pink-100" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {new Set(appointments.map(a => a.client_email)).size}
              </div>
              <p className="text-xs text-pink-100 mt-1">
                {completedAppointments.length} sessions completed
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Stats Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Live Now</p>
                  <p className="text-2xl font-bold text-red-600">{activeSessions.length}</p>
                </div>
                <Video className="w-8 h-8 text-red-600" />
              </div>
            </CardContent>
          </Card>

          <Card className={`hover:shadow-lg transition-shadow ${newProgressEntries > 0 ? 'border-2 border-purple-400' : ''}`}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">New Entries</p>
                  <p className="text-2xl font-bold text-purple-600">{newProgressEntries}</p>
                </div>
                <BookOpen className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className={`hover:shadow-lg transition-shadow ${pendingExchanges > 0 ? 'border-2 border-pink-400' : ''}`}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending</p>
                  <p className="text-2xl font-bold text-pink-600">{pendingExchanges}</p>
                </div>
                <Heart className="w-8 h-8 text-pink-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Services</p>
                  <p className="text-2xl font-bold text-amber-600">{services.filter(s => s.is_active).length}</p>
                </div>
                <Clock className="w-8 h-8 text-amber-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="today" className="space-y-6">
          <TabsList className="bg-white p-1 rounded-lg shadow flex-wrap h-auto">
            <TabsTrigger value="today">Today</TabsTrigger>
            <TabsTrigger value="week">This Week</TabsTrigger>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="analytics">
              <BarChart3 className="w-4 h-4 mr-2" />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="practitioners">
              <Users className="w-4 h-4 mr-2" />
              Practitioners
            </TabsTrigger>
            <TabsTrigger value="clients">
              <Users className="w-4 h-4 mr-2" />
              Clients
            </TabsTrigger>
            <TabsTrigger value="referrals">
              <Gift className="w-4 h-4 mr-2" />
              Referrals
            </TabsTrigger>
            <TabsTrigger value="subscriptions">
              <Crown className="w-4 h-4 mr-2" />
              Subscriptions
            </TabsTrigger>
            <TabsTrigger value="packages">Packages</TabsTrigger>
            <TabsTrigger value="live-sessions">Live Sessions</TabsTrigger>
            <TabsTrigger value="appointments">Appointments</TabsTrigger>
            <TabsTrigger value="reminders">Reminders</TabsTrigger>
            <TabsTrigger value="sub-plans">Sub Plans</TabsTrigger>
            <TabsTrigger value="client-progress">
              Client Progress
              {newProgressEntries > 0 && (
                <span className="ml-2 bg-purple-600 text-white text-xs px-2 py-0.5 rounded-full">
                  {newProgressEntries}
                </span>
              )}
            </TabsTrigger>
            <TabsTrigger value="energy-exchange">
              Energy Exchange
              {pendingExchanges > 0 && (
                <span className="ml-2 bg-pink-600 text-white text-xs px-2 py-0.5 rounded-full">
                  {pendingExchanges}
                </span>
              )}
            </TabsTrigger>
            <TabsTrigger value="services">Services</TabsTrigger>
            <TabsTrigger value="learning">Learning</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="settings">
            <PlatformSettings />
          </TabsContent>

          <TabsContent value="today">
            <DailyAgenda appointments={upcomingAppointments} />
          </TabsContent>

          <TabsContent value="week">
            <WeeklyCalendar appointments={upcomingAppointments} />
          </TabsContent>

          <TabsContent value="overview">
            <DashboardOverview 
              appointments={appointments}
              payments={payments}
              subscriptions={subscriptions}
              services={services}
            />
          </TabsContent>

          <TabsContent value="analytics">
            <SubscriptionAnalytics />
          </TabsContent>

          <TabsContent value="practitioners">
            <PractitionerManagement />
          </TabsContent>

          <TabsContent value="clients">
            <ClientManagement />
          </TabsContent>

          <TabsContent value="referrals">
            <ReferralProgramOversight />
          </TabsContent>

          <TabsContent value="subscriptions">
            <SubscriptionAnalytics />
          </TabsContent>

          <TabsContent value="packages">
            <ServicePackagesManager />
          </TabsContent>

          <TabsContent value="live-sessions">
            <LiveSessionsManager />
          </TabsContent>

          <TabsContent value="appointments">
            <AppointmentsList appointments={appointments} />
          </TabsContent>

          <TabsContent value="reminders">
            <AppointmentReminders />
          </TabsContent>

          <TabsContent value="sub-plans">
            <SubscriptionPlansManager />
          </TabsContent>

          <TabsContent value="client-progress">
            <ClientProgressManager />
          </TabsContent>

          <TabsContent value="energy-exchange">
            <EnergyExchangeManager />
          </TabsContent>

          <TabsContent value="services">
            <ServicesManager />
          </TabsContent>

          <TabsContent value="learning">
            <LearningManager />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}