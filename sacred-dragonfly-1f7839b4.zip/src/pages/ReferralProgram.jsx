import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Gift, Users, Copy, CheckCircle2, DollarSign, TrendingUp, Share2 } from "lucide-react";
import { toast } from "sonner";

export default function ReferralProgram() {
  const [user, setUser] = useState(null);
  const [copiedCode, setCopiedCode] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  const { data: referralCode } = useQuery({
    queryKey: ['my-referral-code', user?.email],
    queryFn: async () => {
      if (!user) return null;
      const codes = await base44.entities.ReferralCode.filter({ referrer_email: user.email });
      return codes[0] || null;
    },
    enabled: !!user,
  });

  const { data: myReferrals = [] } = useQuery({
    queryKey: ['my-referrals', user?.email],
    queryFn: () => {
      if (!user) return [];
      return base44.entities.Referral.filter({ referrer_email: user.email }, '-created_date');
    },
    enabled: !!user,
  });

  const createReferralCodeMutation = useMutation({
    mutationFn: async () => {
      const code = `${user.full_name.replace(/\s/g, '').toUpperCase().substring(0, 4)}${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
      return base44.entities.ReferralCode.create({
        code,
        referrer_email: user.email,
        referrer_name: user.full_name
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['my-referral-code']);
      toast.success("Referral code created!");
    }
  });

  const handleCopyCode = () => {
    if (referralCode) {
      navigator.clipboard.writeText(referralCode.code);
      setCopiedCode(true);
      toast.success("Code copied to clipboard!");
      setTimeout(() => setCopiedCode(false), 2000);
    }
  };

  const handleShareCode = async () => {
    const shareData = {
      title: 'Sacred Healing Referral',
      text: `Use my referral code ${referralCode.code} to get $20 off your first healing session!`,
      url: window.location.origin
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        handleCopyCode();
      }
    } else {
      handleCopyCode();
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  const qualifiedReferrals = myReferrals.filter(r => r.status === 'qualified' || r.status === 'rewarded');
  const pendingReferrals = myReferrals.filter(r => r.status === 'pending');
  const totalEarned = myReferrals.reduce((sum, r) => sum + (r.referrer_reward_amount || 0), 0);

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full mb-6 border border-purple-200">
            <Gift className="w-4 h-4 text-purple-600" />
            <span className="text-sm font-medium text-purple-900">Referral Rewards Program</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Share the <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Gift of Healing</span>
          </h1>
          <p className="text-lg text-gray-600">
            Refer friends and earn rewards when they book their first session
          </p>
        </div>

        {/* How It Works */}
        <Card className="mb-8 bg-gradient-to-r from-purple-100 to-pink-100 border-2 border-purple-300">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-purple-600" />
              How It Works
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-600 text-white rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-3">1</div>
                <h3 className="font-semibold text-gray-900 mb-2">Share Your Code</h3>
                <p className="text-sm text-gray-700">Share your unique referral code with friends and family</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-600 text-white rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-3">2</div>
                <h3 className="font-semibold text-gray-900 mb-2">They Book & Save</h3>
                <p className="text-sm text-gray-700">Your friend gets $20 off their first healing session</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-600 text-white rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-3">3</div>
                <h3 className="font-semibold text-gray-900 mb-2">You Both Win</h3>
                <p className="text-sm text-gray-700">You earn $25 in credits after their session is completed</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Overview */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                Total Referrals
              </CardTitle>
              <Users className="w-5 h-5 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-gray-900">{myReferrals.length}</div>
              <p className="text-xs text-gray-500 mt-1">Friends referred</p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                Qualified
              </CardTitle>
              <CheckCircle2 className="w-5 h-5 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-gray-900">{qualifiedReferrals.length}</div>
              <p className="text-xs text-gray-500 mt-1">Completed bookings</p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                Total Earned
              </CardTitle>
              <DollarSign className="w-5 h-5 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-gray-900">${totalEarned}</div>
              <p className="text-xs text-gray-500 mt-1">In rewards</p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                Available Balance
              </CardTitle>
              <Gift className="w-5 h-5 text-pink-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-gray-900">${user.rewards_balance || 0}</div>
              <p className="text-xs text-gray-500 mt-1">Ready to use</p>
            </CardContent>
          </Card>
        </div>

        {/* Your Referral Code */}
        <Card className="mb-8 bg-gradient-to-br from-purple-600 to-pink-600 text-white shadow-2xl">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              <Share2 className="w-6 h-6" />
              Your Referral Code
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!referralCode ? (
              <div className="text-center py-8">
                <p className="mb-4 text-purple-100">Generate your unique referral code to start earning rewards</p>
                <Button
                  onClick={() => createReferralCodeMutation.mutate()}
                  disabled={createReferralCodeMutation.isPending}
                  className="bg-white text-purple-600 hover:bg-purple-50"
                >
                  <Gift className="w-4 h-4 mr-2" />
                  Generate My Code
                </Button>
              </div>
            ) : (
              <div>
                <div className="flex items-center gap-4 mb-6">
                  <Input
                    value={referralCode.code}
                    readOnly
                    className="text-2xl font-bold text-center bg-white/20 border-white/40 text-white placeholder-white/60"
                  />
                  <Button
                    onClick={handleCopyCode}
                    className="bg-white/20 hover:bg-white/30 border-white"
                    variant="outline"
                  >
                    {copiedCode ? <CheckCircle2 className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                  </Button>
                  <Button
                    onClick={handleShareCode}
                    className="bg-white/20 hover:bg-white/30 border-white"
                    variant="outline"
                  >
                    <Share2 className="w-5 h-5" />
                  </Button>
                </div>
                <div className="flex items-center justify-between text-purple-100">
                  <div>
                    <p className="text-sm">Times Used: <span className="font-bold text-white">{referralCode.uses_count}</span></p>
                  </div>
                  <div>
                    <p className="text-sm">Total Earned: <span className="font-bold text-white">${referralCode.total_rewards_earned}</span></p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Referral History */}
        <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              <Users className="w-6 h-6 text-blue-600" />
              Your Referrals
            </CardTitle>
          </CardHeader>
          <CardContent>
            {myReferrals.length === 0 ? (
              <div className="text-center py-12">
                <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">No referrals yet. Share your code to get started!</p>
              </div>
            ) : (
              <div className="space-y-3">
                {myReferrals.map((referral) => (
                  <div key={referral.id} className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-semibold text-gray-900">{referral.referred_name}</h4>
                        <p className="text-sm text-gray-600">{referral.referred_email}</p>
                        {referral.qualification_date && (
                          <p className="text-xs text-gray-500 mt-1">
                            Qualified: {new Date(referral.qualification_date).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                      <div className="text-right">
                        <Badge className={
                          referral.status === 'rewarded' ? 'bg-green-100 text-green-800' :
                          referral.status === 'qualified' ? 'bg-blue-100 text-blue-800' :
                          'bg-yellow-100 text-yellow-800'
                        }>
                          {referral.status}
                        </Badge>
                        {referral.referrer_reward_amount > 0 && (
                          <p className="text-sm font-semibold text-purple-600 mt-2">
                            +${referral.referrer_reward_amount}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}