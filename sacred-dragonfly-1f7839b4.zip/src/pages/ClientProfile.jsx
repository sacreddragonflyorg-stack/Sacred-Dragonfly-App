import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { User, Mail, Phone, Calendar, Save, Loader2, CheckCircle2, Upload, FileText, Trash2, MapPin, History, CreditCard, Sparkles } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { format } from "date-fns";

export default function ClientProfile() {
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({
    full_name: "",
    phone: "",
    date_of_birth: "",
    address_street: "",
    address_city: "",
    address_state: "",
    address_zip: "",
    address_country: "",
    bio: "",
    healing_intentions: "",
    emergency_contact_name: "",
    emergency_contact_phone: "",
    emergency_contact_relationship: "",
    medical_conditions: "",
    current_medications: "",
    allergies: "",
    preferred_contact_method: "email"
  });
  const [uploadingDoc, setUploadingDoc] = useState(false);
  const [documents, setDocuments] = useState([]);

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      setFormData({
        full_name: u.full_name || "",
        phone: u.phone || "",
        date_of_birth: u.date_of_birth || "",
        address_street: u.address_street || "",
        address_city: u.address_city || "",
        address_state: u.address_state || "",
        address_zip: u.address_zip || "",
        address_country: u.address_country || "",
        bio: u.bio || "",
        healing_intentions: u.healing_intentions || "",
        emergency_contact_name: u.emergency_contact_name || "",
        emergency_contact_phone: u.emergency_contact_phone || "",
        emergency_contact_relationship: u.emergency_contact_relationship || "",
        medical_conditions: u.medical_conditions || "",
        current_medications: u.current_medications || "",
        allergies: u.allergies || "",
        preferred_contact_method: u.preferred_contact_method || "email"
      });
      setDocuments(u.documents || []);
    }).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  const { data: appointments = [] } = useQuery({
    queryKey: ['my-appointments', user?.email],
    queryFn: () => user ? base44.entities.Appointment.filter({ client_email: user.email }, '-appointment_date') : [],
    enabled: !!user,
  });

  const { data: tarotReadings = [] } = useQuery({
    queryKey: ['my-tarot-readings', user?.email],
    queryFn: () => user ? base44.entities.TarotReading.list('-created_date') : [],
    enabled: !!user,
  });

  const { data: payments = [] } = useQuery({
    queryKey: ['my-payments', user?.email],
    queryFn: () => user ? base44.entities.Payment.filter({ client_email: user.email }, '-payment_date') : [],
    enabled: !!user,
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data) => {
      return base44.auth.updateMe(data);
    },
    onSuccess: (updatedUser) => {
      setUser(updatedUser);
      toast.success("Profile updated successfully!");
    },
    onError: () => {
      toast.error("Failed to update profile");
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    updateProfileMutation.mutate(formData);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingDoc(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const newDoc = {
        name: file.name,
        url: file_url,
        type: file.type,
        uploaded_date: new Date().toISOString()
      };
      const updatedDocs = [...documents, newDoc];
      setDocuments(updatedDocs);
      await base44.auth.updateMe({ documents: updatedDocs });
      toast.success("Document uploaded successfully!");
    } catch (error) {
      toast.error("Failed to upload document");
    } finally {
      setUploadingDoc(false);
    }
  };

  const handleDeleteDocument = async (index) => {
    const updatedDocs = documents.filter((_, i) => i !== index);
    setDocuments(updatedDocs);
    await base44.auth.updateMe({ documents: updatedDocs });
    toast.success("Document deleted");
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            My <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Profile</span>
          </h1>
          <p className="text-lg text-gray-600">Manage your information and view your healing journey</p>
        </div>

        <Tabs defaultValue="personal" className="space-y-6">
          <TabsList className="bg-white p-1 rounded-lg shadow">
            <TabsTrigger value="personal">Personal Info</TabsTrigger>
            <TabsTrigger value="history">Session History</TabsTrigger>
            <TabsTrigger value="payments">Payment Methods</TabsTrigger>
          </TabsList>

          {/* Personal Information Tab */}
          <TabsContent value="personal" className="space-y-6">
            {/* Account Info Card */}
            <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
              <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Account Information
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="flex items-center gap-3 p-4 bg-purple-50 rounded-lg">
                    <Mail className="w-5 h-5 text-purple-600" />
                    <div>
                      <p className="text-sm text-gray-600">Email</p>
                      <p className="font-semibold text-gray-900">{user.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-purple-50 rounded-lg">
                    <Calendar className="w-5 h-5 text-purple-600" />
                    <div>
                      <p className="text-sm text-gray-600">Member Since</p>
                      <p className="font-semibold text-gray-900">
                        {format(new Date(user.created_date), 'MMM d, yyyy')}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Profile Form */}
            <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
              <CardHeader>
                <CardTitle className="text-2xl">Personal Information</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Basic Info */}
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="full_name">Full Name *</Label>
                        <Input
                          id="full_name"
                          value={formData.full_name}
                          onChange={(e) => handleChange('full_name', e.target.value)}
                          placeholder="Your full name"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="date_of_birth">Date of Birth</Label>
                        <Input
                          id="date_of_birth"
                          type="date"
                          value={formData.date_of_birth}
                          onChange={(e) => handleChange('date_of_birth', e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                          <Input
                            id="phone"
                            type="tel"
                            value={formData.phone}
                            onChange={(e) => handleChange('phone', e.target.value)}
                            placeholder="+1 (555) 123-4567"
                            className="pl-10"
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="preferred_contact_method">Preferred Contact</Label>
                        <Select value={formData.preferred_contact_method} onValueChange={(value) => handleChange('preferred_contact_method', value)}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="email">Email</SelectItem>
                            <SelectItem value="phone">Phone</SelectItem>
                            <SelectItem value="text">Text Message</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bio">About Me</Label>
                      <Textarea
                        id="bio"
                        value={formData.bio}
                        onChange={(e) => handleChange('bio', e.target.value)}
                        placeholder="Tell us a bit about yourself..."
                        rows={4}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="healing_intentions">Healing Intentions</Label>
                      <Textarea
                        id="healing_intentions"
                        value={formData.healing_intentions}
                        onChange={(e) => handleChange('healing_intentions', e.target.value)}
                        placeholder="What are you hoping to achieve through your healing journey?"
                        rows={4}
                      />
                    </div>
                  </div>

                  {/* Address */}
                  <div className="pt-6 border-t">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                      <MapPin className="w-5 h-5" />
                      Address
                    </h3>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="address_street">Street Address</Label>
                        <Input
                          id="address_street"
                          value={formData.address_street}
                          onChange={(e) => handleChange('address_street', e.target.value)}
                          placeholder="123 Main Street"
                        />
                      </div>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="address_city">City</Label>
                          <Input
                            id="address_city"
                            value={formData.address_city}
                            onChange={(e) => handleChange('address_city', e.target.value)}
                            placeholder="City"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="address_state">State/Province</Label>
                          <Input
                            id="address_state"
                            value={formData.address_state}
                            onChange={(e) => handleChange('address_state', e.target.value)}
                            placeholder="State"
                          />
                        </div>
                      </div>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="address_zip">ZIP/Postal Code</Label>
                          <Input
                            id="address_zip"
                            value={formData.address_zip}
                            onChange={(e) => handleChange('address_zip', e.target.value)}
                            placeholder="12345"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="address_country">Country</Label>
                          <Input
                            id="address_country"
                            value={formData.address_country}
                            onChange={(e) => handleChange('address_country', e.target.value)}
                            placeholder="Country"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Health Info */}
                  <div className="pt-6 border-t">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Health Information (Optional)</h3>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="medical_conditions">Medical Conditions</Label>
                        <Textarea
                          id="medical_conditions"
                          value={formData.medical_conditions}
                          onChange={(e) => handleChange('medical_conditions', e.target.value)}
                          placeholder="Any relevant medical conditions..."
                          rows={3}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="current_medications">Current Medications</Label>
                        <Textarea
                          id="current_medications"
                          value={formData.current_medications}
                          onChange={(e) => handleChange('current_medications', e.target.value)}
                          placeholder="List medications..."
                          rows={3}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="allergies">Allergies</Label>
                        <Input
                          id="allergies"
                          value={formData.allergies}
                          onChange={(e) => handleChange('allergies', e.target.value)}
                          placeholder="Any known allergies"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Emergency Contact */}
                  <div className="pt-6 border-t">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Emergency Contact (Optional)</h3>
                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="emergency_contact_name">Contact Name</Label>
                        <Input
                          id="emergency_contact_name"
                          value={formData.emergency_contact_name}
                          onChange={(e) => handleChange('emergency_contact_name', e.target.value)}
                          placeholder="Emergency contact name"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="emergency_contact_phone">Contact Phone</Label>
                        <Input
                          id="emergency_contact_phone"
                          type="tel"
                          value={formData.emergency_contact_phone}
                          onChange={(e) => handleChange('emergency_contact_phone', e.target.value)}
                          placeholder="+1 (555) 123-4567"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="emergency_contact_relationship">Relationship</Label>
                        <Input
                          id="emergency_contact_relationship"
                          value={formData.emergency_contact_relationship}
                          onChange={(e) => handleChange('emergency_contact_relationship', e.target.value)}
                          placeholder="e.g., Spouse, Parent"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Save Button */}
                  <div className="pt-6 border-t">
                    <Button
                      type="submit"
                      disabled={updateProfileMutation.isPending}
                      size="lg"
                      className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                    >
                      {updateProfileMutation.isPending ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Saving Changes...
                        </>
                      ) : (
                        <>
                          <Save className="w-5 h-5 mr-2" />
                          Save Profile
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>

            {/* Documents */}
            <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
              <CardHeader>
                <CardTitle className="text-2xl flex items-center gap-2">
                  <FileText className="w-6 h-6" />
                  Documents & Records
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <Input
                      type="file"
                      id="document_upload"
                      className="hidden"
                      onChange={handleFileUpload}
                      accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => document.getElementById('document_upload').click()}
                      disabled={uploadingDoc}
                    >
                      {uploadingDoc ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
                      Upload Document
                    </Button>
                    <p className="text-sm text-gray-500">Upload medical records or assessments</p>
                  </div>

                  {documents.length > 0 && (
                    <div className="space-y-2">
                      {documents.map((doc, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <FileText className="w-5 h-5 text-purple-600" />
                            <div>
                              <p className="font-medium text-sm">{doc.name}</p>
                              <p className="text-xs text-gray-500">{new Date(doc.uploaded_date).toLocaleDateString()}</p>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <a href={doc.url} target="_blank" rel="noopener noreferrer" className="text-purple-600 text-sm">View</a>
                            <Button variant="ghost" size="sm" onClick={() => handleDeleteDocument(index)} className="text-red-600">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Session History Tab */}
          <TabsContent value="history" className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="w-6 h-6" />
                  My Session History
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  {/* Appointments */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                      <Calendar className="w-5 h-5 text-purple-600" />
                      Healing Sessions ({appointments.length})
                    </h3>
                    {appointments.length === 0 ? (
                      <p className="text-gray-500 text-center py-8">No appointments yet</p>
                    ) : (
                      <div className="space-y-3">
                        {appointments.slice(0, 10).map((apt) => (
                          <div key={apt.id} className="p-4 bg-purple-50 rounded-lg border border-purple-100">
                            <div className="flex justify-between items-start mb-2">
                              <div>
                                <h4 className="font-semibold text-gray-900">{apt.service_name}</h4>
                                <p className="text-sm text-gray-600">
                                  {format(new Date(apt.appointment_date), 'MMM d, yyyy • h:mm a')}
                                </p>
                              </div>
                              <Badge className={
                                apt.status === 'completed' ? 'bg-green-100 text-green-800' :
                                apt.status === 'confirmed' ? 'bg-blue-100 text-blue-800' :
                                apt.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                                'bg-yellow-100 text-yellow-800'
                              }>
                                {apt.status}
                              </Badge>
                            </div>
                            {apt.notes && (
                              <p className="text-sm text-gray-600 mt-2">{apt.notes.substring(0, 150)}...</p>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Tarot Readings */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-pink-600" />
                      Tarot Readings ({tarotReadings.length})
                    </h3>
                    {tarotReadings.length === 0 ? (
                      <p className="text-gray-500 text-center py-8">No tarot readings yet</p>
                    ) : (
                      <div className="space-y-3">
                        {tarotReadings.slice(0, 10).map((reading) => (
                          <div key={reading.id} className="p-4 bg-pink-50 rounded-lg border border-pink-100">
                            <div className="flex justify-between items-start mb-2">
                              <div>
                                <h4 className="font-semibold text-gray-900">{reading.spread_type.replace(/_/g, ' ').toUpperCase()}</h4>
                                <p className="text-sm text-gray-600">
                                  {format(new Date(reading.created_date), 'MMM d, yyyy')}
                                </p>
                              </div>
                              <Badge className="bg-pink-100 text-pink-800">
                                {reading.cards_drawn?.length || 0} cards
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-700 mt-2 line-clamp-2">{reading.user_question}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payment Methods Tab */}
          <TabsContent value="payments" className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="w-6 h-6" />
                  Payment History
                </CardTitle>
              </CardHeader>
              <CardContent>
                {payments.length === 0 ? (
                  <div className="text-center py-12">
                    <CreditCard className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">No payment history yet</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {payments.map((payment) => (
                      <div key={payment.id} className="p-4 bg-gray-50 rounded-lg border border-gray-200 flex justify-between items-center">
                        <div>
                          <p className="font-semibold text-gray-900">${payment.amount.toFixed(2)}</p>
                          <p className="text-sm text-gray-600">
                            {payment.payment_method?.replace(/_/g, ' ')} • {payment.payment_date ? format(new Date(payment.payment_date), 'MMM d, yyyy') : 'Pending'}
                          </p>
                          {payment.notes && (
                            <p className="text-xs text-gray-500 mt-1">{payment.notes}</p>
                          )}
                        </div>
                        <Badge className={
                          payment.status === 'completed' ? 'bg-green-100 text-green-800' :
                          payment.status === 'failed' ? 'bg-red-100 text-red-800' :
                          payment.status === 'refunded' ? 'bg-orange-100 text-orange-800' :
                          'bg-yellow-100 text-yellow-800'
                        }>
                          {payment.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div className="text-sm text-gray-700 flex-1">
                    <p className="font-semibold mb-1">Secure Payments & Billing</p>
                    <p className="mb-3">Manage your saved cards, active subscriptions, and billing history securely via Stripe.</p>
                    <Button 
                      onClick={async () => {
                        try {
                          toast.loading("Opening billing portal...");
                          const { data } = await base44.functions.invoke('createStripeCustomerPortalSession', {
                            return_url: window.location.href
                          });
                          if (data.url) window.location.href = data.url;
                          else toast.error(data.error || "No billing account found");
                        } catch (e) {
                          toast.error("Failed to open portal");
                        } finally {
                          toast.dismiss();
                        }
                      }}
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                      size="sm"
                    >
                      <CreditCard className="w-4 h-4 mr-2" />
                      Manage Billing & Subscriptions
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}