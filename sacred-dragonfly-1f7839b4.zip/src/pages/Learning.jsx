import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookOpen, Clock, PlayCircle, ArrowRight, Sparkles } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import ReactMarkdown from "react-markdown";

const categoryColors = {
  meditation: "from-blue-500 to-purple-500",
  chakra_work: "from-purple-500 to-pink-500",
  energy_techniques: "from-pink-500 to-amber-500",
  self_healing: "from-amber-500 to-green-500",
  reiki_basics: "from-green-500 to-blue-500",
  tarot_guidance: "from-indigo-500 to-purple-500"
};

const difficultyColors = {
  beginner: "bg-green-100 text-green-800",
  intermediate: "bg-yellow-100 text-yellow-800",
  advanced: "bg-red-100 text-red-800"
};

export default function Learning() {
  const [selectedResource, setSelectedResource] = useState(null);
  const [activeCategory, setActiveCategory] = useState("all");

  const { data: resources, isLoading } = useQuery({
    queryKey: ['learning-resources'],
    queryFn: () => base44.entities.LearningResource.list('-created_date'),
    initialData: [],
  });

  const filteredResources = activeCategory === "all" 
    ? resources 
    : resources.filter(r => r.category === activeCategory);

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full mb-6 border border-purple-200">
            <BookOpen className="w-4 h-4 text-purple-600" />
            <span className="text-sm font-medium text-purple-900">Learning Center</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Learn to <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Heal Yourself</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover ancient wisdom and modern techniques for self-healing, energy work, and spiritual growth
          </p>
        </div>

        {/* Category Tabs */}
        <Tabs value={activeCategory} onValueChange={setActiveCategory} className="mb-8">
          <TabsList className="grid grid-cols-3 lg:grid-cols-7 gap-2 bg-white/80 backdrop-blur-sm p-2 rounded-xl">
            <TabsTrigger value="all" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600 data-[state=active]:text-white">
              All
            </TabsTrigger>
            <TabsTrigger value="meditation">Meditation</TabsTrigger>
            <TabsTrigger value="chakra_work">Chakra Work</TabsTrigger>
            <TabsTrigger value="energy_techniques">Energy</TabsTrigger>
            <TabsTrigger value="self_healing">Self Healing</TabsTrigger>
            <TabsTrigger value="reiki_basics">Reiki</TabsTrigger>
            <TabsTrigger value="tarot_guidance">Tarot</TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Resources Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i}>
                <Skeleton className="h-48 w-full" />
                <CardHeader>
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-full" />
                </CardHeader>
              </Card>
            ))}
          </div>
        ) : filteredResources.length === 0 ? (
          <div className="text-center py-20">
            <BookOpen className="w-16 h-16 text-purple-300 mx-auto mb-4" />
            <h3 className="text-2xl font-semibold text-gray-700 mb-2">No Resources Available</h3>
            <p className="text-gray-500">Check back soon for new learning content</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredResources.map((resource) => (
              <Card 
                key={resource.id} 
                className="group overflow-hidden hover:shadow-2xl transition-all duration-300 cursor-pointer border-none bg-white/80 backdrop-blur-sm"
                onClick={() => setSelectedResource(resource)}
              >
                {/* Resource Image */}
                <div className={`relative h-48 bg-gradient-to-br ${categoryColors[resource.category] || 'from-purple-500 to-pink-500'} overflow-hidden`}>
                  {resource.image_url ? (
                    <img src={resource.image_url} alt={resource.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
                  ) : (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <BookOpen className="w-16 h-16 text-white/50" />
                    </div>
                  )}
                  {resource.video_url && (
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <PlayCircle className="w-16 h-16 text-white" />
                    </div>
                  )}
                  <div className="absolute top-4 left-4">
                    {resource.is_free && (
                      <Badge className="bg-green-500 text-white hover:bg-green-600">
                        FREE
                      </Badge>
                    )}
                  </div>
                  <div className="absolute top-4 right-4">
                    <Badge className={difficultyColors[resource.difficulty_level]}>
                      {resource.difficulty_level.toUpperCase()}
                    </Badge>
                  </div>
                </div>

                <CardHeader>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <CardTitle className="text-xl leading-tight">{resource.title}</CardTitle>
                  </div>
                  <p className="text-gray-600 text-sm leading-relaxed line-clamp-2">
                    {resource.description}
                  </p>
                </CardHeader>

                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4" />
                      <span>{resource.duration_minutes || 15} min</span>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {resource.category.replace(/_/g, ' ')}
                    </Badge>
                  </div>
                  <Button 
                    variant="ghost" 
                    className="w-full mt-4 text-purple-600 hover:text-purple-700 hover:bg-purple-50"
                  >
                    Read More
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Resource Detail Dialog */}
      <Dialog open={!!selectedResource} onOpenChange={() => setSelectedResource(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          {selectedResource && (
            <>
              <DialogHeader>
                <div className="flex items-start justify-between gap-4 mb-4">
                  <DialogTitle className="text-3xl">{selectedResource.title}</DialogTitle>
                  <Badge className={difficultyColors[selectedResource.difficulty_level]}>
                    {selectedResource.difficulty_level}
                  </Badge>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline">
                    {selectedResource.category.replace(/_/g, ' ')}
                  </Badge>
                  <Badge variant="outline" className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {selectedResource.duration_minutes || 15} minutes
                  </Badge>
                  {selectedResource.is_free && (
                    <Badge className="bg-green-500 text-white">FREE</Badge>
                  )}
                </div>
              </DialogHeader>

              {selectedResource.video_url && (
                <div className="aspect-video bg-gray-100 rounded-lg mb-6 flex items-center justify-center">
                  <PlayCircle className="w-16 h-16 text-purple-600" />
                  <p className="ml-4 text-gray-600">Video tutorial available</p>
                </div>
              )}

              <div className="prose prose-purple max-w-none">
                <ReactMarkdown>{selectedResource.content}</ReactMarkdown>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}