
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Sparkles, Calendar, BookOpen, User, LogOut, LayoutDashboard, TrendingUp, Zap, Video, Heart, MessageSquare, Users, Gift, Crown } from "lucide-react";
import { base44 } from "@/api/base44Client";
import HealingChatbot from "./components/chatbot/HealingChatbot";
import ShareApp from "./components/common/ShareApp";
import AnnouncementBar from "./components/common/AnnouncementBar";
import GlobalSearch from "./components/common/GlobalSearch";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = React.useState(null);
  const [scrolled, setScrolled] = React.useState(false);

  React.useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  React.useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const publicNavigation = [
    { name: "Home", path: createPageUrl("Home"), icon: Sparkles },
    { name: "Services", path: createPageUrl("Services"), icon: Sparkles },
    { name: "Practitioners", path: createPageUrl("Practitioners"), icon: Users },
    { name: "Packages", path: createPageUrl("Packages"), icon: Gift },
    { name: "Subscriptions", path: createPageUrl("Subscriptions"), icon: Heart },
    { name: "AI Tarot", path: createPageUrl("Tarot"), icon: Zap },
    { name: "Book Session", path: createPageUrl("Booking"), icon: Calendar },
    { name: "Learning Center", path: createPageUrl("LearningCenter"), icon: BookOpen },
    ];

    const clientNavigation = [
    { name: "My Portal", path: createPageUrl("ClientDashboard"), icon: LayoutDashboard },
    { name: "Loyalty Rewards", path: createPageUrl("LoyaltyProgram"), icon: Crown },
    { name: "My Sessions", path: createPageUrl("MyAppointments"), icon: Calendar },
    { name: "Live Sessions", path: createPageUrl("LiveSessions"), icon: Video },
    { name: "Messages", path: createPageUrl("ClientChat"), icon: MessageSquare },
    { name: "My Progress", path: createPageUrl("Progress"), icon: TrendingUp },
    { name: "Referrals", path: createPageUrl("ReferralProgram"), icon: Gift },
    { name: "My Profile", path: createPageUrl("ClientProfile"), icon: User },
  ];

  const practitionerNavigation = [
    { name: "My Dashboard", path: createPageUrl("PractitionerDashboard"), icon: LayoutDashboard },
    { name: "My Profile", path: createPageUrl("PractitionerProfile"), icon: User },
    { name: "Appointments", path: createPageUrl("MyAppointments"), icon: Calendar }, // Reusing client view for now or can be specialized
  ];

  // Determine navigation based on role. 
  // Assuming 'practitioner' role exists or we check specific users.
  // For now, let's assume 'admin' gets everything, 'practitioner' gets specific nav.
  // If role logic is strictly 'admin' vs 'user', we might need to check if user has a Practitioner entity.
  // But snapshot usually implies 'user' role for everyone except app owner.
  // Let's add a condition: if user is admin OR has practitioner profile.
  
  // NOTE: Simple role check for now. If user is a practitioner, they should see their dashboard.
  // Since we don't have a 'practitioner' role in User entity by default (only admin/user), 
  // we might check if they are in the Practitioner entity list? 
  // Or just add the link to public/client nav if they are logged in as a specific user?
  // Let's add it to the menu if they are logged in, maybe as a separate section or integrated.
  
  // Actually, let's just stick to the existing logic but maybe add "Practitioner Dashboard" to the user menu dropdown or main nav if relevant.
  // Since I can't easily check entity existence in Layout without a query, I'll add it to the main list if they are logged in, 
  // or trust the user knows where to go. 
  // BETTER: Add a "Practitioner" link in the user menu.
  
  const navigation = user ? (user.role === 'admin' ? publicNavigation : clientNavigation) : publicNavigation;

  const isActive = (path) => location.pathname === path;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
      <style>{`
        :root {
          --primary: #8B5CF6;
          --secondary: #EC4899;
          --accent: #F59E0B;
          --bg-warm: #FEFAF5;
        }
        
        .glow-effect {
          box-shadow: 0 0 40px rgba(139, 92, 246, 0.3);
        }
        
        .nav-item {
          position: relative;
          transition: all 0.3s ease;
        }
        
        .nav-item::after {
          content: '';
          position: absolute;
          bottom: -2px;
          left: 50%;
          width: 0;
          height: 2px;
          background: linear-gradient(90deg, #8B5CF6, #EC4899);
          transition: all 0.3s ease;
          transform: translateX(-50%);
        }
        
        .nav-item:hover::after,
        .nav-item.active::after {
          width: 100%;
        }

        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        
        .float-animation {
          animation: float 6s ease-in-out infinite;
        }
      `}</style>

      {/* Fixed Header Container */}
      <div className="fixed top-0 left-0 right-0 z-50 flex flex-col">
        <AnnouncementBar />
        
        {/* Navigation */}
        <nav className={`w-full transition-all duration-300 ${
          scrolled ? 'bg-white/80 backdrop-blur-lg shadow-lg' : 'bg-transparent'
        }`}>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-20">
            {/* Logo */}
            <Link to={createPageUrl("Home")} className="flex items-center gap-3 group">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full blur-lg opacity-50 group-hover:opacity-75 transition-opacity"></div>
                <div className="relative w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-600 rounded-full flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                  Sacred Dragonfly
                </h1>
                <p className="text-xs text-gray-600">Energy • Reiki • Tarot</p>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-8">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  className={`nav-item flex items-center gap-2 px-4 py-2 text-sm font-medium transition-colors ${
                    isActive(item.path)
                      ? 'text-purple-600 active'
                      : 'text-gray-700 hover:text-purple-600'
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  {item.name}
                </Link>
              ))}
              {user?.role === 'admin' && (
                <>
                  <Link
                    to={createPageUrl("Dashboard")}
                    className={`nav-item flex items-center gap-2 px-4 py-2 text-sm font-medium transition-colors ${
                      isActive(createPageUrl("Dashboard"))
                        ? 'text-purple-600 active'
                        : 'text-gray-700 hover:text-purple-600'
                    }`}
                  >
                    <LayoutDashboard className="w-4 h-4" />
                    Dashboard
                  </Link>
                  <Link
                    to={createPageUrl("ClientManagement")}
                    className={`nav-item flex items-center gap-2 px-4 py-2 text-sm font-medium transition-colors ${
                      isActive(createPageUrl("ClientManagement"))
                        ? 'text-purple-600 active'
                        : 'text-gray-700 hover:text-purple-600'
                    }`}
                  >
                    <Users className="w-4 h-4" />
                    Clients
                  </Link>
                  <Link
                    to={createPageUrl("PractitionerChat")}
                    className={`nav-item flex items-center gap-2 px-4 py-2 text-sm font-medium transition-colors ${
                      isActive(createPageUrl("PractitionerChat"))
                        ? 'text-purple-600 active'
                        : 'text-gray-700 hover:text-purple-600'
                    }`}
                  >
                    <MessageSquare className="w-4 h-4" />
                    Messages
                  </Link>
                  <Link
                    to={createPageUrl("PractitionerSubscription")}
                    className={`nav-item flex items-center gap-2 px-4 py-2 text-sm font-medium transition-colors ${
                      isActive(createPageUrl("PractitionerSubscription"))
                        ? 'text-purple-600 active'
                        : 'text-gray-700 hover:text-purple-600'
                    }`}
                  >
                    <Crown className="w-4 h-4" />
                    Subscription
                  </Link>
                </>
              )}
            </div>

            {/* User Menu */}
            <div className="flex items-center gap-4">
              {user && (
                <div className="hidden md:flex items-center gap-3">
                  <span className="text-sm text-gray-700">{user.full_name}</span>
                  <Link 
                    to={createPageUrl("PractitionerDashboard")} 
                    className="text-sm font-medium text-purple-600 hover:text-purple-700 px-3 py-2 rounded-md hover:bg-purple-50 transition-colors"
                  >
                    Practitioner Area
                  </Link>
                  <button
                    onClick={() => base44.auth.logout()}
                    className="flex items-center gap-2 px-4 py-2 text-sm text-gray-700 hover:text-red-600 transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              )}
              
              {/* Global Search */}
              <GlobalSearch />

              {/* Share Button (Visible to everyone) */}
              <div className="hidden md:block">
                <ShareApp />
              </div>
            </div>

            {/* Mobile Menu Button */}
            <button className="md:hidden p-2">
              <div className="w-6 h-5 flex flex-col justify-between">
                <span className="w-full h-0.5 bg-gray-700 rounded"></span>
                <span className="w-full h-0.5 bg-gray-700 rounded"></span>
                <span className="w-full h-0.5 bg-gray-700 rounded"></span>
              </div>
            </button>
          </div>
        </div>
      </nav>
      </div>

      {/* Main Content */}
      <main className="pt-20">
        {children}
      </main>

      {/* AI Chatbot */}
      <HealingChatbot />

      {/* Footer */}
      <footer className="bg-gradient-to-r from-purple-900 via-pink-900 to-purple-900 text-white py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">Sacred Dragonfly</h3>
              <p className="text-purple-200">
                Transforming lives through energy healing, reiki, and spiritual guidance.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <div className="space-y-2">
                {publicNavigation.map((item) => (
                  <Link
                    key={item.name}
                    to={item.path}
                    className="block text-purple-200 hover:text-white transition-colors"
                  >
                    {item.name}
                  </Link>
                ))}
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Connect</h4>
              <p className="text-purple-200 mb-2">Email: info@sacred-dragonfly.org</p>
              <p className="text-purple-200">Phone: (207) 719-5798</p>
            </div>
          </div>
          <div className="border-t border-purple-800 mt-8 pt-8 text-center text-purple-200">
            <p>© 2025 Sacred Dragonfly. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
