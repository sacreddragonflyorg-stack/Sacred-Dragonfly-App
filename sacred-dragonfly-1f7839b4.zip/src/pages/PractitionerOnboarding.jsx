import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Loader2, Sparkles } from "lucide-react";
import { toast } from "sonner";

// Steps Components
import WelcomeStep from "../components/onboarding/practitioner/WelcomeStep";
import ProfileStep from "../components/onboarding/practitioner/ProfileStep";
import ServicesStep from "../components/onboarding/practitioner/ServicesStep";
import AvailabilityStep from "../components/onboarding/practitioner/AvailabilityStep";
import StripeStep from "../components/onboarding/practitioner/StripeStep";
import CompletionStep from "../components/onboarding/practitioner/CompletionStep";

const STEPS = [
  { id: 0, title: "Welcome" },
  { id: 1, title: "Profile" },
  { id: 2, title: "Services" },
  { id: 3, title: "Availability" },
  { id: 4, title: "Payouts" },
  { id: 5, title: "Complete" }
];

export default function PractitionerOnboarding() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [loading, setLoading] = useState(false);

  // Data State
  const [profileData, setProfileData] = useState({
    full_name: "", phone: "", bio: "", specialties: "", certifications: "", years_experience: "", tagline: "", payout_info: ""
  });
  const [agreementAccepted, setAgreementAccepted] = useState(false);
  const [serviceData, setServiceData] = useState({
    name: "", description: "", type: "energy_healing", duration_minutes: 60, price: "", pricing_model: "fixed", payment_methods: ['credit_card']
  });
  const [availability, setAvailability] = useState({
    monday: { enabled: true, start: '09:00', end: '17:00' },
    tuesday: { enabled: true, start: '09:00', end: '17:00' },
    wednesday: { enabled: true, start: '09:00', end: '17:00' },
    thursday: { enabled: true, start: '09:00', end: '17:00' },
    friday: { enabled: true, start: '09:00', end: '17:00' },
    saturday: { enabled: false, start: '09:00', end: '17:00' },
    sunday: { enabled: false, start: '09:00', end: '17:00' }
  });

  // Fetch Practitioner
  const { data: practitioner } = useQuery({
    queryKey: ['practitioner-profile', user?.email],
    queryFn: () => user ? base44.entities.Practitioner.filter({ user_email: user.email }).then(res => res[0]) : null,
    enabled: !!user
  });

  useEffect(() => {
    base44.auth.me().then((u) => {
      if (u.role !== 'admin') {
        navigate(createPageUrl("Home"));
        return;
      }
      setUser(u);
      setProfileData(prev => ({
        ...prev,
        full_name: u.full_name || "",
        phone: u.phone || "",
        bio: u.bio || "",
        specialties: u.specialties || "",
        certifications: u.certifications || "",
        years_experience: u.years_experience || "",
        tagline: u.tagline || ""
      }));
      // If user has verified stripe account or completed onboarding, maybe jump steps?
      if (u.onboarding_completed) {
         navigate(createPageUrl("PractitionerDashboard"));
      }
    }).catch(() => base44.auth.redirectToLogin());
  }, []);

  const updateProfileMutation = useMutation({
    mutationFn: async (data) => {
        // Update user
        await base44.auth.updateMe(data);
        
        // Update or Create Practitioner
        const pData = {
            user_email: user.email,
            display_name: data.full_name,
            bio: data.bio,
            title: data.specialties ? data.specialties.split(',')[0] : 'Healer',
            payout_info: data.payout_info,
            subcontractor_agreement_accepted: agreementAccepted,
            specialties: data.specialties ? data.specialties.split(',').map(s=>s.trim()) : [],
            years_experience: parseInt(data.years_experience) || 0,
            certifications: data.certifications ? [{name: data.certifications}] : [], // Simple map for now
            availability: availability,
            is_active: true
        };

        if (practitioner) {
            await base44.entities.Practitioner.update(practitioner.id, pData);
        } else {
            await base44.entities.Practitioner.create(pData);
        }
    },
    onSuccess: () => {
        queryClient.invalidateQueries(['practitioner-profile']);
        queryClient.invalidateQueries(['user']);
    }
  });

  const createServiceMutation = useMutation({
    mutationFn: async (data) => base44.entities.Service.create({ ...data, practitioner_email: user.email, is_active: true }),
    onSuccess: () => queryClient.invalidateQueries(['services'])
  });

  const handleNext = async () => {
    setLoading(true);
    try {
      if (currentStep === 1) { // Profile Step
         await updateProfileMutation.mutateAsync(profileData);
      } else if (currentStep === 2) { // Service Step
         // Check if service already created to avoid dupes if they go back/forth? 
         // For now simpler to just create. Or maybe we only create at the very end? 
         // User requested step-by-step so probably create as we go.
         await createServiceMutation.mutateAsync(serviceData);
      } else if (currentStep === 3) { // Availability Step
         // Already synced in profile mutation, but let's make sure
         if (practitioner) {
            await base44.entities.Practitioner.update(practitioner.id, { availability });
         }
      } else if (currentStep === 4) { // Payouts Step
         // Stripe logic is handled inside component, just need to mark complete here
         await base44.auth.updateMe({ onboarding_completed: true });
         if (practitioner) {
             await base44.entities.Practitioner.update(practitioner.id, { onboarding_status: 'approved' });
         }
      }
      
      setCurrentStep(prev => prev + 1);
    } catch (error) {
      toast.error("Error saving step: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => setCurrentStep(prev => prev - 1);

  if (!user) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="w-12 h-12 animate-spin text-purple-600" /></div>;

  const progress = (currentStep / (STEPS.length - 1)) * 100;

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full mb-4 border border-purple-200">
            <Sparkles className="w-4 h-4 text-purple-600" />
            <span className="text-sm font-medium text-purple-900">Practitioner Onboarding</span>
            </div>
            {currentStep > 0 && currentStep < 5 && (
                <Progress value={progress} className="h-2 w-64 mx-auto mt-4" />
            )}
        </div>

        <Card className="bg-white/90 backdrop-blur-sm shadow-2xl border-2 border-purple-100 min-h-[500px]">
             <CardHeader>
                {currentStep > 0 && currentStep < 5 && (
                    <CardTitle className="text-center text-xl text-gray-500">Step {currentStep} of 4: {STEPS[currentStep].title}</CardTitle>
                )}
             </CardHeader>
             <CardContent className="p-6">
                {currentStep === 0 && <WelcomeStep onNext={() => setCurrentStep(1)} user={user} />}
                
                {currentStep === 1 && <ProfileStep 
                    profileData={profileData} 
                    setProfileData={setProfileData} 
                    agreementAccepted={agreementAccepted}
                    setAgreementAccepted={setAgreementAccepted}
                    onNext={handleNext} 
                />}
                
                {currentStep === 2 && <ServicesStep 
                    serviceData={serviceData} 
                    setServiceData={setServiceData} 
                    onNext={handleNext} 
                    onBack={handleBack} 
                />}
                
                {currentStep === 3 && <AvailabilityStep 
                    availability={availability} 
                    setAvailability={setAvailability} 
                    onNext={handleNext} 
                    onBack={handleBack} 
                />}
                
                {currentStep === 4 && <StripeStep 
                    practitioner={practitioner} 
                    onNext={handleNext} 
                    onBack={handleBack} 
                />}
                
                {currentStep === 5 && <CompletionStep />}
             </CardContent>
        </Card>
      </div>
    </div>
  );
}