import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Calendar, 
  BookOpen, 
  User, 
  Heart, 
  Clock, 
  TrendingUp, 
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Video,
  Plus,
  Bell,
  Package,
  Award,
  Settings
} from "lucide-react";
import { format, isFuture, isPast, isWithinInterval, addDays } from "date-fns";
import { toast } from "sonner";
import DashboardPackages from "../components/client-dashboard/DashboardPackages";
import DashboardLearning from "../components/client-dashboard/DashboardLearning";
import DashboardPreferences from "../components/client-dashboard/DashboardPreferences";
import DashboardAppointmentHistory from "../components/client-dashboard/DashboardAppointmentHistory";

export default function ClientDashboard() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  const { data: appointments = [] } = useQuery({
    queryKey: ['client-appointments', user?.email],
    queryFn: () => {
      if (!user) return [];
      return base44.entities.Appointment.filter({ client_email: user.email }, '-appointment_date');
    },
    enabled: !!user,
  });

  const { data: tarotReadings = [] } = useQuery({
    queryKey: ['client-tarot-readings', user?.email],
    queryFn: () => {
      if (!user) return [];
      return base44.entities.TarotReading.list('-created_date', 10);
    },
    enabled: !!user,
  });

  const { data: progressEntries = [] } = useQuery({
    queryKey: ['client-progress-entries', user?.email],
    queryFn: () => {
      if (!user) return [];
      return base44.entities.ProgressEntry.filter({ created_by: user.email }, '-entry_date');
    },
    enabled: !!user,
  });

  const { data: liveSessions = [] } = useQuery({
    queryKey: ['client-live-sessions', user?.email],
    queryFn: () => {
      if (!user) return [];
      return base44.entities.LiveSession.filter({ client_email: user.email }, '-scheduled_start');
    },
    enabled: !!user,
  });

  const { data: packagePurchases = [] } = useQuery({
    queryKey: ['client-packages', user?.email],
    queryFn: () => {
      if (!user) return [];
      return base44.entities.PackagePurchase.filter({ client_email: user.email }, '-purchase_date');
    },
    enabled: !!user,
  });

  const { data: subscriptions = [] } = useQuery({
    queryKey: ['client-subscriptions', user?.email],
    queryFn: () => {
      if (!user) return [];
      return base44.entities.ClientSubscription.filter({ client_email: user.email }, '-created_date');
    },
    enabled: !!user,
  });

  const { data: learningResources = [] } = useQuery({
    queryKey: ['learning-resources'],
    queryFn: () => base44.entities.LearningResource.list(),
    enabled: !!user,
  });

  const { data: pointTransactions = [] } = useQuery({
    queryKey: ['point-transactions', user?.email],
    queryFn: () => {
      if (!user) return [];
      return base44.entities.PointTransaction.filter({ user_email: user.email }, '-transaction_date', 10);
    },
    enabled: !!user,
  });

  const sendReminderMutation = useMutation({
    mutationFn: async (appointmentId) => {
      const appointment = appointments.find(a => a.id === appointmentId);
      await base44.integrations.Core.SendEmail({
        to: appointment.client_email,
        subject: `Reminder: ${appointment.service_name} Session`,
        body: `Hi ${appointment.client_name},\n\nThis is a friendly reminder about your upcoming healing session:\n\nService: ${appointment.service_name}\nDate: ${format(new Date(appointment.appointment_date), 'EEEE, MMMM d, yyyy')}\nTime: ${format(new Date(appointment.appointment_date), 'h:mm a')}\n\nWe look forward to seeing you!\n\nWith love and light,\nSacred Healing`
      });
      return base44.entities.Appointment.update(appointmentId, {
        reminder_sent: true,
        reminder_sent_date: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['client-appointments']);
      toast.success("Reminder sent!");
    }
  });

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  const upcomingAppointments = appointments.filter(
    apt => isFuture(new Date(apt.appointment_date)) && apt.status !== 'cancelled'
  );
  const nextAppointment = upcomingAppointments[0];

  const completedSessions = appointments.filter(apt => apt.status === 'completed').length;
  const recentProgress = progressEntries.slice(0, 3);
  const entriesWithFeedback = progressEntries.filter(e => e.practitioner_feedback && !e.practitioner_viewed).length;
  const recentTarotReadings = tarotReadings.slice(0, 3);

  const activeLiveSessions = liveSessions.filter(s => 
    s.status === 'in_progress' || s.status === 'waiting'
  );

  // Appointments needing reminders (within 24-48 hours)
  const appointmentsNeedingReminder = upcomingAppointments.filter(apt => 
    !apt.reminder_sent && 
    isWithinInterval(new Date(apt.appointment_date), {
      start: new Date(),
      end: addDays(new Date(), 2)
    })
  );

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Welcome Header */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-pink-600 rounded-full flex items-center justify-center">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-gray-900">
                Welcome back, <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">{user.full_name || 'Friend'}</span>
              </h1>
              <p className="text-lg text-gray-600">Your healing journey at a glance</p>
            </div>
          </div>
        </div>

        {/* Active Session Alert */}
        {activeLiveSessions.length > 0 && (
          <Card className="mb-8 border-2 border-red-400 bg-red-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-900">
                <Video className="w-6 h-6 animate-pulse" />
                Live Session In Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-red-800 mb-4">You have an active healing session right now!</p>
              <Link to={createPageUrl("LiveSessions")}>
                <Button className="bg-red-600 hover:bg-red-700">
                  Join Session Now
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}

        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          <Card className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-xs font-medium text-gray-600">Upcoming</CardTitle>
              <Calendar className="w-4 h-4 text-blue-600" />
            </CardHeader>
            <CardContent className="pt-0">
              <div className="text-2xl font-bold text-gray-900">{upcomingAppointments.length}</div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-xs font-medium text-gray-600">Completed</CardTitle>
              <CheckCircle2 className="w-4 h-4 text-green-600" />
            </CardHeader>
            <CardContent className="pt-0">
              <div className="text-2xl font-bold text-gray-900">{completedSessions}</div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-xs font-medium text-gray-600">Packages</CardTitle>
              <Package className="w-4 h-4 text-amber-600" />
            </CardHeader>
            <CardContent className="pt-0">
              <div className="text-2xl font-bold text-gray-900">{packagePurchases.filter(p => p.status === 'active').length}</div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-xs font-medium text-gray-600">Points</CardTitle>
              <Award className="w-4 h-4 text-purple-600" />
            </CardHeader>
            <CardContent className="pt-0">
              <div className="text-2xl font-bold text-gray-900">{user.points_balance || 0}</div>
            </CardContent>
          </Card>

          <Card className={`bg-white/80 backdrop-blur-sm hover:shadow-xl transition-shadow ${entriesWithFeedback > 0 ? 'border-2 border-purple-400' : ''}`}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-xs font-medium text-gray-600">Feedback</CardTitle>
              <Heart className="w-4 h-4 text-pink-600" />
            </CardHeader>
            <CardContent className="pt-0">
              <div className="text-2xl font-bold text-gray-900">{entriesWithFeedback}</div>
            </CardContent>
          </Card>
        </div>

        {/* Next Appointment */}
        {nextAppointment && (
          <Card className="mb-8 bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-2xl">
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-2">
                <Clock className="w-6 h-6" />
                Your Next Session
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-xl font-semibold mb-2">{nextAppointment.service_name}</h3>
                  <div className="space-y-2 text-purple-100">
                    <p className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      {format(new Date(nextAppointment.appointment_date), 'EEEE, MMMM d, yyyy')}
                    </p>
                    <p className="flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      {format(new Date(nextAppointment.appointment_date), 'h:mm a')}
                    </p>
                  </div>
                  {!nextAppointment.client_confirmed && (
                    <Badge className="mt-4 bg-yellow-500 hover:bg-yellow-600">
                      Awaiting Confirmation
                    </Badge>
                  )}
                </div>
                <div className="flex flex-col items-end justify-center gap-3">
                  {appointmentsNeedingReminder.includes(nextAppointment) && (
                    <Button 
                      onClick={() => sendReminderMutation.mutate(nextAppointment.id)}
                      disabled={sendReminderMutation.isPending}
                      variant="outline"
                      className="bg-white/20 border-white text-white hover:bg-white/30"
                    >
                      <Bell className="w-4 h-4 mr-2" />
                      Send Reminder
                    </Button>
                  )}
                  <Link to={createPageUrl("MyAppointments")}>
                    <Button className="bg-white text-purple-600 hover:bg-purple-50">
                      View Details
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Quick Actions */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Link to={createPageUrl("Booking")}>
            <Card className="bg-gradient-to-br from-green-500 to-emerald-600 text-white hover:shadow-xl transition-all duration-300 cursor-pointer group h-full">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Plus className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-lg">Book New Session</CardTitle>
                    <p className="text-sm text-green-100">Schedule your healing</p>
                  </div>
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </div>
              </CardHeader>
            </Card>
          </Link>

          <Link to={createPageUrl("MyAppointments")}>
            <Card className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 cursor-pointer group h-full">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Calendar className="w-6 h-6 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-lg">My Appointments</CardTitle>
                    <p className="text-sm text-gray-600">View & manage sessions</p>
                  </div>
                  <ArrowRight className="w-5 h-5 text-gray-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </CardHeader>
            </Card>
          </Link>

          <Link to={createPageUrl("Progress")}>
            <Card className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 cursor-pointer group h-full">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                    <TrendingUp className="w-6 h-6 text-purple-600" />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-lg">My Progress</CardTitle>
                    <p className="text-sm text-gray-600">Track your journey</p>
                  </div>
                  <ArrowRight className="w-5 h-5 text-gray-400 group-hover:translate-x-1 transition-transform" />
                </div>
              </CardHeader>
            </Card>
          </Link>

          <Link to={createPageUrl("LoyaltyProgram")}>
            <Card className="bg-gradient-to-br from-amber-400 to-orange-500 text-white hover:shadow-xl transition-all duration-300 cursor-pointer group h-full">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Crown className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-lg">Loyalty Rewards</CardTitle>
                    <p className="text-sm text-amber-100">{user?.points_balance || 0} Points Available</p>
                  </div>
                  <ArrowRight className="w-5 h-5 text-white group-hover:translate-x-1 transition-transform" />
                </div>
              </CardHeader>
            </Card>
          </Link>
        </div>

        {/* Tabbed Dashboard Sections */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-white p-1 rounded-lg shadow flex-wrap h-auto">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="appointments">Appointments</TabsTrigger>
            <TabsTrigger value="packages">Packages</TabsTrigger>
            <TabsTrigger value="learning">Learning</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Upcoming Appointments */}
              <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl flex items-center gap-2">
                      <Calendar className="w-5 h-5 text-blue-600" />
                      Upcoming Sessions
                    </CardTitle>
                    <Link to={createPageUrl("MyAppointments")}>
                      <Button variant="outline" size="sm">View All</Button>
                    </Link>
                  </div>
                </CardHeader>
                <CardContent>
                  {upcomingAppointments.length === 0 ? (
                    <div className="text-center py-6">
                      <Calendar className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                      <p className="text-gray-500 text-sm mb-3">No upcoming sessions</p>
                      <Link to={createPageUrl("Booking")}>
                        <Button size="sm"><Plus className="w-4 h-4 mr-1" /> Book Session</Button>
                      </Link>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {upcomingAppointments.slice(0, 3).map((apt) => (
                        <div key={apt.id} className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-semibold text-sm text-gray-900">{apt.service_name}</h4>
                              <p className="text-xs text-gray-600">
                                {format(new Date(apt.appointment_date), 'MMM d • h:mm a')}
                              </p>
                            </div>
                            <Badge className={apt.status === 'confirmed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                              {apt.status}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Recent Tarot Readings */}
              <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-pink-600" />
                      Tarot Readings
                    </CardTitle>
                    <Link to={createPageUrl("Tarot")}>
                      <Button variant="outline" size="sm">New Reading</Button>
                    </Link>
                  </div>
                </CardHeader>
                <CardContent>
                  {recentTarotReadings.length === 0 ? (
                    <div className="text-center py-6">
                      <Sparkles className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                      <p className="text-gray-500 text-sm mb-3">No readings yet</p>
                      <Link to={createPageUrl("Tarot")}>
                        <Button size="sm"><Sparkles className="w-4 h-4 mr-1" /> Get Reading</Button>
                      </Link>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {recentTarotReadings.slice(0, 3).map((reading) => (
                        <div key={reading.id} className="p-3 bg-pink-50 rounded-lg border border-pink-200">
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-semibold text-sm text-gray-900">
                                {reading.spread_type.replace(/_/g, ' ')}
                              </h4>
                              <p className="text-xs text-gray-600">
                                {format(new Date(reading.created_date), 'MMM d, yyyy')}
                              </p>
                            </div>
                            <Badge className="bg-pink-100 text-pink-800">{reading.cards_drawn?.length || 0} cards</Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Progress & Packages Row */}
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Recent Progress */}
              <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-purple-600" />
                      Progress Journal
                    </CardTitle>
                    <Link to={createPageUrl("Progress")}>
                      <Button variant="outline" size="sm">View All</Button>
                    </Link>
                  </div>
                </CardHeader>
                <CardContent>
                  {recentProgress.length === 0 ? (
                    <div className="text-center py-6">
                      <BookOpen className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                      <p className="text-gray-500 text-sm mb-3">No entries yet</p>
                      <Link to={createPageUrl("Progress")}>
                        <Button size="sm"><Plus className="w-4 h-4 mr-1" /> Add Entry</Button>
                      </Link>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {recentProgress.slice(0, 3).map((entry) => (
                        <div key={entry.id} className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="font-semibold text-sm text-gray-900">
                                {format(new Date(entry.entry_date), 'MMM d, yyyy')}
                              </p>
                              {entry.mood && <p className="text-xs text-gray-600">Mood: {entry.mood}</p>}
                            </div>
                            {entry.practitioner_feedback && (
                              <Badge className="bg-purple-600 text-white text-xs">Feedback</Badge>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Points Summary */}
              <Card className="bg-gradient-to-br from-amber-50 to-orange-50 border-2 border-amber-200 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-xl flex items-center gap-2 text-amber-800">
                    <Crown className="w-5 h-5 text-amber-600" />
                    Loyalty Status: {user.loyalty_tier || 'Bronze'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-4xl font-bold text-amber-600">{user.points_balance || 0}</span>
                    <span className="text-sm text-gray-600">redeemable points</span>
                  </div>
                  <p className="text-sm text-gray-600 mb-4">
                    You have spent ${user.lifetime_spend || 0} lifetime. Reach the next tier for exclusive perks!
                  </p>
                  <div className="flex gap-2">
                    <Link to={createPageUrl("LoyaltyProgram")}>
                      <Button size="sm" className="bg-amber-600 hover:bg-amber-700 text-white">View Rewards</Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Appointments Tab */}
          <TabsContent value="appointments">
            <DashboardAppointmentHistory appointments={appointments} />
          </TabsContent>

          {/* Packages Tab */}
          <TabsContent value="packages">
            <DashboardPackages purchases={packagePurchases} subscriptions={subscriptions} />
          </TabsContent>

          {/* Learning Tab */}
          <TabsContent value="learning">
            <DashboardLearning user={user} resources={learningResources} />
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <DashboardPreferences user={user} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}