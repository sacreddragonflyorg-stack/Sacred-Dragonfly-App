import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Package, DollarSign, Calendar, CheckCircle2, ArrowRight, Sparkles, Clock, Loader2, CreditCard, Repeat, Search, Filter, SlidersHorizontal } from "lucide-react";
import { toast } from "sonner";
import { format, addDays, addMonths, addWeeks } from "date-fns";
import StripePaymentForm from "../components/payment/StripePaymentForm";
import PackageTierSelector from "../components/packages/PackageTierSelector";

export default function Packages() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [selectedTier, setSelectedTier] = useState(null);
  const [selectedValidity, setSelectedValidity] = useState(null);
  const [showTierSelector, setShowTierSelector] = useState(false);
  const [showValiditySelector, setShowValiditySelector] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [createdPurchase, setCreatedPurchase] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [packageTypeFilter, setPackageTypeFilter] = useState("all");
  const [priceRange, setPriceRange] = useState([0, 1000]);
  const [sortBy, setSortBy] = useState("name");

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  const { data: packages = [], isLoading } = useQuery({
    queryKey: ['active-packages'],
    queryFn: () => base44.entities.ServicePackage.filter({ is_active: true }),
  });

  // Sort: Put platform/admin packages first if any, then others
  // Or sort by creation date
  const sortedPackages = [...packages].sort((a, b) => {
      // Logic: If one has practitioner_email and other doesn't, maybe prioritize?
      // For now, let's just reverse chronological
      return new Date(b.created_date) - new Date(a.created_date);
  });

  // Filter and sort packages
  const filteredPackages = packages.filter(pkg => {
    // Show platform packages (practitioner_email is null/undefined) OR show all if that's desired behavior?
    // Usually platform packages page shows global packages + maybe practitioner ones if searched?
    // Let's show all active packages for now to allow discovery.
    
    const matchesSearch = searchQuery === "" || 
      pkg.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      pkg.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      pkg.benefits?.some(b => b.toLowerCase().includes(searchQuery.toLowerCase())) ||
      pkg.service_names?.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesType = packageTypeFilter === "all" || pkg.package_type === packageTypeFilter;
    
    const pkgPrice = pkg.pricing_tiers?.length > 0 
      ? Math.min(...pkg.pricing_tiers.map(t => t.price))
      : pkg.package_price || 0;
    const matchesPrice = pkgPrice >= priceRange[0] && pkgPrice <= priceRange[1];
    
    return matchesSearch && matchesType && matchesPrice;
  }).sort((a, b) => {
    const priceA = a.pricing_tiers?.length > 0 ? Math.min(...a.pricing_tiers.map(t => t.price)) : a.package_price;
    const priceB = b.pricing_tiers?.length > 0 ? Math.min(...b.pricing_tiers.map(t => t.price)) : b.package_price;
    
    switch (sortBy) {
      case "price_low": return priceA - priceB;
      case "price_high": return priceB - priceA;
      case "sessions": return b.total_sessions - a.total_sessions;
      case "savings": return (b.savings || 0) - (a.savings || 0);
      case "name": default: return a.name.localeCompare(b.name);
    }
  });

  const { data: myPurchases = [] } = useQuery({
    queryKey: ['my-package-purchases', user?.email],
    queryFn: () => user ? base44.entities.PackagePurchase.filter({ client_email: user.email, status: 'active' }) : [],
    enabled: !!user,
  });

  const createPurchaseMutation = useMutation({
    mutationFn: async ({ pkg, tier, validityDays }) => {
      if (!user) {
        base44.auth.redirectToLogin(window.location.pathname);
        throw new Error("Not authenticated");
      }

      const isSubscription = pkg.package_type === "subscription";
      const sessionsTotal = tier?.sessions_included || pkg.total_sessions;
      const purchasePrice = tier?.price || pkg.package_price;
      const validity = tier?.validity_days || validityDays || pkg.validity_days;
      
      let expiryDate;
      if (isSubscription) {
        // Calculate based on subscription interval
        switch (pkg.subscription_interval) {
          case 'weekly': expiryDate = addWeeks(new Date(), 1); break;
          case 'monthly': expiryDate = addMonths(new Date(), 1); break;
          case 'quarterly': expiryDate = addMonths(new Date(), 3); break;
          case 'yearly': expiryDate = addMonths(new Date(), 12); break;
          default: expiryDate = addMonths(new Date(), 1);
        }
      } else {
        expiryDate = addDays(new Date(), validity);
      }
      
      return base44.entities.PackagePurchase.create({
        package_id: pkg.id,
        package_name: pkg.name,
        package_type: pkg.package_type || "one_time",
        selected_tier: tier?.tier_name || null,
        client_email: user.email,
        client_name: user.full_name,
        purchase_price: purchasePrice,
        sessions_total: sessionsTotal,
        sessions_remaining: sessionsTotal,
        selected_validity_days: validityDays || validity,
        expiry_date: expiryDate.toISOString(),
        subscription_interval: isSubscription ? pkg.subscription_interval : null,
        current_period_start: isSubscription ? new Date().toISOString() : null,
        current_period_end: isSubscription ? expiryDate.toISOString() : null,
        auto_renew: isSubscription ? pkg.auto_renew : null,
        status: 'active',
        payment_status: 'pending',
        service_ids: pkg.service_ids,
        service_configs: pkg.service_configs || null
      });
    },
    onSuccess: (purchase) => {
      setCreatedPurchase(purchase);
      setShowPayment(true);
      setShowTierSelector(false);
      setShowValiditySelector(false);
    },
    onError: () => {
      toast.error("Failed to create purchase. Please try again.");
    }
  });

  const updatePurchasePaymentMutation = useMutation({
    mutationFn: async ({ purchaseId, paymentData }) => {
      await base44.entities.Payment.create({
        appointment_id: purchaseId,
        client_email: createdPurchase.client_email,
        amount: createdPurchase.purchase_price,
        status: 'completed',
        payment_method: 'credit_card',
        transaction_id: paymentData.payment_intent_id,
        payment_date: new Date().toISOString(),
        notes: `Payment for package: ${createdPurchase.package_name}`
      });

      return base44.entities.PackagePurchase.update(purchaseId, {
        payment_status: 'paid',
        stripe_payment_intent_id: paymentData.payment_intent_id,
        purchase_date: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['my-package-purchases']);
      toast.success("Package purchased successfully! 🎉");
      navigate(createPageUrl("ClientDashboard"));
    }
  });

  const handlePurchase = (pkg) => {
    if (!user) {
      base44.auth.redirectToLogin(window.location.pathname);
      return;
    }
    setSelectedPackage(pkg);
    
    // Check if package has tiers
    if (pkg.pricing_tiers && pkg.pricing_tiers.length > 0) {
      setShowTierSelector(true);
      return;
    }
    
    // Check if package has flexible validity
    if (pkg.flexible_validity && pkg.validity_options?.length > 0) {
      setShowValiditySelector(true);
      return;
    }
    
    // Direct purchase
    createPurchaseMutation.mutate({ pkg, tier: null, validityDays: null });
  };

  const handleTierSelected = (tier) => {
    setSelectedTier(tier);
    if (selectedPackage.flexible_validity) {
      setShowTierSelector(false);
      setShowValiditySelector(true);
    } else {
      createPurchaseMutation.mutate({ pkg: selectedPackage, tier, validityDays: null });
    }
  };

  const handleValiditySelected = (days) => {
    setSelectedValidity(days);
    createPurchaseMutation.mutate({ pkg: selectedPackage, tier: selectedTier, validityDays: days });
  };

  const handlePaymentSuccess = (paymentData) => {
    updatePurchasePaymentMutation.mutate({
      purchaseId: createdPurchase.id,
      paymentData
    });
  };

  const handlePaymentCancel = () => {
    setShowPayment(false);
    setSelectedPackage(null);
    toast.info("You can complete payment later from your dashboard");
  };

  // Tier Selector View
  if (showTierSelector && selectedPackage) {
    return (
      <div className="min-h-screen py-12 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <Button variant="outline" onClick={() => { setShowTierSelector(false); setSelectedPackage(null); }}>
              ← Back to Packages
            </Button>
          </div>
          <Card className="bg-white/80 backdrop-blur-sm shadow-2xl">
            <CardHeader>
              <CardTitle className="text-3xl">{selectedPackage.name}</CardTitle>
              <p className="text-gray-600">{selectedPackage.description}</p>
            </CardHeader>
            <CardContent>
              <PackageTierSelector pkg={selectedPackage} onSelectTier={handleTierSelected} />
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Validity Selector View
  if (showValiditySelector && selectedPackage) {
    return (
      <div className="min-h-screen py-12 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <Button variant="outline" onClick={() => { 
              setShowValiditySelector(false); 
              if (selectedPackage.pricing_tiers?.length > 0) {
                setShowTierSelector(true);
              } else {
                setSelectedPackage(null);
              }
            }}>
              ← Back
            </Button>
          </div>
          <Card className="bg-white/80 backdrop-blur-sm shadow-2xl">
            <CardHeader>
              <CardTitle className="text-3xl">Choose Validity Period</CardTitle>
              <p className="text-gray-600">How long would you like to use this package?</p>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                {selectedPackage.validity_options.map(days => (
                  <Card
                    key={days}
                    onClick={() => handleValiditySelected(days)}
                    className="cursor-pointer hover:shadow-xl transition-all border-2 hover:border-purple-600"
                  >
                    <CardContent className="text-center pt-8 pb-8">
                      <Clock className="w-12 h-12 mx-auto mb-4 text-purple-600" />
                      <p className="text-3xl font-bold text-gray-900">{days} Days</p>
                      <p className="text-sm text-gray-600 mt-2">
                        Valid until {format(addDays(new Date(), days), 'MMM d, yyyy')}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (showPayment && createdPurchase) {
    return (
      <div className="min-h-screen py-12">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Complete Your Purchase</h1>
            <p className="text-gray-600">Secure payment for {selectedPackage?.name}</p>
          </div>
          
          <StripePaymentForm
            amount={createdPurchase.purchase_price}
            description={`${createdPurchase.package_name} - ${createdPurchase.sessions_total} sessions`}
            metadata={{
              purchase_id: createdPurchase.id,
              client_email: createdPurchase.client_email,
              package_name: createdPurchase.package_name
            }}
            mode={createdPurchase.package_type === 'subscription' ? 'subscription' : 'payment'}
            planDetails={createdPurchase.package_type === 'subscription' ? {
                id: createdPurchase.package_id,
                billing_interval: createdPurchase.subscription_interval,
                name: createdPurchase.package_name
            } : null}
            onSuccess={handlePaymentSuccess}
            onCancel={handlePaymentCancel}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full mb-6 border border-purple-200">
            <Package className="w-4 h-4 text-purple-600" />
            <span className="text-sm font-medium text-purple-900">Service Packages</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Save More with <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Package Deals</span>
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Bundle multiple healing sessions at discounted prices and commit to your transformation
          </p>
        </div>

        {/* My Active Packages */}
        {user && myPurchases.length > 0 && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">My Active Packages</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {myPurchases.map((purchase) => (
                <Card key={purchase.id} className="border-2 border-green-200 bg-green-50">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-xl">{purchase.package_name}</CardTitle>
                      <Badge className="bg-green-600">Active</Badge>
                    </div>
                    {/* Show practitioner if applicable */}
                    {packages.find(p => p.id === purchase.package_id)?.practitioner_email && (
                        <p className="text-xs text-gray-500">Practitioner Bundle</p>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Sessions Remaining:</span>
                      <span className="font-bold text-green-700">
                        {purchase.sessions_remaining} / {purchase.sessions_total}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Expires:</span>
                      <span className="font-medium">{format(new Date(purchase.expiry_date), 'MMM d, yyyy')}</span>
                    </div>
                    <Button
                      onClick={() => navigate(createPageUrl("Booking"))}
                      size="sm"
                      className="w-full bg-green-600 hover:bg-green-700"
                    >
                      Book Session with Package
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Search and Filter Section */}
        <Card className="bg-white/80 backdrop-blur-sm shadow-xl mb-8">
          <CardContent className="pt-6">
            <div className="space-y-4">
              {/* Search Bar */}
              <div className="relative">
                <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                <Input
                  placeholder="Search packages by name, description, services, or benefits..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 h-12 text-lg"
                />
              </div>

              {/* Filters */}
              <div className="grid md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm flex items-center gap-2">
                    <Filter className="w-4 h-4" />
                    Package Type
                  </Label>
                  <Select value={packageTypeFilter} onValueChange={setPackageTypeFilter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="one_time">One-Time Purchase</SelectItem>
                      <SelectItem value="subscription">Subscription</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-sm flex items-center gap-2">
                    <DollarSign className="w-4 h-4" />
                    Min Price
                  </Label>
                  <Input
                    type="number"
                    min="0"
                    value={priceRange[0]}
                    onChange={(e) => setPriceRange([parseInt(e.target.value) || 0, priceRange[1]])}
                    placeholder="$0"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-sm">Max Price</Label>
                  <Input
                    type="number"
                    min="0"
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value) || 1000])}
                    placeholder="$1000"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-sm flex items-center gap-2">
                    <SlidersHorizontal className="w-4 h-4" />
                    Sort By
                  </Label>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="name">Name (A-Z)</SelectItem>
                      <SelectItem value="price_low">Price (Low to High)</SelectItem>
                      <SelectItem value="price_high">Price (High to Low)</SelectItem>
                      <SelectItem value="sessions">Most Sessions</SelectItem>
                      <SelectItem value="savings">Best Savings</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Results Count */}
              <div className="flex items-center justify-between pt-2 border-t">
                <p className="text-sm text-gray-600">
                  Showing <span className="font-semibold">{filteredPackages.length}</span> of {packages.length} packages
                </p>
                {(searchQuery || packageTypeFilter !== "all" || priceRange[0] > 0 || priceRange[1] < 1000) && (
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => {
                      setSearchQuery("");
                      setPackageTypeFilter("all");
                      setPriceRange([0, 1000]);
                    }}
                  >
                    Clear Filters
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Available Packages */}
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Available Packages</h2>
        
        {isLoading ? (
          <div className="text-center py-12">
            <Loader2 className="w-12 h-12 animate-spin text-purple-600 mx-auto" />
          </div>
        ) : filteredPackages.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600">
                {packages.length === 0 ? "No packages available at the moment" : "No packages match your search criteria"}
              </p>
              <p className="text-sm text-gray-500 mt-1">
                {packages.length === 0 ? "Check back soon for special bundled offerings" : "Try adjusting your filters or search query"}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPackages.map((pkg) => {
              const isSubscription = pkg.package_type === "subscription";
              const hasTiers = pkg.pricing_tiers && pkg.pricing_tiers.length > 0;
              
              return (
              <Card key={pkg.id} className="relative hover:shadow-2xl transition-all duration-300 border-2 border-purple-100 hover:border-purple-300 flex flex-col h-full">
                {isSubscription && (
                  <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-4 py-2 rounded-t-lg flex items-center justify-center gap-2">
                    <Repeat className="w-4 h-4" />
                    <span className="text-sm font-semibold">Recurring Subscription</span>
                  </div>
                )}
                {pkg.image_url && (
                  <div className="h-48 overflow-hidden rounded-t-lg">
                    <img src={pkg.image_url} alt={pkg.name} className="w-full h-full object-cover" />
                  </div>
                )}
                <CardHeader>
                  <CardTitle className="text-2xl">{pkg.name}</CardTitle>
                  <p className="text-sm text-gray-600">{pkg.description}</p>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Included Services */}
                  <div>
                    <p className="text-sm font-semibold text-gray-700 mb-3">Includes {pkg.total_sessions} sessions:</p>
                    <div className="space-y-2">
                      {pkg.service_names?.map((name, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-sm text-gray-700">
                          <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
                          <span>{name}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Benefits */}
                  {pkg.benefits && pkg.benefits.length > 0 && (
                    <div>
                      <p className="text-sm font-semibold text-gray-700 mb-3">Benefits:</p>
                      <div className="space-y-2">
                        {pkg.benefits.map((benefit, idx) => (
                          <div key={idx} className="flex items-center gap-2 text-sm text-gray-700">
                            <Sparkles className="w-4 h-4 text-purple-600 flex-shrink-0" />
                            <span>{benefit}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Pricing */}
                  <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg p-4 space-y-2">
                    {hasTiers ? (
                      <div>
                        <p className="text-sm text-gray-600 mb-2">Starting at:</p>
                        <div className="text-center">
                          <span className="text-3xl font-bold text-purple-600">
                            ${Math.min(...pkg.pricing_tiers.map(t => t.price)).toFixed(2)}
                          </span>
                          {isSubscription && (
                            <span className="text-sm text-gray-600">/{pkg.subscription_interval}</span>
                          )}
                        </div>
                        <p className="text-xs text-gray-500 text-center mt-2">
                          {pkg.pricing_tiers.length} tiers available
                        </p>
                      </div>
                    ) : (
                      <>
                        {pkg.regular_price && (
                          <div className="flex justify-between items-center text-sm">
                            <span className="text-gray-600">Regular Price:</span>
                            <span className="line-through text-gray-500">${pkg.regular_price.toFixed(2)}</span>
                          </div>
                        )}
                        <div className="flex justify-between items-center">
                          <span className="font-semibold text-gray-900">
                            {isSubscription ? 'Per Period:' : 'Package Price:'}
                          </span>
                          <div className="text-right">
                            <span className="text-3xl font-bold text-purple-600">${pkg.package_price.toFixed(2)}</span>
                            {isSubscription && (
                              <p className="text-xs text-gray-600">every {pkg.subscription_interval}</p>
                            )}
                          </div>
                        </div>
                        {pkg.savings && pkg.savings > 0 && (
                          <div className="flex justify-between items-center pt-2 border-t border-purple-200">
                            <span className="text-sm font-medium text-green-700">You Save:</span>
                            <span className="text-xl font-bold text-green-700">${pkg.savings.toFixed(0)}</span>
                          </div>
                        )}
                      </>
                    )}
                  </div>

                  {/* Validity */}
                  {!isSubscription && (
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Calendar className="w-4 h-4" />
                      {pkg.flexible_validity ? (
                        <span>Flexible validity period ({pkg.validity_options?.join(', ')} days)</span>
                      ) : (
                        <span>Valid for {pkg.validity_days} days after purchase</span>
                      )}
                    </div>
                  )}
                  {pkg.practitioner_email && (
                      <div className="mt-2 pt-2 border-t text-xs text-gray-500 flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-purple-400" />
                          Created by {pkg.practitioner_email}
                      </div>
                  )}
                  {isSubscription && (
                    <div className="flex items-center gap-2 text-sm text-blue-700 bg-blue-50 p-2 rounded">
                      <Repeat className="w-4 h-4" />
                      <span>{pkg.subscription_sessions_per_interval} sessions per {pkg.subscription_interval}</span>
                    </div>
                  )}

                  {/* Purchase Button */}
                  <Button
                    onClick={() => handlePurchase(pkg)}
                    disabled={createPurchaseMutation.isPending}
                    size="lg"
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                  >
                    {createPurchaseMutation.isPending ? (
                      <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Processing...</>
                    ) : (
                      <>
                        <CreditCard className="w-5 h-5 mr-2" />
                        {isSubscription ? 'Subscribe Now' : hasTiers ? 'Select Tier' : 'Purchase Package'}
                        <ArrowRight className="w-5 h-5 ml-2" />
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}