import Layout from "./Layout.jsx";

import Home from "./Home";

import Services from "./Services";

import Booking from "./Booking";

import MyAppointments from "./MyAppointments";

import Learning from "./Learning";

import Dashboard from "./Dashboard";

import Progress from "./Progress";

import Tarot from "./Tarot";

import LiveSessions from "./LiveSessions";

import AppointmentAction from "./AppointmentAction";

import ClientDashboard from "./ClientDashboard";

import ClientProfile from "./ClientProfile";

import PaymentSuccess from "./PaymentSuccess";

import Subscriptions from "./Subscriptions";

import PractitionerChat from "./PractitionerChat";

import ClientChat from "./ClientChat";

import ClientManagement from "./ClientManagement";

import PractitionerProfile from "./PractitionerProfile";

import PractitionerOnboarding from "./PractitionerOnboarding";

import PractitionerSubscription from "./PractitionerSubscription";

import ReferralProgram from "./ReferralProgram";

import Packages from "./Packages";

import PointsRedemption from "./PointsRedemption";

import Practitioners from "./Practitioners";

import PractitionerDetail from "./PractitionerDetail";

import LearningCenter from "./LearningCenter";

import ClientOnboarding from "./ClientOnboarding";

import PractitionerDashboard from "./PractitionerDashboard";

import LoyaltyProgram from "./LoyaltyProgram";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Home: Home,
    
    Services: Services,
    
    Booking: Booking,
    
    MyAppointments: MyAppointments,
    
    Learning: Learning,
    
    Dashboard: Dashboard,
    
    Progress: Progress,
    
    Tarot: Tarot,
    
    LiveSessions: LiveSessions,
    
    AppointmentAction: AppointmentAction,
    
    ClientDashboard: ClientDashboard,
    
    ClientProfile: ClientProfile,
    
    PaymentSuccess: PaymentSuccess,
    
    Subscriptions: Subscriptions,
    
    PractitionerChat: PractitionerChat,
    
    ClientChat: ClientChat,
    
    ClientManagement: ClientManagement,
    
    PractitionerProfile: PractitionerProfile,
    
    PractitionerOnboarding: PractitionerOnboarding,
    
    PractitionerSubscription: PractitionerSubscription,
    
    ReferralProgram: ReferralProgram,
    
    Packages: Packages,
    
    PointsRedemption: PointsRedemption,
    
    Practitioners: Practitioners,
    
    PractitionerDetail: PractitionerDetail,
    
    LearningCenter: LearningCenter,
    
    ClientOnboarding: ClientOnboarding,
    
    PractitionerDashboard: PractitionerDashboard,
    
    LoyaltyProgram: LoyaltyProgram,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Home />} />
                
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/Services" element={<Services />} />
                
                <Route path="/Booking" element={<Booking />} />
                
                <Route path="/MyAppointments" element={<MyAppointments />} />
                
                <Route path="/Learning" element={<Learning />} />
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Progress" element={<Progress />} />
                
                <Route path="/Tarot" element={<Tarot />} />
                
                <Route path="/LiveSessions" element={<LiveSessions />} />
                
                <Route path="/AppointmentAction" element={<AppointmentAction />} />
                
                <Route path="/ClientDashboard" element={<ClientDashboard />} />
                
                <Route path="/ClientProfile" element={<ClientProfile />} />
                
                <Route path="/PaymentSuccess" element={<PaymentSuccess />} />
                
                <Route path="/Subscriptions" element={<Subscriptions />} />
                
                <Route path="/PractitionerChat" element={<PractitionerChat />} />
                
                <Route path="/ClientChat" element={<ClientChat />} />
                
                <Route path="/ClientManagement" element={<ClientManagement />} />
                
                <Route path="/PractitionerProfile" element={<PractitionerProfile />} />
                
                <Route path="/PractitionerOnboarding" element={<PractitionerOnboarding />} />
                
                <Route path="/PractitionerSubscription" element={<PractitionerSubscription />} />
                
                <Route path="/ReferralProgram" element={<ReferralProgram />} />
                
                <Route path="/Packages" element={<Packages />} />
                
                <Route path="/PointsRedemption" element={<PointsRedemption />} />
                
                <Route path="/Practitioners" element={<Practitioners />} />
                
                <Route path="/PractitionerDetail" element={<PractitionerDetail />} />
                
                <Route path="/LearningCenter" element={<LearningCenter />} />
                
                <Route path="/ClientOnboarding" element={<ClientOnboarding />} />
                
                <Route path="/PractitionerDashboard" element={<PractitionerDashboard />} />
                
                <Route path="/LoyaltyProgram" element={<LoyaltyProgram />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}