import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { 
  BookOpen, Search, Award, Trophy, Play, CheckCircle2, 
  ArrowLeft, ChevronRight, Lock, Gift, Filter, Loader2, Target, Flame
} from "lucide-react";
import { toast } from "sonner";
import { addDays } from "date-fns";

import CourseCard from "../components/learning/CourseCard";
import ModuleContent from "../components/learning/ModuleContent";
import QuizComponent from "../components/learning/QuizComponent";
import PointsRedemptionPanel from "../components/learning/PointsRedemptionPanel";
import BadgeDisplay, { BADGE_DEFINITIONS } from "../components/learning/BadgeDisplay";
import Leaderboard from "../components/learning/Leaderboard";
import ChallengesPanel from "../components/learning/ChallengesPanel";
import ForumMain from "../components/community/ForumMain";
import AIPathGenerator from "../components/learning/AIPathGenerator";
import SkillTree from "../components/learning/SkillTree";
import MeditationLibrary from "../components/learning/MeditationLibrary";
import RelatedContent from "../components/common/RelatedContent";
import { Users as UsersIcon, Sparkles, GitBranch, Headphones } from "lucide-react";

export default function LearningCenter() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [isAISearching, setIsAISearching] = useState(false);
  const [aiSearchResults, setAiSearchResults] = useState(null);
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [difficultyFilter, setDifficultyFilter] = useState("all");
  const [activeCourse, setActiveCourse] = useState(null);
  const [activeModule, setActiveModule] = useState(null);
  const [showQuiz, setShowQuiz] = useState(false);
  const [activeQuiz, setActiveQuiz] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => base44.auth.redirectToLogin());
  }, []);

  const { data: courses = [], isLoading: coursesLoading } = useQuery({
    queryKey: ['learning-courses'],
    queryFn: () => base44.entities.LearningCourse.filter({ is_active: true }, 'order'),
  });

  const { data: modules = [] } = useQuery({
    queryKey: ['learning-modules', activeCourse?.id],
    queryFn: () => activeCourse ? base44.entities.LearningModule.filter({ course_id: activeCourse.id }, 'order') : [],
    enabled: !!activeCourse,
  });

  const { data: quizzes = [] } = useQuery({
    queryKey: ['learning-quizzes', activeCourse?.id],
    queryFn: () => activeCourse ? base44.entities.LearningQuiz.filter({ course_id: activeCourse.id }) : [],
    enabled: !!activeCourse,
  });

  const { data: userProgress = [] } = useQuery({
    queryKey: ['user-course-progress', user?.email],
    queryFn: () => user ? base44.entities.UserCourseProgress.filter({ user_email: user.email }) : [],
    enabled: !!user,
  });

  const { data: redemptions = [] } = useQuery({
    queryKey: ['user-redemptions', user?.email],
    queryFn: () => user ? base44.entities.PointRedemption.filter({ user_email: user.email }) : [],
    enabled: !!user,
  });

  const { data: userBadges = [] } = useQuery({
    queryKey: ['user-badges', user?.email],
    queryFn: () => user ? base44.entities.UserBadge.filter({ user_email: user.email }) : [],
    enabled: !!user,
  });

  const { data: challenges = [] } = useQuery({
    queryKey: ['learning-challenges'],
    queryFn: () => base44.entities.LearningChallenge.filter({ is_active: true }),
  });

  const { data: practitioners = [] } = useQuery({
    queryKey: ['practitioners'],
    queryFn: () => base44.entities.Practitioner.filter({ is_active: true }),
  });

  const { data: challengeProgress = [] } = useQuery({
    queryKey: ['user-challenge-progress', user?.email],
    queryFn: () => user ? base44.entities.UserChallengeProgress.filter({ user_email: user.email }) : [],
    enabled: !!user,
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['leaderboard-users'],
    queryFn: () => base44.entities.User.list('-learning_points', 20),
  });

  const getProgressForCourse = (courseId) => userProgress.find(p => p.course_id === courseId);
  const currentProgress = activeCourse ? getProgressForCourse(activeCourse.id) : null;

  // Start Course
  const startCourseMutation = useMutation({
    mutationFn: async (course) => {
      return base44.entities.UserCourseProgress.create({
        user_email: user.email,
        course_id: course.id,
        course_title: course.title,
        status: 'in_progress',
        started_at: new Date().toISOString(),
        progress_percentage: 0
      });
    },
    onSuccess: (_, course) => {
      queryClient.invalidateQueries(['user-course-progress']);
      setActiveCourse(course);
      toast.success("Course started! Let's begin your learning journey.");
    }
  });

  // Award badge helper
  const awardBadge = async (badgeId) => {
    const existing = userBadges.find(b => b.badge_id === badgeId);
    if (existing) return;
    const def = BADGE_DEFINITIONS[badgeId];
    if (!def) return;
    await base44.entities.UserBadge.create({
      user_email: user.email,
      badge_id: badgeId,
      badge_name: def.name,
      badge_icon: def.icon,
      badge_category: 'course_completion',
      description: def.description,
      earned_at: new Date().toISOString()
    });
    toast.success(`🏆 Badge earned: ${def.name}!`);
    queryClient.invalidateQueries(['user-badges']);
  };

  // Complete Module
  const completeModuleMutation = useMutation({
    mutationFn: async ({ module, progress }) => {
      const completedModules = [...(progress?.completed_modules || []), module.id];
      const totalModules = modules.length;
      const newPercentage = Math.round((completedModules.length / totalModules) * 100);
      const isComplete = newPercentage === 100;

      // Update progress
      const updateData = {
        completed_modules: completedModules,
        progress_percentage: newPercentage,
        last_accessed_module: module.id,
        status: isComplete ? 'completed' : 'in_progress',
        ...(isComplete && { completed_at: new Date().toISOString() })
      };

      await base44.entities.UserCourseProgress.update(progress.id, updateData);

      // Award points
      let pointsEarned = module.points_reward || 10;
      if (isComplete) pointsEarned += activeCourse.points_reward || 100;

      await base44.entities.PointTransaction.create({
        user_email: user.email,
        points: pointsEarned,
        type: 'earned',
        reason: isComplete ? `Completed course: ${activeCourse.title}` : `Completed module: ${module.title}`,
        resource_id: module.id,
        transaction_date: new Date().toISOString()
      });

      const newTotal = (user.learning_points || 0) + pointsEarned;
      await base44.auth.updateMe({ learning_points: newTotal });

      // Check for badge milestones
      const totalCompleted = completedModules.length + userProgress.reduce((sum, p) => sum + (p.completed_modules?.length || 0), 0);
      if (totalCompleted === 1) await awardBadge('first_module');
      if (totalCompleted >= 5) await awardBadge('five_modules');
      if (totalCompleted >= 10) await awardBadge('ten_modules');

      const coursesCompleted = userProgress.filter(p => p.status === 'completed').length + (isComplete ? 1 : 0);
      if (isComplete && coursesCompleted === 1) await awardBadge('first_course');
      if (coursesCompleted >= 3) await awardBadge('three_courses');

      if (newTotal >= 100) await awardBadge('points_100');
      if (newTotal >= 500) await awardBadge('points_500');
      if (newTotal >= 1000) await awardBadge('points_1000');

      // Update challenge progress
      const moduleChallenge = challengeProgress.find(cp => 
        challenges.find(c => c.id === cp.challenge_id && c.requirement_type === 'complete_modules' && cp.status === 'in_progress')
      );
      if (moduleChallenge) {
        const newProgress = (moduleChallenge.current_progress || 0) + 1;
        const challenge = challenges.find(c => c.id === moduleChallenge.challenge_id);
        await base44.entities.UserChallengeProgress.update(moduleChallenge.id, {
          current_progress: newProgress,
          status: newProgress >= challenge.requirement_count ? 'completed' : 'in_progress',
          ...(newProgress >= challenge.requirement_count && { completed_at: new Date().toISOString() })
        });
        if (newProgress >= challenge.requirement_count) {
          toast.success(`🎯 Challenge completed: ${challenge.title}!`);
          await awardBadge('challenge_complete');
        }
      }

      return { pointsEarned, isComplete };
    },
    onSuccess: ({ pointsEarned, isComplete }) => {
      queryClient.invalidateQueries(['user-course-progress']);
      queryClient.invalidateQueries(['user-challenge-progress']);
      setUser(prev => ({ ...prev, learning_points: (prev.learning_points || 0) + pointsEarned }));
      toast.success(`+${pointsEarned} points earned!${isComplete ? ' 🎉 Course completed!' : ''}`);
    }
  });

  // Complete Quiz
  const completeQuizMutation = useMutation({
    mutationFn: async ({ quiz, score, passed }) => {
      if (!passed) return { passed: false };

      const quizScore = {
        quiz_id: quiz.id,
        score,
        passed,
        completed_at: new Date().toISOString()
      };

      await base44.entities.UserCourseProgress.update(currentProgress.id, {
        quiz_scores: [...(currentProgress.quiz_scores || []), quizScore]
      });

      await base44.entities.PointTransaction.create({
        user_email: user.email,
        points: quiz.points_reward,
        type: 'earned',
        reason: `Passed quiz: ${quiz.title}`,
        resource_id: quiz.id,
        transaction_date: new Date().toISOString()
      });

      await base44.auth.updateMe({
        learning_points: (user.learning_points || 0) + quiz.points_reward
      });

      return { passed: true, points: quiz.points_reward };
    },
    onSuccess: ({ passed, points }) => {
      queryClient.invalidateQueries(['user-course-progress']);
      if (passed) {
        setUser(prev => ({ ...prev, learning_points: (prev.learning_points || 0) + points }));
      }
      setShowQuiz(false);
      setActiveQuiz(null);
    }
  });

  // Unlock Course
  const unlockCourseMutation = useMutation({
    mutationFn: async (course) => {
      await base44.entities.PointTransaction.create({
        user_email: user.email,
        points: -course.points_required,
        type: 'spent',
        reason: `Unlocked course: ${course.title}`,
        resource_id: course.id,
        transaction_date: new Date().toISOString()
      });

      await base44.entities.PointRedemption.create({
        user_email: user.email,
        redemption_type: 'course_unlock',
        item_id: course.id,
        item_name: course.title,
        points_spent: course.points_required,
        status: 'used'
      });

      await base44.auth.updateMe({
        learning_points: (user.learning_points || 0) - course.points_required
      });

      return base44.entities.UserCourseProgress.create({
        user_email: user.email,
        course_id: course.id,
        course_title: course.title,
        status: 'not_started',
        progress_percentage: 0
      });
    },
    onSuccess: (_, course) => {
      queryClient.invalidateQueries(['user-course-progress']);
      queryClient.invalidateQueries(['user-redemptions']);
      setUser(prev => ({ ...prev, learning_points: (prev.learning_points || 0) - course.points_required }));
      toast.success(`Course unlocked! You can now start ${course.title}`);
    }
  });

  // Redeem Points
  const redeemPointsMutation = useMutation({
    mutationFn: async (option) => {
      const discountCode = `HEAL${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
      
      await base44.entities.PointTransaction.create({
        user_email: user.email,
        points: -option.points,
        type: 'spent',
        reason: `Redeemed: ${option.title}`,
        transaction_date: new Date().toISOString()
      });

      await base44.entities.PointRedemption.create({
        user_email: user.email,
        redemption_type: option.type,
        item_name: option.title,
        points_spent: option.points,
        discount_amount: option.discount,
        discount_code: discountCode,
        status: 'active',
        expires_at: addDays(new Date(), 90).toISOString()
      });

      await base44.auth.updateMe({
        learning_points: (user.learning_points || 0) - option.points
      });

      return discountCode;
    },
    onSuccess: (code) => {
      queryClient.invalidateQueries(['user-redemptions']);
      setUser(prev => ({ ...prev, learning_points: (prev.learning_points || 0) }));
      toast.success(`Reward redeemed! ${code ? `Code: ${code}` : 'Check your rewards.'}`);
    }
  });

  // Join Challenge
  const joinChallengeMutation = useMutation({
    mutationFn: async (challenge) => {
      return base44.entities.UserChallengeProgress.create({
        user_email: user.email,
        challenge_id: challenge.id,
        challenge_title: challenge.title,
        current_progress: 0,
        requirement_count: challenge.requirement_count,
        status: 'in_progress'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['user-challenge-progress']);
      toast.success("Challenge joined! Start making progress.");
    }
  });

  // AI Search Mutation
  const aiSearchMutation = useMutation({
    mutationFn: async (query) => {
      const { data } = await base44.functions.invoke('searchLearningContent', { query });
      return data.results;
    },
    onSuccess: (results) => {
      setAiSearchResults(results);
      setIsAISearching(false);
    },
    onError: () => {
      setIsAISearching(false);
      toast.error("AI Search failed. Falling back to basic filter.");
    }
  });

  const handleSearch = (e) => {
    if (e.key === 'Enter' && searchQuery.length > 2) {
      setIsAISearching(true);
      aiSearchMutation.mutate(searchQuery);
    }
  };

  const clearSearch = () => {
    setSearchQuery("");
    setAiSearchResults(null);
  };

  // Filter courses (Mixed mode: AI results or basic filter)
  const filteredCourses = aiSearchResults 
    ? courses.filter(c => aiSearchResults.some(r => r.id === c.id && r.type === 'course'))
    : courses.filter(course => {
        const matchesSearch = searchQuery === "" ||
          course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          course.description?.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesCategory = categoryFilter === "all" || course.category === categoryFilter;
        const matchesDifficulty = difficultyFilter === "all" || course.difficulty_level === difficultyFilter;
        return matchesSearch && matchesCategory && matchesDifficulty;
      });
  
  // Sort AI results by relevance if active
  if (aiSearchResults) {
    filteredCourses.sort((a, b) => {
      const scoreA = aiSearchResults.find(r => r.id === a.id)?.relevance_score || 0;
      const scoreB = aiSearchResults.find(r => r.id === b.id)?.relevance_score || 0;
      return scoreB - scoreA;
    });
  }

  const categories = [...new Set(courses.map(c => c.category))];

  if (!user) {
    return <div className="min-h-screen flex items-center justify-center"><Loader2 className="w-12 h-12 animate-spin text-purple-600" /></div>;
  }

  // Course View
  if (activeCourse && !showQuiz) {
    const moduleQuiz = activeModule ? quizzes.find(q => q.module_id === activeModule.id) : null;
    const isModuleCompleted = currentProgress?.completed_modules?.includes(activeModule?.id);

    return (
      <div className="min-h-screen py-8 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
        <div className="max-w-6xl mx-auto px-4">
          {/* Back Button */}
          <Button variant="ghost" onClick={() => { setActiveCourse(null); setActiveModule(null); }} className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Courses
          </Button>

          <div className="grid lg:grid-cols-4 gap-6">
            {/* Sidebar - Module List */}
            <div className="lg:col-span-1">
              <Card className="sticky top-24">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">{activeCourse.title}</CardTitle>
                  <Progress value={currentProgress?.progress_percentage || 0} className="h-2" />
                  <p className="text-xs text-gray-500">{currentProgress?.progress_percentage || 0}% complete</p>
                </CardHeader>
                <CardContent className="space-y-1 p-2">
                  {modules.map((module, idx) => {
                    const isCompleted = currentProgress?.completed_modules?.includes(module.id);
                    const isActive = activeModule?.id === module.id;
                    return (
                      <button
                        key={module.id}
                        onClick={() => setActiveModule(module)}
                        className={`w-full text-left p-3 rounded-lg flex items-center gap-3 transition-all ${
                          isActive ? 'bg-purple-100 border-purple-300' : 'hover:bg-gray-50'
                        }`}
                      >
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                          isCompleted ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-600'
                        }`}>
                          {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                        </div>
                        <span className={`text-sm flex-1 ${isCompleted ? 'text-gray-500' : 'text-gray-900'}`}>
                          {module.title}
                        </span>
                        {module.has_quiz && <Badge variant="outline" className="text-xs">Quiz</Badge>}
                      </button>
                    );
                  })}
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-3">
              {activeModule ? (
                <ModuleContent
                  module={activeModule}
                  practitioner={practitioners.find(p => p.user_email === activeCourse.practitioner_email)}
                  isCompleted={isModuleCompleted}
                  onComplete={() => completeModuleMutation.mutate({ module: activeModule, progress: currentProgress })}
                  onStartQuiz={() => { setActiveQuiz(moduleQuiz); setShowQuiz(true); }}
                />
              ) : (
                <Card className="text-center py-12">
                  <CardContent>
                    <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-600">Select a module to begin learning</p>
                  </CardContent>
                </Card>
              )}
              
              {/* Related Courses */}
              <RelatedContent 
                type="course" 
                currentId={activeCourse.id} 
                category={activeCourse.category} 
                tags={activeCourse.tags} 
              />
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Quiz View
  if (showQuiz && activeQuiz) {
    return (
      <div className="min-h-screen py-12 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
        <div className="max-w-4xl mx-auto px-4">
          <Button variant="ghost" onClick={() => { setShowQuiz(false); setActiveQuiz(null); }} className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Module
          </Button>
          <QuizComponent
            quiz={activeQuiz}
            onComplete={(score, passed) => completeQuizMutation.mutate({ quiz: activeQuiz, score, passed })}
            onClose={() => { setShowQuiz(false); setActiveQuiz(null); }}
          />
        </div>
      </div>
    );
  }

  // Main Course List View
  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full mb-6 border border-purple-200">
            <BookOpen className="w-4 h-4 text-purple-600" />
            <span className="text-sm font-medium text-purple-900">Learning Center</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Expand Your <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Healing Knowledge</span>
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Complete courses, pass quizzes, and earn points to unlock rewards
          </p>
        </div>

        <Tabs defaultValue="courses" className="space-y-6">
          <TabsList className="bg-white p-1 rounded-lg shadow flex-wrap h-auto">
            <TabsTrigger value="path"><Sparkles className="w-4 h-4 mr-2" /> My AI Path</TabsTrigger>
            <TabsTrigger value="meditations"><Headphones className="w-4 h-4 mr-2" /> Meditations</TabsTrigger>
            <TabsTrigger value="skill-tree"><GitBranch className="w-4 h-4 mr-2" /> Skill Tree</TabsTrigger>
            <TabsTrigger value="courses"><BookOpen className="w-4 h-4 mr-2" /> Courses</TabsTrigger>
            <TabsTrigger value="challenges"><Target className="w-4 h-4 mr-2" /> Challenges</TabsTrigger>
            <TabsTrigger value="my-progress"><Trophy className="w-4 h-4 mr-2" /> My Progress</TabsTrigger>
            <TabsTrigger value="leaderboard"><Flame className="w-4 h-4 mr-2" /> Leaderboard</TabsTrigger>
            <TabsTrigger value="community"><UsersIcon className="w-4 h-4 mr-2" /> Community</TabsTrigger>
            <TabsTrigger value="rewards"><Gift className="w-4 h-4 mr-2" /> Rewards</TabsTrigger>
          </TabsList>

          {/* AI Path Tab */}
          <TabsContent value="path">
            <AIPathGenerator user={user} courses={courses} />
          </TabsContent>

          <TabsContent value="meditations">
            <MeditationLibrary />
          </TabsContent>

          <TabsContent value="skill-tree">
            <SkillTree 
              courses={courses} 
              userProgress={userProgress} 
              onStartCourse={(c) => { setActiveCourse(c); setActiveModule(null); }} 
            />
          </TabsContent>

          {/* Courses Tab */}
          <TabsContent value="courses" className="space-y-6">
            {/* Filters */}
            <Card className="bg-white/80">
              <CardContent className="pt-6">
                <div className="grid md:grid-cols-4 gap-4">
                  <div className="md:col-span-2 relative">
                    {isAISearching ? (
                      <Loader2 className="absolute left-3 top-3 w-5 h-5 text-purple-500 animate-spin" />
                    ) : (
                      <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                    )}
                    <Input
                      placeholder="Ask AI: 'I feel anxious' or 'Learn Reiki'..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      onKeyDown={handleSearch}
                      className={`pl-10 ${aiSearchResults ? 'border-purple-500 ring-1 ring-purple-500' : ''}`}
                    />
                    {aiSearchResults && (
                      <div className="absolute right-3 top-2.5">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-6 w-6 p-0 hover:bg-transparent"
                          onClick={clearSearch}
                        >
                          <span className="sr-only">Clear</span>
                          ✕
                        </Button>
                      </div>
                    )}
                  </div>
                  <Select value={categoryFilter} onValueChange={setCategoryFilter} disabled={!!aiSearchResults}>
                    <SelectTrigger>
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {categories.map(c => (
                        <SelectItem key={c} value={c}>{c?.replace(/_/g, ' ')}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Difficulty" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Levels</SelectItem>
                      <SelectItem value="beginner">Beginner</SelectItem>
                      <SelectItem value="intermediate">Intermediate</SelectItem>
                      <SelectItem value="advanced">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Course Grid */}
            {coursesLoading ? (
              <div className="text-center py-12"><Loader2 className="w-12 h-12 animate-spin text-purple-600 mx-auto" /></div>
            ) : filteredCourses.length === 0 ? (
              <Card className="text-center py-12">
                <CardContent>
                  <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-600">
                    {aiSearchResults ? "No matches found for your AI search. Try rephrasing?" : "No courses found"}
                  </p>
                  {aiSearchResults && <Button variant="link" onClick={clearSearch}>Clear Search</Button>}
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {aiSearchResults && (
                  <div className="flex items-center justify-between bg-purple-50 p-3 rounded-lg border border-purple-100">
                    <p className="text-sm text-purple-700 flex items-center gap-2">
                      <Sparkles className="w-4 h-4" /> 
                      AI found {filteredCourses.length} relevant results based on "{searchQuery}"
                    </p>
                    <Button variant="ghost" size="sm" onClick={clearSearch} className="h-auto py-1 text-purple-700 hover:text-purple-900">
                      Reset
                    </Button>
                  </div>
                )}
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredCourses.map(course => {
                    const aiReason = aiSearchResults?.find(r => r.id === course.id)?.reason;
                    const practitioner = practitioners.find(p => p.user_email === course.practitioner_email);
                    return (
                      <div key={course.id} className="relative group">
                        {aiReason && (
                          <div className="absolute -top-3 left-4 right-4 z-10">
                            <div className="bg-purple-600 text-white text-xs px-3 py-1 rounded-full shadow-lg text-center truncate">
                              {aiReason}
                            </div>
                          </div>
                        )}
                        <CourseCard
                          course={course}
                          practitioner={practitioner}
                          progress={getProgressForCourse(course.id)}
                          userPoints={user.learning_points || 0}
                          onStart={(c) => startCourseMutation.mutate(c)}
                          onContinue={(c) => { setActiveCourse(c); setActiveModule(null); }}
                          onUnlock={(c) => unlockCourseMutation.mutate(c)}
                        />
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </TabsContent>

          {/* Challenges Tab */}
          <TabsContent value="challenges">
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <ChallengesPanel 
                  challenges={challenges}
                  userProgress={challengeProgress}
                  onJoinChallenge={(c) => joinChallengeMutation.mutate(c)}
                />
              </div>
              <div>
                <BadgeDisplay badges={userBadges} showAll={false} />
              </div>
            </div>
          </TabsContent>

          {/* My Progress Tab */}
          <TabsContent value="my-progress">
            <div className="grid md:grid-cols-4 gap-6 mb-8">
              <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
                <CardContent className="pt-6">
                  <Trophy className="w-10 h-10 text-purple-200 mb-2" />
                  <p className="text-4xl font-bold">{userProgress.filter(p => p.status === 'completed').length}</p>
                  <p className="text-purple-100">Courses Completed</p>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-pink-500 to-pink-600 text-white">
                <CardContent className="pt-6">
                  <Play className="w-10 h-10 text-pink-200 mb-2" />
                  <p className="text-4xl font-bold">{userProgress.filter(p => p.status === 'in_progress').length}</p>
                  <p className="text-pink-100">In Progress</p>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-amber-500 to-amber-600 text-white">
                <CardContent className="pt-6">
                  <Award className="w-10 h-10 text-amber-200 mb-2" />
                  <p className="text-4xl font-bold">{user.learning_points || 0}</p>
                  <p className="text-amber-100">Total Points</p>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-teal-500 to-teal-600 text-white">
                <CardContent className="pt-6">
                  <Award className="w-10 h-10 text-teal-200 mb-2" />
                  <p className="text-4xl font-bold">{userBadges.length}</p>
                  <p className="text-teal-100">Badges Earned</p>
                </CardContent>
              </Card>
            </div>

            {/* Badges Section */}
            <div className="mb-8">
              <BadgeDisplay badges={userBadges} showAll={true} />
            </div>

            {/* Progress List */}
            <div className="space-y-4">
              {userProgress.length === 0 ? (
                <Card className="text-center py-12">
                  <CardContent>
                    <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-600">Start a course to track your progress</p>
                  </CardContent>
                </Card>
              ) : (
                userProgress.map(progress => {
                  const course = courses.find(c => c.id === progress.course_id);
                  return (
                    <Card key={progress.id} className="hover:shadow-lg transition-shadow">
                      <CardContent className="pt-6">
                        <div className="flex items-center gap-4">
                          <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                            {course?.image_url ? (
                              <img src={course.image_url} alt="" className="w-full h-full object-cover" />
                            ) : (
                              <div className="w-full h-full bg-purple-200 flex items-center justify-center">
                                <BookOpen className="w-6 h-6 text-purple-600" />
                              </div>
                            )}
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold text-gray-900">{progress.course_title}</h3>
                            <div className="flex items-center gap-4 mt-1">
                              <Progress value={progress.progress_percentage} className="h-2 flex-1" />
                              <span className="text-sm text-gray-500">{progress.progress_percentage}%</span>
                            </div>
                          </div>
                          <Badge className={progress.status === 'completed' ? 'bg-green-500' : 'bg-purple-500'}>
                            {progress.status.replace('_', ' ')}
                          </Badge>
                          <Button
                            variant="outline"
                            onClick={() => { setActiveCourse(course); setActiveModule(null); }}
                          >
                            {progress.status === 'completed' ? 'Review' : 'Continue'}
                            <ChevronRight className="w-4 h-4 ml-1" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>
          </TabsContent>

          {/* Leaderboard Tab */}
          <TabsContent value="leaderboard">
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Leaderboard users={allUsers} currentUserEmail={user.email} period="all" />
              </div>
              <div className="space-y-6">
                <Card className="bg-gradient-to-br from-purple-600 to-pink-600 text-white">
                  <CardContent className="pt-6 text-center">
                    <p className="text-purple-100 text-sm">Your Rank</p>
                    <p className="text-5xl font-bold">
                      #{allUsers.findIndex(u => u.email === user.email) + 1 || '-'}
                    </p>
                    <p className="text-purple-200 text-sm mt-2">of {allUsers.length} learners</p>
                  </CardContent>
                </Card>
                <BadgeDisplay badges={userBadges} showAll={false} />
              </div>
            </div>
          </TabsContent>

          {/* Community Tab */}
          <TabsContent value="community">
            <ForumMain user={user} redemptions={redemptions} />
          </TabsContent>

          {/* Rewards Tab */}
          <TabsContent value="rewards">
            <PointsRedemptionPanel
              userPoints={user.learning_points || 0}
              onRedeem={(option) => redeemPointsMutation.mutate(option)}
              existingRedemptions={redemptions}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}