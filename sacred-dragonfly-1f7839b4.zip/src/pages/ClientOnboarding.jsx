import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import WelcomeStep from "../components/onboarding/WelcomeStep";
import PersonalDetailsStep from "../components/onboarding/PersonalDetailsStep";
import HealthIntakeStep from "../components/onboarding/HealthIntakeStep";
import ExpectationsStep from "../components/onboarding/ExpectationsStep";
import CompletionStep from "../components/onboarding/CompletionStep";

export default function ClientOnboarding() {
  const [step, setStep] = useState(1);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [formData, setFormData] = useState({});

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      setFormData({
        full_name: u.full_name || "",
        phone: u.phone || "",
        date_of_birth: u.date_of_birth || "",
        address_street: u.address_street || "",
        address_city: u.address_city || "",
        address_state: u.address_state || "",
        address_zip: u.address_zip || "",
        address_country: u.address_country || "",
        bio: u.bio || "",
        healing_intentions: u.healing_intentions || "",
        medical_conditions: u.medical_conditions || "",
        current_medications: u.current_medications || "",
        allergies: u.allergies || "",
        emergency_contact_name: u.emergency_contact_name || "",
        emergency_contact_phone: u.emergency_contact_phone || "",
        emergency_contact_relationship: u.emergency_contact_relationship || "",
        preferred_contact_method: u.preferred_contact_method || "email"
      });
      setIsLoading(false);
    }).catch(() => {
      base44.auth.redirectToLogin();
    });
  }, []);

  const updateProfileMutation = useMutation({
    mutationFn: async (data) => {
      return base44.auth.updateMe(data);
    },
    onSuccess: (updatedUser) => {
      setUser(updatedUser);
      // Don't toast on every step save, only if needed or on final
    },
    onError: () => {
      toast.error("Failed to save progress");
    }
  });

  const handleUpdateFormData = (newData) => {
    setFormData(prev => ({ ...prev, ...newData }));
  };

  const nextStep = () => {
    // Save current progress before moving
    updateProfileMutation.mutate(formData);
    setStep(prev => prev + 1);
    window.scrollTo(0, 0);
  };

  const prevStep = () => {
    setStep(prev => prev - 1);
    window.scrollTo(0, 0);
  };

  const completeOnboarding = () => {
    updateProfileMutation.mutate({ 
      ...formData, 
      onboarding_completed: true 
    }, {
      onSuccess: () => {
        setStep(5); // Completion step
        toast.success("Onboarding completed!");
      }
    });
  };

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center"><Loader2 className="animate-spin w-12 h-12 text-purple-600" /></div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Progress Bar */}
        {step < 5 && (
          <div className="mb-8">
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-purple-600 to-pink-600 transition-all duration-500 ease-in-out"
                style={{ width: `${(step / 4) * 100}%` }}
              />
            </div>
            <div className="flex justify-between text-xs text-gray-500 mt-2">
              <span>Welcome</span>
              <span>Details</span>
              <span>Health</span>
              <span>Expectations</span>
            </div>
          </div>
        )}

        <div className="bg-white/80 backdrop-blur-md rounded-2xl shadow-xl p-8 md:p-12 min-h-[600px] flex flex-col justify-center">
          {step === 1 && (
            <WelcomeStep 
              onNext={nextStep} 
              user={user} 
            />
          )}

          {step === 2 && (
            <PersonalDetailsStep 
              formData={formData} 
              updateFormData={handleUpdateFormData}
              onNext={nextStep}
              onBack={prevStep}
            />
          )}

          {step === 3 && (
            <HealthIntakeStep 
              formData={formData} 
              updateFormData={handleUpdateFormData}
              onNext={nextStep}
              onBack={prevStep}
            />
          )}

          {step === 4 && (
            <ExpectationsStep 
              onNext={completeOnboarding}
              onBack={prevStep}
            />
          )}

          {step === 5 && (
            <CompletionStep user={user} />
          )}
        </div>
      </div>
    </div>
  );
}