import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { Calendar, CheckCircle2, Loader2, Heart, DollarSign, CreditCard, User, ArrowLeft, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import StripePaymentForm from "../components/payment/StripePaymentForm";
import PractitionerSelector from "../components/booking/PractitionerSelector";
import PractitionerAvailability from "../components/booking/PractitionerAvailability";
import BookingConfirmation from "../components/booking/BookingConfirmation";

export default function Booking() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [step, setStep] = useState(1); // 1: Service, 2: Practitioner, 3: Details, 4: Confirm, 5: Payment
  const [user, setUser] = useState(null);
  const [selectedService, setSelectedService] = useState("");
  const [selectedPractitioner, setSelectedPractitioner] = useState(null);
  const [showPayment, setShowPayment] = useState(false);
  const [createdAppointment, setCreatedAppointment] = useState(null);
  const [usePackage, setUsePackage] = useState(null);
  const [formData, setFormData] = useState({
    client_name: "",
    client_email: "",
    phone: "",
    appointment_date: "",
    appointment_time: "",
    notes: "",
    preferred_method: "live_video",
    payment_method: "",
    custom_amount: ""
  });

  const { data: services = [], isLoading: servicesLoading } = useQuery({
    queryKey: ['services'],
    queryFn: () => base44.entities.Service.filter({ is_active: true }),
  });

  const { data: practitioners = [] } = useQuery({
    queryKey: ['practitioners'],
    queryFn: () => base44.entities.Practitioner.filter({ is_active: true }),
  });

  const { data: packages = [] } = useQuery({
    queryKey: ['user-packages', user?.email],
    queryFn: () => user ? base44.entities.PackagePurchase.filter({ client_email: user.email, status: 'active' }) : [],
    enabled: !!user,
  });

  const { data: subscriptions = [] } = useQuery({
    queryKey: ['user-subscriptions', user?.email],
    queryFn: () => user ? base44.entities.ClientSubscription.filter({ client_email: user.email, status: 'active' }) : [],
    enabled: !!user,
  });

  // Parse URL params
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const serviceId = urlParams.get('service');
    const practitionerId = urlParams.get('practitioner');
    
    if (serviceId) setSelectedService(serviceId);
    if (practitionerId) setSelectedPractitioner(practitionerId);
    
    if (serviceId && practitionerId) setStep(3);
    else if (serviceId) setStep(2);
  }, []);

  // Load user data
  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      setFormData(prev => ({
        ...prev,
        client_name: u.full_name || "",
        client_email: u.email || "",
        phone: u.phone || ""
      }));
    }).catch(() => setUser(null));
  }, []);

  const selectedServiceData = services.find(s => s.id === selectedService);
  const selectedPractitionerData = practitioners.find(p => p.id === selectedPractitioner);

  const createAppointmentMutation = useMutation({
    mutationFn: async (data) => {
      const service = services.find(s => s.id === selectedService);
      const appointmentDateTime = `${data.appointment_date}T${data.appointment_time}`;
      
      let finalPrice = usePackage ? 0 : service.price;
      if (!usePackage && service.pricing_model === 'sliding_scale' && data.custom_amount) {
        finalPrice = parseFloat(data.custom_amount);
      } else if (!usePackage && service.pricing_model === 'donation' && data.custom_amount) {
        finalPrice = parseFloat(data.custom_amount);
      }

      const appointmentData = {
        service_id: selectedService,
        service_name: service.name,
        client_name: data.client_name,
        client_email: data.client_email,
        phone: data.phone,
        appointment_date: appointmentDateTime,
        notes: `${selectedPractitionerData ? `Practitioner: ${selectedPractitionerData.display_name}\n` : ''}Preferred Method: ${data.preferred_method}\n${usePackage ? `Using Package: ${usePackage.package_name || usePackage.plan_name}\n` : `Payment Method: ${data.payment_method || 'To be arranged'}\n`}\n${data.notes}`,
        price: finalPrice,
        status: "pending",
        payment_status: usePackage ? "paid" : "pending"
      };

      const appointment = await base44.entities.Appointment.create(appointmentData);

      // If using a package, update the package
      if (usePackage) {
        if (usePackage.sessions_remaining !== undefined) {
          // It's a package purchase
          await base44.entities.PackagePurchase.update(usePackage.id, {
            sessions_used: (usePackage.sessions_used || 0) + 1,
            sessions_remaining: usePackage.sessions_remaining - 1,
            used_session_ids: [...(usePackage.used_session_ids || []), appointment.id]
          });
        } else {
          // It's a subscription
          await base44.entities.ClientSubscription.update(usePackage.id, {
            sessions_used: (usePackage.sessions_used || 0) + 1
          });
        }
      }

      return { appointment, service };
    },
    onSuccess: async ({ appointment, service }) => {
      queryClient.invalidateQueries(['appointments']);
      queryClient.invalidateQueries(['user-packages']);
      queryClient.invalidateQueries(['user-subscriptions']);

      // Sync to Google Calendar
      try {
        base44.functions.invoke('syncToGoogleCalendar', { appointment_id: appointment.id });
      } catch (err) {
        console.error("Failed to sync calendar", err);
      }

      if (usePackage) {
        base44.functions.invoke('sendBookingConfirmation', { appointment_id: appointment.id });
        toast.success("Session booked using your package!");
        navigate(createPageUrl("MyAppointments"));
      } else if (formData.payment_method === 'credit_card') {
        setCreatedAppointment(appointment);
        setShowPayment(true);
      } else {
        base44.functions.invoke('sendBookingConfirmation', { appointment_id: appointment.id });
        toast.success("Session booked! Payment instructions will be sent via email.");
        navigate(createPageUrl("MyAppointments"));
      }
    },
    onError: () => {
      toast.error("Failed to book session. Please try again.");
    }
  });

  const updateAppointmentPaymentMutation = useMutation({
    mutationFn: async ({ appointmentId, paymentData }) => {
      await base44.entities.Payment.create({
        appointment_id: appointmentId,
        client_email: createdAppointment.client_email,
        amount: createdAppointment.price,
        status: 'completed',
        payment_method: 'credit_card',
        transaction_id: paymentData.payment_intent_id,
        payment_date: new Date().toISOString()
      });

      return base44.entities.Appointment.update(appointmentId, {
        payment_status: 'paid',
        stripe_payment_intent_id: paymentData.payment_intent_id,
        status: 'confirmed'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['appointments']);
      base44.functions.invoke('sendBookingConfirmation', { appointment_id: createdAppointment.id });
      navigate(`${createPageUrl("PaymentSuccess")}?appointment_id=${createdAppointment.id}`);
    }
  });

  const handleSubmit = () => {
    if (!selectedService) {
      toast.error("Please select a service");
      return;
    }
    if (!formData.appointment_date || !formData.appointment_time) {
      toast.error("Please select a date and time");
      return;
    }
    const service = services.find(s => s.id === selectedService);
    if (!usePackage && service.pricing_model !== 'energy_exchange' && !formData.payment_method) {
      toast.error("Please select a payment method");
      return;
    }
    createAppointmentMutation.mutate(formData);
  };

  const handleUsePackage = (pkg, type = 'package') => {
    setUsePackage(pkg);
    handleSubmit();
  };

  const handleSlotSelect = (date, time) => {
    setFormData(prev => ({ ...prev, appointment_date: date, appointment_time: time }));
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Payment Screen
  if (showPayment && createdAppointment) {
    return (
      <div className="min-h-screen py-12">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Complete Your Payment</h1>
            <p className="text-gray-600">Secure your healing session with a quick payment</p>
          </div>
          
          <StripePaymentForm
            amount={createdAppointment.price}
            description={`${createdAppointment.service_name} - ${createdAppointment.client_name}`}
            metadata={{
              appointment_id: createdAppointment.id,
              client_email: createdAppointment.client_email,
              service_name: createdAppointment.service_name
            }}
            onSuccess={(paymentData) => updateAppointmentPaymentMutation.mutate({ appointmentId: createdAppointment.id, paymentData })}
            onCancel={() => { setShowPayment(false); toast.info("You can complete payment later"); navigate(createPageUrl("MyAppointments")); }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full mb-6 border border-purple-200">
            <Calendar className="w-4 h-4 text-purple-600" />
            <span className="text-sm font-medium text-purple-900">Book Your Healing Session</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Begin Your <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Healing Journey</span>
          </h1>
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {['Service', 'Practitioner', 'Schedule', 'Confirm'].map((label, idx) => (
            <React.Fragment key={label}>
              <button
                onClick={() => idx + 1 < step && setStep(idx + 1)}
                className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  step === idx + 1 ? 'bg-purple-600 text-white' : 
                  step > idx + 1 ? 'bg-purple-100 text-purple-700 cursor-pointer hover:bg-purple-200' : 
                  'bg-gray-100 text-gray-400'
                }`}
              >
                <span className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center text-xs">
                  {step > idx + 1 ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                </span>
                <span className="hidden md:inline">{label}</span>
              </button>
              {idx < 3 && <div className={`w-8 h-0.5 ${step > idx + 1 ? 'bg-purple-400' : 'bg-gray-200'}`} />}
            </React.Fragment>
          ))}
        </div>

        <Card className="border-none shadow-2xl bg-white/80 backdrop-blur-sm">
          <CardContent className="pt-6">
            {/* Step 1: Service Selection */}
            {step === 1 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-semibold mb-2">Select a Service</h2>
                  <p className="text-gray-600">Choose the healing modality that resonates with you</p>
                </div>
                
                <div className="grid md:grid-cols-2 gap-4">
                  {servicesLoading ? (
                    <div className="col-span-2 text-center py-12"><Loader2 className="w-8 h-8 animate-spin mx-auto text-purple-600" /></div>
                  ) : services.map(service => (
                    <Card 
                      key={service.id}
                      onClick={() => setSelectedService(service.id)}
                      className={`cursor-pointer transition-all ${selectedService === service.id ? 'ring-2 ring-purple-600 bg-purple-50' : 'hover:shadow-lg'}`}
                    >
                      <CardContent className="pt-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-semibold text-gray-900">{service.name}</h3>
                            <p className="text-sm text-gray-600">{service.duration_minutes} minutes</p>
                          </div>
                          <span className="text-lg font-bold text-purple-600">${service.price}</span>
                        </div>
                        <p className="text-sm text-gray-500 mt-2 line-clamp-2">{service.description}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                <div className="flex justify-end">
                  <Button 
                    onClick={() => setStep(2)} 
                    disabled={!selectedService}
                    className="bg-gradient-to-r from-purple-600 to-pink-600"
                  >
                    Continue <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </div>
            )}

            {/* Step 2: Practitioner Selection */}
            {step === 2 && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-semibold mb-2">Choose Your Practitioner</h2>
                    <p className="text-gray-600">Select a healer or let us assign the best match</p>
                  </div>
                  <Button variant="outline" onClick={() => setStep(1)}>
                    <ArrowLeft className="w-4 h-4 mr-2" /> Back
                  </Button>
                </div>

                <PractitionerSelector 
                  practitioners={practitioners}
                  selectedId={selectedPractitioner}
                  onSelect={setSelectedPractitioner}
                  serviceId={selectedService}
                />

                <div className="flex justify-end">
                  <Button 
                    onClick={() => setStep(3)}
                    className="bg-gradient-to-r from-purple-600 to-pink-600"
                  >
                    Continue <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </div>
            )}

            {/* Step 3: Schedule & Details */}
            {step === 3 && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-semibold mb-2">Schedule & Details</h2>
                    <p className="text-gray-600">Pick a time and provide your information</p>
                  </div>
                  <Button variant="outline" onClick={() => setStep(2)}>
                    <ArrowLeft className="w-4 h-4 mr-2" /> Back
                  </Button>
                </div>

                {/* Practitioner Availability */}
                {selectedPractitioner && selectedPractitionerData && (
                  <PractitionerAvailability
                    practitioner={selectedPractitionerData}
                    serviceDuration={selectedServiceData?.duration_minutes}
                    selectedDate={formData.appointment_date}
                    selectedTime={formData.appointment_time}
                    onSelectSlot={handleSlotSelect}
                  />
                )}

                {/* Manual Date/Time if no practitioner selected */}
                {!selectedPractitioner && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Select Date & Time</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Preferred Date *</Label>
                          <Input
                            type="date"
                            value={formData.appointment_date}
                            onChange={(e) => handleInputChange('appointment_date', e.target.value)}
                            min={new Date().toISOString().split('T')[0]}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Preferred Time *</Label>
                          <Input
                            type="time"
                            value={formData.appointment_time}
                            onChange={(e) => handleInputChange('appointment_time', e.target.value)}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Client Info */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <User className="w-5 h-5 text-purple-600" />
                      Your Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Full Name *</Label>
                        <Input
                          value={formData.client_name}
                          onChange={(e) => handleInputChange('client_name', e.target.value)}
                          placeholder="Your full name"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Email *</Label>
                        <Input
                          type="email"
                          value={formData.client_email}
                          onChange={(e) => handleInputChange('client_email', e.target.value)}
                          placeholder="your@email.com"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Phone</Label>
                      <Input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                        placeholder="+1 (555) 123-4567"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Preferred Method</Label>
                      <Select value={formData.preferred_method} onValueChange={(v) => handleInputChange('preferred_method', v)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="live_video">🎥 Live Video Session</SelectItem>
                          <SelectItem value="email">📧 Email Healing</SelectItem>
                          <SelectItem value="text">💬 Text/Message Healing</SelectItem>
                          <SelectItem value="practitioner_choice">✨ Practitioner's Choice</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Notes (optional)</Label>
                      <Textarea
                        value={formData.notes}
                        onChange={(e) => handleInputChange('notes', e.target.value)}
                        placeholder="Share what brings you to healing today..."
                        rows={3}
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Payment Method */}
                {selectedServiceData && selectedServiceData.pricing_model !== 'energy_exchange' && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <CreditCard className="w-5 h-5 text-green-600" />
                        Payment Method
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {(selectedServiceData.pricing_model === 'sliding_scale' || selectedServiceData.pricing_model === 'donation') && (
                        <div className="space-y-2">
                          <Label>
                            {selectedServiceData.pricing_model === 'sliding_scale' 
                              ? `Choose Your Price ($${selectedServiceData.sliding_scale_min} - $${selectedServiceData.sliding_scale_max})` 
                              : 'Donation Amount'}
                          </Label>
                          <Input
                            type="number"
                            step="0.01"
                            value={formData.custom_amount}
                            onChange={(e) => handleInputChange('custom_amount', e.target.value)}
                            placeholder={`Suggested: $${selectedServiceData.price}`}
                          />
                        </div>
                      )}
                      <RadioGroup value={formData.payment_method} onValueChange={(v) => handleInputChange('payment_method', v)}>
                        {selectedServiceData.payment_methods?.map((method) => (
                          <div key={method} className="flex items-center space-x-2 p-3 bg-gray-50 rounded-lg border hover:border-purple-300">
                            <RadioGroupItem value={method} id={method} />
                            <Label htmlFor={method} className="flex-1 cursor-pointer">
                              {method === 'credit_card' && '💳 Credit Card'}
                              {method === 'paypal' && 'PayPal'}
                              {method === 'venmo' && 'Venmo'}
                              {method === 'cashapp' && 'Cash App'}
                              {method === 'bank_transfer' && '🏦 Bank Transfer'}
                              {method === 'cash' && '💵 Cash'}
                              {method === 'one_bank' && 'One Bank'}
                              {method === 'dave_bank' && 'Dave Bank'}
                              {method === 'chime_bank' && 'Chime Bank'}
                              {method === 'google_pay' && 'Google Pay'}
                              </Label>
                              </div>
                              ))}
                              </RadioGroup>

                              {/* Payment Instructions Display */}
                              {formData.payment_method && formData.payment_method !== 'credit_card' && selectedPractitionerData?.payment_handles && (
                              <div className="mt-4 p-4 bg-purple-50 rounded-lg border border-purple-100 animate-in fade-in">
                              <h4 className="font-semibold text-purple-900 mb-2">Payment Instructions</h4>
                              <p className="text-sm text-gray-700 mb-2">
                              Please send payment to the practitioner using the details below:
                              </p>
                              <div className="font-medium text-lg text-purple-700">
                              {formData.payment_method === 'paypal' && (selectedPractitionerData.payment_handles.paypal_link || "Details provided in email")}
                              {formData.payment_method === 'venmo' && (selectedPractitionerData.payment_handles.venmo_handle || "Details provided in email")}
                              {formData.payment_method === 'cashapp' && (selectedPractitionerData.payment_handles.cashapp_tag || "Details provided in email")}
                              {formData.payment_method === 'chime_bank' && (selectedPractitionerData.payment_handles.chime_sign || "Details provided in email")}
                              {formData.payment_method === 'dave_bank' && (selectedPractitionerData.payment_handles.dave_link || "Details provided in email")}
                              {formData.payment_method === 'one_bank' && (selectedPractitionerData.payment_handles.one_link || "Details provided in email")}
                              {formData.payment_method === 'google_pay' && (selectedPractitionerData.payment_handles.google_pay_link || "Details provided in email")}
                              </div>
                              </div>
                              )}
                              </CardContent>
                  </Card>
                )}

                <div className="flex justify-end">
                  <Button 
                    onClick={() => setStep(4)}
                    disabled={!formData.appointment_date || !formData.appointment_time || !formData.client_name || !formData.client_email}
                    className="bg-gradient-to-r from-purple-600 to-pink-600"
                  >
                    Review Booking <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </div>
            )}

            {/* Step 4: Confirmation */}
            {step === 4 && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-semibold mb-2">Confirm Your Booking</h2>
                    <p className="text-gray-600">Review and complete your session booking</p>
                  </div>
                  <Button variant="outline" onClick={() => setStep(3)}>
                    <ArrowLeft className="w-4 h-4 mr-2" /> Back
                  </Button>
                </div>

                <BookingConfirmation
                  service={selectedServiceData}
                  practitioner={selectedPractitionerData}
                  date={formData.appointment_date}
                  time={formData.appointment_time}
                  price={formData.custom_amount || selectedServiceData?.price}
                  packages={packages}
                  subscriptions={subscriptions}
                  onProceedToPayment={handleSubmit}
                  onUsePackage={handleUsePackage}
                />

                {createAppointmentMutation.isPending && (
                  <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
                    <Card className="p-8">
                      <Loader2 className="w-12 h-12 animate-spin text-purple-600 mx-auto mb-4" />
                      <p className="text-center">Processing your booking...</p>
                    </Card>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}