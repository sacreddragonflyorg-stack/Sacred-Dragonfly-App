import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sparkles, Clock, ArrowRight, CheckCircle2, DollarSign, Heart, Search, Filter, SlidersHorizontal } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const categoryColors = {
  tarot_reading: "from-purple-500 to-pink-500",
  reiki_healing: "from-pink-500 to-amber-500",
  energy_healing: "from-amber-500 to-purple-500",
  chakra_balancing: "from-purple-500 to-blue-500",
  crystal_healing: "from-blue-500 to-pink-500"
};

const formatPrice = (service) => {
  if (service.pricing_model === 'energy_exchange') {
    return { display: 'Energy Exchange', icon: <Heart className="w-4 h-4 text-purple-600" /> };
  }
  if (service.pricing_model === 'donation') {
    return { 
      display: service.price > 0 ? `Suggested $${service.price}` : 'Donation-Based',
      icon: <Heart className="w-4 h-4 text-green-600" />
    };
  }
  if (service.pricing_model === 'sliding_scale') {
    return {
      display: `$${service.sliding_scale_min} - $${service.sliding_scale_max}`,
      icon: <DollarSign className="w-4 h-4 text-blue-600" />
    };
  }
  return {
    display: `$${service.price}`,
    icon: <DollarSign className="w-4 h-4 text-purple-600" />
  };
};

export default function Services() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedType, setSelectedType] = useState("all");
  const [priceRange, setPriceRange] = useState([0, 500]);
  const [sortBy, setSortBy] = useState("name");

  const { data: services, isLoading } = useQuery({
    queryKey: ['services'],
    queryFn: () => base44.entities.Service.filter({ is_active: true }),
    initialData: [],
  });

  // Filter and sort services
  const filteredServices = services.filter(service => {
    const matchesSearch = searchQuery === "" || 
      service.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      service.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      service.benefits?.some(b => b.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesType = selectedType === "all" || service.type === selectedType;
    const matchesPrice = service.price >= priceRange[0] && service.price <= priceRange[1];
    
    return matchesSearch && matchesType && matchesPrice;
  }).sort((a, b) => {
    switch (sortBy) {
      case "price_low": return a.price - b.price;
      case "price_high": return b.price - a.price;
      case "duration": return a.duration_minutes - b.duration_minutes;
      case "name": default: return a.name.localeCompare(b.name);
    }
  });

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full mb-6 border border-purple-200">
            <Sparkles className="w-4 h-4 text-purple-600" />
            <span className="text-sm font-medium text-purple-900">Distance Healing Services</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Choose Your Path to <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Healing</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-4">
            All sessions conducted remotely through live video, email, or text
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-50 rounded-full">
            <Heart className="w-4 h-4 text-purple-600" />
            <span className="text-sm text-purple-900">Flexible pricing & payment options</span>
          </div>
        </div>

        {/* Search and Filter Section */}
        <Card className="bg-white/80 backdrop-blur-sm shadow-xl mb-8">
          <CardContent className="pt-6">
            <div className="space-y-4">
              {/* Search Bar */}
              <div className="relative">
                <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                <Input
                  placeholder="Search services by name, description, or benefits..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 h-12 text-lg"
                />
              </div>

              {/* Filters */}
              <div className="grid md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm flex items-center gap-2">
                    <Filter className="w-4 h-4" />
                    Service Type
                  </Label>
                  <Select value={selectedType} onValueChange={setSelectedType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="tarot_reading">Tarot Reading</SelectItem>
                      <SelectItem value="reiki_healing">Reiki Healing</SelectItem>
                      <SelectItem value="energy_healing">Energy Healing</SelectItem>
                      <SelectItem value="chakra_balancing">Chakra Balancing</SelectItem>
                      <SelectItem value="crystal_healing">Crystal Healing</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-sm flex items-center gap-2">
                    <DollarSign className="w-4 h-4" />
                    Min Price
                  </Label>
                  <Input
                    type="number"
                    min="0"
                    value={priceRange[0]}
                    onChange={(e) => setPriceRange([parseInt(e.target.value) || 0, priceRange[1]])}
                    placeholder="$0"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-sm">Max Price</Label>
                  <Input
                    type="number"
                    min="0"
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value) || 500])}
                    placeholder="$500"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-sm flex items-center gap-2">
                    <SlidersHorizontal className="w-4 h-4" />
                    Sort By
                  </Label>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="name">Name (A-Z)</SelectItem>
                      <SelectItem value="price_low">Price (Low to High)</SelectItem>
                      <SelectItem value="price_high">Price (High to Low)</SelectItem>
                      <SelectItem value="duration">Duration (Shortest First)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Results Count */}
              <div className="flex items-center justify-between pt-2 border-t">
                <p className="text-sm text-gray-600">
                  Showing <span className="font-semibold">{filteredServices.length}</span> of {services.length} services
                </p>
                {(searchQuery || selectedType !== "all" || priceRange[0] > 0 || priceRange[1] < 500) && (
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => {
                      setSearchQuery("");
                      setSelectedType("all");
                      setPriceRange([0, 500]);
                    }}
                  >
                    Clear Filters
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Services Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="h-48 w-full" />
                <CardHeader>
                  <Skeleton className="h-8 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-full" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-20 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredServices.length === 0 ? (
          <div className="text-center py-20">
            <Sparkles className="w-16 h-16 text-purple-300 mx-auto mb-4" />
            <h3 className="text-2xl font-semibold text-gray-700 mb-2">
              {services.length === 0 ? "No Services Available" : "No Services Match Your Criteria"}
            </h3>
            <p className="text-gray-500">
              {services.length === 0 ? "Please check back soon for our healing services" : "Try adjusting your filters or search query"}
            </p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredServices.map((service) => {
              const priceInfo = formatPrice(service);
              return (
                <Card key={service.id} className="group overflow-hidden hover:shadow-2xl transition-all duration-300 border-none bg-white/80 backdrop-blur-sm flex flex-col h-full">
                  {/* Service Image */}
                  <div className={`relative h-48 bg-gradient-to-br ${categoryColors[service.type] || 'from-purple-500 to-pink-500'} overflow-hidden`}>
                    {service.image_url ? (
                      <img src={service.image_url} alt={service.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
                    ) : (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Sparkles className="w-16 h-16 text-white/50" />
                      </div>
                    )}
                    <div className="absolute top-4 right-4">
                      <Badge className="bg-white/90 text-purple-900 hover:bg-white">
                        {service.type.replace(/_/g, ' ').toUpperCase()}
                      </Badge>
                    </div>
                    {service.pricing_model !== 'fixed' && (
                      <div className="absolute top-4 left-4">
                        <Badge className="bg-green-500/90 text-white">
                          {service.pricing_model === 'sliding_scale' ? 'Sliding Scale' : 
                           service.pricing_model === 'donation' ? 'Donation' : 'Energy Exchange'}
                        </Badge>
                      </div>
                    )}
                  </div>

                  <CardHeader>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">{service.name}</h3>
                    <p className="text-gray-600 leading-relaxed">{service.description}</p>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    {/* Benefits */}
                    {service.benefits && service.benefits.length > 0 && (
                      <div className="space-y-2">
                        {service.benefits.slice(0, 3).map((benefit, index) => (
                          <div key={index} className="flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-purple-600 mt-0.5 flex-shrink-0" />
                            <span className="text-sm text-gray-700">{benefit}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Details */}
                    <div className="flex items-center justify-between pt-4 border-t">
                      <div className="flex items-center gap-2 text-gray-600">
                        <Clock className="w-4 h-4" />
                        <span className="text-sm">{service.duration_minutes} min</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {priceInfo.icon}
                        <span className="text-sm text-purple-600 font-medium">{priceInfo.display}</span>
                      </div>
                    </div>

                    {/* Payment Methods */}
                    {service.payment_methods && service.payment_methods.length > 0 && (
                      <div className="pt-2">
                        <p className="text-xs text-gray-500 mb-2">Accepts:</p>
                        <div className="flex flex-wrap gap-1">
                          {service.payment_methods.slice(0, 3).map((method) => (
                            <Badge key={method} variant="outline" className="text-xs">
                              {method.replace(/_/g, ' ')}
                            </Badge>
                          ))}
                          {service.payment_methods.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{service.payment_methods.length - 3} more
                            </Badge>
                          )}
                        </div>
                      </div>
                    )}
                  </CardContent>

                  <CardFooter className="mt-auto pt-6">
                    <Link to={`${createPageUrl("Booking")}?service=${service.id}`} className="w-full">
                      <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full group-hover:shadow-lg transition-all duration-300">
                        Book This Service
                        <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              );
            })}
          </div>
        )}

        {/* Distance Methods Info */}
        <div className="mt-20 bg-gradient-to-r from-purple-50 to-pink-50 rounded-3xl p-8 md:p-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">All Services Available Via</h2>
            <p className="text-gray-600">Choose the distance healing method that works best for you</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center p-6 bg-white rounded-2xl">
              <div className="text-4xl mb-3">🎥</div>
              <h3 className="font-semibold mb-2">Live Video</h3>
              <p className="text-sm text-gray-600">Real-time interactive healing sessions</p>
            </div>
            <div className="text-center p-6 bg-white rounded-2xl">
              <div className="text-4xl mb-3">📧</div>
              <h3 className="font-semibold mb-2">Email Healing</h3>
              <p className="text-sm text-gray-600">Detailed correspondence and energy work</p>
            </div>
            <div className="text-center p-6 bg-white rounded-2xl">
              <div className="text-4xl mb-3">💬</div>
              <h3 className="font-semibold mb-2">Text/Message</h3>
              <p className="text-sm text-gray-600">Convenient messaging-based sessions</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}