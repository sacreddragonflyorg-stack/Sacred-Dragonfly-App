import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { CheckCircle2, Calendar, Clock, User, Mail, XCircle, Loader2, Heart } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

export default function AppointmentAction() {
  const queryClient = useQueryClient();
  const [appointmentId, setAppointmentId] = useState(null);
  const [action, setAction] = useState(null);
  const [rescheduleData, setRescheduleData] = useState({
    new_date: "",
    new_time: "",
    reason: ""
  });

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');
    const actionType = urlParams.get('action');
    setAppointmentId(id);
    setAction(actionType);
  }, []);

  const { data: appointment, isLoading } = useQuery({
    queryKey: ['appointment', appointmentId],
    queryFn: async () => {
      const appointments = await base44.entities.Appointment.list();
      return appointments.find(a => a.id === appointmentId);
    },
    enabled: !!appointmentId,
  });

  const confirmMutation = useMutation({
    mutationFn: async () => {
      return base44.entities.Appointment.update(appointmentId, {
        client_confirmed: true,
        client_confirmed_date: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['appointment', appointmentId]);
      toast.success("Appointment confirmed! You'll receive a reminder closer to your session.");
    },
  });

  const cancelMutation = useMutation({
    mutationFn: async () => {
      return base44.entities.Appointment.update(appointmentId, {
        status: 'cancelled'
      });
    },
    onSuccess: async () => {
      queryClient.invalidateQueries(['appointment', appointmentId]);
      toast.success("Appointment cancelled. We'll be in touch if you'd like to reschedule.");
      
      // Notify practitioner
      await base44.integrations.Core.SendEmail({
        to: appointment.created_by,
        subject: `Appointment Cancelled - ${appointment.client_name}`,
        body: `Client ${appointment.client_name} has cancelled their appointment for ${format(new Date(appointment.appointment_date), 'PPP p')}.`
      });
    },
  });

  const rescheduleMutation = useMutation({
    mutationFn: async (data) => {
      const newDateTime = `${data.new_date}T${data.new_time}`;
      return base44.entities.Appointment.update(appointmentId, {
        reschedule_requested: true,
        reschedule_reason: data.reason,
        notes: `${appointment.notes}\n\n[Reschedule Request] Requested new time: ${newDateTime}\nReason: ${data.reason}`
      });
    },
    onSuccess: async () => {
      queryClient.invalidateQueries(['appointment', appointmentId]);
      toast.success("Reschedule request sent! The practitioner will contact you to confirm the new time.");
      
      // Notify practitioner
      const newDateTime = `${rescheduleData.new_date}T${rescheduleData.new_time}`;
      await base44.integrations.Core.SendEmail({
        to: appointment.created_by,
        subject: `Reschedule Request - ${appointment.client_name}`,
        body: `Client ${appointment.client_name} has requested to reschedule their appointment.\n\nOriginal: ${format(new Date(appointment.appointment_date), 'PPP p')}\nRequested: ${format(new Date(newDateTime), 'PPP p')}\n\nReason: ${rescheduleData.reason}`
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-purple-600" />
      </div>
    );
  }

  if (!appointment) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <XCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Appointment Not Found</h2>
            <p className="text-gray-600">This appointment link may be invalid or expired.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (appointment.status === 'cancelled') {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <XCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Appointment Cancelled</h2>
            <p className="text-gray-600">This appointment has been cancelled.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-purple-50 via-pink-50 to-amber-50">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Appointment Details Card */}
        <Card className="mb-8 border-2 border-purple-200 shadow-xl">
          <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
            <CardTitle className="text-2xl">Your Healing Session</CardTitle>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <div className="grid gap-4">
              <div className="flex items-center gap-3">
                <Heart className="w-5 h-5 text-purple-600" />
                <div>
                  <p className="text-sm text-gray-600">Service</p>
                  <p className="font-semibold">{appointment.service_name}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-purple-600" />
                <div>
                  <p className="text-sm text-gray-600">Date & Time</p>
                  <p className="font-semibold">{format(new Date(appointment.appointment_date), 'EEEE, MMMM d, yyyy')}</p>
                  <p className="text-sm text-gray-600">{format(new Date(appointment.appointment_date), 'h:mm a')}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <User className="w-5 h-5 text-purple-600" />
                <div>
                  <p className="text-sm text-gray-600">Client</p>
                  <p className="font-semibold">{appointment.client_name}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-purple-600" />
                <div>
                  <p className="text-sm text-gray-600">Email</p>
                  <p className="font-semibold">{appointment.client_email}</p>
                </div>
              </div>
            </div>

            {appointment.client_confirmed && (
              <div className="mt-4 p-3 bg-green-50 rounded-lg border border-green-200 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                <span className="text-sm text-green-900 font-medium">
                  You confirmed this appointment on {format(new Date(appointment.client_confirmed_date), 'MMM d, yyyy')}
                </span>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Action Cards */}
        {action === 'confirm' && !appointment.client_confirmed && (
          <Card className="border-2 border-green-200 shadow-xl">
            <CardHeader className="bg-green-50">
              <CardTitle className="flex items-center gap-2 text-green-900">
                <CheckCircle2 className="w-6 h-6" />
                Confirm Your Appointment
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <p className="text-gray-700 mb-6">
                Please confirm that you'll attend this healing session. We'll send you a reminder closer to your appointment date.
              </p>
              <div className="flex gap-4">
                <Button
                  onClick={() => confirmMutation.mutate()}
                  disabled={confirmMutation.isPending}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  size="lg"
                >
                  {confirmMutation.isPending ? (
                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Confirming...</>
                  ) : (
                    <><CheckCircle2 className="w-4 h-4 mr-2" /> Yes, Confirm Appointment</>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {action === 'reschedule' && (
          <Card className="border-2 border-blue-200 shadow-xl">
            <CardHeader className="bg-blue-50">
              <CardTitle className="flex items-center gap-2 text-blue-900">
                <Clock className="w-6 h-6" />
                Request to Reschedule
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <p className="text-gray-700 mb-6">
                Need to change your appointment time? Let us know your preferred new date and time.
              </p>
              <form onSubmit={(e) => { e.preventDefault(); rescheduleMutation.mutate(rescheduleData); }} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Preferred New Date *</Label>
                    <Input
                      type="date"
                      value={rescheduleData.new_date}
                      onChange={(e) => setRescheduleData(prev => ({ ...prev, new_date: e.target.value }))}
                      min={new Date().toISOString().split('T')[0]}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Preferred New Time *</Label>
                    <Input
                      type="time"
                      value={rescheduleData.new_time}
                      onChange={(e) => setRescheduleData(prev => ({ ...prev, new_time: e.target.value }))}
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Reason for Rescheduling</Label>
                  <Textarea
                    value={rescheduleData.reason}
                    onChange={(e) => setRescheduleData(prev => ({ ...prev, reason: e.target.value }))}
                    placeholder="Let us know why you need to reschedule (optional)"
                    rows={3}
                  />
                </div>
                <Button
                  type="submit"
                  disabled={rescheduleMutation.isPending}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  size="lg"
                >
                  {rescheduleMutation.isPending ? (
                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Sending Request...</>
                  ) : (
                    <><Clock className="w-4 h-4 mr-2" /> Send Reschedule Request</>
                  )}
                </Button>
                <p className="text-sm text-gray-600 text-center">
                  The practitioner will review your request and contact you to confirm the new time.
                </p>
              </form>
            </CardContent>
          </Card>
        )}

        {action === 'cancel' && (
          <Card className="border-2 border-red-200 shadow-xl">
            <CardHeader className="bg-red-50">
              <CardTitle className="flex items-center gap-2 text-red-900">
                <XCircle className="w-6 h-6" />
                Cancel Appointment
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <p className="text-gray-700 mb-6">
                We're sorry to hear you need to cancel. If you'd like to reschedule instead, please use the reschedule option.
              </p>
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
                <p className="text-sm text-red-900">
                  <strong>Note:</strong> Cancelling will remove this appointment from your schedule. You'll need to book a new appointment if you wish to reschedule later.
                </p>
              </div>
              <Button
                onClick={() => cancelMutation.mutate()}
                disabled={cancelMutation.isPending}
                variant="destructive"
                className="w-full"
                size="lg"
              >
                {cancelMutation.isPending ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Cancelling...</>
                ) : (
                  <><XCircle className="w-4 h-4 mr-2" /> Yes, Cancel Appointment</>
                )}
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Quick Actions */}
        {!action && (
          <Card className="border-2 border-purple-200 shadow-xl">
            <CardHeader>
              <CardTitle>What would you like to do?</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {!appointment.client_confirmed && (
                <Button
                  onClick={() => setAction('confirm')}
                  className="w-full bg-green-600 hover:bg-green-700"
                  size="lg"
                >
                  <CheckCircle2 className="w-5 h-5 mr-2" />
                  Confirm Appointment
                </Button>
              )}
              <Button
                onClick={() => setAction('reschedule')}
                className="w-full bg-blue-600 hover:bg-blue-700"
                size="lg"
              >
                <Clock className="w-5 h-5 mr-2" />
                Request to Reschedule
              </Button>
              <Button
                onClick={() => setAction('cancel')}
                variant="outline"
                className="w-full border-red-300 text-red-600 hover:bg-red-50"
                size="lg"
              >
                <XCircle className="w-5 h-5 mr-2" />
                Cancel Appointment
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}