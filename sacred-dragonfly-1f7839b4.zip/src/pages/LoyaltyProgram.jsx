import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Crown, Gift, TrendingUp, Shield, ShieldCheck, Gem, History, Copy, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import confetti from "canvas-confetti";

export default function LoyaltyProgram() {
    const [user, setUser] = useState(null);
    const queryClient = useQueryClient();

    useEffect(() => {
        base44.auth.me().then(setUser).catch(() => base44.auth.redirectToLogin());
    }, []);

    const { data: tiers = [] } = useQuery({
        queryKey: ['loyalty-tiers'],
        queryFn: () => base44.entities.LoyaltyTier.list(),
    });

    const { data: transactions = [] } = useQuery({
        queryKey: ['point-transactions', user?.email],
        queryFn: () => user ? base44.entities.PointTransaction.filter({ user_email: user.email }) : [],
        enabled: !!user
    });

    const redeemMutation = useMutation({
        mutationFn: async ({ rewardType, cost }) => {
            const { data } = await base44.functions.invoke('redeemLoyaltyPoints', { rewardType, cost });
            if (data.error) throw new Error(data.error);
            return data;
        },
        onSuccess: (data) => {
            toast.success("Reward Redeemed!");
            confetti({
                particleCount: 100,
                spread: 70,
                origin: { y: 0.6 }
            });
            queryClient.invalidateQueries(['point-transactions']);
            // Refresh user to get new balance
            base44.auth.me().then(setUser);
        },
        onError: (err) => {
            toast.error(err.message);
        }
    });

    if (!user) return <div className="p-12 text-center">Loading...</div>;

    // Calculate Progress
    const sortedTiers = [...tiers].sort((a, b) => a.min_spend - b.min_spend);
    const currentTierIndex = sortedTiers.findIndex(t => t.name === (user.loyalty_tier || "Bronze"));
    const currentTier = sortedTiers[currentTierIndex] || sortedTiers[0];
    const nextTier = sortedTiers[currentTierIndex + 1];
    
    const spend = user.lifetime_spend || 0;
    const nextTierSpend = nextTier ? nextTier.min_spend : spend;
    const prevTierSpend = currentTier.min_spend;
    
    // Progress calculation relative to current tier bracket
    const progressPercent = nextTier 
        ? Math.min(100, Math.max(0, ((spend - prevTierSpend) / (nextTierSpend - prevTierSpend)) * 100))
        : 100;

    const TierIcon = ({ name, className }) => {
        switch(name) {
            case "Silver": return <ShieldCheck className={className} />;
            case "Gold": return <Crown className={className} />;
            case "Platinum": return <Gem className={className} />;
            default: return <Shield className={className} />;
        }
    };

    return (
        <div className="min-h-screen py-12 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
                
                {/* Header Section */}
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-bold text-gray-900 mb-4">Loyalty Rewards</h1>
                    <p className="text-lg text-gray-600">Earn points, unlock tiers, and enjoy exclusive benefits.</p>
                </div>

                {/* Status Cards */}
                <div className="grid md:grid-cols-3 gap-6 mb-12">
                    {/* Tier Status */}
                    <Card className="bg-white/80 backdrop-blur border-none shadow-xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-4 opacity-10">
                            <TierIcon name={currentTier?.name} className="w-32 h-32" />
                        </div>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <TierIcon name={currentTier?.name} className="w-6 h-6 text-purple-600" />
                                Current Tier
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <h2 className="text-4xl font-bold text-purple-700 mb-2">{currentTier?.name || "Bronze"}</h2>
                            {nextTier ? (
                                <div className="space-y-2">
                                    <div className="flex justify-between text-sm text-gray-600">
                                        <span>${spend.toFixed(0)} spent</span>
                                        <span>${nextTier.min_spend} for {nextTier.name}</span>
                                    </div>
                                    <Progress value={progressPercent} className="h-2" />
                                    <p className="text-xs text-gray-500 mt-2">
                                        Spend ${Math.max(0, nextTier.min_spend - spend).toFixed(2)} more to reach {nextTier.name}
                                    </p>
                                </div>
                            ) : (
                                <p className="text-green-600 font-medium">You've reached the top tier!</p>
                            )}
                        </CardContent>
                    </Card>

                    {/* Points Balance */}
                    <Card className="bg-white/80 backdrop-blur border-none shadow-xl">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Gift className="w-6 h-6 text-pink-600" />
                                Points Balance
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <h2 className="text-4xl font-bold text-pink-600 mb-2">{user.points_balance || 0}</h2>
                            <p className="text-gray-600">Available to redeem</p>
                            <p className="text-xs text-gray-500 mt-2">Earn {currentTier?.point_multiplier || 1}x points per $1 spent</p>
                        </CardContent>
                    </Card>

                    {/* Referral Quick Link */}
                    <Card className="bg-gradient-to-br from-purple-600 to-indigo-700 text-white border-none shadow-xl">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2 text-white">
                                <TrendingUp className="w-6 h-6" />
                                Refer & Earn
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="mb-4 text-purple-100">Give $20, Get $20 for every friend you refer.</p>
                            <Button variant="secondary" className="w-full bg-white text-purple-700 hover:bg-gray-100" asChild>
                                <a href="/referral-program">Go to Referral Dashboard</a>
                            </Button>
                        </CardContent>
                    </Card>
                </div>

                <Tabs defaultValue="redeem" className="space-y-8">
                    <TabsList className="bg-white p-1 rounded-xl shadow-md w-full md:w-auto grid grid-cols-3 md:flex">
                        <TabsTrigger value="redeem" className="rounded-lg px-8">Redeem Points</TabsTrigger>
                        <TabsTrigger value="benefits" className="rounded-lg px-8">Tier Benefits</TabsTrigger>
                        <TabsTrigger value="history" className="rounded-lg px-8">History</TabsTrigger>
                    </TabsList>

                    <TabsContent value="redeem">
                        <h3 className="text-2xl font-bold mb-6">Rewards Catalog</h3>
                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {[
                                { title: "$10 Off Session", cost: 500, type: 'discount_coupon' },
                                { title: "$25 Off Session", cost: 1000, type: 'discount_coupon' },
                                { title: "$50 Off Session", cost: 1800, type: 'discount_coupon' },
                                { title: "Free Meditation Course", cost: 800, type: 'course_unlock' },
                                { title: "Exclusive Tarot Reading", cost: 1500, type: 'session_discount' },
                            ].map((reward, i) => (
                                <Card key={i} className="hover:shadow-lg transition-all border-l-4 border-l-purple-500">
                                    <CardHeader>
                                        <CardTitle>{reward.title}</CardTitle>
                                        <CardDescription>{reward.cost} Points</CardDescription>
                                    </CardHeader>
                                    <CardContent>
                                        <Button 
                                            className="w-full" 
                                            disabled={(user.points_balance || 0) < reward.cost || redeemMutation.isPending}
                                            onClick={() => redeemMutation.mutate({ rewardType: reward.type, cost: reward.cost })}
                                        >
                                            {redeemMutation.isPending ? "Processing..." : "Redeem Reward"}
                                        </Button>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </TabsContent>

                    <TabsContent value="benefits">
                        <h3 className="text-2xl font-bold mb-6">Tier Benefits</h3>
                        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                            {sortedTiers.map(tier => (
                                <Card key={tier.id} className={`border-t-4 ${
                                    tier.name === currentTier?.name ? "border-t-purple-600 shadow-xl scale-105" : "border-t-gray-300 opacity-80"
                                }`}>
                                    <CardHeader>
                                        <CardTitle className="flex items-center gap-2">
                                            <TierIcon name={tier.name} className="w-5 h-5" />
                                            {tier.name}
                                        </CardTitle>
                                        <CardDescription>Spend ${tier.min_spend}+</CardDescription>
                                    </CardHeader>
                                    <CardContent>
                                        <ul className="space-y-2">
                                            {tier.benefits?.map((benefit, i) => (
                                                <li key={i} className="flex items-start gap-2 text-sm">
                                                    <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                                                    <span>{benefit}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </CardContent>
                                </Card>
                            ))}
                        </div>
                    </TabsContent>

                    <TabsContent value="history">
                        <Card>
                            <CardHeader>
                                <CardTitle>Points History</CardTitle>
                            </CardHeader>
                            <CardContent>
                                {transactions.length === 0 ? (
                                    <p className="text-gray-500 text-center py-8">No transaction history yet.</p>
                                ) : (
                                    <div className="space-y-4">
                                        {transactions.sort((a,b) => new Date(b.transaction_date) - new Date(a.transaction_date)).map(tx => (
                                            <div key={tx.id} className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                                                <div>
                                                    <p className="font-medium">{tx.reason}</p>
                                                    <p className="text-xs text-gray-500">{format(new Date(tx.transaction_date), 'MMM d, yyyy h:mm a')}</p>
                                                </div>
                                                <div className={`font-bold ${tx.points > 0 ? 'text-green-600' : 'text-red-600'}`}>
                                                    {tx.points > 0 ? '+' : ''}{tx.points} pts
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}