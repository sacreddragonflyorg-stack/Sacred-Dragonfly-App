import { base44 } from './base44Client';


export const generateLearningPath = base44.functions.generateLearningPath;

export const generateCourseContent = base44.functions.generateCourseContent;

export const sendAppointmentReminders = base44.functions.sendAppointmentReminders;

export const searchLearningContent = base44.functions.searchLearningContent;

export const generateSessionNotes = base44.functions.generateSessionNotes;

export const suggestFollowUp = base44.functions.suggestFollowUp;

export const analyzeFeedback = base44.functions.analyzeFeedback;

export const analyzeBookingTrends = base44.functions.analyzeBookingTrends;

export const analyzePractitionerPerformance = base44.functions.analyzePractitionerPerformance;

export const suggestNewOfferings = base44.functions.suggestNewOfferings;

export const createStripePaymentIntent = base44.functions.createStripePaymentIntent;

export const verifyStripePayment = base44.functions.verifyStripePayment;

export const sendBookingConfirmation = base44.functions.sendBookingConfirmation;

export const createStripeCustomerPortalSession = base44.functions.createStripeCustomerPortalSession;

export const stripeSubscriptionManager = base44.functions.stripeSubscriptionManager;

export const getStripeConfig = base44.functions.getStripeConfig;

export const createStripeSubscription = base44.functions.createStripeSubscription;

export const completeSession = base44.functions.completeSession;

export const processScheduledPayouts = base44.functions.processScheduledPayouts;

export const processLoyaltyRewards = base44.functions.processLoyaltyRewards;

export const redeemLoyaltyPoints = base44.functions.redeemLoyaltyPoints;

export const searchContent = base44.functions.searchContent;

export const stripeConnectManager = base44.functions.stripeConnectManager;

