import React from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export const useReferralRewards = () => {
  const queryClient = useQueryClient();

  const processReferralMutation = useMutation({
    mutationFn: async ({ referralCode, newUserEmail, newUserName }) => {
      // Find the referral code
      const codes = await base44.entities.ReferralCode.filter({ code: referralCode, is_active: true });
      const codeData = codes[0];
      
      if (!codeData) {
        throw new Error("Invalid referral code");
      }

      // Create referral record
      const referral = await base44.entities.Referral.create({
        referrer_email: codeData.referrer_email,
        referrer_name: codeData.referrer_name,
        referred_email: newUserEmail,
        referred_name: newUserName,
        referral_code: referralCode,
        status: "pending",
        referrer_reward_amount: 25,
        referred_reward_amount: 20,
        referrer_reward_type: "credit",
        referred_reward_type: "discount"
      });

      // Update referral code usage
      await base44.entities.ReferralCode.update(codeData.id, {
        uses_count: (codeData.uses_count || 0) + 1
      });

      // Update new user's referred_by_code
      await base44.auth.updateMe({ referred_by_code: referralCode });

      return referral;
    }
  });

  const qualifyReferralMutation = useMutation({
    mutationFn: async ({ referralId, referrerEmail, referredEmail }) => {
      // Update referral status to qualified
      const referral = await base44.entities.Referral.update(referralId, {
        status: "qualified",
        qualification_date: new Date().toISOString()
      });

      // Get current referral code to update
      const codes = await base44.entities.ReferralCode.filter({ 
        referrer_email: referrerEmail 
      });
      const codeData = codes[0];

      if (codeData) {
        await base44.entities.ReferralCode.update(codeData.id, {
          total_rewards_earned: (codeData.total_rewards_earned || 0) + 25
        });
      }

      return referral;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['my-referrals']);
      queryClient.invalidateQueries(['my-referral-code']);
    }
  });

  const issueRewardsMutation = useMutation({
    mutationFn: async ({ referralId, referrerEmail, referredEmail }) => {
      // Get referral details
      const referrals = await base44.entities.Referral.filter({ id: referralId });
      const referral = referrals[0];

      if (!referral || referral.status === "rewarded") {
        throw new Error("Referral not found or already rewarded");
      }

      // Update referral status
      await base44.entities.Referral.update(referralId, {
        status: "rewarded",
        reward_issued_date: new Date().toISOString()
      });

      // Issue rewards (this would integrate with actual reward system)
      // For now, we'll just mark as rewarded
      
      toast.success("Rewards issued successfully!");
      
      return referral;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['my-referrals']);
    }
  });

  return {
    processReferral: processReferralMutation.mutate,
    qualifyReferral: qualifyReferralMutation.mutate,
    issueRewards: issueRewardsMutation.mutate,
    isProcessing: processReferralMutation.isPending || qualifyReferralMutation.isPending || issueRewardsMutation.isPending
  };
};

export default function ReferralRewardManager({ referralId, referral, onSuccess }) {
  const { qualifyReferral, issueRewards, isProcessing } = useReferralRewards();

  const handleQualify = () => {
    qualifyReferral({
      referralId: referral.id,
      referrerEmail: referral.referrer_email,
      referredEmail: referral.referred_email
    }, {
      onSuccess: () => {
        toast.success("Referral qualified!");
        onSuccess?.();
      }
    });
  };

  const handleIssueRewards = () => {
    issueRewards({
      referralId: referral.id,
      referrerEmail: referral.referrer_email,
      referredEmail: referral.referred_email
    }, {
      onSuccess: () => {
        onSuccess?.();
      }
    });
  };

  return (
    <div className="flex gap-2">
      {referral.status === "pending" && (
        <Button
          size="sm"
          onClick={handleQualify}
          disabled={isProcessing}
          className="bg-blue-600 hover:bg-blue-700"
        >
          Mark as Qualified
        </Button>
      )}
      {referral.status === "qualified" && (
        <Button
          size="sm"
          onClick={handleIssueRewards}
          disabled={isProcessing}
          className="bg-green-600 hover:bg-green-700"
        >
          Issue Rewards
        </Button>
      )}
    </div>
  );
}