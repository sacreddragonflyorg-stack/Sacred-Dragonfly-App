import React, { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, ChevronLeft, ChevronRight, Loader2 } from "lucide-react";
import { format, addDays, startOfWeek, isSameDay, isAfter, setHours, setMinutes, parseISO } from "date-fns";

export default function PractitionerAvailability({ 
  practitioner, 
  serviceDuration = 60,
  selectedDate,
  selectedTime,
  onSelectSlot 
}) {
  const [weekStart, setWeekStart] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }));

  // Get practitioner's existing appointments
  const { data: existingAppointments = [], isLoading } = useQuery({
    queryKey: ['practitioner-appointments', practitioner?.id],
    queryFn: async () => {
      if (!practitioner) return [];
      // Get appointments for practitioners services
      const appointments = await base44.entities.Appointment.filter({
        status: { $in: ['pending', 'confirmed'] }
      });
      // In a real scenario, you'd filter by practitioner_id on the appointment
      return appointments;
    },
    enabled: !!practitioner,
  });

  const weekDays = useMemo(() => {
    return Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
  }, [weekStart]);

  const dayNames = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

  const getAvailableSlots = (date) => {
    if (!practitioner?.availability) return [];
    
    const dayName = dayNames[date.getDay() === 0 ? 6 : date.getDay() - 1];
    const daySlots = practitioner.availability[dayName] || [];
    
    // Filter out past times for today
    const now = new Date();
    return daySlots.filter(slot => {
      if (!isSameDay(date, now)) return true;
      const [hours, minutes] = slot.split(':').map(Number);
      const slotTime = setMinutes(setHours(date, hours), minutes);
      return isAfter(slotTime, now);
    });
  };

  const isSlotBooked = (date, time) => {
    // Check if this slot is already booked
    return existingAppointments.some(apt => {
      const aptDate = new Date(apt.appointment_date);
      return isSameDay(aptDate, date) && format(aptDate, 'HH:mm') === time;
    });
  };

  if (!practitioner) {
    return (
      <Card className="bg-gray-50">
        <CardContent className="py-8 text-center text-gray-500">
          <Calendar className="w-12 h-12 mx-auto mb-3 text-gray-300" />
          <p>Select a practitioner to view availability</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-purple-600" />
            {practitioner.display_name}'s Availability
          </CardTitle>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setWeekStart(addDays(weekStart, -7))}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <span className="text-sm font-medium px-2">
              {format(weekStart, 'MMM d')} - {format(addDays(weekStart, 6), 'MMM d, yyyy')}
            </span>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setWeekStart(addDays(weekStart, 7))}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
          </div>
        ) : (
          <div className="grid grid-cols-7 gap-2">
            {weekDays.map(date => {
              const slots = getAvailableSlots(date);
              const isPast = date < new Date().setHours(0, 0, 0, 0);
              
              return (
                <div key={date.toISOString()} className="text-center">
                  <div className={`py-2 mb-2 rounded-lg ${isPast ? 'bg-gray-100 text-gray-400' : 'bg-purple-50'}`}>
                    <p className="text-xs font-medium">{format(date, 'EEE')}</p>
                    <p className={`text-lg font-bold ${isSameDay(date, new Date()) ? 'text-purple-600' : ''}`}>
                      {format(date, 'd')}
                    </p>
                  </div>
                  
                  <div className="space-y-1 max-h-48 overflow-y-auto">
                    {isPast ? (
                      <p className="text-xs text-gray-400">-</p>
                    ) : slots.length === 0 ? (
                      <p className="text-xs text-gray-400">No slots</p>
                    ) : (
                      slots.map(slot => {
                        const isBooked = isSlotBooked(date, slot);
                        const isSelected = selectedDate && selectedTime && 
                          isSameDay(new Date(selectedDate), date) && selectedTime === slot;
                        
                        return (
                          <button
                            key={slot}
                            onClick={() => !isBooked && onSelectSlot(format(date, 'yyyy-MM-dd'), slot)}
                            disabled={isBooked}
                            className={`w-full text-xs py-1.5 px-1 rounded transition-all ${
                              isBooked 
                                ? 'bg-gray-200 text-gray-400 cursor-not-allowed line-through'
                                : isSelected
                                  ? 'bg-purple-600 text-white'
                                  : 'bg-white border border-purple-200 text-purple-700 hover:bg-purple-100'
                            }`}
                          >
                            {slot}
                          </button>
                        );
                      })
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
        
        {selectedDate && selectedTime && (
          <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
            <p className="text-green-800 font-medium flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Selected: {format(new Date(selectedDate), 'EEEE, MMMM d, yyyy')} at {selectedTime}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}