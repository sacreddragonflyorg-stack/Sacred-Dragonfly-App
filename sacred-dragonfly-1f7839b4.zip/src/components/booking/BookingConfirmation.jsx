import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Calendar, Clock, User, DollarSign, Package, 
  Heart, CheckCircle2, ArrowRight, Gift, Repeat 
} from "lucide-react";
import { format } from "date-fns";

export default function BookingConfirmation({ 
  service, 
  practitioner, 
  date, 
  time, 
  price,
  packages = [],
  subscriptions = [],
  onProceedToPayment,
  onUsePackage
}) {
  // Find matching packages for this service
  const matchingPackages = packages.filter(pkg => 
    pkg.status === 'active' && 
    pkg.sessions_remaining > 0 &&
    (pkg.service_ids?.includes(service?.id) || !pkg.service_ids?.length)
  );

  // Find matching subscriptions
  const matchingSubscriptions = subscriptions.filter(sub =>
    sub.status === 'active' &&
    sub.sessions_used < sub.sessions_total
  );

  return (
    <div className="space-y-6">
      {/* Booking Summary */}
      <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-2 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-green-600" />
            Booking Summary
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Service */}
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <Heart className="w-5 h-5 text-purple-600" />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-gray-900">{service?.name}</p>
              <p className="text-sm text-gray-600">{service?.duration_minutes} minutes</p>
            </div>
            <Badge className="bg-green-100 text-green-800 text-lg px-3">
              ${price || service?.price}
            </Badge>
          </div>

          <Separator />

          {/* Practitioner */}
          {practitioner && (
            <>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full overflow-hidden">
                  {practitioner.photo_url ? (
                    <img src={practitioner.photo_url} alt={practitioner.display_name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-purple-400 flex items-center justify-center text-white font-bold">
                      {practitioner.display_name?.charAt(0)}
                    </div>
                  )}
                </div>
                <div>
                  <p className="font-semibold text-gray-900">{practitioner.display_name}</p>
                  <p className="text-sm text-purple-600">{practitioner.title}</p>
                </div>
              </div>
              <Separator />
            </>
          )}

          {/* Date & Time */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Calendar className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="font-semibold text-gray-900">
                {date ? format(new Date(date), 'EEEE, MMMM d, yyyy') : 'Select a date'}
              </p>
              <p className="text-sm text-gray-600">
                {time ? `at ${time}` : 'Select a time'}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Use Package/Subscription Options */}
      {(matchingPackages.length > 0 || matchingSubscriptions.length > 0) && (
        <Card className="border-2 border-amber-200 bg-amber-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-amber-800">
              <Gift className="w-5 h-5" />
              Use Your Packages or Subscriptions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {matchingPackages.map(pkg => (
              <div key={pkg.id} className="p-4 bg-white rounded-lg border border-amber-200">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-semibold text-gray-900">{pkg.package_name}</p>
                    <p className="text-sm text-gray-600">
                      {pkg.sessions_remaining} of {pkg.sessions_total} sessions remaining
                    </p>
                  </div>
                  <Badge className="bg-amber-100 text-amber-800">
                    <Package className="w-3 h-3 mr-1" /> Package
                  </Badge>
                </div>
                <Button 
                  onClick={() => onUsePackage(pkg)}
                  variant="outline"
                  className="w-full border-amber-400 text-amber-700 hover:bg-amber-100"
                >
                  Use This Package (Free Session)
                </Button>
              </div>
            ))}

            {matchingSubscriptions.map(sub => (
              <div key={sub.id} className="p-4 bg-white rounded-lg border border-blue-200">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-semibold text-gray-900">{sub.plan_name}</p>
                    <p className="text-sm text-gray-600">
                      {sub.sessions_total - sub.sessions_used} sessions left this period
                    </p>
                  </div>
                  <Badge className="bg-blue-100 text-blue-800">
                    <Repeat className="w-3 h-3 mr-1" /> Subscription
                  </Badge>
                </div>
                <Button 
                  onClick={() => onUsePackage(sub, 'subscription')}
                  variant="outline"
                  className="w-full border-blue-400 text-blue-700 hover:bg-blue-100"
                >
                  Use Subscription Session
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Proceed to Payment */}
      <Button
        onClick={onProceedToPayment}
        size="lg"
        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
      >
        <DollarSign className="w-5 h-5 mr-2" />
        Proceed to Payment - ${price || service?.price}
        <ArrowRight className="w-5 h-5 ml-2" />
      </Button>

      {/* Alternative Options */}
      <div className="grid md:grid-cols-2 gap-4">
        <Link to={createPageUrl("Packages")}>
          <Card className="p-4 hover:shadow-lg transition-shadow cursor-pointer group h-full">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <Package className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="font-semibold text-gray-900">Save with Packages</p>
                <p className="text-xs text-gray-600">Bundle sessions for discounts</p>
              </div>
            </div>
          </Card>
        </Link>
        <Link to={createPageUrl("Subscriptions")}>
          <Card className="p-4 hover:shadow-lg transition-shadow cursor-pointer group h-full">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-pink-100 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <Heart className="w-5 h-5 text-pink-600" />
              </div>
              <div>
                <p className="font-semibold text-gray-900">Subscribe & Save</p>
                <p className="text-xs text-gray-600">Regular sessions at best rates</p>
              </div>
            </div>
          </Card>
        </Link>
      </div>
    </div>
  );
}