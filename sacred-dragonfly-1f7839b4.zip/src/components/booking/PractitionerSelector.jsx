import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, Award, CheckCircle2 } from "lucide-react";

export default function PractitionerSelector({ practitioners, selectedId, onSelect, serviceId }) {
  // Filter practitioners who offer the selected service
  const availablePractitioners = serviceId 
    ? practitioners.filter(p => p.service_ids?.includes(serviceId))
    : practitioners;

  if (availablePractitioners.length === 0) {
    return (
      <div className="text-center py-6 text-gray-500">
        No practitioners available for this service
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Option for no preference */}
      <Card 
        onClick={() => onSelect(null)}
        className={`cursor-pointer transition-all ${!selectedId ? 'ring-2 ring-purple-600 bg-purple-50' : 'hover:shadow-md'}`}
      >
        <CardContent className="pt-4 pb-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
              <span className="text-gray-500 text-xl">?</span>
            </div>
            <div>
              <p className="font-semibold text-gray-900">No Preference</p>
              <p className="text-sm text-gray-600">Any available practitioner</p>
            </div>
          </div>
          {!selectedId && <CheckCircle2 className="w-6 h-6 text-purple-600" />}
        </CardContent>
      </Card>

      {/* Practitioner options */}
      {availablePractitioners.map(practitioner => (
        <Card 
          key={practitioner.id}
          onClick={() => onSelect(practitioner.id)}
          className={`cursor-pointer transition-all ${selectedId === practitioner.id ? 'ring-2 ring-purple-600 bg-purple-50' : 'hover:shadow-md'}`}
        >
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center gap-4">
              {/* Photo */}
              <div className="w-16 h-16 rounded-full overflow-hidden flex-shrink-0">
                {practitioner.photo_url ? (
                  <img 
                    src={practitioner.photo_url} 
                    alt={practitioner.display_name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center">
                    <span className="text-white text-xl font-bold">
                      {practitioner.display_name?.charAt(0)}
                    </span>
                  </div>
                )}
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-semibold text-gray-900">{practitioner.display_name}</p>
                  {practitioner.is_featured && (
                    <Badge className="bg-amber-500 text-xs">Featured</Badge>
                  )}
                </div>
                <p className="text-sm text-purple-600">{practitioner.title}</p>
                <div className="flex items-center gap-3 mt-1 text-sm">
                  {practitioner.average_rating && (
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                      <span>{practitioner.average_rating.toFixed(1)}</span>
                    </div>
                  )}
                  {practitioner.years_experience && (
                    <div className="flex items-center gap-1 text-gray-600">
                      <Award className="w-3 h-3" />
                      <span>{practitioner.years_experience}+ yrs</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Selected indicator */}
              {selectedId === practitioner.id && (
                <CheckCircle2 className="w-6 h-6 text-purple-600 flex-shrink-0" />
              )}
            </div>

            {/* Specialties */}
            {practitioner.specialties?.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-3 ml-20">
                {practitioner.specialties.slice(0, 3).map(s => (
                  <Badge key={s} variant="outline" className="text-xs">{s}</Badge>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}