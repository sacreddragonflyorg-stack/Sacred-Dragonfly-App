import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Plus, Video, Calendar, Edit, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function LiveSessionsManager() {
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState("");
  const [meetingLink, setMeetingLink] = useState("");
  const [clientConcerns, setClientConcerns] = useState("");
  const [useIntegratedVideo, setUseIntegratedVideo] = useState(true);

  const queryClient = useQueryClient();

  const { data: liveSessions } = useQuery({
    queryKey: ['live-sessions-admin'],
    queryFn: () => base44.entities.LiveSession.list('-scheduled_start'),
    initialData: [],
  });

  const { data: appointments } = useQuery({
    queryKey: ['confirmed-appointments'],
    queryFn: async () => {
      const allAppointments = await base44.entities.Appointment.filter(
        { status: 'confirmed' },
        '-appointment_date'
      );
      
      // Filter out appointments that already have live sessions
      const sessionAppointmentIds = liveSessions.map(s => s.appointment_id);
      return allAppointments.filter(apt => !sessionAppointmentIds.includes(apt.id));
    },
    initialData: [],
  });

  const createSessionMutation = useMutation({
    mutationFn: async () => {
      const appointment = appointments.find(a => a.id === selectedAppointment);
      if (!appointment) throw new Error("Appointment not found");

      return base44.entities.LiveSession.create({
        appointment_id: appointment.id,
        practitioner_email: appointment.created_by,
        client_email: appointment.client_email,
        client_name: appointment.client_name,
        service_name: appointment.service_name,
        scheduled_start: appointment.appointment_date,
        meeting_link: meetingLink,
        client_concerns: clientConcerns,
        status: 'scheduled',
        chat_messages: []
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['live-sessions-admin']);
      queryClient.invalidateQueries(['confirmed-appointments']);
      toast.success("Live session created!");
      setShowCreateDialog(false);
      setSelectedAppointment("");
      setMeetingLink("");
      setClientConcerns("");
    },
  });

  const deleteSessionMutation = useMutation({
    mutationFn: (sessionId) => base44.entities.LiveSession.delete(sessionId),
    onSuccess: () => {
      queryClient.invalidateQueries(['live-sessions-admin']);
      toast.success("Session deleted");
    },
  });

  const upcomingSessions = liveSessions.filter(s => 
    s.status === 'scheduled' && new Date(s.scheduled_start) >= new Date()
  );

  const activeSessions = liveSessions.filter(s => 
    s.status === 'in_progress' || s.status === 'waiting'
  );

  return (
    <div className="space-y-6">
      {/* Active Sessions Alert */}
      {activeSessions.length > 0 && (
        <Card className="border-l-4 border-l-red-600 bg-red-50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-lg text-red-900">
                  {activeSessions.length} Active Session{activeSessions.length > 1 ? 's' : ''}
                </h3>
                <p className="text-red-700 text-sm">
                  You have live sessions in progress
                </p>
              </div>
              <Badge className="bg-red-600 text-white text-lg px-4 py-2">
                ● LIVE
              </Badge>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Create Session Card */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Live Sessions Management</CardTitle>
          <Button
            onClick={() => setShowCreateDialog(true)}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Live Session
          </Button>
        </CardHeader>
        <CardContent>
          {upcomingSessions.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <Video className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p>No upcoming live sessions</p>
              <p className="text-sm mt-2">Create sessions from confirmed appointments</p>
            </div>
          ) : (
            <div className="space-y-4">
              {upcomingSessions.map((session) => (
                <Card key={session.id} className="border-l-4 border-l-purple-600">
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-semibold text-lg">{session.service_name}</h3>
                          <Badge>{session.status}</Badge>
                        </div>
                        <div className="space-y-1 text-sm text-gray-600">
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4" />
                            <span>
                              {format(new Date(session.scheduled_start), 'MMMM d, yyyy - h:mm a')}
                            </span>
                          </div>
                          <div>Client: {session.client_name}</div>
                          {session.meeting_link && (
                            <a
                              href={session.meeting_link}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-purple-600 hover:text-purple-700 flex items-center gap-1"
                            >
                              <Video className="w-4 h-4" />
                              Meeting Link
                            </a>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteSessionMutation.mutate(session.id)}
                          className="text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Session Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Create Live Session</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Select Appointment *</Label>
              <Select value={selectedAppointment} onValueChange={setSelectedAppointment}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a confirmed appointment" />
                </SelectTrigger>
                <SelectContent>
                  {appointments.length === 0 ? (
                    <SelectItem value="none" disabled>No confirmed appointments available</SelectItem>
                  ) : (
                    appointments.map((apt) => (
                      <SelectItem key={apt.id} value={apt.id}>
                        {apt.service_name} - {apt.client_name} - {format(new Date(apt.appointment_date), 'MMM d, h:mm a')}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Meeting Link *</Label>
              <Input
                value={meetingLink}
                onChange={(e) => setMeetingLink(e.target.value)}
                placeholder="https://zoom.us/j/... or https://meet.google.com/..."
              />
              <p className="text-xs text-gray-500">
                Add your Zoom, Google Meet, or other video conferencing link
              </p>
            </div>

            <div className="space-y-2">
              <Label>Client Concerns / Session Focus</Label>
              <Textarea
                value={clientConcerns}
                onChange={(e) => setClientConcerns(e.target.value)}
                placeholder="Note any specific concerns or focus areas for this session..."
                rows={4}
              />
            </div>

            <div className="flex gap-2">
              <Button
                onClick={() => createSessionMutation.mutate()}
                disabled={!selectedAppointment || !meetingLink.trim()}
                className="flex-1 bg-purple-600 hover:bg-purple-700"
              >
                <Video className="w-4 h-4 mr-2" />
                Create Session
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowCreateDialog(false)}
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}