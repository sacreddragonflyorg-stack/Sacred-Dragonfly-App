import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Users, Search, Mail, Calendar, DollarSign, Gift, Heart } from "lucide-react";
import { format } from "date-fns";

export default function ClientManagement() {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("recent");

  const { data: allUsers = [] } = useQuery({
    queryKey: ['all-clients'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: appointments = [] } = useQuery({
    queryKey: ['all-client-appointments'],
    queryFn: () => base44.entities.Appointment.list('-created_date'),
    initialData: [],
  });

  const { data: payments = [] } = useQuery({
    queryKey: ['all-client-payments'],
    queryFn: () => base44.entities.Payment.list(),
    initialData: [],
  });

  const { data: referrals = [] } = useQuery({
    queryKey: ['all-referrals'],
    queryFn: () => base44.entities.Referral.list(),
    initialData: [],
  });

  const clients = allUsers.filter(u => u.role === 'user');

  const clientsWithData = clients.map(client => {
    const clientAppointments = appointments.filter(a => a.client_email === client.email);
    const clientPayments = payments.filter(p => p.client_email === client.email && p.status === 'completed');
    const totalSpent = clientPayments.reduce((sum, p) => sum + (p.amount || 0), 0);
    
    const referredBy = referrals.find(r => r.referred_email === client.email);
    const referredClients = referrals.filter(r => r.referrer_email === client.email);

    return {
      ...client,
      appointmentCount: clientAppointments.length,
      completedSessions: clientAppointments.filter(a => a.status === 'completed').length,
      totalSpent,
      referredBy: referredBy?.referrer_name,
      referralCount: referredClients.length,
      rewardsBalance: client.rewards_balance || 0,
      lastAppointment: clientAppointments[0]?.appointment_date
    };
  });

  const filteredClients = clientsWithData
    .filter(c => {
      const matchesSearch = c.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          c.email?.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesSearch;
    })
    .sort((a, b) => {
      if (sortBy === 'recent') {
        const dateA = a.lastAppointment ? new Date(a.lastAppointment) : new Date(0);
        const dateB = b.lastAppointment ? new Date(b.lastAppointment) : new Date(0);
        return dateB - dateA;
      }
      if (sortBy === 'sessions') return b.completedSessions - a.completedSessions;
      if (sortBy === 'spent') return b.totalSpent - a.totalSpent;
      if (sortBy === 'referrals') return b.referralCount - a.referralCount;
      return 0;
    });

  const stats = {
    total: clients.length,
    withAppointments: clientsWithData.filter(c => c.appointmentCount > 0).length,
    referred: clientsWithData.filter(c => c.referredBy).length,
    activeReferrers: clientsWithData.filter(c => c.referralCount > 0).length,
    totalRevenue: clientsWithData.reduce((sum, c) => sum + c.totalSpent, 0)
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-2xl">
            <Users className="w-6 h-6" />
            Client Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Total Clients</p>
              <p className="text-2xl font-bold text-blue-900">{stats.total}</p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Active</p>
              <p className="text-2xl font-bold text-green-900">{stats.withAppointments}</p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Referred</p>
              <p className="text-2xl font-bold text-purple-900">{stats.referred}</p>
            </div>
            <div className="bg-pink-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Referrers</p>
              <p className="text-2xl font-bold text-pink-900">{stats.activeReferrers}</p>
            </div>
            <div className="bg-amber-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold text-amber-900">${stats.totalRevenue.toFixed(0)}</p>
            </div>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-4 mb-6">
            <div className="flex-1 min-w-[200px]">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search clients..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recent">Most Recent</SelectItem>
                <SelectItem value="sessions">Most Sessions</SelectItem>
                <SelectItem value="spent">Highest Spend</SelectItem>
                <SelectItem value="referrals">Most Referrals</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Clients List */}
          <div className="space-y-3">
            {filteredClients.length === 0 ? (
              <p className="text-center text-gray-500 py-8">No clients found</p>
            ) : (
              filteredClients.map((client) => (
                <div key={client.id} className="p-4 bg-gray-50 rounded-lg border border-gray-200 hover:border-blue-300 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="font-semibold text-lg">{client.full_name || 'No Name'}</h4>
                        {client.referralCount > 0 && (
                          <Badge className="bg-pink-100 text-pink-800">
                            <Gift className="w-3 h-3 mr-1" />
                            Referrer
                          </Badge>
                        )}
                        {client.referredBy && (
                          <Badge className="bg-purple-100 text-purple-800">
                            Referred by {client.referredBy}
                          </Badge>
                        )}
                      </div>
                      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-2 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <Mail className="w-4 h-4" />
                          {client.email}
                        </div>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          {client.completedSessions} completed session{client.completedSessions !== 1 ? 's' : ''}
                        </div>
                        <div className="flex items-center gap-2">
                          <DollarSign className="w-4 h-4 text-green-600" />
                          <span className="text-green-700 font-medium">${client.totalSpent.toFixed(0)} spent</span>
                        </div>
                        {client.referralCount > 0 && (
                          <div className="flex items-center gap-2">
                            <Gift className="w-4 h-4 text-pink-600" />
                            <span className="text-pink-700">{client.referralCount} referral{client.referralCount !== 1 ? 's' : ''}</span>
                          </div>
                        )}
                        {client.rewardsBalance > 0 && (
                          <div className="flex items-center gap-2">
                            <Heart className="w-4 h-4 text-purple-600" />
                            <span className="text-purple-700">${client.rewardsBalance} rewards</span>
                          </div>
                        )}
                        {client.lastAppointment && (
                          <div className="text-gray-500 text-xs">
                            Last visit: {format(new Date(client.lastAppointment), 'MMM d, yyyy')}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}