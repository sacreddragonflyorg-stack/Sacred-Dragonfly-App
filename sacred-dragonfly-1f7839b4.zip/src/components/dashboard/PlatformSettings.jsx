import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Save, Settings } from "lucide-react";
import { toast } from "sonner";

export default function PlatformSettings() {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState(null);

  const { data: settings, isLoading } = useQuery({
    queryKey: ['platform-settings'],
    queryFn: async () => {
      const res = await base44.entities.PlatformSettings.list({ limit: 1 });
      return res.length > 0 ? res[0] : null;
    },
  });

  // Initialize form data when settings are loaded
  React.useEffect(() => {
    if (settings) {
      setFormData(settings);
    } else if (!isLoading && !settings) {
        // No settings found, prepare default
        setFormData({
            default_platform_fee_percent: 0.20,
            payout_schedule: 'weekly'
        });
    }
  }, [settings, isLoading]);

  const saveMutation = useMutation({
    mutationFn: (data) => {
      if (settings?.id) {
        return base44.entities.PlatformSettings.update(settings.id, data);
      } else {
        return base44.entities.PlatformSettings.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['platform-settings']);
      toast.success("Platform settings updated");
    },
    onError: () => toast.error("Failed to update settings")
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    saveMutation.mutate(formData);
  };

  if (isLoading) return <div className="p-8 text-center"><Loader2 className="animate-spin mx-auto" /></div>;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Platform Configuration
        </CardTitle>
        <CardDescription>Manage global fees and payout schedules</CardDescription>
      </CardHeader>
      <CardContent>
        {formData && (
            <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                <Label>Global Default Platform Fee (%)</Label>
                <div className="flex items-center gap-2">
                    <Input
                    type="number"
                    step="0.01"
                    min="0"
                    max="1"
                    value={formData.default_platform_fee_percent}
                    onChange={(e) => setFormData({ ...formData, default_platform_fee_percent: parseFloat(e.target.value) })}
                    className="w-32"
                    />
                    <span className="text-gray-500">
                        = {(formData.default_platform_fee_percent * 100).toFixed(0)}%
                    </span>
                </div>
                <p className="text-sm text-gray-500">
                    This fee applies to all practitioners unless overridden.
                </p>
                </div>

                <div className="space-y-2">
                <Label>Payout Schedule</Label>
                <Select 
                    value={formData.payout_schedule} 
                    onValueChange={(val) => setFormData({ ...formData, payout_schedule: val })}
                >
                    <SelectTrigger>
                    <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="bi-weekly">Bi-Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                </Select>
                <p className="text-sm text-gray-500">
                    Frequency of automated payout processing (informational).
                </p>
                </div>
            </div>

            <Button type="submit" disabled={saveMutation.isPending} className="bg-purple-600">
                {saveMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                Save Settings
            </Button>
            </form>
        )}
      </CardContent>
    </Card>
  );
}