import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Edit, Trash2, X, ChevronRight, ChevronDown, BookOpen, FileText, HelpCircle, GripVertical, Moon, Activity, Trophy } from "lucide-react";
import { toast } from "sonner";
import AIContentGenerator from "./AIContentGenerator";
import ShadowWorkManager from "../cms/ShadowWorkManager";
import ProgressTracker from "../cms/ProgressTracker";
import QuizManager from "../cms/QuizManager";

export default function LearningManager() {
  const [activeTab, setActiveTab] = useState("courses");
  const [editingCourse, setEditingCourse] = useState(null);
  const [editingModule, setEditingModule] = useState(null);
  const [expandedCourse, setExpandedCourse] = useState(null);
  const [showCourseForm, setShowCourseForm] = useState(false);
  const [showModuleForm, setShowModuleForm] = useState(false);

  const [courseForm, setCourseForm] = useState({
    title: "", description: "", category: "meditation", 
    difficulty_level: "beginner", estimated_hours: 1, 
    points_reward: 100, is_premium: false, points_required: 0, image_url: ""
  });

  const [moduleForm, setModuleForm] = useState({
    title: "", description: "", content: "", 
    video_url: "", duration_minutes: 15, points_reward: 10
  });

  const queryClient = useQueryClient();

  // Queries
  const { data: courses = [], isLoading: coursesLoading } = useQuery({
    queryKey: ['admin-courses'],
    queryFn: () => base44.entities.LearningCourse.list('order'),
  });

  const { data: modules = [] } = useQuery({
    queryKey: ['admin-modules', expandedCourse],
    queryFn: () => expandedCourse ? base44.entities.LearningModule.filter({ course_id: expandedCourse }, 'order') : [],
    enabled: !!expandedCourse,
  });

  // Mutations
  const saveCourseMutation = useMutation({
    mutationFn: (data) => editingCourse 
      ? base44.entities.LearningCourse.update(editingCourse.id, data)
      : base44.entities.LearningCourse.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['admin-courses']);
      toast.success(editingCourse ? "Course updated" : "Course created");
      closeCourseForm();
    },
  });

  const deleteCourseMutation = useMutation({
    mutationFn: (id) => base44.entities.LearningCourse.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['admin-courses']);
      toast.success("Course deleted");
    },
  });

  const saveModuleMutation = useMutation({
    mutationFn: (data) => editingModule
      ? base44.entities.LearningModule.update(editingModule.id, data)
      : base44.entities.LearningModule.create({ ...data, course_id: expandedCourse }),
    onSuccess: () => {
      queryClient.invalidateQueries(['admin-modules']);
      toast.success(editingModule ? "Module updated" : "Module created");
      closeModuleForm();
    },
  });

  const deleteModuleMutation = useMutation({
    mutationFn: (id) => base44.entities.LearningModule.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['admin-modules']);
      toast.success("Module deleted");
    },
  });

  const createModulesFromOutline = useMutation({
    mutationFn: async (outline) => {
      // First, create the course
      const course = await base44.entities.LearningCourse.create({
        title: outline.title,
        description: outline.description,
        category: 'meditation', // Default
        is_active: false // Draft
      });

      // Then create modules
      for (let i = 0; i < outline.modules.length; i++) {
        const mod = outline.modules[i];
        await base44.entities.LearningModule.create({
          course_id: course.id,
          title: mod.title,
          description: mod.description,
          content: "# " + mod.title + "\n\nContent coming soon...",
          order: i + 1
        });
      }
      return course;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['admin-courses']);
      toast.success("Course and modules created from outline!");
    }
  });

  // Handlers
  const handleEditCourse = (course) => {
    setEditingCourse(course);
    setCourseForm(course);
    setShowCourseForm(true);
  };

  const closeCourseForm = () => {
    setShowCourseForm(false);
    setEditingCourse(null);
    setCourseForm({
      title: "", description: "", category: "meditation", 
      difficulty_level: "beginner", estimated_hours: 1, 
      points_reward: 100, is_premium: false, points_required: 0, image_url: ""
    });
  };

  const handleEditModule = (module) => {
    setEditingModule(module);
    setModuleForm(module);
    setShowModuleForm(true);
  };

  const closeModuleForm = () => {
    setShowModuleForm(false);
    setEditingModule(null);
    setModuleForm({
      title: "", description: "", content: "", 
      video_url: "", duration_minutes: 15, points_reward: 10
    });
  };

  const handleAIOutline = (data) => {
    if (showCourseForm) {
      // Just fill form
      setCourseForm(prev => ({ ...prev, title: data.title, description: data.description }));
      // We can't easily create modules here until course is saved, so maybe just toast a hint
      toast.info("Course details filled. Save to create modules manually or use the main 'Generate Outline' to create everything at once.");
    } else {
      // Create full structure
      createModulesFromOutline.mutate(data);
    }
  };

  const handleAIDescription = (data) => {
    setCourseForm(prev => ({
      ...prev,
      description: data.short_description
    }));
  };

  const handleAIModuleContent = (data) => {
    setModuleForm(prev => ({
      ...prev,
      content: data.content
    }));
  };

  const handleAIExercises = (data) => {
    const exercisesText = data.exercises.map(ex => `### ${ex.title}\n${ex.instruction}\n*Time: ${ex.estimated_time}*`).join('\n\n');
    setModuleForm(prev => ({
      ...prev,
      content: prev.content + "\n\n## Practice Exercises\n\n" + exercisesText
    }));
  };

  return (
    <div className="space-y-6">
      <Tabs defaultValue="courses" className="space-y-6">
        <TabsList className="bg-white p-1 rounded-lg border w-full justify-start h-auto flex-wrap">
          <TabsTrigger value="courses" className="data-[state=active]:bg-purple-100 data-[state=active]:text-purple-700">
            <BookOpen className="w-4 h-4 mr-2" /> Courses
          </TabsTrigger>
          <TabsTrigger value="quizzes" className="data-[state=active]:bg-purple-100 data-[state=active]:text-purple-700">
            <HelpCircle className="w-4 h-4 mr-2" /> Quizzes
          </TabsTrigger>
          <TabsTrigger value="shadow_work" className="data-[state=active]:bg-purple-100 data-[state=active]:text-purple-700">
            <Moon className="w-4 h-4 mr-2" /> Shadow Work
          </TabsTrigger>
          <TabsTrigger value="progress" className="data-[state=active]:bg-purple-100 data-[state=active]:text-purple-700">
            <Activity className="w-4 h-4 mr-2" /> User Progress
          </TabsTrigger>
        </TabsList>

        <TabsContent value="courses">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Course Management</CardTitle>
          <div className="flex gap-2">
            <AIContentGenerator 
              mode="outline" 
              onGenerate={handleAIOutline}
              buttonLabel="Generate New Course"
            />
            <Button onClick={() => setShowCourseForm(true)} className="bg-purple-600">
              <Plus className="w-4 h-4 mr-2" /> New Course
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {showCourseForm && (
            <Card className="mb-6 border-2 border-purple-200">
              <CardContent className="pt-6 space-y-4">
                <div className="flex justify-between items-start">
                  <h3 className="font-semibold text-lg">{editingCourse ? "Edit Course" : "New Course"}</h3>
                  <div className="flex gap-2">
                     <AIContentGenerator 
                      mode="description" 
                      initialData={{ topic: courseForm.title, course_title: courseForm.title }}
                      onGenerate={handleAIDescription}
                      buttonLabel="AI Description"
                    />
                    <Button variant="ghost" size="sm" onClick={closeCourseForm}><X className="w-4 h-4" /></Button>
                  </div>
                </div>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Title</Label>
                    <Input value={courseForm.title} onChange={e => setCourseForm({...courseForm, title: e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Select value={courseForm.category} onValueChange={v => setCourseForm({...courseForm, category: v})}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {["meditation", "chakra_work", "energy_techniques", "self_healing", "reiki_basics", "tarot_guidance", "crystal_healing", "manifestation"].map(c => (
                          <SelectItem key={c} value={c}>{c.replace('_', ' ')}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Description</Label>
                  <Textarea value={courseForm.description} onChange={e => setCourseForm({...courseForm, description: e.target.value})} rows={3} />
                </div>

                <div className="grid md:grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <Label>Difficulty</Label>
                    <Select value={courseForm.difficulty_level} onValueChange={v => setCourseForm({...courseForm, difficulty_level: v})}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="beginner">Beginner</SelectItem>
                        <SelectItem value="intermediate">Intermediate</SelectItem>
                        <SelectItem value="advanced">Advanced</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Est. Hours</Label>
                    <Input type="number" value={courseForm.estimated_hours} onChange={e => setCourseForm({...courseForm, estimated_hours: +e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <Label>Points Reward</Label>
                    <Input type="number" value={courseForm.points_reward} onChange={e => setCourseForm({...courseForm, points_reward: +e.target.value})} />
                  </div>
                   <div className="space-y-2">
                    <Label>Points Cost (0=Free)</Label>
                    <Input type="number" value={courseForm.points_required} onChange={e => setCourseForm({...courseForm, points_required: +e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <Label>Prerequisite Course ID</Label>
                    <Input value={courseForm.prerequisite_course_id || ""} onChange={e => setCourseForm({...courseForm, prerequisite_course_id: e.target.value})} placeholder="Optional ID" />
                  </div>
                </div>

                <Button onClick={() => saveCourseMutation.mutate(courseForm)} className="w-full bg-purple-600">
                  {editingCourse ? "Update Course" : "Create Course"}
                </Button>
              </CardContent>
            </Card>
          )}

          <div className="space-y-4">
            {courses.map(course => (
              <div key={course.id} className="border rounded-lg overflow-hidden">
                <div className="p-4 bg-gray-50 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="p-0 h-8 w-8"
                      onClick={() => setExpandedCourse(expandedCourse === course.id ? null : course.id)}
                    >
                      {expandedCourse === course.id ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                    </Button>
                    <div>
                      <h3 className="font-semibold">{course.title}</h3>
                      <p className="text-xs text-gray-500">{course.category} • {course.modules_count || 0} modules</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="sm" onClick={() => handleEditCourse(course)}><Edit className="w-4 h-4" /></Button>
                    <Button variant="ghost" size="sm" className="text-red-500" onClick={() => deleteCourseMutation.mutate(course.id)}><Trash2 className="w-4 h-4" /></Button>
                  </div>
                </div>

                {expandedCourse === course.id && (
                  <div className="p-4 border-t bg-white space-y-4">
                    <div className="flex justify-between items-center">
                      <h4 className="text-sm font-semibold text-gray-700">Modules</h4>
                      <Button size="sm" variant="outline" onClick={() => setShowModuleForm(true)}>
                        <Plus className="w-3 h-3 mr-2" /> Add Module
                      </Button>
                    </div>

                    {showModuleForm && (
                      <Card className="border-purple-100 bg-purple-50/50">
                        <CardContent className="pt-6 space-y-4">
                           <div className="flex justify-between">
                             <h4 className="font-semibold">{editingModule ? "Edit Module" : "New Module"}</h4>
                              <div className="flex gap-2">
                                <AIContentGenerator 
                                  mode="module_content"
                                  initialData={{ topic: moduleForm.title, course_title: course.title, module_title: moduleForm.title }}
                                  onGenerate={handleAIModuleContent}
                                  buttonLabel="AI Content"
                                />
                                <Button variant="ghost" size="sm" onClick={closeModuleForm}><X className="w-4 h-4" /></Button>
                              </div>
                           </div>
                           
                           <Input placeholder="Module Title" value={moduleForm.title} onChange={e => setModuleForm({...moduleForm, title: e.target.value})} />
                           
                           <div className="grid md:grid-cols-2 gap-4">
                             <Textarea placeholder="Content (Markdown)" value={moduleForm.content} onChange={e => setModuleForm({...moduleForm, content: e.target.value})} rows={10} />
                             <div className="space-y-4">
                                <Textarea placeholder="Description" value={moduleForm.description} onChange={e => setModuleForm({...moduleForm, description: e.target.value})} rows={3} />
                                <div className="grid grid-cols-2 gap-2">
                                  <Input type="number" placeholder="Mins" value={moduleForm.duration_minutes} onChange={e => setModuleForm({...moduleForm, duration_minutes: +e.target.value})} />
                                  <Input type="number" placeholder="Points" value={moduleForm.points_reward} onChange={e => setModuleForm({...moduleForm, points_reward: +e.target.value})} />
                                </div>
                                <AIContentGenerator 
                                  mode="exercises"
                                  initialData={{ content: moduleForm.content }}
                                  onGenerate={handleAIExercises}
                                  buttonLabel="Add AI Exercises"
                                />
                             </div>
                           </div>
                           
                           <Button onClick={() => saveModuleMutation.mutate(moduleForm)} className="w-full bg-purple-600">Save Module</Button>
                        </CardContent>
                      </Card>
                    )}

                    <div className="space-y-2">
                      {modules.map((mod, idx) => (
                        <div key={mod.id} className="flex items-center justify-between p-3 border rounded hover:bg-gray-50">
                          <div className="flex items-center gap-3">
                            <span className="bg-gray-100 w-6 h-6 flex items-center justify-center rounded-full text-xs font-medium">{idx + 1}</span>
                            <span>{mod.title}</span>
                          </div>
                          <div className="flex gap-2">
                            <Button variant="ghost" size="sm" onClick={() => handleEditModule(mod)}><Edit className="w-3 h-3" /></Button>
                            <Button variant="ghost" size="sm" className="text-red-500" onClick={() => deleteModuleMutation.mutate(mod.id)}><Trash2 className="w-3 h-3" /></Button>
                          </div>
                        </div>
                      ))}
                      {modules.length === 0 && !showModuleForm && <p className="text-center text-sm text-gray-500 italic py-2">No modules yet.</p>}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      </TabsContent>

      <TabsContent value="quizzes">
        <QuizManager />
      </TabsContent>

      <TabsContent value="shadow_work">
        <ShadowWorkManager />
      </TabsContent>

      <TabsContent value="progress">
        <ProgressTracker />
      </TabsContent>
      </Tabs>
    </div>
  );
}