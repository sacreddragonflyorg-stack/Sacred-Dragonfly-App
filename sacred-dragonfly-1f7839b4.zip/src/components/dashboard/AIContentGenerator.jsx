import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Sparkles, Loader2, Wand2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { useMutation } from "@tanstack/react-query";

export default function AIContentGenerator({ 
  mode, // 'outline', 'module_content', 'quiz', 'exercises', 'description'
  initialData = {}, // { topic, content, course_title, module_title }
  onGenerate,
  buttonLabel = "Generate with AI"
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [inputData, setInputData] = useState({
    topic: initialData.topic || "",
    content: initialData.content || "",
    course_title: initialData.course_title || "",
    module_title: initialData.module_title || ""
  });

  const generateMutation = useMutation({
    mutationFn: async () => {
      const { data } = await base44.functions.invoke('generateCourseContent', {
        mode,
        ...inputData
      });
      return data;
    },
    onSuccess: (data) => {
      onGenerate(data);
      setIsOpen(false);
      toast.success("Content generated successfully!");
    },
    onError: () => {
      toast.error("Failed to generate content. Please try again.");
    }
  });

  const getTitle = () => {
    switch(mode) {
      case 'outline': return "Generate Course Outline";
      case 'module_content': return "Generate Module Content";
      case 'quiz': return "Generate Quiz Questions";
      case 'exercises': return "Generate Exercises";
      case 'description': return "Generate Descriptions";
      case 'course_ideas': return "Generate Course Ideas";
      case 'hashtags': return "Generate Hashtags";
      default: return "AI Generation";
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2 text-purple-600 border-purple-200 hover:bg-purple-50">
          <Sparkles className="w-4 h-4" />
          {buttonLabel}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wand2 className="w-5 h-5 text-purple-600" />
            {getTitle()}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          {(mode === 'outline' || mode === 'description' || mode === 'module_content' || mode === 'course_ideas' || mode === 'hashtags') && (
            <div className="space-y-2">
              <label className="text-sm font-medium">
                {mode === 'course_ideas' ? "Client Need / Context" : "Topic / Context"}
              </label>
              <Input 
                value={inputData.topic} 
                onChange={(e) => setInputData(prev => ({...prev, topic: e.target.value}))}
                placeholder={mode === 'course_ideas' ? "e.g. Overcoming burnout, Grief recovery" : "e.g. Advanced Chakra Healing"}
              />
            </div>
          )}
          
          {mode === 'module_content' && (
             <div className="space-y-2">
               <label className="text-sm font-medium">Module Title</label>
               <Input 
                 value={inputData.module_title} 
                 onChange={(e) => setInputData(prev => ({...prev, module_title: e.target.value}))}
                 placeholder="e.g. Introduction to Chakras"
               />
             </div>
          )}

          {(mode === 'quiz' || mode === 'exercises') && (
            <div className="space-y-2">
              <label className="text-sm font-medium">Source Content</label>
              <Textarea 
                value={inputData.content} 
                onChange={(e) => setInputData(prev => ({...prev, content: e.target.value}))}
                placeholder="Paste the module content here..."
                rows={6}
              />
            </div>
          )}

          <Button 
            onClick={() => generateMutation.mutate()} 
            disabled={generateMutation.isPending}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600"
          >
            {generateMutation.isPending ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating...</>
            ) : (
              <><Sparkles className="w-4 h-4 mr-2" /> Generate Content</>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}