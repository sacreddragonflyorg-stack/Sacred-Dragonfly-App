import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Loader2, Copy, CheckCircle2, RefreshCw, Crown, Upload, FileText } from "lucide-react";
import { toast } from "sonner";

export default function AISessionNotes({ appointment, clientHistory = [] }) {
  const [generating, setGenerating] = useState(false);
  const [sessionNotes, setSessionNotes] = useState(appointment.session_notes || "");
  const [transcriptInput, setTranscriptInput] = useState("");
  const [aiSuggestions, setAiSuggestions] = useState(null);
  const [copied, setCopied] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(false);

  const { data: subscription } = useQuery({
    queryKey: ['practitioner-subscription-ai'],
    queryFn: async () => {
      const user = await base44.auth.me();
      const subs = await base44.entities.PractitionerSubscription.filter({ practitioner_email: user.email });
      return subs[0];
    }
  });

  const isPremium = subscription?.plan_tier === 'premium';

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingFile(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      // Use AI to extract text from the file
      const extractedData = await base44.integrations.Core.ExtractDataFromUploadedFile({
        file_url,
        json_schema: {
          type: "object",
          properties: {
            transcript: { type: "string" }
          }
        }
      });

      if (extractedData.status === 'success' && extractedData.output?.transcript) {
        setTranscriptInput(extractedData.output.transcript);
        toast.success("Transcript extracted from file!");
      } else {
        toast.error("Could not extract text from file");
      }
    } catch (error) {
      toast.error("Failed to process file");
    } finally {
      setUploadingFile(false);
    }
  };

  const generateSummary = async () => {
    setGenerating(true);
    try {
      const clientContext = clientHistory.length > 0 
        ? `Previous sessions: ${clientHistory.slice(0, 5).map(apt => 
            `${apt.service_name} on ${new Date(apt.appointment_date).toLocaleDateString()} - Notes: ${apt.notes || 'No notes'}`
          ).join('; ')}`
        : 'This is the client\'s first session.';

      const transcriptContext = transcriptInput 
        ? `\n\nSession Transcript/Recording:\n${transcriptInput}\n\n`
        : '';

      const prompt = `You are an experienced healing practitioner assistant. Generate comprehensive session notes and recommendations for this healing session.

Session Details:
- Service: ${appointment.service_name}
- Client: ${appointment.client_name}
- Date: ${new Date(appointment.appointment_date).toLocaleDateString()}
- Duration: ${appointment.duration_minutes || 60} minutes
- Client's Concerns/Notes: ${appointment.notes || 'Not specified'}

${clientContext}
${transcriptContext}

${isPremium ? `
PREMIUM ANALYSIS - Provide advanced insights:
1. A detailed session summary with specific observations and techniques used
2. Deep analysis of the client's energetic patterns and emotional themes
3. Personalized follow-up recommendations based on the session
4. Suggested timeline and focus areas for future sessions
5. Specific self-care practices tailored to the client's needs
6. Identification of any blockages or areas requiring special attention
` : `
Please provide:
1. A draft session summary (what was observed, techniques used, client's response)
2. Follow-up recommendations for the client
3. Suggested next steps or future session focus areas
4. Self-care practices or exercises to recommend
`}

Format your response as a well-structured professional note.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            session_summary: { type: "string" },
            follow_up_recommendations: { type: "string" },
            next_steps: { type: "string" },
            self_care_practices: { type: "string" },
            ...(isPremium ? {
              energetic_analysis: { type: "string" },
              blockages_identified: { type: "string" }
            } : {})
          }
        }
      });

      setAiSuggestions(response);
      
      // Auto-fill session notes
      let fullNotes = `SESSION SUMMARY:\n${response.session_summary}\n\nFOLLOW-UP RECOMMENDATIONS:\n${response.follow_up_recommendations}\n\nNEXT STEPS:\n${response.next_steps}\n\nSELF-CARE PRACTICES:\n${response.self_care_practices}`;
      
      if (isPremium && response.energetic_analysis) {
        fullNotes += `\n\nENERGETIC ANALYSIS:\n${response.energetic_analysis}\n\nBLOCKAGES IDENTIFIED:\n${response.blockages_identified}`;
      }
      
      setSessionNotes(fullNotes);
      toast.success("AI suggestions generated!");
    } catch (error) {
      toast.error("Failed to generate suggestions");
      console.error(error);
    } finally {
      setGenerating(false);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    toast.success("Copied to clipboard!");
    setTimeout(() => setCopied(false), 2000);
  };

  const saveNotes = async () => {
    try {
      await base44.entities.Appointment.update(appointment.id, {
        session_notes: sessionNotes
      });
      toast.success("Session notes saved!");
    } catch (error) {
      toast.error("Failed to save notes");
    }
  };

  return (
    <div className="space-y-4">
      <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Sparkles className="w-5 h-5 text-purple-600" />
              AI Session Assistant
              {isPremium && (
                <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
                  <Crown className="w-3 h-3 mr-1" />
                  Premium
                </Badge>
              )}
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-gray-700">
            {isPremium 
              ? "Generate advanced session summaries with deep energetic analysis and personalized recommendations."
              : "Generate professional session summaries and recommendations. Upgrade to Premium for advanced analysis."}
          </p>

          {/* Transcript Input */}
          {isPremium && (
            <div className="space-y-2 border-t pt-4">
              <Label htmlFor="transcript">Session Transcript/Recording (Optional)</Label>
              <Textarea
                id="transcript"
                value={transcriptInput}
                onChange={(e) => setTranscriptInput(e.target.value)}
                placeholder="Paste session transcript or notes here for more detailed AI analysis..."
                rows={6}
                className="font-mono text-sm"
              />
              <div className="flex gap-2">
                <input
                  type="file"
                  id="file_upload"
                  className="hidden"
                  accept=".txt,.doc,.docx,.pdf"
                  onChange={handleFileUpload}
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => document.getElementById('file_upload').click()}
                  disabled={uploadingFile}
                >
                  {uploadingFile ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
                  Upload Transcript
                </Button>
                <span className="text-xs text-gray-500 self-center">
                  Upload .txt, .doc, .docx, or .pdf files
                </span>
              </div>
            </div>
          )}
          
          <Button
            onClick={generateSummary}
            disabled={generating}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600"
          >
            {generating ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating AI Insights...</>
            ) : (
              <><Sparkles className="w-4 h-4 mr-2" /> {isPremium ? 'Generate Advanced Analysis' : 'Generate Session Notes'}</>
            )}
          </Button>

          {aiSuggestions && (
            <div className="space-y-4 pt-4 border-t">
              <div className="space-y-3">
                <div className="bg-white rounded-lg p-4 border border-purple-200">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-semibold text-sm text-purple-900">Session Summary</h4>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => copyToClipboard(aiSuggestions.session_summary)}
                    >
                      {copied ? <CheckCircle2 className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </div>
                  <p className="text-sm text-gray-700 whitespace-pre-wrap">{aiSuggestions.session_summary}</p>
                </div>

                <div className="bg-white rounded-lg p-4 border border-blue-200">
                  <h4 className="font-semibold text-sm text-blue-900 mb-2">Follow-Up Recommendations</h4>
                  <p className="text-sm text-gray-700 whitespace-pre-wrap">{aiSuggestions.follow_up_recommendations}</p>
                </div>

                <div className="bg-white rounded-lg p-4 border border-green-200">
                  <h4 className="font-semibold text-sm text-green-900 mb-2">Next Steps</h4>
                  <p className="text-sm text-gray-700 whitespace-pre-wrap">{aiSuggestions.next_steps}</p>
                </div>

                <div className="bg-white rounded-lg p-4 border border-amber-200">
                  <h4 className="font-semibold text-sm text-amber-900 mb-2">Self-Care Practices</h4>
                  <p className="text-sm text-gray-700 whitespace-pre-wrap">{aiSuggestions.self_care_practices}</p>
                </div>

                {isPremium && aiSuggestions.energetic_analysis && (
                  <>
                    <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg p-4 border-2 border-purple-300">
                      <div className="flex items-center gap-2 mb-2">
                        <Crown className="w-4 h-4 text-purple-600" />
                        <h4 className="font-semibold text-sm text-purple-900">Energetic Analysis (Premium)</h4>
                      </div>
                      <p className="text-sm text-gray-700 whitespace-pre-wrap">{aiSuggestions.energetic_analysis}</p>
                    </div>

                    <div className="bg-gradient-to-br from-pink-50 to-purple-50 rounded-lg p-4 border-2 border-pink-300">
                      <div className="flex items-center gap-2 mb-2">
                        <Sparkles className="w-4 h-4 text-pink-600" />
                        <h4 className="font-semibold text-sm text-pink-900">Blockages Identified (Premium)</h4>
                      </div>
                      <p className="text-sm text-gray-700 whitespace-pre-wrap">{aiSuggestions.blockages_identified}</p>
                    </div>
                  </>
                )}
              </div>

              <Button
                variant="outline"
                onClick={generateSummary}
                className="w-full"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Regenerate Suggestions
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Session Notes</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="session_notes">Edit and Save Notes</Label>
            <Textarea
              id="session_notes"
              value={sessionNotes}
              onChange={(e) => setSessionNotes(e.target.value)}
              rows={12}
              placeholder="Enter your session notes here..."
              className="font-mono text-sm"
            />
          </div>
          <Button onClick={saveNotes} className="w-full">
            <CheckCircle2 className="w-4 h-4 mr-2" />
            Save Session Notes
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}