import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Heart, 
  Sparkles, 
  Baby, 
  CheckCircle2, 
  BookOpen, 
  Search, 
  MessageSquare,
  Eye,
  Calendar,
  TrendingUp,
  Filter
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const moodEmojis = {
  very_low: "😔",
  low: "😕",
  neutral: "😐",
  good: "😊",
  excellent: "🤩"
};

export default function ClientProgressManager() {
  const [searchEmail, setSearchEmail] = useState("");
  const [dateFilter, setDateFilter] = useState("all");
  const [selectedEntry, setSelectedEntry] = useState(null);
  const [feedback, setFeedback] = useState("");
  const queryClient = useQueryClient();

  // Fetch all shared entries
  const { data: sharedEntries, isLoading } = useQuery({
    queryKey: ['shared-progress-entries'],
    queryFn: () => base44.entities.ProgressEntry.filter({ is_private: false }, '-entry_date'),
    initialData: [],
  });

  // Add feedback mutation
  const addFeedbackMutation = useMutation({
    mutationFn: ({ entryId, feedback }) => {
      return base44.entities.ProgressEntry.update(entryId, {
        practitioner_feedback: feedback,
        practitioner_viewed: true
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['shared-progress-entries']);
      toast.success("Feedback added successfully");
      setSelectedEntry(null);
      setFeedback("");
    },
  });

  const markAsViewedMutation = useMutation({
    mutationFn: (entryId) => {
      return base44.entities.ProgressEntry.update(entryId, {
        practitioner_viewed: true
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['shared-progress-entries']);
    },
  });

  // Filter entries
  const filteredEntries = sharedEntries.filter(entry => {
    const emailMatch = !searchEmail || entry.created_by.toLowerCase().includes(searchEmail.toLowerCase());
    
    let dateMatch = true;
    if (dateFilter !== "all") {
      const entryDate = new Date(entry.entry_date);
      const now = new Date();
      
      if (dateFilter === "today") {
        dateMatch = entryDate.toDateString() === now.toDateString();
      } else if (dateFilter === "week") {
        const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        dateMatch = entryDate >= weekAgo;
      } else if (dateFilter === "month") {
        const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        dateMatch = entryDate >= monthAgo;
      }
    }
    
    return emailMatch && dateMatch;
  });

  // Group entries by client
  const entriesByClient = filteredEntries.reduce((acc, entry) => {
    const email = entry.created_by;
    if (!acc[email]) {
      acc[email] = [];
    }
    acc[email].push(entry);
    return acc;
  }, {});

  const handleViewEntry = (entry) => {
    setSelectedEntry(entry);
    setFeedback(entry.practitioner_feedback || "");
    if (!entry.practitioner_viewed) {
      markAsViewedMutation.mutate(entry.id);
    }
  };

  const handleSubmitFeedback = () => {
    if (!feedback.trim()) {
      toast.error("Please enter feedback");
      return;
    }
    addFeedbackMutation.mutate({
      entryId: selectedEntry.id,
      feedback: feedback
    });
  };

  const newEntries = sharedEntries.filter(e => !e.practitioner_viewed).length;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-purple-600" />
              Client Progress Tracking
            </CardTitle>
            {newEntries > 0 && (
              <Badge className="bg-purple-600 text-white">
                {newEntries} New {newEntries === 1 ? 'Entry' : 'Entries'}
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Filters */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Search className="w-4 h-4" />
                Search by Client Email
              </Label>
              <Input
                value={searchEmail}
                onChange={(e) => setSearchEmail(e.target.value)}
                placeholder="client@email.com"
              />
            </div>
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Filter className="w-4 h-4" />
                Date Range
              </Label>
              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Time</SelectItem>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="week">Last 7 Days</SelectItem>
                  <SelectItem value="month">Last 30 Days</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg">
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{Object.keys(entriesByClient).length}</div>
              <div className="text-sm text-gray-600">Clients Sharing</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-pink-600">{filteredEntries.length}</div>
              <div className="text-sm text-gray-600">Total Entries</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-amber-600">{newEntries}</div>
              <div className="text-sm text-gray-600">Unviewed</div>
            </div>
          </div>

          {/* Entries List */}
          {isLoading ? (
            <div className="text-center py-8">Loading entries...</div>
          ) : filteredEntries.length === 0 ? (
            <div className="text-center py-12">
              <BookOpen className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No shared progress entries found</p>
            </div>
          ) : (
            <div className="space-y-6">
              {Object.entries(entriesByClient).map(([clientEmail, entries]) => (
                <div key={clientEmail} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="font-semibold text-lg">{clientEmail}</h3>
                      <p className="text-sm text-gray-600">{entries.length} shared {entries.length === 1 ? 'entry' : 'entries'}</p>
                    </div>
                    <Badge variant="outline">
                      {entries.filter(e => !e.practitioner_viewed).length} new
                    </Badge>
                  </div>

                  <div className="space-y-3">
                    {entries.map((entry) => (
                      <div
                        key={entry.id}
                        className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                          entry.practitioner_viewed
                            ? 'bg-gray-50 border-gray-200 hover:border-gray-300'
                            : 'bg-purple-50 border-purple-300 hover:border-purple-400'
                        }`}
                        onClick={() => handleViewEntry(entry)}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-3">
                            <div className="text-3xl">{moodEmojis[entry.mood]}</div>
                            <div>
                              <div className="font-medium">
                                {format(new Date(entry.entry_date), 'MMMM d, yyyy')}
                              </div>
                              <div className="flex gap-2 mt-1">
                                {!entry.practitioner_viewed && (
                                  <Badge className="bg-purple-600 text-white text-xs">New</Badge>
                                )}
                                {entry.practitioner_feedback && (
                                  <Badge className="bg-green-100 text-green-700 text-xs">
                                    <MessageSquare className="w-3 h-3 mr-1" />
                                    Feedback Added
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                          <Button size="sm" variant="ghost">
                            <Eye className="w-4 h-4 mr-2" />
                            View
                          </Button>
                        </div>
                        
                        <div className="flex gap-4 mt-3 text-sm text-gray-600">
                          <span>Energy: {entry.energy_level}/10</span>
                          <span>Stress: {entry.stress_level}/10</span>
                          <span>Sleep: {entry.sleep_quality}/10</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Entry Detail Dialog */}
      <Dialog open={!!selectedEntry} onOpenChange={() => setSelectedEntry(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          {selectedEntry && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3">
                  <span className="text-3xl">{moodEmojis[selectedEntry.mood]}</span>
                  {format(new Date(selectedEntry.entry_date), 'MMMM d, yyyy')}
                </DialogTitle>
                <p className="text-sm text-gray-600">{selectedEntry.created_by}</p>
              </DialogHeader>

              <div className="space-y-4">
                {/* Metrics */}
                <div className="grid grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
                  <div className="text-center">
                    <div className="text-sm text-gray-600">Energy</div>
                    <div className="text-2xl font-bold text-purple-600">{selectedEntry.energy_level}/10</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm text-gray-600">Stress</div>
                    <div className="text-2xl font-bold text-pink-600">{selectedEntry.stress_level}/10</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm text-gray-600">Sleep</div>
                    <div className="text-2xl font-bold text-blue-600">{selectedEntry.sleep_quality}/10</div>
                  </div>
                </div>

                {/* Content Sections */}
                {selectedEntry.daily_activities && (
                  <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600" />
                      <span className="font-medium text-green-900">Daily Activities</span>
                    </div>
                    <p className="text-gray-700 whitespace-pre-wrap">{selectedEntry.daily_activities}</p>
                  </div>
                )}

                {selectedEntry.journal_entry && (
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <BookOpen className="w-4 h-4 text-blue-600" />
                      <span className="font-medium text-blue-900">Journal Entry</span>
                    </div>
                    <p className="text-gray-700 whitespace-pre-wrap">{selectedEntry.journal_entry}</p>
                  </div>
                )}

                {selectedEntry.gratitude_notes && (
                  <div className="p-4 bg-gradient-to-r from-amber-50 to-pink-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Heart className="w-4 h-4 text-pink-600" />
                      <span className="font-medium text-pink-900">Gratitude</span>
                    </div>
                    <p className="text-gray-700 whitespace-pre-wrap">{selectedEntry.gratitude_notes}</p>
                  </div>
                )}

                {selectedEntry.manifestation_writing && (
                  <div className="p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg border-2 border-purple-200">
                    <div className="flex items-center gap-2 mb-2">
                      <Sparkles className="w-4 h-4 text-purple-600" />
                      <span className="font-medium text-purple-900">Manifestation</span>
                    </div>
                    <p className="text-gray-700 whitespace-pre-wrap">{selectedEntry.manifestation_writing}</p>
                  </div>
                )}

                {selectedEntry.inner_child_work && (
                  <div className="p-4 bg-gradient-to-r from-pink-50 to-purple-50 rounded-lg border-2 border-pink-200">
                    <div className="flex items-center gap-2 mb-2">
                      <Baby className="w-4 h-4 text-pink-600" />
                      <span className="font-medium text-pink-900">Inner Child Work</span>
                    </div>
                    <p className="text-gray-700 whitespace-pre-wrap italic">{selectedEntry.inner_child_work}</p>
                  </div>
                )}

                {selectedEntry.symptoms && selectedEntry.symptoms.length > 0 && (
                  <div className="p-4 bg-red-50 rounded-lg">
                    <div className="font-medium text-red-900 mb-2">Symptoms</div>
                    <div className="flex flex-wrap gap-2">
                      {selectedEntry.symptoms.map((symptom, idx) => (
                        <Badge key={idx} variant="outline" className="border-red-300 text-red-700">
                          {symptom.name} ({symptom.severity}/10)
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Practitioner Feedback Section */}
                <div className="border-t pt-4">
                  <Label className="flex items-center gap-2 mb-2">
                    <MessageSquare className="w-4 h-4 text-purple-600" />
                    Your Feedback & Guidance
                  </Label>
                  <Textarea
                    value={feedback}
                    onChange={(e) => setFeedback(e.target.value)}
                    placeholder="Share your insights, encouragement, and guidance for this client..."
                    rows={6}
                    className="mb-3"
                  />
                  <Button
                    onClick={handleSubmitFeedback}
                    disabled={addFeedbackMutation.isPending || !feedback.trim()}
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                  >
                    {addFeedbackMutation.isPending ? "Saving..." : "Add Feedback"}
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}