import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search, TrendingUp, Calendar, Eye, Lock } from "lucide-react";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const moodEmojis = {
  very_low: "😔",
  low: "😕",
  neutral: "😐",
  good: "🙂",
  excellent: "😊"
};

export default function ClientProgress() {
  const [searchEmail, setSearchEmail] = useState("");
  const [selectedClient, setSelectedClient] = useState(null);
  const [viewingEntry, setViewingEntry] = useState(null);

  const { data: allProgress } = useQuery({
    queryKey: ['all-progress'],
    queryFn: () => base44.entities.ProgressEntry.filter({ is_private: false }, '-entry_date'),
    initialData: [],
  });

  // Group by client email
  const clientProgress = {};
  allProgress.forEach(entry => {
    const email = entry.created_by;
    if (!clientProgress[email]) {
      clientProgress[email] = [];
    }
    clientProgress[email].push(entry);
  });

  const filteredClients = Object.entries(clientProgress).filter(([email]) =>
    email.toLowerCase().includes(searchEmail.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Client Progress Tracking</CardTitle>
          <p className="text-sm text-gray-600 mt-2">
            View progress entries that clients have chosen to share with you
          </p>
        </CardHeader>
        <CardContent>
          {/* Search */}
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search by client email..."
                value={searchEmail}
                onChange={(e) => setSearchEmail(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Client List */}
          {filteredClients.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <Lock className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p>No shared progress entries found</p>
              <p className="text-sm mt-2">Clients can choose to share their progress with you</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredClients.map(([email, entries]) => {
                const latestEntry = entries[0];
                const avgMood = (entries.reduce((sum, e) => sum + (e.mood_score || 0), 0) / entries.length).toFixed(1);
                
                return (
                  <Card
                    key={email}
                    className="cursor-pointer hover:shadow-lg transition-shadow"
                    onClick={() => setSelectedClient({ email, entries })}
                  >
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="font-semibold text-lg mb-2">{email}</div>
                          <div className="flex flex-wrap gap-2 text-sm text-gray-600">
                            <Badge variant="outline">
                              {entries.length} shared entries
                            </Badge>
                            <Badge variant="outline">
                              Avg Mood: {avgMood}/5
                            </Badge>
                            <Badge variant="outline">
                              Latest: {format(new Date(latestEntry.entry_date), 'MMM d, yyyy')}
                            </Badge>
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          <Eye className="w-4 h-4 mr-1" />
                          View Progress
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Client Progress Details Dialog */}
      <Dialog open={!!selectedClient} onOpenChange={() => setSelectedClient(null)}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          {selectedClient && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl">
                  Progress Overview: {selectedClient.email}
                </DialogTitle>
                <p className="text-sm text-gray-600 mt-2">
                  Viewing {selectedClient.entries.length} shared entries
                </p>
              </DialogHeader>

              {/* Quick Stats */}
              <div className="grid grid-cols-4 gap-4 mb-6">
                <Card>
                  <CardContent className="pt-4 text-center">
                    <div className="text-2xl font-bold text-purple-600">
                      {(selectedClient.entries.reduce((sum, e) => sum + (e.mood_score || 0), 0) / selectedClient.entries.length).toFixed(1)}
                    </div>
                    <div className="text-xs text-gray-600">Avg Mood</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-4 text-center">
                    <div className="text-2xl font-bold text-amber-600">
                      {(selectedClient.entries.reduce((sum, e) => sum + (e.energy_level || 0), 0) / selectedClient.entries.length).toFixed(1)}
                    </div>
                    <div className="text-xs text-gray-600">Avg Energy</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-4 text-center">
                    <div className="text-2xl font-bold text-red-600">
                      {(selectedClient.entries.reduce((sum, e) => sum + (e.stress_level || 0), 0) / selectedClient.entries.length).toFixed(1)}
                    </div>
                    <div className="text-xs text-gray-600">Avg Stress</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-4 text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {(selectedClient.entries.reduce((sum, e) => sum + (e.sleep_quality || 0), 0) / selectedClient.entries.length).toFixed(1)}
                    </div>
                    <div className="text-xs text-gray-600">Avg Sleep</div>
                  </CardContent>
                </Card>
              </div>

              {/* Entries Timeline */}
              <div className="space-y-3">
                <h3 className="font-semibold text-lg mb-4">Progress Timeline</h3>
                {selectedClient.entries.map((entry) => (
                  <Card
                    key={entry.id}
                    className="cursor-pointer hover:bg-gray-50 transition-colors"
                    onClick={() => setViewingEntry(entry)}
                  >
                    <CardContent className="py-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="text-3xl">{moodEmojis[entry.mood]}</div>
                          <div>
                            <div className="font-medium">
                              {format(new Date(entry.entry_date), 'MMMM d, yyyy')}
                            </div>
                            <div className="text-sm text-gray-600">
                              Energy: {entry.energy_level}/10 • Stress: {entry.stress_level}/10 • Sleep: {entry.sleep_quality}/10
                            </div>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm">
                          <Eye className="w-4 h-4 mr-1" />
                          Details
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Entry Details Dialog */}
      <Dialog open={!!viewingEntry} onOpenChange={() => setViewingEntry(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          {viewingEntry && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3">
                  <span className="text-3xl">{moodEmojis[viewingEntry.mood]}</span>
                  {format(new Date(viewingEntry.entry_date), 'MMMM d, yyyy')}
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-4">
                {/* Metrics */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <div className="text-sm text-gray-600 mb-1">Energy</div>
                    <div className="text-2xl font-bold text-purple-600">{viewingEntry.energy_level}/10</div>
                  </div>
                  <div className="bg-red-50 p-4 rounded-lg">
                    <div className="text-sm text-gray-600 mb-1">Stress</div>
                    <div className="text-2xl font-bold text-red-600">{viewingEntry.stress_level}/10</div>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <div className="text-sm text-gray-600 mb-1">Sleep</div>
                    <div className="text-2xl font-bold text-blue-600">{viewingEntry.sleep_quality}/10</div>
                  </div>
                </div>

                {/* Symptoms */}
                {viewingEntry.symptoms && viewingEntry.symptoms.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2">Symptoms:</h4>
                    <div className="grid md:grid-cols-2 gap-2">
                      {viewingEntry.symptoms.map((symptom, idx) => (
                        <div key={idx} className="bg-red-50 p-3 rounded-lg flex items-center justify-between">
                          <span>{symptom.name}</span>
                          <Badge variant="outline">{symptom.severity}/10</Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Journal */}
                {viewingEntry.journal_entry && (
                  <div>
                    <h4 className="font-semibold mb-2">Journal Entry:</h4>
                    <p className="bg-gray-50 p-4 rounded-lg whitespace-pre-wrap">
                      {viewingEntry.journal_entry}
                    </p>
                  </div>
                )}

                {/* Gratitude */}
                {viewingEntry.gratitude_notes && (
                  <div>
                    <h4 className="font-semibold mb-2">Gratitude:</h4>
                    <p className="bg-pink-50 p-4 rounded-lg whitespace-pre-wrap">
                      {viewingEntry.gratitude_notes}
                    </p>
                  </div>
                )}

                {/* Intentions */}
                {viewingEntry.intentions && (
                  <div>
                    <h4 className="font-semibold mb-2">Intentions:</h4>
                    <p className="bg-amber-50 p-4 rounded-lg whitespace-pre-wrap">
                      {viewingEntry.intentions}
                    </p>
                  </div>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}