import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Crown, TrendingUp, DollarSign, Users, AlertCircle, Calendar } from "lucide-react";
import { format, startOfMonth, endOfMonth, subMonths, isWithinInterval } from "date-fns";

export default function SubscriptionAnalytics() {
  const { data: practitionerSubs = [] } = useQuery({
    queryKey: ['prac-subs-analytics'],
    queryFn: () => base44.entities.PractitionerSubscription.list(),
    initialData: [],
  });

  const { data: clientSubs = [] } = useQuery({
    queryKey: ['client-subs-analytics'],
    queryFn: () => base44.entities.ClientSubscription.list(),
    initialData: [],
  });

  // Practitioner subscription stats
  const pracStats = {
    total: practitionerSubs.length,
    active: practitionerSubs.filter(s => s.status === 'active').length,
    free: practitionerSubs.filter(s => s.plan_tier === 'free').length,
    basic: practitionerSubs.filter(s => s.plan_tier === 'basic').length,
    premium: practitionerSubs.filter(s => s.plan_tier === 'premium').length,
    mrr: practitionerSubs.filter(s => s.status === 'active').reduce((sum, s) => sum + (s.monthly_price || 0), 0),
    pastDue: practitionerSubs.filter(s => s.status === 'past_due').length,
    canceled: practitionerSubs.filter(s => s.status === 'canceled').length,
    trialing: practitionerSubs.filter(s => s.status === 'trialing').length
  };

  // Client subscription stats
  const clientStats = {
    total: clientSubs.length,
    active: clientSubs.filter(s => s.status === 'active').length,
    mrr: clientSubs.filter(s => s.status === 'active').reduce((sum, s) => sum + (s.price || 0), 0),
    pastDue: clientSubs.filter(s => s.status === 'past_due').length,
    canceled: clientSubs.filter(s => s.status === 'canceled').length,
    paused: clientSubs.filter(s => s.status === 'paused').length
  };

  // Churn calculation (last month)
  const lastMonthStart = startOfMonth(subMonths(new Date(), 1));
  const lastMonthEnd = endOfMonth(subMonths(new Date(), 1));
  
  const lastMonthCanceled = [...practitionerSubs, ...clientSubs].filter(s => 
    s.canceled_at && isWithinInterval(new Date(s.canceled_at), {
      start: lastMonthStart,
      end: lastMonthEnd
    })
  ).length;
  
  const churnRate = pracStats.total + clientStats.total > 0 
    ? ((lastMonthCanceled / (pracStats.total + clientStats.total)) * 100).toFixed(1)
    : 0;

  const totalMRR = pracStats.mrr + clientStats.mrr;
  const totalActive = pracStats.active + clientStats.active;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-2xl">
            <Crown className="w-6 h-6" />
            Subscription Analytics
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Overall Stats */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4">Overall Performance</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Total MRR</p>
                <p className="text-3xl font-bold text-purple-900">${totalMRR.toFixed(0)}</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Active Subs</p>
                <p className="text-3xl font-bold text-green-900">{totalActive}</p>
              </div>
              <div className="bg-red-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Churn Rate</p>
                <p className="text-3xl font-bold text-red-900">{churnRate}%</p>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Avg. Revenue</p>
                <p className="text-3xl font-bold text-blue-900">
                  ${totalActive > 0 ? (totalMRR / totalActive).toFixed(0) : 0}
                </p>
              </div>
            </div>
          </div>

          {/* Practitioner Subscriptions */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Users className="w-5 h-5" />
              Practitioner Subscriptions
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-4">
              <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-3 rounded-lg">
                <p className="text-xs text-gray-600">Total</p>
                <p className="text-2xl font-bold text-purple-900">{pracStats.total}</p>
              </div>
              <div className="bg-green-50 p-3 rounded-lg">
                <p className="text-xs text-gray-600">Active</p>
                <p className="text-2xl font-bold text-green-900">{pracStats.active}</p>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <p className="text-xs text-gray-600">Free</p>
                <p className="text-2xl font-bold">{pracStats.free}</p>
              </div>
              <div className="bg-blue-50 p-3 rounded-lg">
                <p className="text-xs text-gray-600">Basic</p>
                <p className="text-2xl font-bold text-blue-900">{pracStats.basic}</p>
              </div>
              <div className="bg-purple-50 p-3 rounded-lg">
                <p className="text-xs text-gray-600">Premium</p>
                <p className="text-2xl font-bold text-purple-900">{pracStats.premium}</p>
              </div>
              <div className="bg-amber-50 p-3 rounded-lg">
                <p className="text-xs text-gray-600">MRR</p>
                <p className="text-2xl font-bold text-amber-900">${pracStats.mrr.toFixed(0)}</p>
              </div>
              <div className="bg-red-50 p-3 rounded-lg">
                <p className="text-xs text-gray-600">Past Due</p>
                <p className="text-2xl font-bold text-red-900">{pracStats.pastDue}</p>
              </div>
            </div>
            
            {/* Recent Practitioner Subscriptions */}
            <div className="space-y-2">
              {practitionerSubs.slice(0, 5).map((sub) => (
                <div key={sub.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200">
                  <div>
                    <p className="font-semibold">{sub.practitioner_email}</p>
                    <div className="flex items-center gap-2 text-sm">
                      <Badge className={
                        sub.plan_tier === 'premium' ? 'bg-purple-100 text-purple-800' :
                        sub.plan_tier === 'basic' ? 'bg-blue-100 text-blue-800' :
                        'bg-gray-100 text-gray-800'
                      }>
                        {sub.plan_tier === 'premium' && <Crown className="w-3 h-3 mr-1" />}
                        {sub.plan_tier?.toUpperCase()}
                      </Badge>
                      <Badge className={
                        sub.status === 'active' ? 'bg-green-100 text-green-800' :
                        sub.status === 'trialing' ? 'bg-blue-100 text-blue-800' :
                        'bg-red-100 text-red-800'
                      }>
                        {sub.status}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-green-700">${sub.monthly_price || 0}/mo</p>
                    {sub.current_period_end && (
                      <p className="text-xs text-gray-500">
                        Renews {format(new Date(sub.current_period_end), 'MMM d')}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Client Subscriptions */}
          <div>
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <DollarSign className="w-5 h-5" />
              Client Subscriptions
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-4">
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-3 rounded-lg">
                <p className="text-xs text-gray-600">Total</p>
                <p className="text-2xl font-bold text-blue-900">{clientStats.total}</p>
              </div>
              <div className="bg-green-50 p-3 rounded-lg">
                <p className="text-xs text-gray-600">Active</p>
                <p className="text-2xl font-bold text-green-900">{clientStats.active}</p>
              </div>
              <div className="bg-amber-50 p-3 rounded-lg">
                <p className="text-xs text-gray-600">MRR</p>
                <p className="text-2xl font-bold text-amber-900">${clientStats.mrr.toFixed(0)}</p>
              </div>
              <div className="bg-yellow-50 p-3 rounded-lg">
                <p className="text-xs text-gray-600">Paused</p>
                <p className="text-2xl font-bold text-yellow-900">{clientStats.paused}</p>
              </div>
              <div className="bg-red-50 p-3 rounded-lg">
                <p className="text-xs text-gray-600">Past Due</p>
                <p className="text-2xl font-bold text-red-900">{clientStats.pastDue}</p>
              </div>
            </div>

            {/* Recent Client Subscriptions */}
            <div className="space-y-2">
              {clientSubs.slice(0, 5).map((sub) => (
                <div key={sub.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200">
                  <div>
                    <p className="font-semibold">{sub.client_name}</p>
                    <div className="flex items-center gap-2 text-sm">
                      <span className="text-gray-600">{sub.plan_name}</span>
                      <Badge className={
                        sub.status === 'active' ? 'bg-green-100 text-green-800' :
                        sub.status === 'paused' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }>
                        {sub.status}
                      </Badge>
                    </div>
                    {sub.sessions_used !== undefined && (
                      <p className="text-xs text-gray-500 mt-1">
                        {sub.sessions_used}/{sub.sessions_total} sessions used
                      </p>
                    )}
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-green-700">${sub.price || 0}/{sub.billing_interval}</p>
                    {sub.current_period_end && (
                      <p className="text-xs text-gray-500">
                        Renews {format(new Date(sub.current_period_end), 'MMM d')}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Alerts */}
          {(pracStats.pastDue > 0 || clientStats.pastDue > 0) && (
            <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-red-600 mt-0.5" />
                <div>
                  <p className="font-semibold text-red-900">Payment Issues Detected</p>
                  <p className="text-sm text-red-700">
                    {pracStats.pastDue + clientStats.pastDue} subscription{pracStats.pastDue + clientStats.pastDue !== 1 ? 's' : ''} {pracStats.pastDue + clientStats.pastDue !== 1 ? 'are' : 'is'} past due. Follow up with affected customers.
                  </p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}