import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Heart, Send, CheckCircle, Clock, Plus, X } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const defaultSuggestions = [
  "Donation (any amount feels right)",
  "Barter or trade",
  "Pay what you can",
  "Pay it forward to someone else",
  "Energy exchange of your choosing"
];

export default function EnergyExchangeManager() {
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState("");
  const [formData, setFormData] = useState({
    client_email: "",
    client_name: "",
    service_name: "",
    session_date: "",
    message: "",
    suggested_options: [...defaultSuggestions],
    notes: ""
  });
  const [customOption, setCustomOption] = useState("");

  const queryClient = useQueryClient();

  // Fetch completed appointments
  const { data: completedAppointments } = useQuery({
    queryKey: ['completed-appointments-exchange'],
    queryFn: () => base44.entities.Appointment.filter({ status: 'completed' }, '-appointment_date'),
    initialData: [],
  });

  // Fetch all energy exchange requests
  const { data: exchangeRequests } = useQuery({
    queryKey: ['energy-exchange-requests'],
    queryFn: () => base44.entities.EnergyExchangeRequest.list('-created_date'),
    initialData: [],
  });

  // Create request mutation
  const createRequestMutation = useMutation({
    mutationFn: (data) => {
      return base44.entities.EnergyExchangeRequest.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['energy-exchange-requests']);
      toast.success("Energy exchange request sent!");
      setShowCreateDialog(false);
      resetForm();
    },
  });

  // Update status mutation
  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }) => {
      return base44.entities.EnergyExchangeRequest.update(id, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['energy-exchange-requests']);
      toast.success("Status updated");
    },
  });

  const resetForm = () => {
    setFormData({
      client_email: "",
      client_name: "",
      service_name: "",
      session_date: "",
      message: "",
      suggested_options: [...defaultSuggestions],
      notes: ""
    });
    setSelectedAppointment("");
    setCustomOption("");
  };

  const handleAppointmentSelect = (appointmentId) => {
    setSelectedAppointment(appointmentId);
    const apt = completedAppointments.find(a => a.id === appointmentId);
    if (apt) {
      setFormData({
        ...formData,
        client_email: apt.client_email,
        client_name: apt.client_name,
        service_name: apt.service_name,
        session_date: apt.appointment_date
      });
    }
  };

  const addCustomOption = () => {
    if (customOption.trim() && !formData.suggested_options.includes(customOption.trim())) {
      setFormData({
        ...formData,
        suggested_options: [...formData.suggested_options, customOption.trim()]
      });
      setCustomOption("");
    }
  };

  const removeOption = (option) => {
    setFormData({
      ...formData,
      suggested_options: formData.suggested_options.filter(o => o !== option)
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    createRequestMutation.mutate({
      ...formData,
      appointment_id: selectedAppointment || undefined
    });
  };

  const statusColors = {
    sent: "bg-blue-100 text-blue-800",
    acknowledged: "bg-yellow-100 text-yellow-800",
    completed: "bg-green-100 text-green-800"
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-pink-600" />
            Energy Exchange Requests
          </CardTitle>
          <Button
            onClick={() => setShowCreateDialog(true)}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Send Request
          </Button>
        </CardHeader>
        <CardContent>
          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mb-6 p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {exchangeRequests.filter(r => r.status === 'sent').length}
              </div>
              <div className="text-sm text-gray-600">Sent</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600">
                {exchangeRequests.filter(r => r.status === 'acknowledged').length}
              </div>
              <div className="text-sm text-gray-600">Acknowledged</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {exchangeRequests.filter(r => r.status === 'completed').length}
              </div>
              <div className="text-sm text-gray-600">Completed</div>
            </div>
          </div>

          {/* Requests List */}
          {exchangeRequests.length === 0 ? (
            <div className="text-center py-12">
              <Heart className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No energy exchange requests yet</p>
            </div>
          ) : (
            <div className="space-y-4">
              {exchangeRequests.map((request) => (
                <Card key={request.id} className="border-l-4 border-l-pink-500">
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-semibold text-lg">{request.client_name}</h3>
                        <p className="text-sm text-gray-600">{request.client_email}</p>
                      </div>
                      <Badge className={statusColors[request.status]}>
                        {request.status.toUpperCase()}
                      </Badge>
                    </div>

                    {request.service_name && (
                      <div className="mb-3">
                        <span className="text-sm font-medium text-purple-600">{request.service_name}</span>
                        {request.session_date && (
                          <span className="text-sm text-gray-600 ml-2">
                            • {format(new Date(request.session_date), 'MMM d, yyyy')}
                          </span>
                        )}
                      </div>
                    )}

                    <div className="bg-purple-50 rounded-lg p-4 mb-3">
                      <p className="text-sm text-gray-700 whitespace-pre-wrap">{request.message}</p>
                    </div>

                    {request.suggested_options && request.suggested_options.length > 0 && (
                      <div className="mb-3">
                        <p className="text-xs text-gray-600 mb-2">Suggested Options:</p>
                        <div className="flex flex-wrap gap-2">
                          {request.suggested_options.map((option, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {option}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {request.client_response && (
                      <div className="bg-green-50 rounded-lg p-3 mb-3">
                        <p className="text-xs text-green-900 font-medium mb-1">Client Response:</p>
                        <p className="text-sm text-gray-700">{request.client_response}</p>
                      </div>
                    )}

                    <div className="flex gap-2">
                      {request.status === 'sent' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => updateStatusMutation.mutate({ id: request.id, status: 'acknowledged' })}
                        >
                          Mark Acknowledged
                        </Button>
                      )}
                      {request.status === 'acknowledged' && (
                        <Button
                          size="sm"
                          onClick={() => updateStatusMutation.mutate({ id: request.id, status: 'completed' })}
                          className="bg-green-600 hover:bg-green-700 text-white"
                        >
                          Mark Completed
                        </Button>
                      )}
                      <p className="text-xs text-gray-500 flex items-center">
                        <Clock className="w-3 h-3 mr-1" />
                        {format(new Date(request.created_date), 'MMM d, h:mm a')}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Request Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-pink-600" />
              Send Energy Exchange Request
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Select Appointment (Optional) */}
            <div className="space-y-2">
              <Label>Link to Completed Session (Optional)</Label>
              <Select value={selectedAppointment} onValueChange={handleAppointmentSelect}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a session or enter details manually" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>None - Enter Manually</SelectItem>
                  {completedAppointments.map((apt) => (
                    <SelectItem key={apt.id} value={apt.id}>
                      {apt.client_name} - {apt.service_name} - {format(new Date(apt.appointment_date), 'MMM d, yyyy')}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Client Info */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Client Name *</Label>
                <Input
                  value={formData.client_name}
                  onChange={(e) => setFormData({ ...formData, client_name: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Client Email *</Label>
                <Input
                  type="email"
                  value={formData.client_email}
                  onChange={(e) => setFormData({ ...formData, client_email: e.target.value })}
                  required
                />
              </div>
            </div>

            {/* Session Info */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Service Name</Label>
                <Input
                  value={formData.service_name}
                  onChange={(e) => setFormData({ ...formData, service_name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Session Date</Label>
                <Input
                  type="date"
                  value={formData.session_date ? formData.session_date.split('T')[0] : ''}
                  onChange={(e) => setFormData({ ...formData, session_date: e.target.value })}
                />
              </div>
            </div>

            {/* Message */}
            <div className="space-y-2">
              <Label>Personal Message to Client *</Label>
              <Textarea
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                placeholder="Thank you for our healing session together. I'm reaching out about energy exchange for our work..."
                rows={6}
                required
              />
            </div>

            {/* Suggested Options */}
            <div className="space-y-2">
              <Label>Suggested Energy Exchange Options</Label>
              <div className="flex gap-2 mb-2">
                <Input
                  value={customOption}
                  onChange={(e) => setCustomOption(e.target.value)}
                  placeholder="Add custom option"
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addCustomOption())}
                />
                <Button type="button" onClick={addCustomOption} size="icon">
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {formData.suggested_options.map((option, idx) => (
                  <Badge key={idx} className="gap-2 bg-purple-100 text-purple-700">
                    {option}
                    <button type="button" onClick={() => removeOption(option)}>
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>

            {/* Internal Notes */}
            <div className="space-y-2">
              <Label>Internal Notes (Private)</Label>
              <Textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Private notes for your records..."
                rows={3}
              />
            </div>

            {/* Submit */}
            <div className="flex gap-2">
              <Button
                type="submit"
                disabled={createRequestMutation.isPending}
                className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                {createRequestMutation.isPending ? "Sending..." : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Send Request
                  </>
                )}
              </Button>
              <Button type="button" variant="outline" onClick={() => setShowCreateDialog(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}