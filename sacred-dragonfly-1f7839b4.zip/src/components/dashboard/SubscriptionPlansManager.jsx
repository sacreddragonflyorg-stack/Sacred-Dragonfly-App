import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, Users, DollarSign, Calendar, X } from "lucide-react";
import { toast } from "sonner";

export default function SubscriptionPlansManager() {
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [editingPlan, setEditingPlan] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    service_type: "energy_healing",
    price: "",
    billing_interval: "monthly",
    sessions_per_interval: "",
    session_duration_minutes: "",
    benefits: [],
    is_active: true
  });
  const [newBenefit, setNewBenefit] = useState("");

  const { data: plans, isLoading } = useQuery({
    queryKey: ['subscription-plans'],
    queryFn: () => base44.entities.SubscriptionPlan.list('-created_date'),
    initialData: [],
  });

  const { data: subscriptions } = useQuery({
    queryKey: ['client-subscriptions'],
    queryFn: () => base44.entities.ClientSubscription.list(),
    initialData: [],
  });

  const savePlanMutation = useMutation({
    mutationFn: (data) => {
      if (editingPlan) {
        return base44.entities.SubscriptionPlan.update(editingPlan.id, data);
      }
      return base44.entities.SubscriptionPlan.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['subscription-plans']);
      toast.success(editingPlan ? "Plan updated!" : "Plan created!");
      resetForm();
    },
  });

  const deletePlanMutation = useMutation({
    mutationFn: (id) => base44.entities.SubscriptionPlan.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['subscription-plans']);
      toast.success("Plan deleted");
    },
  });

  const resetForm = () => {
    setShowForm(false);
    setEditingPlan(null);
    setFormData({
      name: "",
      description: "",
      service_type: "energy_healing",
      price: "",
      billing_interval: "monthly",
      sessions_per_interval: "",
      session_duration_minutes: "",
      benefits: [],
      is_active: true
    });
  };

  const handleEdit = (plan) => {
    setEditingPlan(plan);
    setFormData({
      name: plan.name,
      description: plan.description,
      service_type: plan.service_type,
      price: plan.price,
      billing_interval: plan.billing_interval,
      sessions_per_interval: plan.sessions_per_interval,
      session_duration_minutes: plan.session_duration_minutes,
      benefits: plan.benefits || [],
      is_active: plan.is_active
    });
    setShowForm(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    savePlanMutation.mutate({
      ...formData,
      price: parseFloat(formData.price),
      sessions_per_interval: parseInt(formData.sessions_per_interval),
      session_duration_minutes: parseInt(formData.session_duration_minutes)
    });
  };

  const addBenefit = () => {
    if (newBenefit.trim()) {
      setFormData(prev => ({
        ...prev,
        benefits: [...prev.benefits, newBenefit.trim()]
      }));
      setNewBenefit("");
    }
  };

  const removeBenefit = (index) => {
    setFormData(prev => ({
      ...prev,
      benefits: prev.benefits.filter((_, i) => i !== index)
    }));
  };

  const getActiveSubscribersCount = (planId) => {
    return subscriptions.filter(s => s.plan_id === planId && s.status === 'active').length;
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Subscription Plans</CardTitle>
            <Button onClick={() => setShowForm(!showForm)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Plan
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {showForm && (
            <form onSubmit={handleSubmit} className="mb-6 p-4 bg-gray-50 rounded-lg space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Plan Name *</Label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="Weekly Energy Healing"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Service Type</Label>
                  <Select value={formData.service_type} onValueChange={(v) => setFormData({...formData, service_type: v})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="energy_healing">Energy Healing</SelectItem>
                      <SelectItem value="reiki">Reiki</SelectItem>
                      <SelectItem value="tarot">Tarot</SelectItem>
                      <SelectItem value="chakra_balancing">Chakra Balancing</SelectItem>
                      <SelectItem value="mixed">Mixed Services</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Description *</Label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="What's included in this subscription..."
                  rows={3}
                  required
                />
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Price ($/month) *</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.price}
                    onChange={(e) => setFormData({...formData, price: e.target.value})}
                    placeholder="99.00"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Billing Interval *</Label>
                  <Select value={formData.billing_interval} onValueChange={(v) => setFormData({...formData, billing_interval: v})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Sessions per Period *</Label>
                  <Input
                    type="number"
                    value={formData.sessions_per_interval}
                    onChange={(e) => setFormData({...formData, sessions_per_interval: e.target.value})}
                    placeholder="4"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Session Duration (minutes) *</Label>
                <Input
                  type="number"
                  value={formData.session_duration_minutes}
                  onChange={(e) => setFormData({...formData, session_duration_minutes: e.target.value})}
                  placeholder="60"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label>Benefits</Label>
                <div className="flex gap-2">
                  <Input
                    value={newBenefit}
                    onChange={(e) => setNewBenefit(e.target.value)}
                    placeholder="Add a benefit..."
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addBenefit())}
                  />
                  <Button type="button" onClick={addBenefit}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2 mt-2">
                  {formData.benefits.map((benefit, idx) => (
                    <Badge key={idx} variant="secondary" className="gap-2">
                      {benefit}
                      <button type="button" onClick={() => removeBenefit(idx)}>
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="flex gap-3">
                <Button type="submit" disabled={savePlanMutation.isPending}>
                  {savePlanMutation.isPending ? "Saving..." : editingPlan ? "Update Plan" : "Create Plan"}
                </Button>
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
              </div>
            </form>
          )}

          {isLoading ? (
            <div className="text-center py-8">Loading plans...</div>
          ) : plans.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No subscription plans yet. Create one to get started!
            </div>
          ) : (
            <div className="grid gap-4">
              {plans.map((plan) => (
                <Card key={plan.id} className="border-2">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-xl">{plan.name}</CardTitle>
                        <p className="text-sm text-gray-600 mt-1">{plan.description}</p>
                      </div>
                      <div className="flex gap-2">
                        <Button size="icon" variant="ghost" onClick={() => handleEdit(plan)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button 
                          size="icon" 
                          variant="ghost" 
                          onClick={() => deletePlanMutation.mutate(plan.id)}
                          className="text-red-600"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex flex-wrap gap-4 text-sm">
                        <div className="flex items-center gap-2">
                          <DollarSign className="w-4 h-4 text-green-600" />
                          <span className="font-semibold">${plan.price}/{plan.billing_interval}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-blue-600" />
                          <span>{plan.sessions_per_interval} sessions ({plan.session_duration_minutes} min each)</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4 text-purple-600" />
                          <span>{getActiveSubscribersCount(plan.id)} active subscribers</span>
                        </div>
                      </div>

                      {plan.benefits && plan.benefits.length > 0 && (
                        <div>
                          <p className="text-sm font-medium mb-2">Includes:</p>
                          <ul className="list-disc list-inside text-sm text-gray-700 space-y-1">
                            {plan.benefits.map((benefit, idx) => (
                              <li key={idx}>{benefit}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      <div className="flex gap-2">
                        <Badge className={plan.is_active ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"}>
                          {plan.is_active ? "Active" : "Inactive"}
                        </Badge>
                        <Badge variant="outline">{plan.service_type.replace(/_/g, ' ')}</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}