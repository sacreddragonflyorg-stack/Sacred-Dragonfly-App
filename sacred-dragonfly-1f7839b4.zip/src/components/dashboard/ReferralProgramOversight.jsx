import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Gift, Search, TrendingUp, DollarSign, Users, CheckCircle2, Clock, Award } from "lucide-react";
import { format } from "date-fns";
import ReferralRewardManager from "../referral/ReferralRewardManager";

export default function ReferralProgramOversight() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [sortBy, setSortBy] = useState("recent");

  const { data: referrals = [], refetch } = useQuery({
    queryKey: ['admin-referrals'],
    queryFn: () => base44.entities.Referral.list('-created_date'),
    initialData: [],
  });

  const { data: referralCodes = [] } = useQuery({
    queryKey: ['admin-referral-codes'],
    queryFn: () => base44.entities.ReferralCode.list(),
    initialData: [],
  });

  const filteredReferrals = referrals
    .filter(r => {
      const matchesSearch = r.referrer_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          r.referred_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          r.referral_code?.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = filterStatus === 'all' || r.status === filterStatus;
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      if (sortBy === 'recent') return new Date(b.created_date) - new Date(a.created_date);
      if (sortBy === 'reward') return (b.referrer_reward_amount || 0) - (a.referrer_reward_amount || 0);
      return 0;
    });

  const stats = {
    total: referrals.length,
    pending: referrals.filter(r => r.status === 'pending').length,
    qualified: referrals.filter(r => r.status === 'qualified').length,
    rewarded: referrals.filter(r => r.status === 'rewarded').length,
    totalRewardsIssued: referrals
      .filter(r => r.status === 'rewarded')
      .reduce((sum, r) => sum + (r.referrer_reward_amount || 0) + (r.referred_reward_amount || 0), 0),
    successRate: referrals.length > 0 
      ? ((referrals.filter(r => r.status === 'qualified' || r.status === 'rewarded').length / referrals.length) * 100).toFixed(1)
      : 0,
    activeReferrers: new Set(referrals.map(r => r.referrer_email)).size
  };

  const statusColors = {
    pending: "bg-yellow-100 text-yellow-800",
    qualified: "bg-blue-100 text-blue-800",
    rewarded: "bg-green-100 text-green-800"
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-2xl">
            <Gift className="w-6 h-6" />
            Referral Program Oversight
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-6">
            <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-4 rounded-lg">
              <p className="text-xs text-gray-600">Total</p>
              <p className="text-2xl font-bold text-purple-900">{stats.total}</p>
            </div>
            <div className="bg-yellow-50 p-4 rounded-lg">
              <p className="text-xs text-gray-600">Pending</p>
              <p className="text-2xl font-bold text-yellow-900">{stats.pending}</p>
            </div>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-xs text-gray-600">Qualified</p>
              <p className="text-2xl font-bold text-blue-900">{stats.qualified}</p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <p className="text-xs text-gray-600">Rewarded</p>
              <p className="text-2xl font-bold text-green-900">{stats.rewarded}</p>
            </div>
            <div className="bg-pink-50 p-4 rounded-lg">
              <p className="text-xs text-gray-600">Issued</p>
              <p className="text-2xl font-bold text-pink-900">${stats.totalRewardsIssued}</p>
            </div>
            <div className="bg-amber-50 p-4 rounded-lg">
              <p className="text-xs text-gray-600">Success</p>
              <p className="text-2xl font-bold text-amber-900">{stats.successRate}%</p>
            </div>
            <div className="bg-indigo-50 p-4 rounded-lg">
              <p className="text-xs text-gray-600">Referrers</p>
              <p className="text-2xl font-bold text-indigo-900">{stats.activeReferrers}</p>
            </div>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-4 mb-6">
            <div className="flex-1 min-w-[200px]">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search referrals..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Filter status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="qualified">Qualified</SelectItem>
                <SelectItem value="rewarded">Rewarded</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recent">Most Recent</SelectItem>
                <SelectItem value="reward">Reward Amount</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Referrals List */}
          <div className="space-y-3">
            {filteredReferrals.length === 0 ? (
              <p className="text-center text-gray-500 py-8">No referrals found</p>
            ) : (
              filteredReferrals.map((referral) => (
                <div key={referral.id} className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <Badge className={statusColors[referral.status]}>
                          {referral.status === 'pending' && <Clock className="w-3 h-3 mr-1" />}
                          {referral.status === 'qualified' && <CheckCircle2 className="w-3 h-3 mr-1" />}
                          {referral.status === 'rewarded' && <Award className="w-3 h-3 mr-1" />}
                          {referral.status.toUpperCase()}
                        </Badge>
                        <span className="text-xs text-gray-500">
                          Code: <code className="bg-gray-200 px-2 py-0.5 rounded">{referral.referral_code}</code>
                        </span>
                      </div>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-gray-600">Referrer</p>
                          <p className="font-semibold">{referral.referrer_name}</p>
                          <p className="text-xs text-gray-500">{referral.referrer_email}</p>
                          {referral.referrer_reward_amount > 0 && (
                            <p className="text-xs text-green-700 mt-1">
                              <DollarSign className="w-3 h-3 inline" />
                              ${referral.referrer_reward_amount} {referral.referrer_reward_type}
                            </p>
                          )}
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Referred</p>
                          <p className="font-semibold">{referral.referred_name}</p>
                          <p className="text-xs text-gray-500">{referral.referred_email}</p>
                          {referral.referred_reward_amount > 0 && (
                            <p className="text-xs text-blue-700 mt-1">
                              <DollarSign className="w-3 h-3 inline" />
                              ${referral.referred_reward_amount} {referral.referred_reward_type}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="mt-2 flex items-center gap-4 text-xs text-gray-500">
                        <span>Created: {format(new Date(referral.created_date), 'MMM d, yyyy')}</span>
                        {referral.qualification_date && (
                          <span>Qualified: {format(new Date(referral.qualification_date), 'MMM d, yyyy')}</span>
                        )}
                        {referral.reward_issued_date && (
                          <span>Rewarded: {format(new Date(referral.reward_issued_date), 'MMM d, yyyy')}</span>
                        )}
                      </div>
                    </div>
                    <div>
                      <ReferralRewardManager 
                        referralId={referral.id} 
                        referral={referral}
                        onSuccess={refetch}
                      />
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Top Referrers */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Top Referrers
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {referralCodes
              .sort((a, b) => (b.uses_count || 0) - (a.uses_count || 0))
              .slice(0, 10)
              .map((code, index) => (
                <div key={code.id} className="flex items-center justify-between p-3 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-purple-600 text-white flex items-center justify-center font-bold">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-semibold">{code.referrer_name}</p>
                      <p className="text-xs text-gray-600">{code.referrer_email}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-purple-900">{code.uses_count || 0} referrals</p>
                    <p className="text-xs text-green-700">${code.total_rewards_earned || 0} earned</p>
                  </div>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}