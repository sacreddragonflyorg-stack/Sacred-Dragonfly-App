import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bell, Mail, MessageSquare, Save, Play, Loader2, Info } from "lucide-react";
import { toast } from "sonner";

const DEFAULT_TEMPLATES = {
  client_email: `Hello {{client_name}},

This is a reminder for your upcoming session:
Service: {{service_name}}
Date: {{date}}
Time: {{time}}

Please confirm here: {{confirm_url}}

If you need to reschedule: {{reschedule_url}}

Warmly,
Sacred Healing`,
  client_sms: `Reminder: Healing session with {{practitioner_name}} on {{date}} at {{time}}. Confirm: {{confirm_url}}`,
  practitioner_email: `Reminder: You have a session with {{client_name}} tomorrow at {{time}}. Service: {{service_name}}.`,
  practitioner_sms: `Session Alert: {{client_name}} - {{service_name}} on {{date}} at {{time}}.`
};

export default function AppointmentReminders() {
  const queryClient = useQueryClient();
  const [settings, setSettings] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  // Fetch Settings
  const { data: fetchedSettings, isLoading } = useQuery({
    queryKey: ['reminder-settings'],
    queryFn: async () => {
      const res = await base44.entities.ReminderSettings.list();
      return res[0] || null;
    }
  });

  useEffect(() => {
    if (fetchedSettings) {
      setSettings(fetchedSettings);
    } else if (!isLoading) {
      // Initialize defaults if no settings found
      setSettings({
        reminder_hours_before: 24,
        enable_email: true,
        enable_sms: false,
        client_email_template: DEFAULT_TEMPLATES.client_email,
        client_sms_template: DEFAULT_TEMPLATES.client_sms,
        practitioner_email_template: DEFAULT_TEMPLATES.practitioner_email,
        practitioner_sms_template: DEFAULT_TEMPLATES.practitioner_sms,
        twilio_account_sid: "",
        twilio_auth_token: "",
        twilio_phone_number: ""
      });
    }
  }, [fetchedSettings, isLoading]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (fetchedSettings?.id) {
        return base44.entities.ReminderSettings.update(fetchedSettings.id, data);
      } else {
        return base44.entities.ReminderSettings.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['reminder-settings']);
      toast.success("Settings saved successfully");
    },
    onError: () => toast.error("Failed to save settings")
  });

  const sendRemindersMutation = useMutation({
    mutationFn: async () => {
      // Call backend function to process reminders
      return base44.functions.invoke('sendAppointmentReminders');
    },
    onSuccess: (res) => {
      if (res.data?.success) {
        toast.success(`Processed reminders. Sent: ${res.data.sentCount}`);
      } else {
        toast.error("Error processing reminders: " + res.data?.error);
      }
    },
    onError: (err) => toast.error("Failed to trigger reminders: " + err.message)
  });

  const handleSave = () => {
    saveMutation.mutate(settings);
  };

  const handleChange = (field, value) => {
    setSettings(prev => ({ ...prev, [field]: value }));
  };

  if (isLoading || !settings) return <div className="p-8 text-center"><Loader2 className="animate-spin mx-auto" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
           <h2 className="text-2xl font-bold">Reminder Configuration</h2>
           <p className="text-gray-500">Configure automated appointment reminders for clients and practitioners.</p>
        </div>
        <div className="flex gap-2">
           <Button variant="outline" onClick={() => sendRemindersMutation.mutate()} disabled={sendRemindersMutation.isPending}>
             {sendRemindersMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Play className="w-4 h-4 mr-2" />}
             Run Now
           </Button>
           <Button onClick={handleSave} disabled={saveMutation.isPending}>
             {saveMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
             Save Changes
           </Button>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* General Settings */}
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>General Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
             <div className="space-y-2">
                <Label>Reminder Timing (Hours Before)</Label>
                <Input 
                  type="number" 
                  value={settings.reminder_hours_before} 
                  onChange={(e) => handleChange('reminder_hours_before', parseInt(e.target.value))}
                />
                <p className="text-xs text-gray-500">Usually 24 or 48 hours.</p>
             </div>
             
             <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-2">
                   <Mail className="w-4 h-4 text-purple-600" />
                   <Label className="cursor-pointer" htmlFor="enable_email">Enable Email</Label>
                </div>
                <Switch 
                  id="enable_email" 
                  checked={settings.enable_email} 
                  onCheckedChange={(c) => handleChange('enable_email', c)} 
                />
             </div>

             <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-2">
                   <MessageSquare className="w-4 h-4 text-green-600" />
                   <Label className="cursor-pointer" htmlFor="enable_sms">Enable SMS</Label>
                </div>
                <Switch 
                  id="enable_sms" 
                  checked={settings.enable_sms} 
                  onCheckedChange={(c) => handleChange('enable_sms', c)} 
                />
             </div>

             {settings.enable_sms && (
               <div className="space-y-3 pt-4 border-t">
                 <h4 className="text-sm font-semibold">Twilio Configuration</h4>
                 <div className="space-y-1">
                    <Label className="text-xs">Account SID</Label>
                    <Input className="h-8" value={settings.twilio_account_sid} onChange={(e) => handleChange('twilio_account_sid', e.target.value)} type="password" />
                 </div>
                 <div className="space-y-1">
                    <Label className="text-xs">Auth Token</Label>
                    <Input className="h-8" value={settings.twilio_auth_token} onChange={(e) => handleChange('twilio_auth_token', e.target.value)} type="password" />
                 </div>
                 <div className="space-y-1">
                    <Label className="text-xs">From Number</Label>
                    <Input className="h-8" value={settings.twilio_phone_number} onChange={(e) => handleChange('twilio_phone_number', e.target.value)} placeholder="+1..." />
                 </div>
               </div>
             )}
          </CardContent>
        </Card>

        {/* Templates */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Message Templates</CardTitle>
            <CardDescription>
              Use variables like <code className="bg-gray-100 px-1 rounded">{"{{client_name}}"}</code>, <code className="bg-gray-100 px-1 rounded">{"{{date}}"}</code>, <code className="bg-gray-100 px-1 rounded">{"{{time}}"}</code>, <code className="bg-gray-100 px-1 rounded">{"{{service_name}}"}</code>, <code className="bg-gray-100 px-1 rounded">{"{{confirm_url}}"}</code>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="client">
               <TabsList className="mb-4">
                 <TabsTrigger value="client">Client Reminders</TabsTrigger>
                 <TabsTrigger value="practitioner">Practitioner Reminders</TabsTrigger>
               </TabsList>

               <TabsContent value="client" className="space-y-4">
                  <div className="space-y-2">
                     <Label>Client Email Template</Label>
                     <Textarea 
                        rows={8}
                        value={settings.client_email_template}
                        onChange={(e) => handleChange('client_email_template', e.target.value)}
                     />
                  </div>
                  <div className="space-y-2">
                     <Label>Client SMS Template</Label>
                     <Textarea 
                        rows={3}
                        value={settings.client_sms_template}
                        onChange={(e) => handleChange('client_sms_template', e.target.value)}
                     />
                     <p className="text-xs text-gray-500 text-right">Keep SMS short to avoid segmentation costs.</p>
                  </div>
               </TabsContent>

               <TabsContent value="practitioner" className="space-y-4">
                  <div className="space-y-2">
                     <Label>Practitioner Email Template</Label>
                     <Textarea 
                        rows={8}
                        value={settings.practitioner_email_template}
                        onChange={(e) => handleChange('practitioner_email_template', e.target.value)}
                     />
                  </div>
                  <div className="space-y-2">
                     <Label>Practitioner SMS Template</Label>
                     <Textarea 
                        rows={3}
                        value={settings.practitioner_sms_template}
                        onChange={(e) => handleChange('practitioner_sms_template', e.target.value)}
                     />
                  </div>
               </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}