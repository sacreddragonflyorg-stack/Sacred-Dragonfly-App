import React, { useState, useMemo } from "react";
import { format, startOfWeek, endOfWeek, startOfDay, endOfDay, eachDayOfInterval, eachHourOfInterval, isSameDay, isSameHour, addWeeks, subWeeks, addDays, setHours, setMinutes, isWithinInterval } from "date-fns";
import { ChevronLeft, ChevronRight, Clock, Lock, Calendar as CalendarIcon, MoreHorizontal, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function InteractiveBookingCalendar({ 
  appointments = [], 
  blockedTimes = [], 
  userEmail,
  viewMode = 'week' // 'week' | 'day'
}) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [blockReason, setBlockReason] = useState("");
  const [isBlockModalOpen, setIsBlockModalOpen] = useState(false);
  const queryClient = useQueryClient();

  // Navigation
  const nextPeriod = () => {
    setCurrentDate(prev => viewMode === 'week' ? addWeeks(prev, 1) : addDays(prev, 1));
  };

  const prevPeriod = () => {
    setCurrentDate(prev => viewMode === 'week' ? subWeeks(prev, 1) : addDays(prev, -1));
  };

  const goToToday = () => setCurrentDate(new Date());

  // Data Preparation
  const days = useMemo(() => {
    const start = viewMode === 'week' ? startOfWeek(currentDate, { weekStartsOn: 1 }) : startOfDay(currentDate);
    const end = viewMode === 'week' ? endOfWeek(currentDate, { weekStartsOn: 1 }) : endOfDay(currentDate);
    return eachDayOfInterval({ start, end });
  }, [currentDate, viewMode]);

  const hours = useMemo(() => {
    const start = setHours(startOfDay(new Date()), 8); // Start at 8 AM
    const end = setHours(startOfDay(new Date()), 20); // End at 8 PM
    return eachHourOfInterval({ start, end });
  }, []);

  // Mutations
  const blockTimeMutation = useMutation({
    mutationFn: async (data) => {
      return base44.entities.BlockedTime.create({
        practitioner_email: userEmail,
        start_time: data.start.toISOString(),
        end_time: data.end.toISOString(),
        reason: data.reason,
        is_all_day: false
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['blocked-times']);
      toast.success("Time blocked successfully");
      setIsBlockModalOpen(false);
      setBlockReason("");
      setSelectedSlot(null);
    },
    onError: () => toast.error("Failed to block time")
  });

  const deleteBlockMutation = useMutation({
    mutationFn: async (id) => base44.entities.BlockedTime.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['blocked-times']);
      toast.success("Block removed");
    }
  });

  // Interaction Handlers
  const handleSlotClick = (day, hour) => {
    const start = setMinutes(setHours(day, hour.getHours()), 0);
    const end = setMinutes(setHours(day, hour.getHours() + 1), 0);
    setSelectedSlot({ start, end });
    setIsBlockModalOpen(true);
  };

  const handleBlockSubmit = () => {
    if (selectedSlot) {
      blockTimeMutation.mutate({
        start: selectedSlot.start,
        end: selectedSlot.end,
        reason: blockReason
      });
    }
  };

  // Rendering Helpers
  const getEventsForSlot = (day, hour) => {
    const slotStart = setMinutes(setHours(day, hour.getHours()), 0);
    const slotEnd = setMinutes(setHours(day, hour.getHours() + 1), 0);

    const slotAppointments = appointments.filter(apt => {
      const aptStart = new Date(apt.appointment_date);
      return isSameDay(aptStart, day) && isSameHour(aptStart, slotStart) && apt.status !== 'cancelled';
    });

    const slotBlocks = blockedTimes.filter(block => {
      const blockStart = new Date(block.start_time);
      const blockEnd = new Date(block.end_time);
      // Simple overlap check for hourly grid
      return (
        (blockStart < slotEnd && blockEnd > slotStart)
      );
    });

    return { appointments: slotAppointments, blocks: slotBlocks };
  };

  return (
    <div className="h-[800px] flex flex-col bg-white rounded-lg border shadow-sm">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center gap-4">
          <h2 className="text-xl font-semibold text-gray-900">
            {format(currentDate, viewMode === 'week' ? 'MMMM yyyy' : 'MMMM d, yyyy')}
          </h2>
          <div className="flex items-center bg-gray-100 rounded-lg p-1">
            <Button variant="ghost" size="sm" onClick={prevPeriod} className="h-8 w-8 p-0">
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={goToToday} className="h-8 px-3 text-xs">
              Today
            </Button>
            <Button variant="ghost" size="sm" onClick={nextPeriod} className="h-8 w-8 p-0">
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 text-sm text-gray-500 mr-4">
            <span className="w-3 h-3 rounded-full bg-purple-100 border border-purple-300"></span> Appointment
            <span className="w-3 h-3 rounded-full bg-gray-100 border border-gray-300 ml-2"></span> Blocked
          </div>
        </div>
      </div>

      {/* Calendar Grid */}
      <div className="flex-1 overflow-y-auto">
        <div className="min-w-[800px]">
          {/* Header Row */}
          <div className="flex border-b sticky top-0 bg-white z-10">
            <div className="w-16 flex-shrink-0 border-r bg-gray-50"></div> {/* Time column header */}
            {days.map(day => (
              <div key={day.toISOString()} className={`flex-1 p-2 text-center border-r ${isSameDay(day, new Date()) ? 'bg-purple-50' : ''}`}>
                <div className="text-xs font-medium text-gray-500 uppercase">{format(day, 'EEE')}</div>
                <div className={`text-lg font-bold ${isSameDay(day, new Date()) ? 'text-purple-600' : 'text-gray-900'}`}>
                  {format(day, 'd')}
                </div>
              </div>
            ))}
          </div>

          {/* Time Slots */}
          <div className="relative">
            {hours.map(hour => (
              <div key={hour.toISOString()} className="flex border-b h-20">
                {/* Time Label */}
                <div className="w-16 flex-shrink-0 border-r p-2 text-xs text-gray-500 text-right sticky left-0 bg-white">
                  {format(hour, 'h a')}
                </div>

                {/* Days */}
                {days.map(day => {
                  const { appointments: slotApts, blocks: slotBlocks } = getEventsForSlot(day, hour);
                  const hasEvents = slotApts.length > 0 || slotBlocks.length > 0;

                  return (
                    <div 
                      key={day.toISOString() + hour.toISOString()} 
                      className="flex-1 border-r relative group hover:bg-gray-50 transition-colors"
                      onClick={() => !hasEvents && handleSlotClick(day, hour)}
                    >
                      {!hasEvents && (
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 pointer-events-none">
                          <Button variant="ghost" size="sm" className="h-6 text-xs bg-white/80 shadow-sm pointer-events-auto">
                            <Lock className="w-3 h-3 mr-1" /> Block
                          </Button>
                        </div>
                      )}

                      {/* Render Blocks */}
                      {slotBlocks.map(block => (
                        <div key={block.id} className="absolute inset-1 bg-gray-100 border border-gray-300 rounded p-1 overflow-hidden">
                          <div className="flex justify-between items-start">
                            <div className="flex items-center gap-1 text-xs font-medium text-gray-600">
                              <Lock className="w-3 h-3" />
                              <span className="truncate">{block.reason || 'Unavailable'}</span>
                            </div>
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="h-4 w-4 p-0 hover:bg-red-100 hover:text-red-600"
                                    onClick={(e) => { e.stopPropagation(); deleteBlockMutation.mutate(block.id); }}
                                  >
                                    <Trash2 className="w-3 h-3" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>Remove Block</TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </div>
                        </div>
                      ))}

                      {/* Render Appointments */}
                      {slotApts.map(apt => (
                        <div 
                          key={apt.id} 
                          className={`absolute inset-1 rounded p-1 overflow-hidden border cursor-pointer ${
                            apt.status === 'confirmed' ? 'bg-blue-100 border-blue-300' : 
                            apt.status === 'completed' ? 'bg-green-100 border-green-300' : 
                            'bg-purple-100 border-purple-300'
                          }`}
                          onClick={(e) => { e.stopPropagation(); /* Maybe show details popover */ }}
                        >
                          <div className="text-xs font-semibold truncate">{apt.client_name}</div>
                          <div className="text-[10px] text-gray-600 truncate">{apt.service_name}</div>
                        </div>
                      ))}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Block Time Dialog */}
      <Dialog open={isBlockModalOpen} onOpenChange={setIsBlockModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Block Time Slot</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Time Slot</Label>
              <div className="p-2 bg-gray-50 rounded text-sm">
                {selectedSlot && format(selectedSlot.start, 'EEEE, MMM d')} • {selectedSlot && format(selectedSlot.start, 'h:mm a')} - {selectedSlot && format(selectedSlot.end, 'h:mm a')}
              </div>
            </div>
            <div className="space-y-2">
              <Label>Reason (Optional)</Label>
              <Input 
                placeholder="Meeting, Lunch, Personal..." 
                value={blockReason}
                onChange={(e) => setBlockReason(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsBlockModalOpen(false)}>Cancel</Button>
            <Button onClick={handleBlockSubmit} disabled={blockTimeMutation.isPending}>
              {blockTimeMutation.isPending ? "Blocking..." : "Confirm Block"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}