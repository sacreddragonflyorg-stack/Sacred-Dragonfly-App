import React from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Mail, Phone, CheckCircle, XCircle } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

const statusColors = {
  pending: "bg-yellow-100 text-yellow-800",
  confirmed: "bg-blue-100 text-blue-800",
  completed: "bg-green-100 text-green-800",
  cancelled: "bg-red-100 text-red-800"
};

export default function AppointmentsList({ appointments }) {
  const queryClient = useQueryClient();

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.Appointment.update(id, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries(['all-appointments']);
      toast.success("Appointment status updated");
    },
  });

  const upcomingAppointments = appointments.filter(
    apt => new Date(apt.appointment_date) >= new Date() && apt.status !== 'cancelled'
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle>Appointment Management</CardTitle>
      </CardHeader>
      <CardContent>
        {upcomingAppointments.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <Calendar className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <p>No upcoming appointments</p>
          </div>
        ) : (
          <div className="space-y-4">
            {upcomingAppointments.map((appointment) => (
              <div key={appointment.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                <div className="flex flex-wrap items-start justify-between gap-4 mb-3">
                  <div>
                    <h3 className="font-semibold text-lg">{appointment.service_name}</h3>
                    <p className="text-sm text-gray-600">{appointment.client_name}</p>
                  </div>
                  <Badge className={statusColors[appointment.status]}>
                    {appointment.status.toUpperCase()}
                  </Badge>
                </div>

                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-gray-500" />
                      <span>{format(new Date(appointment.appointment_date), 'EEEE, MMM d, yyyy - h:mm a')}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-gray-500" />
                      <span>{appointment.client_email}</span>
                    </div>
                    {appointment.phone && (
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-gray-500" />
                        <span>{appointment.phone}</span>
                      </div>
                    )}
                  </div>
                  <div>
                    {appointment.notes && (
                      <div className="bg-purple-50 rounded p-3 text-sm">
                        <p className="font-medium text-purple-900 mb-1">Notes:</p>
                        <p className="text-gray-700">{appointment.notes}</p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex gap-2">
                  {appointment.status === 'pending' && (
                    <Button
                      size="sm"
                      onClick={() => updateStatusMutation.mutate({ id: appointment.id, status: 'confirmed' })}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      <CheckCircle className="w-4 h-4 mr-1" />
                      Confirm
                    </Button>
                  )}
                  {appointment.status === 'confirmed' && (
                    <Button
                      size="sm"
                      onClick={() => updateStatusMutation.mutate({ id: appointment.id, status: 'completed' })}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <CheckCircle className="w-4 h-4 mr-1" />
                      Mark Complete
                    </Button>
                  )}
                  {appointment.status !== 'cancelled' && appointment.status !== 'completed' && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => updateStatusMutation.mutate({ id: appointment.id, status: 'cancelled' })}
                      className="text-red-600 hover:bg-red-50"
                    >
                      <XCircle className="w-4 h-4 mr-1" />
                      Cancel
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}