import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock } from "lucide-react";
import { format, startOfWeek, addDays, isSameDay, isToday } from "date-fns";

export default function WeeklyCalendar({ appointments }) {
  const today = new Date();
  const weekStart = startOfWeek(today, { weekStartsOn: 1 }); // Monday
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  const getAppointmentsForDay = (day) => {
    return appointments.filter(apt => 
      isSameDay(new Date(apt.appointment_date), day) && 
      apt.status !== 'cancelled'
    ).sort((a, b) => new Date(a.appointment_date) - new Date(b.appointment_date));
  };

  const statusColors = {
    pending: "bg-yellow-100 text-yellow-800",
    confirmed: "bg-blue-100 text-blue-800",
    completed: "bg-green-100 text-green-800",
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="w-5 h-5" />
          Weekly Schedule
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-7 gap-2">
          {weekDays.map((day, index) => {
            const dayAppointments = getAppointmentsForDay(day);
            const isCurrentDay = isToday(day);
            
            return (
              <div
                key={index}
                className={`p-3 rounded-lg border-2 transition-all ${
                  isCurrentDay
                    ? 'border-purple-500 bg-purple-50'
                    : 'border-gray-200 bg-white'
                }`}
              >
                <div className="text-center mb-2">
                  <p className="text-xs font-medium text-gray-500">
                    {format(day, 'EEE')}
                  </p>
                  <p className={`text-lg font-bold ${
                    isCurrentDay ? 'text-purple-600' : 'text-gray-900'
                  }`}>
                    {format(day, 'd')}
                  </p>
                </div>

                <div className="space-y-1">
                  {dayAppointments.length === 0 ? (
                    <p className="text-xs text-gray-400 text-center py-2">No sessions</p>
                  ) : (
                    dayAppointments.map((apt) => (
                      <div
                        key={apt.id}
                        className="p-2 bg-white rounded border border-gray-200 hover:shadow-md transition-shadow cursor-pointer"
                      >
                        <div className="flex items-center gap-1 mb-1">
                          <Clock className="w-3 h-3 text-gray-500" />
                          <span className="text-xs font-medium">
                            {format(new Date(apt.appointment_date), 'HH:mm')}
                          </span>
                        </div>
                        <p className="text-xs font-semibold text-gray-900 truncate">
                          {apt.client_name}
                        </p>
                        <p className="text-xs text-gray-600 truncate">
                          {apt.service_name}
                        </p>
                        <Badge className={`${statusColors[apt.status]} text-xs mt-1`}>
                          {apt.status}
                        </Badge>
                      </div>
                    ))
                  )}
                </div>

                {dayAppointments.length > 3 && (
                  <p className="text-xs text-center text-purple-600 mt-2 font-medium">
                    +{dayAppointments.length - 3} more
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}