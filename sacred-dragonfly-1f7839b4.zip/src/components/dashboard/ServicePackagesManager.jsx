import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, Package, DollarSign, Calendar, CheckCircle2, Loader2, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function ServicePackagesManager() {
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingPackage, setEditingPackage] = useState(null);
  const [selectedServices, setSelectedServices] = useState([]);
  const [packageType, setPackageType] = useState("one_time");
  const [pricingType, setPricingType] = useState("simple");
  const [tiers, setTiers] = useState([]);
  const [validityOptions, setValidityOptions] = useState([]);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    package_price: "",
    validity_days: 90,
    flexible_validity: false,
    subscription_interval: "monthly",
    subscription_sessions_per_interval: 4,
    auto_renew: true,
    benefits: "",
    image_url: "",
    max_purchases: ""
  });

  const { data: packages = [], isLoading: packagesLoading } = useQuery({
    queryKey: ['service-packages'],
    queryFn: () => base44.entities.ServicePackage.list('-created_date'),
  });

  const { data: services = [] } = useQuery({
    queryKey: ['services'],
    queryFn: () => base44.entities.Service.filter({ is_active: true }),
  });

  const createPackageMutation = useMutation({
    mutationFn: async (data) => base44.entities.ServicePackage.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['service-packages']);
      toast.success("Package created successfully!");
      resetForm();
    },
    onError: () => {
      toast.error("Failed to create package");
    }
  });

  const updatePackageMutation = useMutation({
    mutationFn: async ({ id, data }) => base44.entities.ServicePackage.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['service-packages']);
      toast.success("Package updated successfully!");
      resetForm();
    },
    onError: () => {
      toast.error("Failed to update package");
    }
  });

  const deletePackageMutation = useMutation({
    mutationFn: async (id) => base44.entities.ServicePackage.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['service-packages']);
      toast.success("Package deleted");
    },
    onError: () => {
      toast.error("Failed to delete package");
    }
  });

  const handleServiceToggle = (service) => {
    setSelectedServices(prev => {
      const exists = prev.find(s => s.id === service.id);
      if (exists) {
        return prev.filter(s => s.id !== service.id);
      } else {
        return [...prev, { ...service, session_count: 1, custom_duration_minutes: service.duration_minutes }];
      }
    });
  };

  const updateServiceConfig = (serviceId, field, value) => {
    setSelectedServices(prev => 
      prev.map(s => s.id === serviceId ? { ...s, [field]: value } : s)
    );
  };

  const addTier = () => {
    setTiers(prev => [...prev, { tier_name: "", price: "", sessions_included: "", validity_days: 90, description: "" }]);
  };

  const updateTier = (index, field, value) => {
    setTiers(prev => prev.map((t, i) => i === index ? { ...t, [field]: value } : t));
  };

  const removeTier = (index) => {
    setTiers(prev => prev.filter((_, i) => i !== index));
  };

  const addValidityOption = (days) => {
    if (days && !validityOptions.includes(parseInt(days))) {
      setValidityOptions(prev => [...prev, parseInt(days)].sort((a, b) => a - b));
    }
  };

  const removeValidityOption = (days) => {
    setValidityOptions(prev => prev.filter(d => d !== days));
  };

  const calculateRegularPrice = () => {
    return selectedServices.reduce((sum, s) => sum + (s.price || 0), 0);
  };

  const calculateSavings = () => {
    const regular = calculateRegularPrice();
    const packagePrice = parseFloat(formData.package_price) || 0;
    return regular - packagePrice;
  };

  const handleSubmit = () => {
    if (!formData.name || !formData.description || selectedServices.length === 0) {
      toast.error("Please fill in all required fields and select at least one service");
      return;
    }

    if (packageType === "one_time" && pricingType === "simple" && !formData.package_price) {
      toast.error("Please enter a package price");
      return;
    }

    if (pricingType === "tiered" && tiers.length === 0) {
      toast.error("Please add at least one pricing tier");
      return;
    }

    const totalSessions = selectedServices.reduce((sum, s) => sum + (s.session_count || 1), 0);
    
    const packageData = {
      ...formData,
      package_type: packageType,
      service_ids: selectedServices.map(s => s.id),
      service_names: selectedServices.map(s => s.name),
      service_configs: selectedServices.map(s => ({
        service_id: s.id,
        service_name: s.name,
        session_count: s.session_count || 1,
        custom_duration_minutes: s.custom_duration_minutes || s.duration_minutes
      })),
      regular_price: calculateRegularPrice(),
      total_sessions: totalSessions,
      benefits: formData.benefits ? formData.benefits.split('\n').filter(b => b.trim()) : [],
      max_purchases: formData.max_purchases ? parseInt(formData.max_purchases) : null,
      validity_days: parseInt(formData.validity_days),
      validity_options: formData.flexible_validity ? validityOptions : null,
      subscription_sessions_per_interval: packageType === "subscription" ? parseInt(formData.subscription_sessions_per_interval) : null,
      auto_renew: packageType === "subscription" ? formData.auto_renew : null
    };

    // Handle pricing based on type
    if (pricingType === "tiered") {
      packageData.pricing_tiers = tiers.map(t => ({
        ...t,
        price: parseFloat(t.price),
        sessions_included: parseInt(t.sessions_included),
        validity_days: parseInt(t.validity_days)
      }));
      packageData.package_price = null;
      packageData.savings = null;
    } else {
      packageData.package_price = parseFloat(formData.package_price);
      packageData.savings = calculateSavings();
      packageData.pricing_tiers = null;
    }

    if (editingPackage) {
      updatePackageMutation.mutate({ id: editingPackage.id, data: packageData });
    } else {
      createPackageMutation.mutate(packageData);
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      package_price: "",
      validity_days: 90,
      flexible_validity: false,
      subscription_interval: "monthly",
      subscription_sessions_per_interval: 4,
      auto_renew: true,
      benefits: "",
      image_url: "",
      max_purchases: ""
    });
    setSelectedServices([]);
    setPackageType("one_time");
    setPricingType("simple");
    setTiers([]);
    setValidityOptions([]);
    setEditingPackage(null);
    setIsDialogOpen(false);
  };

  const handleEdit = (pkg) => {
    setEditingPackage(pkg);
    setPackageType(pkg.package_type || "one_time");
    setPricingType(pkg.pricing_tiers ? "tiered" : "simple");
    setFormData({
      name: pkg.name,
      description: pkg.description,
      package_price: pkg.package_price?.toString() || "",
      validity_days: pkg.validity_days,
      flexible_validity: pkg.flexible_validity || false,
      subscription_interval: pkg.subscription_interval || "monthly",
      subscription_sessions_per_interval: pkg.subscription_sessions_per_interval || 4,
      auto_renew: pkg.auto_renew !== false,
      benefits: pkg.benefits?.join('\n') || "",
      image_url: pkg.image_url || "",
      max_purchases: pkg.max_purchases?.toString() || ""
    });
    
    if (pkg.service_configs) {
      const pkgServices = services.filter(s => pkg.service_ids.includes(s.id)).map(s => {
        const config = pkg.service_configs.find(c => c.service_id === s.id);
        return {
          ...s,
          session_count: config?.session_count || 1,
          custom_duration_minutes: config?.custom_duration_minutes || s.duration_minutes
        };
      });
      setSelectedServices(pkgServices);
    } else {
      const pkgServices = services.filter(s => pkg.service_ids.includes(s.id));
      setSelectedServices(pkgServices.map(s => ({ ...s, session_count: 1, custom_duration_minutes: s.duration_minutes })));
    }
    
    setTiers(pkg.pricing_tiers || []);
    setValidityOptions(pkg.validity_options || []);
    setIsDialogOpen(true);
  };

  const handleDelete = (id) => {
    if (confirm("Are you sure you want to delete this package?")) {
      deletePackageMutation.mutate(id);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Service Packages</h2>
          <p className="text-gray-600">Create bundled offerings at discounted prices</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600" onClick={() => { resetForm(); setIsDialogOpen(true); }}>
              <Plus className="w-4 h-4 mr-2" />
              Create Package
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingPackage ? 'Edit Package' : 'Create Service Package'}</DialogTitle>
            </DialogHeader>
            <div className="space-y-6 py-4">
              {/* Package Type */}
              <div className="space-y-2">
                <Label>Package Type *</Label>
                <div className="grid grid-cols-2 gap-3">
                  <div
                    onClick={() => setPackageType("one_time")}
                    className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                      packageType === "one_time" ? 'border-purple-600 bg-purple-50' : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <Package className="w-6 h-6 mb-2 text-purple-600" />
                    <p className="font-semibold">One-Time Purchase</p>
                    <p className="text-xs text-gray-600">Client pays once, uses within validity period</p>
                  </div>
                  <div
                    onClick={() => setPackageType("subscription")}
                    className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                      packageType === "subscription" ? 'border-purple-600 bg-purple-50' : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <TrendingUp className="w-6 h-6 mb-2 text-purple-600" />
                    <p className="font-semibold">Subscription</p>
                    <p className="text-xs text-gray-600">Recurring billing, sessions refresh each period</p>
                  </div>
                </div>
              </div>

              {/* Basic Info */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="pkg_name">Package Name *</Label>
                  <Input
                    id="pkg_name"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="E.g., Complete Healing Journey"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="pkg_description">Description *</Label>
                  <Textarea
                    id="pkg_description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Describe what's included in this package..."
                    rows={4}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="pkg_image">Image URL (Optional)</Label>
                  <Input
                    id="pkg_image"
                    value={formData.image_url}
                    onChange={(e) => setFormData(prev => ({ ...prev, image_url: e.target.value }))}
                    placeholder="https://example.com/image.jpg"
                  />
                </div>
              </div>

              {/* Select Services with Configurations */}
              <div className="space-y-2">
                <Label>Select Services to Include *</Label>
                <div className="border rounded-lg p-4 space-y-3 max-h-96 overflow-y-auto">
                  {services.map((service) => {
                    const selected = selectedServices.find(s => s.id === service.id);
                    return (
                      <div
                        key={service.id}
                        className={`p-3 rounded-lg border transition-all ${
                          selected ? 'bg-purple-50 border-purple-300' : 'bg-white hover:bg-gray-50'
                        }`}
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div 
                            className="flex items-center gap-3 flex-1 cursor-pointer"
                            onClick={() => handleServiceToggle(service)}
                          >
                            <div className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                              selected ? 'bg-purple-600 border-purple-600' : 'border-gray-300'
                            }`}>
                              {selected && <CheckCircle2 className="w-4 h-4 text-white" />}
                            </div>
                            <div>
                              <p className="font-medium">{service.name}</p>
                              <p className="text-xs text-gray-600">{service.duration_minutes} min • ${service.price}</p>
                            </div>
                          </div>
                        </div>
                        {selected && (
                          <div className="ml-8 grid grid-cols-2 gap-2 mt-2">
                            <div>
                              <Label className="text-xs">Sessions</Label>
                              <Input
                                type="number"
                                min="1"
                                value={selected.session_count || 1}
                                onChange={(e) => updateServiceConfig(service.id, 'session_count', parseInt(e.target.value))}
                                className="h-8"
                              />
                            </div>
                            <div>
                              <Label className="text-xs">Custom Duration (min)</Label>
                              <Input
                                type="number"
                                min="15"
                                step="15"
                                value={selected.custom_duration_minutes || service.duration_minutes}
                                onChange={(e) => updateServiceConfig(service.id, 'custom_duration_minutes', parseInt(e.target.value))}
                                className="h-8"
                              />
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Pricing Configuration */}
              <div className="space-y-3">
                <Label>Pricing Structure</Label>
                <div className="grid grid-cols-2 gap-3">
                  <div
                    onClick={() => setPricingType("simple")}
                    className={`p-3 border-2 rounded-lg cursor-pointer transition-all ${
                      pricingType === "simple" ? 'border-purple-600 bg-purple-50' : 'border-gray-200'
                    }`}
                  >
                    <p className="font-semibold text-sm">Simple Pricing</p>
                    <p className="text-xs text-gray-600">One fixed price</p>
                  </div>
                  <div
                    onClick={() => setPricingType("tiered")}
                    className={`p-3 border-2 rounded-lg cursor-pointer transition-all ${
                      pricingType === "tiered" ? 'border-purple-600 bg-purple-50' : 'border-gray-200'
                    }`}
                  >
                    <p className="font-semibold text-sm">Tiered Pricing</p>
                    <p className="text-xs text-gray-600">Bronze, Silver, Gold, etc.</p>
                  </div>
                </div>

                {pricingType === "simple" ? (
                  <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Regular Price:</span>
                      <span className="font-bold">${calculateRegularPrice().toFixed(2)}</span>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="pkg_price">Package Price (USD) *</Label>
                      <Input
                        id="pkg_price"
                        type="number"
                        step="0.01"
                        value={formData.package_price}
                        onChange={(e) => setFormData(prev => ({ ...prev, package_price: e.target.value }))}
                        placeholder="0.00"
                      />
                    </div>
                    {formData.package_price && (
                      <div className="flex justify-between text-sm font-bold text-green-700">
                        <span>Client Saves:</span>
                        <span>${calculateSavings().toFixed(2)}</span>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label>Pricing Tiers</Label>
                      <Button type="button" size="sm" onClick={addTier} variant="outline">
                        <Plus className="w-3 h-3 mr-1" />
                        Add Tier
                      </Button>
                    </div>
                    {tiers.map((tier, index) => (
                      <div key={index} className="bg-purple-50 border border-purple-200 rounded-lg p-3 space-y-2">
                        <div className="flex justify-between items-start">
                          <Input
                            placeholder="Tier name (e.g., Gold)"
                            value={tier.tier_name}
                            onChange={(e) => updateTier(index, 'tier_name', e.target.value)}
                            className="flex-1 mr-2"
                          />
                          <Button type="button" size="sm" variant="ghost" onClick={() => removeTier(index)}>
                            <Trash2 className="w-4 h-4 text-red-600" />
                          </Button>
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <div>
                            <Label className="text-xs">Price</Label>
                            <Input
                              type="number"
                              step="0.01"
                              placeholder="0.00"
                              value={tier.price}
                              onChange={(e) => updateTier(index, 'price', e.target.value)}
                              className="h-8"
                            />
                          </div>
                          <div>
                            <Label className="text-xs">Sessions</Label>
                            <Input
                              type="number"
                              placeholder="4"
                              value={tier.sessions_included}
                              onChange={(e) => updateTier(index, 'sessions_included', e.target.value)}
                              className="h-8"
                            />
                          </div>
                          <div>
                            <Label className="text-xs">Days Valid</Label>
                            <Input
                              type="number"
                              placeholder="90"
                              value={tier.validity_days}
                              onChange={(e) => updateTier(index, 'validity_days', e.target.value)}
                              className="h-8"
                            />
                          </div>
                        </div>
                        <Input
                          placeholder="Description (optional)"
                          value={tier.description}
                          onChange={(e) => updateTier(index, 'description', e.target.value)}
                          className="h-8"
                        />
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Subscription Options */}
              {packageType === "subscription" && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-3">
                  <Label>Subscription Settings</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="sub_interval">Billing Interval</Label>
                      <select
                        id="sub_interval"
                        value={formData.subscription_interval}
                        onChange={(e) => setFormData(prev => ({ ...prev, subscription_interval: e.target.value }))}
                        className="w-full border rounded-md px-3 py-2 text-sm"
                      >
                        <option value="weekly">Weekly</option>
                        <option value="monthly">Monthly</option>
                        <option value="quarterly">Quarterly</option>
                        <option value="yearly">Yearly</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="sessions_per_interval">Sessions Per Period</Label>
                      <Input
                        id="sessions_per_interval"
                        type="number"
                        min="1"
                        value={formData.subscription_sessions_per_interval}
                        onChange={(e) => setFormData(prev => ({ ...prev, subscription_sessions_per_interval: e.target.value }))}
                      />
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="auto_renew"
                      checked={formData.auto_renew}
                      onChange={(e) => setFormData(prev => ({ ...prev, auto_renew: e.target.checked }))}
                      className="rounded"
                    />
                    <Label htmlFor="auto_renew" className="cursor-pointer">Auto-renew by default</Label>
                  </div>
                </div>
              )}

              {/* Validity Options */}
              {packageType === "one_time" && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="flexible_validity"
                      checked={formData.flexible_validity}
                      onChange={(e) => setFormData(prev => ({ ...prev, flexible_validity: e.target.checked }))}
                      className="rounded"
                    />
                    <Label htmlFor="flexible_validity" className="cursor-pointer">Allow clients to choose validity period</Label>
                  </div>
                  
                  {!formData.flexible_validity ? (
                    <div className="space-y-2">
                      <Label htmlFor="validity">Validity (Days)</Label>
                      <Input
                        id="validity"
                        type="number"
                        value={formData.validity_days}
                        onChange={(e) => setFormData(prev => ({ ...prev, validity_days: e.target.value }))}
                        placeholder="90"
                      />
                      <p className="text-xs text-gray-500">How long after purchase can clients use this</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Label>Validity Options (Days)</Label>
                      <div className="flex gap-2">
                        <Input
                          type="number"
                          placeholder="Enter days"
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              addValidityOption(e.target.value);
                              e.target.value = '';
                            }
                          }}
                        />
                        <Button type="button" size="sm" variant="outline">Add</Button>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {validityOptions.map(days => (
                          <Badge key={days} variant="outline" className="cursor-pointer" onClick={() => removeValidityOption(days)}>
                            {days} days ×
                          </Badge>
                        ))}
                      </div>
                      <p className="text-xs text-gray-500">Press Enter to add. Click to remove.</p>
                    </div>
                  )}
                  
                  <div className="space-y-2">
                    <Label htmlFor="max_purchases">Max Purchases (Optional)</Label>
                    <Input
                      id="max_purchases"
                      type="number"
                      value={formData.max_purchases}
                      onChange={(e) => setFormData(prev => ({ ...prev, max_purchases: e.target.value }))}
                      placeholder="Leave empty for unlimited"
                    />
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="benefits">Benefits (One per line)</Label>
                <Textarea
                  id="benefits"
                  value={formData.benefits}
                  onChange={(e) => setFormData(prev => ({ ...prev, benefits: e.target.value }))}
                  placeholder="Save 20% on sessions&#10;Priority booking&#10;Free progress tracking"
                  rows={4}
                />
              </div>

              {/* Actions */}
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
                <Button
                  onClick={handleSubmit}
                  disabled={createPackageMutation.isPending || updatePackageMutation.isPending}
                  className="bg-gradient-to-r from-purple-600 to-pink-600"
                >
                  {(createPackageMutation.isPending || updatePackageMutation.isPending) ? (
                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</>
                  ) : (
                    <>{editingPackage ? 'Update Package' : 'Create Package'}</>
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Info Card */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-gray-700">
              <p className="font-semibold mb-1">About Service Packages</p>
              <p>Bundle multiple services together at a discounted price. Clients purchase packages which give them credits to book included services. Perfect for encouraging commitment and providing better value!</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Packages List */}
      {packagesLoading ? (
        <div className="text-center py-12">
          <Loader2 className="w-12 h-12 animate-spin text-purple-600 mx-auto" />
        </div>
      ) : packages.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-600">No service packages yet</p>
            <p className="text-sm text-gray-500 mt-1">Create your first package to offer bundled services</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 gap-6">
          {packages.map((pkg) => (
            <Card key={pkg.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <CardTitle className="text-xl mb-1">{pkg.name}</CardTitle>
                    <p className="text-sm text-gray-600">{pkg.description}</p>
                  </div>
                  <Badge className={pkg.is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                    {pkg.is_active ? 'Active' : 'Inactive'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Services Included */}
                <div>
                  <p className="text-sm font-semibold text-gray-700 mb-2">Includes {pkg.total_sessions} sessions:</p>
                  <div className="space-y-1">
                    {pkg.service_names?.map((name, idx) => (
                      <div key={idx} className="text-sm text-gray-600 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                        {name}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Benefits */}
                {pkg.benefits && pkg.benefits.length > 0 && (
                  <div>
                    <p className="text-sm font-semibold text-gray-700 mb-2">Benefits:</p>
                    <div className="space-y-1">
                      {pkg.benefits.map((benefit, idx) => (
                        <div key={idx} className="text-sm text-gray-600 flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-purple-600" />
                          {benefit}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Pricing */}
                <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-600">Regular Price:</span>
                    <span className="text-sm line-through text-gray-500">${pkg.regular_price.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-semibold text-gray-900">Package Price:</span>
                    <span className="text-2xl font-bold text-purple-600">${pkg.package_price.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-green-700">You Save:</span>
                    <span className="text-sm font-bold text-green-700">${pkg.savings.toFixed(2)}</span>
                  </div>
                </div>

                {/* Validity & Purchases */}
                <div className="flex gap-4 text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    <span>Valid {pkg.validity_days} days</span>
                  </div>
                  {pkg.max_purchases && (
                    <div className="flex items-center gap-1">
                      <Package className="w-4 h-4" />
                      <span>Max {pkg.max_purchases} purchases</span>
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex gap-2 pt-3 border-t">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit(pkg)}
                    className="flex-1"
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Edit
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDelete(pkg.id)}
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}