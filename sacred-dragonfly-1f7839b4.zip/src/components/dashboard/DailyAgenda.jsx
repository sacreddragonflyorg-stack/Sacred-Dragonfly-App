import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, User, Mail, Phone, Video } from "lucide-react";
import { format, isToday, isTomorrow } from "date-fns";

export default function DailyAgenda({ appointments, onStartSession }) {
  const todayAppointments = appointments.filter(apt =>
    isToday(new Date(apt.appointment_date)) && apt.status !== 'cancelled'
  ).sort((a, b) => new Date(a.appointment_date) - new Date(b.appointment_date));

  const tomorrowAppointments = appointments.filter(apt =>
    isTomorrow(new Date(apt.appointment_date)) && apt.status !== 'cancelled'
  ).sort((a, b) => new Date(a.appointment_date) - new Date(b.appointment_date));

  const statusColors = {
    pending: "bg-yellow-100 text-yellow-800",
    confirmed: "bg-blue-100 text-blue-800",
    completed: "bg-green-100 text-green-800",
  };

  const AppointmentCard = ({ apt, label }) => {
    const appointmentTime = new Date(apt.appointment_date);
    const now = new Date();
    const minutesUntil = Math.floor((appointmentTime - now) / 60000);
    const canStart = minutesUntil <= 15 && minutesUntil >= -30;

    return (
      <div className="p-4 bg-white rounded-lg border-2 border-gray-200 hover:border-purple-300 transition-all">
        <div className="flex justify-between items-start mb-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Clock className="w-4 h-4 text-purple-600" />
              <span className="font-bold text-lg">
                {format(appointmentTime, 'h:mm a')}
              </span>
              {canStart && (
                <Badge className="bg-green-500 text-white animate-pulse">Starting Soon</Badge>
              )}
            </div>
            {label && (
              <p className="text-xs text-gray-500 mb-2">{label}</p>
            )}
          </div>
          <Badge className={statusColors[apt.status]}>{apt.status}</Badge>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-gray-500" />
            <span className="font-semibold text-gray-900">{apt.client_name}</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Mail className="w-4 h-4" />
            {apt.client_email}
          </div>
          {apt.phone && (
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Phone className="w-4 h-4" />
              {apt.phone}
            </div>
          )}
          <div className="pt-2 border-t">
            <p className="text-sm font-medium text-purple-600">{apt.service_name}</p>
          </div>
        </div>

        {canStart && apt.meeting_link && (
          <Button
            onClick={() => onStartSession?.(apt)}
            className="w-full mt-3 bg-gradient-to-r from-purple-600 to-pink-600"
          >
            <Video className="w-4 h-4 mr-2" />
            Start Session
          </Button>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Today's Agenda */}
      <Card>
        <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Today's Agenda
          </CardTitle>
          <p className="text-sm text-gray-600 mt-1">
            {format(new Date(), 'EEEE, MMMM d, yyyy')}
          </p>
        </CardHeader>
        <CardContent className="pt-6">
          {todayAppointments.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Calendar className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p>No appointments scheduled for today</p>
            </div>
          ) : (
            <div className="space-y-4">
              {todayAppointments.map((apt) => (
                <AppointmentCard key={apt.id} apt={apt} />
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Tomorrow's Preview */}
      {tomorrowAppointments.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              Tomorrow's Schedule
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {tomorrowAppointments.map((apt) => (
                <AppointmentCard
                  key={apt.id}
                  apt={apt}
                  label={format(new Date(apt.appointment_date), 'EEEE, MMMM d')}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}