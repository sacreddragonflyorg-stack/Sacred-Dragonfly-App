import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Users, Search, Crown, Mail, Phone, Calendar, DollarSign, Wallet, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function PractitionerManagement() {
  const [searchTerm, setSearchTerm] = useState("");
  const queryClient = useQueryClient();

  const processPayoutsMutation = useMutation({
    mutationFn: async () => {
      const { data } = await base44.functions.invoke('processScheduledPayouts', {});
      if (data.error) throw new Error(data.error);
      return data;
    },
    onSuccess: (data) => {
      const count = data.results?.filter(r => r.status === 'success').length || 0;
      toast.success(`Payouts processed! ${count} transfers initiated.`);
      queryClient.invalidateQueries(['all-users']); // Refresh to maybe show updated revenue stats if we tracked paid out
    },
    onError: (err) => toast.error(err.message || "Failed to process payouts")
  });
  const [filterTier, setFilterTier] = useState("all");
  const [sortBy, setSortBy] = useState("name");

  const { data: allUsers = [] } = useQuery({
    queryKey: ['all-users'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: subscriptions = [] } = useQuery({
    queryKey: ['practitioner-subscriptions'],
    queryFn: () => base44.entities.PractitionerSubscription.list(),
    initialData: [],
  });

  const { data: services = [] } = useQuery({
    queryKey: ['all-services-admin'],
    queryFn: () => base44.entities.Service.list(),
    initialData: [],
  });

  const practitioners = allUsers.filter(u => u.role === 'admin');

  const practitionersWithData = practitioners.map(prac => {
    const sub = subscriptions.find(s => s.practitioner_email === prac.email);
    const pracServices = services.filter(s => s.created_by === prac.email);
    
    return {
      ...prac,
      subscription: sub,
      tier: sub?.plan_tier || 'free',
      serviceCount: pracServices.length,
      monthlyRevenue: sub?.monthly_price || 0
    };
  });

  const filteredPractitioners = practitionersWithData
    .filter(p => {
      const matchesSearch = p.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          p.email?.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesTier = filterTier === 'all' || p.tier === filterTier;
      return matchesSearch && matchesTier;
    })
    .sort((a, b) => {
      if (sortBy === 'name') return (a.full_name || '').localeCompare(b.full_name || '');
      if (sortBy === 'tier') return (a.tier || '').localeCompare(b.tier || '');
      if (sortBy === 'services') return b.serviceCount - a.serviceCount;
      if (sortBy === 'revenue') return b.monthlyRevenue - a.monthlyRevenue;
      return 0;
    });

  const tierColors = {
    free: "bg-gray-100 text-gray-800",
    basic: "bg-blue-100 text-blue-800",
    premium: "bg-purple-100 text-purple-800"
  };

  const stats = {
    total: practitioners.length,
    free: practitionersWithData.filter(p => p.tier === 'free').length,
    basic: practitionersWithData.filter(p => p.tier === 'basic').length,
    premium: practitionersWithData.filter(p => p.tier === 'premium').length,
    totalRevenue: practitionersWithData.reduce((sum, p) => sum + p.monthlyRevenue, 0)
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-2xl">
              <Users className="w-6 h-6" />
              Practitioner Management
            </CardTitle>
            <Button 
              onClick={() => {
                if (window.confirm("Process weekly payouts for all eligible practitioners? This will initiate Stripe transfers.")) {
                  processPayoutsMutation.mutate();
                }
              }}
              disabled={processPayoutsMutation.isPending}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              {processPayoutsMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Wallet className="w-4 h-4 mr-2" />}
              Process Weekly Payouts
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
            <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Total</p>
              <p className="text-2xl font-bold text-purple-900">{stats.total}</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Free</p>
              <p className="text-2xl font-bold">{stats.free}</p>
            </div>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Basic</p>
              <p className="text-2xl font-bold text-blue-900">{stats.basic}</p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Premium</p>
              <p className="text-2xl font-bold text-purple-900">{stats.premium}</p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">MRR</p>
              <p className="text-2xl font-bold text-green-900">${stats.totalRevenue}</p>
            </div>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-4 mb-6">
            <div className="flex-1 min-w-[200px]">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search practitioners..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={filterTier} onValueChange={setFilterTier}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Filter by tier" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Tiers</SelectItem>
                <SelectItem value="free">Free</SelectItem>
                <SelectItem value="basic">Basic</SelectItem>
                <SelectItem value="premium">Premium</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Name</SelectItem>
                <SelectItem value="tier">Tier</SelectItem>
                <SelectItem value="services">Services</SelectItem>
                <SelectItem value="revenue">Revenue</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Tabs defaultValue="list">
            <TabsList className="mb-4">
                <TabsTrigger value="list">All Practitioners</TabsTrigger>
                <TabsTrigger value="nominations">Featured Nominations</TabsTrigger>
            </TabsList>

            <TabsContent value="nominations">
                <FeaturedNominationsList />
            </TabsContent>

            <TabsContent value="list">
          {/* Practitioners List */}
          <div className="space-y-3">
            {filteredPractitioners.length === 0 ? (
              <p className="text-center text-gray-500 py-8">No practitioners found</p>
            ) : (
              filteredPractitioners.map((prac) => (
                <div key={prac.id} className="p-4 bg-gray-50 rounded-lg border border-gray-200 hover:border-purple-300 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="font-semibold text-lg">{prac.full_name || 'No Name'}</h4>
                        <Badge className={tierColors[prac.tier]}>
                          {prac.tier === 'premium' && <Crown className="w-3 h-3 mr-1" />}
                          {prac.tier.toUpperCase()}
                        </Badge>
                        <Button
                            variant="outline"
                            size="sm"
                            className="ml-2 h-6 text-xs"
                            onClick={() => {
                                const fee = prompt(
                                    `Set Platform Fee Override for ${prac.full_name}\n(Enter 0.0 to 1.0, e.g., 0.15 for 15%).\nLeave empty to remove override.`,
                                    prac.default_platform_fee_percent
                                );
                                if (fee !== null) {
                                    const val = fee === "" ? null : parseFloat(fee);
                                    if (val !== null && (isNaN(val) || val < 0 || val > 1)) {
                                        toast.error("Invalid percentage. Must be between 0.0 and 1.0");
                                        return;
                                    }
                                    base44.entities.Practitioner.update(prac.id, { default_platform_fee_percent: val })
                                        .then(() => {
                                            toast.success("Fee updated");
                                            queryClient.invalidateQueries(['all-users']);
                                        });
                                }
                            }}
                        >
                            <DollarSign className="w-3 h-3 mr-1" />
                            {prac.default_platform_fee_percent !== undefined && prac.default_platform_fee_percent !== null 
                                ? `${(prac.default_platform_fee_percent * 100).toFixed(0)}% Fee` 
                                : "Default Fee"}
                        </Button>
                      </div>
                      <div className="grid md:grid-cols-2 gap-2 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <Mail className="w-4 h-4" />
                          {prac.email}
                        </div>
                        {prac.phone && (
                          <div className="flex items-center gap-2">
                            <Phone className="w-4 h-4" />
                            {prac.phone}
                          </div>
                        )}
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          Joined {format(new Date(prac.created_date), 'MMM yyyy')}
                        </div>
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4" />
                          {prac.serviceCount} service{prac.serviceCount !== 1 ? 's' : ''}
                        </div>
                      </div>
                      {prac.subscription && (
                        <div className="mt-2 flex items-center gap-2 text-sm">
                          <DollarSign className="w-4 h-4 text-green-600" />
                          <span className="text-green-700 font-medium">${prac.monthlyRevenue}/mo</span>
                          <span className="text-gray-500">
                            • {prac.subscription.status}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
          </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}

function FeaturedNominationsList() {
    const queryClient = useQueryClient();
    const { data: nominations = [] } = useQuery({
        queryKey: ['admin-nominations'],
        queryFn: () => base44.entities.FeaturedNomination.filter({ status: 'pending' })
    });

    const updateStatus = useMutation({
        mutationFn: async ({ id, status, email }) => {
            await base44.entities.FeaturedNomination.update(id, { status });
            if (status === 'approved') {
                // Find practitioner and update
                const users = await base44.entities.Practitioner.filter({ user_email: email });
                if (users.length > 0) {
                    await base44.entities.Practitioner.update(users[0].id, { is_featured: true });
                }
            }
        },
        onSuccess: () => {
            toast.success("Status updated");
            queryClient.invalidateQueries(['admin-nominations']);
        }
    });

    if (nominations.length === 0) return <p className="text-gray-500 py-4">No pending nominations.</p>;

    return (
        <div className="space-y-4">
            {nominations.map(nom => (
                <div key={nom.id} className="p-4 border rounded-lg flex justify-between items-start bg-amber-50/50">
                    <div>
                        <h4 className="font-bold">{nom.practitioner_name}</h4>
                        <p className="text-sm text-gray-600 mb-2">{nom.practitioner_email}</p>
                        <p className="text-gray-800 bg-white p-2 rounded border">{nom.reason}</p>
                        <p className="text-xs text-gray-500 mt-1">Submitted: {new Date(nom.submission_date).toLocaleDateString()}</p>
                    </div>
                    <div className="flex gap-2">
                        <Button 
                            size="sm" 
                            className="bg-green-600 hover:bg-green-700"
                            onClick={() => updateStatus.mutate({ id: nom.id, status: 'approved', email: nom.practitioner_email })}
                        >
                            Approve
                        </Button>
                        <Button 
                            size="sm" 
                            variant="destructive"
                            onClick={() => updateStatus.mutate({ id: nom.id, status: 'rejected', email: nom.practitioner_email })}
                        >
                            Reject
                        </Button>
                    </div>
                </div>
            ))}
        </div>
    );
}