import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, DollarSign, TrendingUp, Users, Clock, Heart } from "lucide-react";
import { format, isWithinInterval, startOfWeek, endOfWeek, startOfMonth, endOfMonth } from "date-fns";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const COLORS = ['#8B5CF6', '#EC4899', '#F59E0B', '#10B981', '#3B82F6', '#EF4444'];

export default function DashboardOverview({ appointments, payments, subscriptions, services }) {
  // Recent activity
  const recentAppointments = appointments
    .filter(a => new Date(a.appointment_date) >= new Date())
    .slice(0, 5);

  const recentPayments = payments
    .filter(p => p.status === 'completed')
    .slice(0, 5);

  // Revenue over time (last 6 months)
  const getLast6Months = () => {
    const months = [];
    for (let i = 5; i >= 0; i--) {
      const date = new Date();
      date.setMonth(date.getMonth() - i);
      months.push({
        name: format(date, 'MMM'),
        month: date.getMonth(),
        year: date.getFullYear()
      });
    }
    return months;
  };

  const revenueData = getLast6Months().map(({ name, month, year }) => {
    const monthPayments = payments.filter(p => {
      if (!p.payment_date || p.status !== 'completed') return false;
      const date = new Date(p.payment_date);
      return date.getMonth() === month && date.getFullYear() === year;
    });
    return {
      name,
      revenue: monthPayments.reduce((sum, p) => sum + (p.amount || 0), 0)
    };
  });

  // Service popularity
  const serviceStats = services.map(service => {
    const count = appointments.filter(a => a.service_id === service.id).length;
    return {
      name: service.name,
      value: count
    };
  }).filter(s => s.value > 0).slice(0, 5);

  // Weekly sessions
  const thisWeekSessions = appointments.filter(a => 
    isWithinInterval(new Date(a.appointment_date), {
      start: startOfWeek(new Date()),
      end: endOfWeek(new Date())
    })
  ).length;

  const activeClients = new Set(
    appointments
      .filter(a => new Date(a.appointment_date) >= new Date(Date.now() - 30 * 24 * 60 * 60 * 1000))
      .map(a => a.client_email)
  ).size;

  return (
    <div className="space-y-6">
      {/* Charts Row */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Revenue Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip formatter={(value) => `$${value.toFixed(2)}`} />
                <Line type="monotone" dataKey="revenue" stroke="#8B5CF6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Popular Services</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={serviceStats}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {serviceStats.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Activity Cards */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-purple-600" />
              Upcoming Sessions
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentAppointments.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No upcoming sessions</p>
            ) : (
              <div className="space-y-3">
                {recentAppointments.map((apt) => (
                  <div key={apt.id} className="flex items-start justify-between p-3 bg-purple-50 rounded-lg">
                    <div className="flex-1">
                      <p className="font-semibold text-gray-900">{apt.client_name}</p>
                      <p className="text-sm text-gray-600">{apt.service_name}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {format(new Date(apt.appointment_date), 'MMM d, h:mm a')}
                      </p>
                    </div>
                    <Badge className={
                      apt.status === 'confirmed' ? 'bg-green-100 text-green-700' :
                      apt.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-gray-100 text-gray-700'
                    }>
                      {apt.status}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-green-600" />
              Recent Payments
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentPayments.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No recent payments</p>
            ) : (
              <div className="space-y-3">
                {recentPayments.map((payment) => (
                  <div key={payment.id} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <div>
                      <p className="font-semibold text-gray-900">{payment.client_email}</p>
                      <p className="text-xs text-gray-500">
                        {payment.payment_date && format(new Date(payment.payment_date), 'MMM d, yyyy')}
                      </p>
                    </div>
                    <p className="text-lg font-bold text-green-700">
                      ${payment.amount?.toFixed(2)}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Stats */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-purple-100 to-purple-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <Clock className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <p className="text-3xl font-bold text-purple-900">{thisWeekSessions}</p>
              <p className="text-sm text-purple-700">Sessions This Week</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-pink-100 to-pink-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <Users className="w-8 h-8 text-pink-600 mx-auto mb-2" />
              <p className="text-3xl font-bold text-pink-900">{activeClients}</p>
              <p className="text-sm text-pink-700">Active Clients (30d)</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-100 to-blue-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <TrendingUp className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <p className="text-3xl font-bold text-blue-900">
                {subscriptions.filter(s => s.status === 'active').length}
              </p>
              <p className="text-sm text-blue-700">Active Subscriptions</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-100 to-green-200">
          <CardContent className="pt-6">
            <div className="text-center">
              <Heart className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <p className="text-3xl font-bold text-green-900">
                {appointments.filter(a => a.status === 'completed').length}
              </p>
              <p className="text-sm text-green-700">Total Completed</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}