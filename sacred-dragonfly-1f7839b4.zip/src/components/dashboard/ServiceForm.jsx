import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { X, DollarSign } from "lucide-react";
import { toast } from "sonner";

export default function ServiceForm({ service, onClose }) {
  const queryClient = useQueryClient();
  const [isAdmin, setIsAdmin] = useState(false);
  
  React.useEffect(() => {
    base44.auth.me().then(u => setIsAdmin(u?.role === 'admin'));
  }, []);

  const [formData, setFormData] = useState(service || {
    name: "",
    description: "",
    type: "energy_healing",
    duration_minutes: 60,
    price: 0,
    pricing_model: "fixed",
    sliding_scale_min: 0,
    sliding_scale_max: 0,
    payment_methods: [],
    image_url: "",
    benefits: [],
    is_active: true
  });
  const [benefitInput, setBenefitInput] = useState("");

  const saveMutation = useMutation({
    mutationFn: (data) => {
      if (service) {
        return base44.entities.Service.update(service.id, data);
      }
      return base44.entities.Service.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['services']);
      toast.success(service ? "Service updated" : "Service created");
      onClose();
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    saveMutation.mutate(formData);
  };

  const addBenefit = () => {
    if (benefitInput.trim()) {
      setFormData(prev => ({
        ...prev,
        benefits: [...(prev.benefits || []), benefitInput.trim()]
      }));
      setBenefitInput("");
    }
  };

  const removeBenefit = (index) => {
    setFormData(prev => ({
      ...prev,
      benefits: prev.benefits.filter((_, i) => i !== index)
    }));
  };

  const togglePaymentMethod = (method) => {
    setFormData(prev => ({
      ...prev,
      payment_methods: prev.payment_methods?.includes(method)
        ? prev.payment_methods.filter(m => m !== method)
        : [...(prev.payment_methods || []), method]
    }));
  };

  return (
    <Card className="border-2 border-purple-200">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>{service ? "Edit Service" : "Create New Service"}</CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Service Name *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                required
              />
            </div>
            <div className="space-y-2">
              <Label>Type *</Label>
              <Select value={formData.type} onValueChange={(value) => setFormData(prev => ({ ...prev, type: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="tarot_reading">Tarot Reading</SelectItem>
                  <SelectItem value="reiki_healing">Reiki Healing</SelectItem>
                  <SelectItem value="energy_healing">Energy Healing</SelectItem>
                  <SelectItem value="chakra_balancing">Chakra Balancing</SelectItem>
                  <SelectItem value="crystal_healing">Crystal Healing</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Description *</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              rows={3}
              required
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Duration (minutes) *</Label>
              <Input
                type="number"
                value={formData.duration_minutes}
                onChange={(e) => setFormData(prev => ({ ...prev, duration_minutes: parseInt(e.target.value) }))}
                required
              />
            </div>
            <div className="space-y-2">
              <Label>Pricing Model *</Label>
              <Select value={formData.pricing_model} onValueChange={(value) => setFormData(prev => ({ ...prev, pricing_model: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="fixed">Fixed Price</SelectItem>
                  <SelectItem value="sliding_scale">Sliding Scale</SelectItem>
                  <SelectItem value="energy_exchange">Energy Exchange</SelectItem>
                  <SelectItem value="donation">Donation-Based</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Pricing Fields */}
          <div className="p-4 bg-purple-50 rounded-lg border border-purple-200 space-y-4">
            <div className="flex items-center gap-2 text-purple-900 font-semibold">
              <DollarSign className="w-5 h-5" />
              <span>Pricing Details</span>
            </div>

            {formData.pricing_model === 'fixed' && (
              <div className="space-y-2">
                <Label>Price ($) *</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.price}
                  onChange={(e) => setFormData(prev => ({ ...prev, price: parseFloat(e.target.value) }))}
                  required
                />
              </div>
            )}

            {formData.pricing_model === 'sliding_scale' && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Minimum Price ($) *</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.sliding_scale_min}
                    onChange={(e) => setFormData(prev => ({ ...prev, sliding_scale_min: parseFloat(e.target.value) }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Maximum Price ($) *</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.sliding_scale_max}
                    onChange={(e) => setFormData(prev => ({ ...prev, sliding_scale_max: parseFloat(e.target.value) }))}
                    required
                  />
                </div>
                <div className="col-span-2 space-y-2">
                  <Label>Suggested Price ($)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.price}
                    onChange={(e) => setFormData(prev => ({ ...prev, price: parseFloat(e.target.value) }))}
                  />
                </div>
              </div>
            )}

            {formData.pricing_model === 'donation' && (
              <div className="space-y-2">
                <Label>Suggested Donation ($)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.price}
                  onChange={(e) => setFormData(prev => ({ ...prev, price: parseFloat(e.target.value) }))}
                />
                <p className="text-xs text-gray-600">Optional - displayed as suggested amount</p>
              </div>
            )}

            {formData.pricing_model === 'energy_exchange' && (
              <div className="text-sm text-gray-600 p-3 bg-white rounded border border-purple-200">
                <p>No fixed pricing. Energy exchange will be arranged personally after session confirmation.</p>
              </div>
            )}
          </div>

          {/* Payment Methods */}
          {formData.pricing_model !== 'energy_exchange' && (
            <div className="space-y-3">
              <Label>Accepted Payment Methods</Label>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { value: 'credit_card', label: '💳 Credit Card' },
                  { value: 'paypal', label: 'PayPal' },
                  { value: 'venmo', label: 'Venmo' },
                  { value: 'cashapp', label: 'Cash App' },
                  { value: 'bank_transfer', label: '🏦 Bank Transfer' },
                  { value: 'cash', label: '💵 Cash' }
                ].map((method) => (
                  <div key={method.value} className="flex items-center gap-2 p-2 bg-white rounded border border-gray-200">
                    <Checkbox
                      checked={formData.payment_methods?.includes(method.value)}
                      onCheckedChange={() => togglePaymentMethod(method.value)}
                    />
                    <label className="text-sm cursor-pointer flex-1" onClick={() => togglePaymentMethod(method.value)}>
                      {method.label}
                    </label>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label>Image URL</Label>
            <Input
              value={formData.image_url}
              onChange={(e) => setFormData(prev => ({ ...prev, image_url: e.target.value }))}
              placeholder="https://images.unsplash.com/..."
            />
          </div>

          {isAdmin && (
            <div className="space-y-2 p-4 bg-gray-50 border border-gray-200 rounded-lg">
                <Label className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-green-600" />
                    Platform Fee Override (Admin Only)
                </Label>
                <div className="flex items-center gap-2">
                    <Input
                        type="number"
                        step="0.01"
                        min="0"
                        max="1"
                        value={formData.platform_fee_percent !== undefined ? formData.platform_fee_percent : ""}
                        onChange={(e) => setFormData(prev => ({ 
                            ...prev, 
                            platform_fee_percent: e.target.value === "" ? null : parseFloat(e.target.value) 
                        }))}
                        placeholder="Default"
                        className="w-32"
                    />
                    <span className="text-sm text-gray-500">
                        {formData.platform_fee_percent !== undefined && formData.platform_fee_percent !== null
                            ? `${(formData.platform_fee_percent * 100).toFixed(0)}%`
                            : "Using Global/Practitioner Default"}
                    </span>
                </div>
                <p className="text-xs text-gray-500">
                    Set a specific commission fee for this service (0.0 to 1.0). Leave empty to use defaults.
                </p>
            </div>
          )}

          <div className="space-y-2">
            <Label>Benefits</Label>
            <div className="flex gap-2">
              <Input
                value={benefitInput}
                onChange={(e) => setBenefitInput(e.target.value)}
                placeholder="Add a benefit..."
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addBenefit())}
              />
              <Button type="button" onClick={addBenefit} variant="outline">
                Add
              </Button>
            </div>
            <div className="space-y-1">
              {formData.benefits?.map((benefit, index) => (
                <div key={index} className="flex items-center justify-between bg-purple-50 p-2 rounded">
                  <span className="text-sm">{benefit}</span>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => removeBenefit(index)}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-3">
            <Button type="submit" className="flex-1 bg-purple-600 hover:bg-purple-700" disabled={saveMutation.isPending}>
              {service ? "Update Service" : "Create Service"}
            </Button>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}