import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { format } from "date-fns";
import { Loader2 } from "lucide-react";

export default function ProgressTracker() {
  const { data: progressData = [], isLoading } = useQuery({
    queryKey: ['all-user-progress'],
    queryFn: async () => {
      // Fetch all progress records - filtering could be added for performance later
      const allProgress = await base44.entities.UserCourseProgress.list('-started_at', 50);
      return allProgress;
    },
  });

  if (isLoading) return <div className="p-8 flex justify-center"><Loader2 className="w-8 h-8 animate-spin text-purple-600" /></div>;

  return (
    <Card>
      <CardHeader>
        <CardTitle>User Progress Tracker</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Course</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Progress</TableHead>
                <TableHead>Last Active</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {progressData.map(p => (
                <TableRow key={p.id}>
                  <TableCell className="font-medium">{p.user_email}</TableCell>
                  <TableCell>{p.course_title}</TableCell>
                  <TableCell>
                    <Badge className={
                      p.status === 'completed' ? 'bg-green-100 text-green-700' : 
                      p.status === 'in_progress' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'
                    }>
                      {p.status.replace('_', ' ')}
                    </Badge>
                  </TableCell>
                  <TableCell className="w-48">
                    <div className="flex items-center gap-2">
                      <Progress value={p.progress_percentage} className="h-2" />
                      <span className="text-xs text-gray-500 w-8">{p.progress_percentage}%</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-sm text-gray-500">
                    {p.updated_date ? format(new Date(p.updated_date), 'MMM d, yyyy') : '-'}
                  </TableCell>
                </TableRow>
              ))}
              {progressData.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-gray-500">No active learners yet.</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}