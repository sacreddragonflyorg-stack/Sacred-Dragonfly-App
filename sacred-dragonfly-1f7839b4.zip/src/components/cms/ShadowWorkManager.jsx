import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Edit, Trash2, Plus, Moon } from "lucide-react";
import { toast } from "sonner";

const CATEGORIES = [
  { id: 'triggers', name: 'Emotional Triggers' },
  { id: 'relationships', name: 'Relationships' },
  { id: 'fears', name: 'Fears & Insecurities' },
  { id: 'childhood', name: 'Childhood & Past' },
  { id: 'self_image', name: 'Self-Image' },
  { id: 'patterns', name: 'Patterns & Habits' }
];

export default function ShadowWorkManager() {
  const queryClient = useQueryClient();
  const [editingPrompt, setEditingPrompt] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ text: "", category: "triggers", is_active: true });

  const { data: prompts = [], isLoading } = useQuery({
    queryKey: ['shadow-work-prompts'],
    queryFn: () => base44.entities.ShadowWorkPrompt.list(),
  });

  const saveMutation = useMutation({
    mutationFn: (data) => editingPrompt 
      ? base44.entities.ShadowWorkPrompt.update(editingPrompt.id, data)
      : base44.entities.ShadowWorkPrompt.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['shadow-work-prompts']);
      toast.success(editingPrompt ? "Prompt updated" : "Prompt created");
      setShowForm(false);
      setEditingPrompt(null);
      setFormData({ text: "", category: "triggers", is_active: true });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.ShadowWorkPrompt.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['shadow-work-prompts']);
      toast.success("Prompt deleted");
    },
  });

  const handleEdit = (prompt) => {
    setEditingPrompt(prompt);
    setFormData(prompt);
    setShowForm(true);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <Moon className="w-5 h-5 text-purple-600" />
          Shadow Work Prompts
        </CardTitle>
        <Button onClick={() => { setEditingPrompt(null); setFormData({ text: "", category: "triggers", is_active: true }); setShowForm(true); }}>
          <Plus className="w-4 h-4 mr-2" /> New Prompt
        </Button>
      </CardHeader>
      <CardContent>
        {showForm && (
          <Card className="mb-6 border-2 border-purple-200 bg-purple-50">
            <CardContent className="pt-6 space-y-4">
              <div className="space-y-2">
                <Label>Prompt Text</Label>
                <Input value={formData.text} onChange={e => setFormData({...formData, text: e.target.value})} placeholder="e.g., What triggers your anger?" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Category</Label>
                  <Select value={formData.category} onValueChange={v => setFormData({...formData, category: v})}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 flex items-center pt-8">
                  <Label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={formData.is_active} onChange={e => setFormData({...formData, is_active: e.target.checked})} className="w-4 h-4" />
                    Active
                  </Label>
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={() => saveMutation.mutate(formData)} className="bg-purple-600">Save</Button>
                <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Prompt</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {prompts.map(prompt => (
                <TableRow key={prompt.id}>
                  <TableCell className="font-medium">{prompt.text}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{CATEGORIES.find(c => c.id === prompt.category)?.name || prompt.category}</Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={prompt.is_active ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"}>
                      {prompt.is_active ? "Active" : "Inactive"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button variant="ghost" size="icon" onClick={() => handleEdit(prompt)}><Edit className="w-4 h-4" /></Button>
                      <Button variant="ghost" size="icon" className="text-red-500" onClick={() => deleteMutation.mutate(prompt.id)}><Trash2 className="w-4 h-4" /></Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {prompts.length === 0 && !isLoading && (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-8 text-gray-500">No prompts found.</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}