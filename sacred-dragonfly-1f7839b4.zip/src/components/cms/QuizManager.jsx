import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Plus, Trash2, Save, HelpCircle, CheckCircle } from "lucide-react";
import { toast } from "sonner";
import AIContentGenerator from "../dashboard/AIContentGenerator";

export default function QuizManager() {
  const queryClient = useQueryClient();
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [selectedModule, setSelectedModule] = useState(null);
  const [quizForm, setQuizForm] = useState(null);

  const { data: courses = [] } = useQuery({
    queryKey: ['cms-courses'],
    queryFn: () => base44.entities.LearningCourse.list('title'),
  });

  const { data: modules = [] } = useQuery({
    queryKey: ['cms-modules', selectedCourse],
    queryFn: () => selectedCourse ? base44.entities.LearningModule.filter({ course_id: selectedCourse }, 'order') : [],
    enabled: !!selectedCourse,
  });

  const { data: existingQuiz, isLoading: quizLoading } = useQuery({
    queryKey: ['cms-quiz', selectedModule],
    queryFn: async () => {
      if (!selectedModule) return null;
      const quizzes = await base44.entities.LearningQuiz.filter({ module_id: selectedModule });
      return quizzes[0] || null;
    },
    enabled: !!selectedModule,
  });

  // Effect to load existing quiz into form
  React.useEffect(() => {
    if (existingQuiz) {
      setQuizForm(existingQuiz);
    } else if (selectedModule) {
      setQuizForm({
        module_id: selectedModule,
        course_id: selectedCourse,
        title: "Module Quiz",
        description: "Test your knowledge",
        passing_score: 70,
        points_reward: 25,
        questions: []
      });
    } else {
      setQuizForm(null);
    }
  }, [existingQuiz, selectedModule, selectedCourse]);

  const saveQuizMutation = useMutation({
    mutationFn: (data) => data.id 
      ? base44.entities.LearningQuiz.update(data.id, data)
      : base44.entities.LearningQuiz.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['cms-quiz']);
      // Also update module has_quiz flag
      if (selectedModule) {
        base44.entities.LearningModule.update(selectedModule, { has_quiz: true });
      }
      toast.success("Quiz saved successfully!");
    }
  });

  const deleteQuizMutation = useMutation({
    mutationFn: (id) => base44.entities.LearningQuiz.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['cms-quiz']);
      if (selectedModule) {
        base44.entities.LearningModule.update(selectedModule, { has_quiz: false });
      }
      setQuizForm({ ...quizForm, id: undefined, questions: [] }); // Reset to new
      toast.success("Quiz deleted");
    }
  });

  const addQuestion = () => {
    setQuizForm({
      ...quizForm,
      questions: [
      ...quizForm.questions,
      {
      question: "",
      type: "multiple_choice",
      options: ["", "", "", ""],
      correct_answer: 0,
      correct_answers: [],
      pairs: [],
      explanation: "",
      points: 5
      }
      ]
    });
  };

  const updateQuestion = (idx, field, value) => {
    const newQuestions = [...quizForm.questions];
    newQuestions[idx] = { ...newQuestions[idx], [field]: value };
    setQuizForm({ ...quizForm, questions: newQuestions });
  };

  const updateOption = (qIdx, oIdx, value) => {
    const newQuestions = [...quizForm.questions];
    const newOptions = [...newQuestions[qIdx].options];
    newOptions[oIdx] = value;
    newQuestions[qIdx].options = newOptions;
    setQuizForm({ ...quizForm, questions: newQuestions });
  };

  const removeQuestion = (idx) => {
    const newQuestions = [...quizForm.questions];
    newQuestions.splice(idx, 1);
    setQuizForm({ ...quizForm, questions: newQuestions });
  };

  const handleAIQuiz = (data) => {
    // Assuming data.questions is array of question objects
    // Need to map them to our format if needed, but the generator likely matches
    // Let's assume generator returns { questions: [...] }
    if (data.questions) {
      setQuizForm(prev => ({
        ...prev,
        questions: [...prev.questions, ...data.questions]
      }));
      toast.success(`Added ${data.questions.length} AI questions`);
    }
  };

  if (!courses.length) return <div className="p-4">No courses available. Create a course first.</div>;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Quiz Manager</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4 mb-6">
            <div className="space-y-2">
              <Label>Select Course</Label>
              <Select value={selectedCourse} onValueChange={setSelectedCourse}>
                <SelectTrigger><SelectValue placeholder="Choose a course..." /></SelectTrigger>
                <SelectContent>
                  {courses.map(c => <SelectItem key={c.id} value={c.id}>{c.title}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Select Module</Label>
              <Select value={selectedModule} onValueChange={setSelectedModule} disabled={!selectedCourse}>
                <SelectTrigger><SelectValue placeholder="Choose a module..." /></SelectTrigger>
                <SelectContent>
                  {modules.map(m => <SelectItem key={m.id} value={m.id}>{m.title}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          {selectedModule && quizForm && (
            <div className="space-y-6 animate-in fade-in">
              <div className="border-t pt-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold">{quizForm.id ? "Edit Quiz" : "Create Quiz"}</h3>
                  <div className="flex gap-2">
                     <AIContentGenerator 
                        mode="quiz"
                        initialData={{ 
                          course_title: courses.find(c => c.id === selectedCourse)?.title,
                          module_title: modules.find(m => m.id === selectedModule)?.title
                        }}
                        onGenerate={handleAIQuiz}
                        buttonLabel="Generate AI Questions"
                      />
                    {quizForm.id && (
                      <Button variant="destructive" size="sm" onClick={() => deleteQuizMutation.mutate(quizForm.id)}>
                        <Trash2 className="w-4 h-4 mr-2" /> Delete Quiz
                      </Button>
                    )}
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div className="space-y-2">
                    <Label>Quiz Title</Label>
                    <Input value={quizForm.title} onChange={e => setQuizForm({...quizForm, title: e.target.value})} />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-2">
                      <Label>Passing Score (%)</Label>
                      <Input type="number" value={quizForm.passing_score} onChange={e => setQuizForm({...quizForm, passing_score: +e.target.value})} />
                    </div>
                    <div className="space-y-2">
                      <Label>Points Reward</Label>
                      <Input type="number" value={quizForm.points_reward} onChange={e => setQuizForm({...quizForm, points_reward: +e.target.value})} />
                    </div>
                  </div>
                </div>
                <div className="space-y-2 mb-6">
                  <Label>Description/Instructions</Label>
                  <Textarea value={quizForm.description} onChange={e => setQuizForm({...quizForm, description: e.target.value})} rows={2} />
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <Label className="text-base">Questions ({quizForm.questions.length})</Label>
                    <Button size="sm" variant="outline" onClick={addQuestion}>
                      <Plus className="w-4 h-4 mr-2" /> Add Question
                    </Button>
                  </div>

                  <Accordion type="single" collapsible className="space-y-2">
                    {quizForm.questions.map((q, idx) => (
                      <AccordionItem key={idx} value={`item-${idx}`} className="border rounded-lg px-4 bg-gray-50">
                        <AccordionTrigger className="hover:no-underline py-3">
                          <div className="flex items-center gap-3 text-left">
                            <span className="bg-purple-100 w-6 h-6 flex items-center justify-center rounded-full text-xs font-bold text-purple-700">{idx + 1}</span>
                            <span className="font-medium truncate max-w-md">{q.question || "New Question"}</span>
                          </div>
                        </AccordionTrigger>
                        <AccordionContent className="pt-2 pb-4 space-y-4">
                          <div className="space-y-2">
                            <Label>Question Text</Label>
                            <Input value={q.question} onChange={e => updateQuestion(idx, 'question', e.target.value)} />
                          </div>
                          
                          {/* Type Selector */}
                          <div className="space-y-2">
                            <Label>Question Type</Label>
                            <Select value={q.type} onValueChange={(v) => updateQuestion(idx, 'type', v)}>
                              <SelectTrigger><SelectValue /></SelectTrigger>
                              <SelectContent>
                                <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                                <SelectItem value="true_false">True/False</SelectItem>
                                <SelectItem value="reflection">Reflection</SelectItem>
                                <SelectItem value="fill_in_the_blank">Fill in the Blank</SelectItem>
                                <SelectItem value="matching">Matching</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          {/* Multiple Choice Options */}
                          {q.type === 'multiple_choice' && (
                            <div className="space-y-3">
                              <Label>Options (Select correct one)</Label>
                              {q.options.map((opt, oIdx) => (
                                <div key={oIdx} className="flex items-center gap-2">
                                  <input 
                                    type="radio" 
                                    name={`correct-${idx}`}
                                    checked={q.correct_answer === oIdx}
                                    onChange={() => updateQuestion(idx, 'correct_answer', oIdx)}
                                    className="w-4 h-4 text-purple-600"
                                  />
                                  <Input value={opt} onChange={e => updateOption(idx, oIdx, e.target.value)} placeholder={`Option ${oIdx + 1}`} />
                                </div>
                              ))}
                            </div>
                          )}

                          {/* Fill in the Blank */}
                          {q.type === 'fill_in_the_blank' && (
                            <div className="space-y-3">
                              <Label>Question Text (Use [blank] for missing words)</Label>
                              <Textarea 
                                value={q.question} 
                                onChange={e => updateQuestion(idx, 'question', e.target.value)} 
                                placeholder="e.g. The capital of France is [blank]." 
                              />
                              <Label>Correct Answer(s) (comma separated for multiple blanks)</Label>
                              <Input 
                                value={q.correct_answers ? q.correct_answers.join(', ') : ''} 
                                onChange={e => updateQuestion(idx, 'correct_answers', e.target.value.split(',').map(s => s.trim()))} 
                                placeholder="e.g. Paris" 
                              />
                            </div>
                          )}

                          {/* Matching */}
                          {q.type === 'matching' && (
                            <div className="space-y-3">
                              <Label>Matching Pairs</Label>
                              {(q.pairs || [{left:'', right:''}, {left:'', right:''}]).map((pair, pIdx) => (
                                <div key={pIdx} className="flex gap-2 items-center">
                                  <Input 
                                    placeholder="Left Item" 
                                    value={pair.left} 
                                    onChange={e => {
                                      const newPairs = [...(q.pairs || [{left:'', right:''}, {left:'', right:''}])];
                                      newPairs[pIdx].left = e.target.value;
                                      updateQuestion(idx, 'pairs', newPairs);
                                    }} 
                                  />
                                  <ArrowRight className="w-4 h-4" />
                                  <Input 
                                    placeholder="Right Item" 
                                    value={pair.right} 
                                    onChange={e => {
                                      const newPairs = [...(q.pairs || [{left:'', right:''}, {left:'', right:''}])];
                                      newPairs[pIdx].right = e.target.value;
                                      updateQuestion(idx, 'pairs', newPairs);
                                    }} 
                                  />
                                </div>
                              ))}
                              <Button 
                                variant="outline" 
                                size="sm" 
                                onClick={() => {
                                  const newPairs = [...(q.pairs || [{left:'', right:''}, {left:'', right:''}]), {left:'', right:''}];
                                  updateQuestion(idx, 'pairs', newPairs);
                                }}
                              >
                                Add Pair
                              </Button>
                            </div>
                          )}

                          <div className="space-y-2">
                            <Label>Explanation (shown after answer)</Label>
                            <Textarea value={q.explanation} onChange={e => updateQuestion(idx, 'explanation', e.target.value)} rows={2} />
                          </div>

                          <div className="flex justify-end pt-2">
                            <Button variant="ghost" size="sm" className="text-red-500" onClick={() => removeQuestion(idx)}>
                              <Trash2 className="w-4 h-4 mr-2" /> Remove Question
                            </Button>
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </div>

                <div className="mt-8">
                  <Button onClick={() => saveQuizMutation.mutate(quizForm)} className="w-full bg-purple-600 text-lg py-6">
                    <Save className="w-5 h-5 mr-2" /> Save Quiz
                  </Button>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}