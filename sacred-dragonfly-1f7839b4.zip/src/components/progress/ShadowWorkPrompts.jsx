import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Moon, ChevronRight, AlertCircle, RefreshCw, Zap, Loader2 } from "lucide-react";

const SHADOW_WORK_CATEGORIES = [
  { id: 'triggers', name: 'Emotional Triggers', color: 'bg-red-100 text-red-700' },
  { id: 'relationships', name: 'Relationships', color: 'bg-pink-100 text-pink-700' },
  { id: 'fears', name: 'Fears & Insecurities', color: 'bg-purple-100 text-purple-700' },
  { id: 'childhood', name: 'Childhood & Past', color: 'bg-blue-100 text-blue-700' },
  { id: 'self_image', name: 'Self-Image', color: 'bg-green-100 text-green-700' },
  { id: 'patterns', name: 'Patterns & Habits', color: 'bg-amber-100 text-amber-700' }
];

export default function ShadowWorkPrompts({ onSelectPrompt }) {
  const [activeCategory, setActiveCategory] = useState('all');

  const { data: prompts = [], isLoading } = useQuery({
    queryKey: ['shadow-work-prompts'],
    queryFn: async () => {
       const data = await base44.entities.ShadowWorkPrompt.filter({ is_active: true });
       // Sort by random or recent? Let's just shuffle or keep as is.
       return data;
    },
  });

  const filteredPrompts = activeCategory === 'all' 
    ? prompts 
    : prompts.filter(p => p.category === activeCategory);

  const getCategoryColor = (catId) => {
    return SHADOW_WORK_CATEGORIES.find(c => c.id === catId)?.color || 'bg-gray-100 text-gray-700';
  };

  if (isLoading) return <div className="flex justify-center p-8"><Loader2 className="w-8 h-8 animate-spin text-purple-600" /></div>;

  return (
    <div className="grid md:grid-cols-4 gap-6">
      <Card className="md:col-span-1 bg-gradient-to-br from-slate-900 to-slate-800 text-white border-none shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <Moon className="w-5 h-5 text-purple-400" />
            Shadow Work
          </CardTitle>
          <p className="text-sm text-slate-400 mt-2">
            Explore the hidden parts of your psyche. Bring light to the shadows to integrate and heal.
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Button
              variant={activeCategory === 'all' ? 'secondary' : 'ghost'}
              className={`w-full justify-start ${activeCategory === 'all' ? 'bg-white/10 text-white' : 'text-slate-300 hover:text-white hover:bg-white/5'}`}
              onClick={() => setActiveCategory('all')}
            >
              All Prompts
            </Button>
            {SHADOW_WORK_CATEGORIES.map(category => (
              <Button
                key={category.id}
                variant="ghost"
                className={`w-full justify-start ${activeCategory === category.id ? 'bg-white/10 text-white' : 'text-slate-300 hover:text-white hover:bg-white/5'}`}
                onClick={() => setActiveCategory(category.id)}
              >
                {category.name}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="md:col-span-3">
        <Card>
          <CardHeader>
            <CardTitle>Choose a Prompt</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[500px] pr-4">
              <div className="grid gap-4">
                {filteredPrompts.map((prompt, idx) => (
                  <div
                    key={idx}
                    className="group relative p-6 bg-white border rounded-xl hover:shadow-md transition-all cursor-pointer hover:border-purple-300"
                    onClick={() => onSelectPrompt(prompt.text)}
                  >
                    <div className="flex justify-between items-start mb-3">
                      <Badge className={getCategoryColor(prompt.category)}>
                        {SHADOW_WORK_CATEGORIES.find(c => c.id === prompt.category)?.name}
                      </Badge>
                      <Button size="sm" variant="ghost" className="opacity-0 group-hover:opacity-100 transition-opacity text-purple-600">
                        Use Prompt <ChevronRight className="w-4 h-4 ml-1" />
                      </Button>
                    </div>
                    <p className="text-lg text-gray-700 font-medium group-hover:text-purple-800 transition-colors">
                      {prompt.text}
                    </p>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}