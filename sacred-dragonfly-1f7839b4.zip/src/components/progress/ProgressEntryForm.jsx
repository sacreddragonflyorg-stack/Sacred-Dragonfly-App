import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { X, Plus, Sparkles, Heart, Baby, CheckCircle2, Moon } from "lucide-react";
import { toast } from "sonner";

const moodOptions = [
  { value: "very_low", label: "Very Low", emoji: "😔", score: 1 },
  { value: "low", label: "Low", emoji: "😕", score: 2 },
  { value: "neutral", label: "Neutral", emoji: "😐", score: 3 },
  { value: "good", label: "Good", emoji: "😊", score: 4 },
  { value: "excellent", label: "Excellent", emoji: "🤩", score: 5 }
];

export default function ProgressEntryForm({ entry, onClose, user, appointments }) {
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useState({
    entry_date: entry?.entry_date || new Date().toISOString().split('T')[0],
    mood: entry?.mood || "neutral",
    mood_score: entry?.mood_score || 3,
    energy_level: entry?.energy_level || 5,
    stress_level: entry?.stress_level || 5,
    sleep_quality: entry?.sleep_quality || 5,
    symptoms: entry?.symptoms || [],
    journal_entry: entry?.journal_entry || "",
    gratitude_notes: entry?.gratitude_notes || "",
    intentions: entry?.intentions || "",
    manifestation_writing: entry?.manifestation_writing || "",
    inner_child_work: entry?.inner_child_work || "",
    shadow_work: entry?.shadow_work || "",
    daily_activities: entry?.daily_activities || "",
    related_appointment_id: entry?.related_appointment_id || "",
    is_private: entry?.is_private !== undefined ? entry.is_private : true,
    tags: entry?.tags || []
  });

  const [newSymptom, setNewSymptom] = useState({ name: "", severity: 5 });
  const [newTag, setNewTag] = useState("");

  const saveMutation = useMutation({
    mutationFn: (data) => {
      if (entry) {
        return base44.entities.ProgressEntry.update(entry.id, data);
      }
      return base44.entities.ProgressEntry.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['progress-entries']);
      toast.success(entry ? "Entry updated!" : "Entry saved!");
      onClose();
    },
    onError: () => {
      toast.error("Failed to save entry");
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    saveMutation.mutate(formData);
  };

  const handleMoodChange = (mood) => {
    const moodData = moodOptions.find(m => m.value === mood);
    setFormData({
      ...formData,
      mood,
      mood_score: moodData.score
    });
  };

  const addSymptom = () => {
    if (newSymptom.name.trim()) {
      setFormData({
        ...formData,
        symptoms: [...formData.symptoms, newSymptom]
      });
      setNewSymptom({ name: "", severity: 5 });
    }
  };

  const removeSymptom = (index) => {
    setFormData({
      ...formData,
      symptoms: formData.symptoms.filter((_, i) => i !== index)
    });
  };

  const addTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, newTag.trim()]
      });
      setNewTag("");
    }
  };

  const removeTag = (tag) => {
    setFormData({
      ...formData,
      tags: formData.tags.filter(t => t !== tag)
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-600" />
          {entry ? "Edit Progress Entry" : "New Progress Entry"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Date */}
          <div className="space-y-2">
            <Label>Date</Label>
            <Input
              type="date"
              value={formData.entry_date}
              onChange={(e) => setFormData({ ...formData, entry_date: e.target.value })}
              required
            />
          </div>

          {/* Mood */}
          <div className="space-y-2">
            <Label>How are you feeling today?</Label>
            <div className="grid grid-cols-5 gap-2">
              {moodOptions.map((mood) => (
                <button
                  key={mood.value}
                  type="button"
                  onClick={() => handleMoodChange(mood.value)}
                  className={`p-3 rounded-lg border-2 transition-all ${
                    formData.mood === mood.value
                      ? 'border-purple-600 bg-purple-50'
                      : 'border-gray-200 hover:border-purple-300'
                  }`}
                >
                  <div className="text-3xl mb-1">{mood.emoji}</div>
                  <div className="text-xs font-medium">{mood.label}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Metrics */}
          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Energy Level (1-10): {formData.energy_level}</Label>
              <input
                type="range"
                min="1"
                max="10"
                value={formData.energy_level}
                onChange={(e) => setFormData({ ...formData, energy_level: parseInt(e.target.value) })}
                className="w-full"
              />
            </div>
            <div className="space-y-2">
              <Label>Stress Level (1-10): {formData.stress_level}</Label>
              <input
                type="range"
                min="1"
                max="10"
                value={formData.stress_level}
                onChange={(e) => setFormData({ ...formData, stress_level: parseInt(e.target.value) })}
                className="w-full"
              />
            </div>
            <div className="space-y-2">
              <Label>Sleep Quality (1-10): {formData.sleep_quality}</Label>
              <input
                type="range"
                min="1"
                max="10"
                value={formData.sleep_quality}
                onChange={(e) => setFormData({ ...formData, sleep_quality: parseInt(e.target.value) })}
                className="w-full"
              />
            </div>
          </div>

          {/* Symptoms */}
          <div className="space-y-2">
            <Label>Symptoms (if any)</Label>
            <div className="flex gap-2">
              <Input
                value={newSymptom.name}
                onChange={(e) => setNewSymptom({ ...newSymptom, name: e.target.value })}
                placeholder="Symptom name"
              />
              <Input
                type="number"
                min="1"
                max="10"
                value={newSymptom.severity}
                onChange={(e) => setNewSymptom({ ...newSymptom, severity: parseInt(e.target.value) })}
                className="w-20"
              />
              <Button type="button" onClick={addSymptom} size="icon">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {formData.symptoms.map((symptom, index) => (
                <Badge key={index} variant="secondary" className="gap-2">
                  {symptom.name} ({symptom.severity}/10)
                  <button type="button" onClick={() => removeSymptom(index)}>
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </div>

          {/* Daily Activities */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-600" />
              Daily Activities & Accomplishments
            </Label>
            <Textarea
              value={formData.daily_activities}
              onChange={(e) => setFormData({ ...formData, daily_activities: e.target.value })}
              placeholder="What did you do today? What did you accomplish? Celebrate your wins, big and small..."
              rows={4}
            />
          </div>

          {/* Journal Entry */}
          <div className="space-y-2">
            <Label>Journal Entry</Label>
            <Textarea
              value={formData.journal_entry}
              onChange={(e) => setFormData({ ...formData, journal_entry: e.target.value })}
              placeholder="Express your thoughts and feelings freely..."
              rows={6}
            />
          </div>

          {/* Gratitude */}
          <div className="space-y-2 bg-gradient-to-r from-amber-50 to-pink-50 rounded-lg p-4">
            <Label className="flex items-center gap-2">
              <Heart className="w-4 h-4 text-pink-600" />
              Gratitude Journal
            </Label>
            <Textarea
              value={formData.gratitude_notes}
              onChange={(e) => setFormData({ ...formData, gratitude_notes: e.target.value })}
              placeholder="What are you grateful for today? Even small things count..."
              rows={4}
            />
          </div>

          {/* Manifestation Writing */}
          <div className="space-y-2 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-4">
            <Label className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-600" />
              Manifestation Journal
            </Label>
            <p className="text-sm text-gray-600 mb-2">
              Write as if you ALREADY have what you want. Stay in abundance, not lack.
            </p>
            <Textarea
              value={formData.manifestation_writing}
              onChange={(e) => setFormData({ ...formData, manifestation_writing: e.target.value })}
              placeholder="I am so grateful now that... I love having... I feel amazing because... (Write in present tense!)"
              rows={5}
            />
          </div>

          {/* Inner Child Work */}
          <div className="space-y-2 bg-gradient-to-r from-pink-50 to-purple-50 rounded-lg p-4">
          <Label className="flex items-center gap-2">
            <Baby className="w-4 h-4 text-pink-600" />
            Inner Child Communication
          </Label>
          <p className="text-sm text-gray-600 mb-2">
            Connect with your inner child. What does little you need to hear? What do they want to tell you?
          </p>
          <Textarea
            value={formData.inner_child_work}
            onChange={(e) => setFormData({ ...formData, inner_child_work: e.target.value })}
            placeholder="Dear little one... or... From my inner child..."
            rows={5}
          />
          </div>

          {/* Shadow Work */}
          <div className="space-y-2 bg-gradient-to-r from-slate-100 to-gray-100 rounded-lg p-4 border border-slate-200">
          <Label className="flex items-center gap-2 text-slate-800">
            <Moon className="w-4 h-4 text-indigo-600" />
            Shadow Work Reflection
          </Label>
          <p className="text-sm text-gray-600 mb-2">
            Explore your triggers, hidden emotions, and unconscious patterns. Bring the shadow into the light.
          </p>
          <Textarea
            value={formData.shadow_work}
            onChange={(e) => setFormData({ ...formData, shadow_work: e.target.value })}
            placeholder="I noticed I was triggered when... The deeper emotion underneath is..."
            rows={6}
            className="bg-white"
          />
          </div>

          {/* Intentions */}
          <div className="space-y-2">
            <Label>Intentions & Affirmations</Label>
            <Textarea
              value={formData.intentions}
              onChange={(e) => setFormData({ ...formData, intentions: e.target.value })}
              placeholder="Set your intentions for today/tomorrow..."
              rows={3}
            />
          </div>

          {/* Related Appointment */}
          {appointments && appointments.length > 0 && (
            <div className="space-y-2">
              <Label>Related to a Healing Session?</Label>
              <Select
                value={formData.related_appointment_id}
                onValueChange={(value) => setFormData({ ...formData, related_appointment_id: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Optional - link to appointment" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>None</SelectItem>
                  {appointments.map((apt) => (
                    <SelectItem key={apt.id} value={apt.id}>
                      {apt.service_name} - {new Date(apt.appointment_date).toLocaleDateString()}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Tags */}
          <div className="space-y-2">
            <Label>Tags</Label>
            <div className="flex gap-2">
              <Input
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                placeholder="Add a tag"
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
              />
              <Button type="button" onClick={addTag} size="icon">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {formData.tags.map((tag, index) => (
                <Badge key={index} className="gap-2 bg-purple-100 text-purple-700">
                  {tag}
                  <button type="button" onClick={() => removeTag(tag)}>
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </div>

          {/* Privacy */}
          <div className="flex items-center gap-2 p-4 bg-gray-50 rounded-lg">
            <input
              type="checkbox"
              id="is_private"
              checked={!formData.is_private}
              onChange={(e) => setFormData({ ...formData, is_private: !e.target.checked })}
              className="w-4 h-4"
            />
            <Label htmlFor="is_private" className="cursor-pointer">
              Share this entry with my practitioner
            </Label>
          </div>

          {/* Buttons */}
          <div className="flex gap-3">
            <Button
              type="submit"
              disabled={saveMutation.isPending}
              className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              {saveMutation.isPending ? "Saving..." : "Save Entry"}
            </Button>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}