import React from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { Edit, Trash2, Lock, Unlock, Heart, Sparkles, Baby, CheckCircle2, BookOpen, MessageSquare, Moon } from "lucide-react";
import { toast } from "sonner";

const moodEmojis = {
  very_low: "😔",
  low: "😕",
  neutral: "😐",
  good: "😊",
  excellent: "🤩"
};

export default function ProgressJournal({ entries, isLoading, onEdit, user }) {
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.ProgressEntry.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['progress-entries']);
      toast.success("Entry deleted");
    },
  });

  const togglePrivacyMutation = useMutation({
    mutationFn: ({ id, isPrivate }) => {
      return base44.entities.ProgressEntry.update(id, { is_private: !isPrivate });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['progress-entries']);
      toast.success("Privacy updated");
    },
  });

  if (isLoading) {
    return (
      <div className="grid gap-6">
        {[1, 2, 3].map((i) => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-6 w-1/3" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-24 w-full" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (entries.length === 0) {
    return (
      <Card className="text-center py-16">
        <CardContent>
          <BookOpen className="w-16 h-16 text-purple-300 mx-auto mb-4" />
          <h3 className="text-2xl font-semibold text-gray-700 mb-2">Start Your Journey</h3>
          <p className="text-gray-500">Begin tracking your progress and healing journey</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid gap-6">
      {entries.map((entry) => (
        <Card key={entry.id} className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="text-4xl">{moodEmojis[entry.mood]}</div>
                <div>
                  <CardTitle className="flex items-center gap-2">
                    {format(new Date(entry.entry_date), 'EEEE, MMMM d, yyyy')}
                  </CardTitle>
                  <div className="flex gap-2 mt-2">
                    {entry.is_private ? (
                      <Badge variant="outline" className="gap-1">
                        <Lock className="w-3 h-3" />
                        Private
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="gap-1 border-purple-300 text-purple-700">
                        <Unlock className="w-3 h-3" />
                        Shared
                      </Badge>
                    )}
                    {entry.practitioner_feedback && (
                      <Badge className="bg-green-100 text-green-700 gap-1">
                        <MessageSquare className="w-3 h-3" />
                        Practitioner Feedback
                      </Badge>
                    )}
                    {entry.tags?.map((tag, idx) => (
                      <Badge key={idx} className="bg-purple-100 text-purple-700">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => togglePrivacyMutation.mutate({ id: entry.id, isPrivate: entry.is_private })}
                  title={entry.is_private ? "Share with practitioner" : "Make private"}
                >
                  {entry.is_private ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => onEdit(entry)}
                >
                  <Edit className="w-4 h-4" />
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => deleteMutation.mutate(entry.id)}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Metrics */}
            <div className="grid grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
              <div className="text-center">
                <div className="text-sm text-gray-600">Energy</div>
                <div className="text-2xl font-bold text-purple-600">{entry.energy_level}/10</div>
              </div>
              <div className="text-center">
                <div className="text-sm text-gray-600">Stress</div>
                <div className="text-2xl font-bold text-pink-600">{entry.stress_level}/10</div>
              </div>
              <div className="text-center">
                <div className="text-sm text-gray-600">Sleep</div>
                <div className="text-2xl font-bold text-blue-600">{entry.sleep_quality}/10</div>
              </div>
            </div>

            {/* Practitioner Feedback */}
            {entry.practitioner_feedback && (
              <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border-2 border-green-200">
                <div className="flex items-center gap-2 mb-2">
                  <MessageSquare className="w-4 h-4 text-green-600" />
                  <span className="font-medium text-green-900">Practitioner's Guidance:</span>
                </div>
                <p className="text-gray-700 whitespace-pre-wrap">{entry.practitioner_feedback}</p>
              </div>
            )}

            {/* Symptoms */}
            {entry.symptoms && entry.symptoms.length > 0 && (
              <div className="p-3 bg-red-50 rounded-lg">
                <div className="text-sm font-medium text-red-900 mb-2">Symptoms:</div>
                <div className="flex flex-wrap gap-2">
                  {entry.symptoms.map((symptom, idx) => (
                    <Badge key={idx} variant="outline" className="border-red-300 text-red-700">
                      {symptom.name} ({symptom.severity}/10)
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Daily Activities */}
            {entry.daily_activities && (
              <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  <span className="text-sm font-medium text-green-900">Daily Activities:</span>
                </div>
                <p className="text-gray-700 whitespace-pre-wrap">{entry.daily_activities}</p>
              </div>
            )}

            {/* Journal Entry */}
            {entry.journal_entry && (
              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <BookOpen className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-900">Journal:</span>
                </div>
                <p className="text-gray-700 whitespace-pre-wrap">{entry.journal_entry}</p>
              </div>
            )}

            {/* Gratitude */}
            {entry.gratitude_notes && (
              <div className="p-4 bg-gradient-to-r from-amber-50 to-pink-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Heart className="w-4 h-4 text-pink-600" />
                  <span className="text-sm font-medium text-pink-900">Gratitude:</span>
                </div>
                <p className="text-gray-700 whitespace-pre-wrap">{entry.gratitude_notes}</p>
              </div>
            )}

            {/* Manifestation */}
            {entry.manifestation_writing && (
              <div className="p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg border-2 border-purple-200">
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="w-4 h-4 text-purple-600" />
                  <span className="text-sm font-medium text-purple-900">Manifestation:</span>
                </div>
                <p className="text-gray-700 whitespace-pre-wrap font-medium">{entry.manifestation_writing}</p>
              </div>
            )}

            {/* Inner Child */}
            {entry.inner_child_work && (
              <div className="p-4 bg-gradient-to-r from-pink-50 to-purple-50 rounded-lg border-2 border-pink-200">
                <div className="flex items-center gap-2 mb-2">
                  <Baby className="w-4 h-4 text-pink-600" />
                  <span className="text-sm font-medium text-pink-900">Inner Child:</span>
                </div>
                <p className="text-gray-700 whitespace-pre-wrap italic">{entry.inner_child_work}</p>
              </div>
            )}

            {/* Shadow Work */}
            {entry.shadow_work && (
              <div className="p-4 bg-gradient-to-r from-slate-100 to-gray-100 rounded-lg border-2 border-slate-300">
                <div className="flex items-center gap-2 mb-2">
                  <Moon className="w-4 h-4 text-indigo-600" />
                  <span className="text-sm font-medium text-indigo-900">Shadow Work:</span>
                </div>
                <p className="text-gray-800 whitespace-pre-wrap">{entry.shadow_work}</p>
              </div>
            )}

            {/* Intentions */}
            {entry.intentions && (
              <div className="p-4 bg-purple-50 rounded-lg">
                <div className="text-sm font-medium text-purple-900 mb-2">Intentions:</div>
                <p className="text-gray-700 whitespace-pre-wrap">{entry.intentions}</p>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}