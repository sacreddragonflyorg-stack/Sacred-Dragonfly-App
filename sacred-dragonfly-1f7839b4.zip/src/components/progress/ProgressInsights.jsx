import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Minus, Sparkles, Calendar, Target } from "lucide-react";

export default function ProgressInsights({ entries, isLoading }) {
  if (isLoading || entries.length < 2) {
    return (
      <Card>
        <CardContent className="text-center py-16">
          <Sparkles className="w-16 h-16 text-purple-300 mx-auto mb-4" />
          <p className="text-gray-500">Add more entries to see personalized insights</p>
        </CardContent>
      </Card>
    );
  }

  // Calculate trends (comparing last 7 entries vs previous 7)
  const recent = entries.slice(0, 7);
  const previous = entries.slice(7, 14);

  const calculateAvg = (arr, field) => {
    if (arr.length === 0) return 0;
    return arr.reduce((sum, e) => sum + (e[field] || 0), 0) / arr.length;
  };

  const trends = {
    mood: calculateAvg(recent, 'mood_score') - calculateAvg(previous, 'mood_score'),
    energy: calculateAvg(recent, 'energy_level') - calculateAvg(previous, 'energy_level'),
    stress: calculateAvg(recent, 'stress_level') - calculateAvg(previous, 'stress_level'),
    sleep: calculateAvg(recent, 'sleep_quality') - calculateAvg(previous, 'sleep_quality')
  };

  const getTrendIcon = (value) => {
    if (value > 0.5) return <TrendingUp className="w-5 h-5 text-green-600" />;
    if (value < -0.5) return <TrendingDown className="w-5 h-5 text-red-600" />;
    return <Minus className="w-5 h-5 text-gray-600" />;
  };

  const getTrendColor = (value, inverse = false) => {
    const isPositive = inverse ? value < -0.5 : value > 0.5;
    const isNegative = inverse ? value > 0.5 : value < -0.5;
    
    if (isPositive) return "bg-green-100 text-green-800 border-green-200";
    if (isNegative) return "bg-red-100 text-red-800 border-red-200";
    return "bg-gray-100 text-gray-800 border-gray-200";
  };

  const getTrendText = (value) => {
    if (value > 0.5) return "Improving";
    if (value < -0.5) return "Declining";
    return "Stable";
  };

  // Find patterns
  const allSymptoms = {};
  entries.forEach(entry => {
    entry.symptoms?.forEach(symptom => {
      if (!allSymptoms[symptom.name]) {
        allSymptoms[symptom.name] = [];
      }
      allSymptoms[symptom.name].push(symptom.severity);
    });
  });

  const improvingSymptoms = [];
  const worseningSymptoms = [];

  Object.entries(allSymptoms).forEach(([name, severities]) => {
    if (severities.length >= 2) {
      const recent = severities.slice(0, Math.ceil(severities.length / 2));
      const previous = severities.slice(Math.ceil(severities.length / 2));
      const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
      const previousAvg = previous.reduce((a, b) => a + b, 0) / previous.length;
      const change = recentAvg - previousAvg;

      if (change < -1) {
        improvingSymptoms.push({ name, change: -change });
      } else if (change > 1) {
        worseningSymptoms.push({ name, change });
      }
    }
  });

  // Consistency score
  const entriesLast30Days = entries.filter(e => {
    const daysSince = (new Date() - new Date(e.entry_date)) / (1000 * 60 * 60 * 24);
    return daysSince <= 30;
  });
  const consistencyScore = Math.round((entriesLast30Days.length / 30) * 100);

  return (
    <div className="space-y-6">
      {/* Consistency */}
      <Card className="border-l-4 border-l-purple-600">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-purple-600" />
            Tracking Consistency
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <div className="text-4xl font-bold text-purple-600 mb-2">{consistencyScore}%</div>
              <p className="text-gray-600">
                You've logged {entriesLast30Days.length} entries in the last 30 days
              </p>
            </div>
            <div className="w-32 h-32 relative">
              <svg className="transform -rotate-90" width="128" height="128">
                <circle
                  cx="64"
                  cy="64"
                  r="56"
                  stroke="#E5E7EB"
                  strokeWidth="8"
                  fill="none"
                />
                <circle
                  cx="64"
                  cy="64"
                  r="56"
                  stroke="url(#gradient)"
                  strokeWidth="8"
                  fill="none"
                  strokeDasharray={`${(consistencyScore / 100) * 352} 352`}
                  strokeLinecap="round"
                />
                <defs>
                  <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#8B5CF6" />
                    <stop offset="100%" stopColor="#EC4899" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Trends */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-purple-600" />
            Recent Trends (Last 7 vs Previous 7 Entries)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <div className="text-sm text-gray-600 mb-1">Mood</div>
                <Badge className={`${getTrendColor(trends.mood)} border`}>
                  {getTrendText(trends.mood)}
                </Badge>
              </div>
              {getTrendIcon(trends.mood)}
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <div className="text-sm text-gray-600 mb-1">Energy Level</div>
                <Badge className={`${getTrendColor(trends.energy)} border`}>
                  {getTrendText(trends.energy)}
                </Badge>
              </div>
              {getTrendIcon(trends.energy)}
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <div className="text-sm text-gray-600 mb-1">Stress Level</div>
                <Badge className={`${getTrendColor(trends.stress, true)} border`}>
                  {getTrendText(-trends.stress)}
                </Badge>
              </div>
              {getTrendIcon(-trends.stress)}
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <div className="text-sm text-gray-600 mb-1">Sleep Quality</div>
                <Badge className={`${getTrendColor(trends.sleep)} border`}>
                  {getTrendText(trends.sleep)}
                </Badge>
              </div>
              {getTrendIcon(trends.sleep)}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Symptom Changes */}
      {(improvingSymptoms.length > 0 || worseningSymptoms.length > 0) && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="w-5 h-5 text-purple-600" />
              Symptom Patterns
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {improvingSymptoms.length > 0 && (
              <div>
                <div className="font-medium text-green-700 mb-2 flex items-center gap-2">
                  <TrendingDown className="w-4 h-4" />
                  Improving Symptoms
                </div>
                <div className="space-y-2">
                  {improvingSymptoms.map((symptom, idx) => (
                    <div key={idx} className="flex items-center justify-between bg-green-50 p-3 rounded-lg">
                      <span className="font-medium">{symptom.name}</span>
                      <Badge className="bg-green-100 text-green-800">
                        ↓ {symptom.change.toFixed(1)} points
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {worseningSymptoms.length > 0 && (
              <div>
                <div className="font-medium text-red-700 mb-2 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" />
                  Symptoms Needing Attention
                </div>
                <div className="space-y-2">
                  {worseningSymptoms.map((symptom, idx) => (
                    <div key={idx} className="flex items-center justify-between bg-red-50 p-3 rounded-lg">
                      <span className="font-medium">{symptom.name}</span>
                      <Badge className="bg-red-100 text-red-800">
                        ↑ {symptom.change.toFixed(1)} points
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Recommendations */}
      <Card className="border-l-4 border-l-amber-600 bg-gradient-to-r from-amber-50 to-orange-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-600" />
            Personalized Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3">
            {consistencyScore < 50 && (
              <li className="flex items-start gap-2">
                <span className="text-amber-600 mt-0.5">•</span>
                <span className="text-gray-700">
                  Try to log your progress more consistently to get better insights
                </span>
              </li>
            )}
            {trends.stress > 1 && (
              <li className="flex items-start gap-2">
                <span className="text-amber-600 mt-0.5">•</span>
                <span className="text-gray-700">
                  Your stress levels are increasing. Consider booking a Reiki or energy healing session
                </span>
              </li>
            )}
            {trends.sleep < -1 && (
              <li className="flex items-start gap-2">
                <span className="text-amber-600 mt-0.5">•</span>
                <span className="text-gray-700">
                  Your sleep quality is declining. Explore our meditation resources in the Learning Center
                </span>
              </li>
            )}
            {trends.mood < -1 && (
              <li className="flex items-start gap-2">
                <span className="text-amber-600 mt-0.5">•</span>
                <span className="text-gray-700">
                  Your mood has been lower lately. A tarot reading might provide guidance and clarity
                </span>
              </li>
            )}
            {trends.mood > 1 && trends.energy > 1 && (
              <li className="flex items-start gap-2">
                <span className="text-amber-600 mt-0.5">•</span>
                <span className="text-gray-700">
                  Great progress! You're on a positive trajectory. Keep up your healing practices
                </span>
              </li>
            )}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}