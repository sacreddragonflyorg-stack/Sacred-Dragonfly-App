import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { TrendingUp, Activity, Moon, Zap, AlertCircle } from "lucide-react";
import { format } from "date-fns";

export default function ProgressCharts({ entries, isLoading }) {
  if (isLoading || entries.length === 0) {
    return (
      <Card>
        <CardContent className="text-center py-16">
          <Activity className="w-16 h-16 text-purple-300 mx-auto mb-4" />
          <p className="text-gray-500">Add more entries to see your analytics</p>
        </CardContent>
      </Card>
    );
  }

  // Prepare data for charts (last 30 entries, sorted by date)
  const chartData = entries
    .slice(0, 30)
    .reverse()
    .map(entry => ({
      date: format(new Date(entry.entry_date), 'MMM d'),
      mood: entry.mood_score,
      energy: entry.energy_level,
      stress: entry.stress_level,
      sleep: entry.sleep_quality
    }));

  // Calculate averages
  const averages = {
    mood: (entries.reduce((sum, e) => sum + (e.mood_score || 0), 0) / entries.length).toFixed(1),
    energy: (entries.reduce((sum, e) => sum + (e.energy_level || 0), 0) / entries.length).toFixed(1),
    stress: (entries.reduce((sum, e) => sum + (e.stress_level || 0), 0) / entries.length).toFixed(1),
    sleep: (entries.reduce((sum, e) => sum + (e.sleep_quality || 0), 0) / entries.length).toFixed(1)
  };

  // Get most common symptoms
  const symptomFrequency = {};
  entries.forEach(entry => {
    entry.symptoms?.forEach(symptom => {
      if (!symptomFrequency[symptom.name]) {
        symptomFrequency[symptom.name] = { count: 0, totalSeverity: 0 };
      }
      symptomFrequency[symptom.name].count++;
      symptomFrequency[symptom.name].totalSeverity += symptom.severity;
    });
  });

  const topSymptoms = Object.entries(symptomFrequency)
    .map(([name, data]) => ({
      name,
      frequency: data.count,
      avgSeverity: (data.totalSeverity / data.count).toFixed(1)
    }))
    .sort((a, b) => b.frequency - a.frequency)
    .slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">{averages.mood}/5</div>
                <div className="text-sm text-gray-600">Avg Mood</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                <Zap className="w-6 h-6 text-amber-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">{averages.energy}/10</div>
                <div className="text-sm text-gray-600">Avg Energy</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">{averages.stress}/10</div>
                <div className="text-sm text-gray-600">Avg Stress</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Moon className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">{averages.sleep}/10</div>
                <div className="text-sm text-gray-600">Avg Sleep</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Mood & Energy Trends */}
      <Card>
        <CardHeader>
          <CardTitle>Mood & Energy Trends</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis domain={[0, 10]} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="mood" stroke="#8B5CF6" strokeWidth={2} name="Mood (1-5)" />
              <Line type="monotone" dataKey="energy" stroke="#F59E0B" strokeWidth={2} name="Energy" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Stress & Sleep */}
      <Card>
        <CardHeader>
          <CardTitle>Stress & Sleep Quality</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis domain={[0, 10]} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="stress" stroke="#EF4444" strokeWidth={2} name="Stress" />
              <Line type="monotone" dataKey="sleep" stroke="#3B82F6" strokeWidth={2} name="Sleep" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Top Symptoms */}
      {topSymptoms.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Most Frequent Symptoms</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={topSymptoms}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="frequency" fill="#8B5CF6" name="Frequency" />
                <Bar dataKey="avgSeverity" fill="#EC4899" name="Avg Severity" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}
    </div>
  );
}