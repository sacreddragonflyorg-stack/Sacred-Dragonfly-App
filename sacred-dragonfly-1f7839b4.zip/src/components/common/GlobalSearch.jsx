import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Loader2, Sparkles, BookOpen, User, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

export default function GlobalSearch() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const search = async () => {
      if (query.length < 2) {
        setResults([]);
        return;
      }
      setIsLoading(true);
      try {
        const { data } = await base44.functions.invoke('searchContent', { query });
        setResults(data.results || []);
      } catch (error) {
        console.error("Search failed:", error);
      } finally {
        setIsLoading(false);
      }
    };

    const timeoutId = setTimeout(search, 500);
    return () => clearTimeout(timeoutId);
  }, [query]);

  const getIcon = (type) => {
    switch (type) {
      case 'service': return <Sparkles className="w-4 h-4 text-purple-500" />;
      case 'course': return <BookOpen className="w-4 h-4 text-blue-500" />;
      case 'practitioner': return <User className="w-4 h-4 text-green-500" />;
      default: return <Search className="w-4 h-4" />;
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="text-gray-600 hover:text-purple-600">
          <Search className="w-5 h-5" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] p-0 gap-0">
        <div className="p-4 border-b">
          <div className="flex items-center gap-3">
            <Search className="w-5 h-5 text-gray-400" />
            <Input
              placeholder="Search services, practitioners, articles..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="border-none shadow-none focus-visible:ring-0 text-lg p-0"
              autoFocus
            />
            {isLoading && <Loader2 className="w-4 h-4 animate-spin text-purple-600" />}
          </div>
        </div>
        
        <div className="max-h-[60vh] overflow-y-auto p-2">
          {results.length === 0 && query.length > 1 && !isLoading && (
            <p className="text-center text-gray-500 py-8">No results found for "{query}"</p>
          )}
          
          {results.length === 0 && query.length < 2 && (
            <div className="p-4 text-center text-gray-500 text-sm">
              Type at least 2 characters to search...
            </div>
          )}

          <div className="space-y-1">
            {results.map((result, index) => (
              <Link
                key={`${result.type}-${result.id}-${index}`}
                to={result.url}
                onClick={() => setOpen(false)}
                className="flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors group"
              >
                <div className="mt-1 bg-white p-2 rounded-full border shadow-sm">
                  {getIcon(result.type)}
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900 group-hover:text-purple-600 transition-colors">
                    {result.title}
                  </h4>
                  <p className="text-sm text-gray-500 line-clamp-1">
                    {result.description}
                  </p>
                  {result.tags && result.tags.length > 0 && (
                    <div className="flex gap-2 mt-1">
                      {result.tags.slice(0, 3).map(tag => (
                        <span key={tag} className="text-xs bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded">
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-purple-400 mt-2" />
              </Link>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}