import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Copy, CheckCircle2, Share2, Globe, QrCode } from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";

export default function ShareApp() {
  const [isOpen, setIsOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [appUrl, setAppUrl] = useState("");

  useEffect(() => {
    // Get the base URL without any specific paths
    // In production/preview, this is the correct URL to share
    setAppUrl(window.location.origin);
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(appUrl);
    setCopied(true);
    toast.success("App link copied to clipboard!");
    setTimeout(() => setCopied(false), 2000);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Sacred Healing',
          text: 'Join me on Sacred Healing for energy work and spiritual growth.',
          url: appUrl,
        });
      } catch (err) {
        console.error('Error sharing:', err);
      }
    } else {
      handleCopy();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          size="sm" 
          className="gap-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white border-none hover:opacity-90 transition-opacity"
        >
          <Share2 className="w-4 h-4" />
          Share App
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Globe className="w-5 h-5 text-purple-600" />
            Share Your App
          </DialogTitle>
          <DialogDescription>
            Share this link with your clients. This is the public link to your app where they can book sessions and sign up.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          <div className="p-4 bg-purple-50 rounded-lg border border-purple-100">
            <p className="text-sm font-medium text-purple-900 mb-2">Public App Link</p>
            <div className="flex gap-2">
              <Input 
                value={appUrl} 
                readOnly 
                className="bg-white font-mono text-sm"
              />
              <Button size="icon" variant="outline" onClick={handleCopy}>
                {copied ? <CheckCircle2 className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
              </Button>
            </div>
            <p className="text-xs text-purple-600 mt-2">
              Clients using this link will see the public version of your app, without editing capabilities.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
             <Button onClick={handleCopy} variant="outline" className="w-full">
              <Copy className="w-4 h-4 mr-2" />
              Copy Link
            </Button>
            <Button onClick={handleNativeShare} className="w-full bg-purple-600 text-white hover:bg-purple-700">
              <Share2 className="w-4 h-4 mr-2" />
              Share
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}