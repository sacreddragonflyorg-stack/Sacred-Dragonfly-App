import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { X, Sparkles } from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function AnnouncementBar() {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  return (
    <div className="bg-gradient-to-r from-purple-900 via-pink-800 to-purple-900 text-white relative z-[60] shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex items-center justify-between text-xs sm:text-sm">
        <div className="flex-1 flex flex-wrap items-center justify-center sm:justify-start gap-x-4 gap-y-1 text-center sm:text-left">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400 animate-pulse hidden sm:block" />
            <span className="font-medium tracking-wide">Now accepting new Practitioners & Clients!</span>
          </div>
          
          <div className="flex items-center gap-3">
             <Link 
               to={createPageUrl("PractitionerOnboarding")} 
               className="font-bold text-amber-300 hover:text-amber-100 underline decoration-amber-400/50 hover:decoration-amber-200 transition-colors"
             >
               Join as Practitioner
             </Link>
             <span className="text-white/30 hidden sm:inline">|</span>
             <Link 
               to={createPageUrl("Booking")} 
               className="font-bold text-pink-300 hover:text-pink-100 underline decoration-pink-400/50 hover:decoration-pink-200 transition-colors"
             >
               Book a Session
             </Link>
          </div>
        </div>
        <button 
          onClick={() => setIsVisible(false)}
          className="ml-4 p-1 hover:bg-white/10 rounded-full transition-colors flex-shrink-0"
          aria-label="Close announcement"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}