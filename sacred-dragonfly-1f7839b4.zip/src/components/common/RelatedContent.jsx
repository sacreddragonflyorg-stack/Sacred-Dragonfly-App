import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

export default function RelatedContent({ tags = [], category, currentId, type }) {
  const { data: relatedItems = [] } = useQuery({
    queryKey: ['related-content', type, currentId],
    queryFn: async () => {
      // Simple client-side filtering simulation or specific query
      // Ideally, use a backend function or smart filtering
      // Here we fetch similar items based on type
      
      if (type === 'service') {
        const items = await base44.entities.Service.filter({ is_active: true });
        return items.filter(item => 
          item.id !== currentId && 
          (item.type === category || item.benefits?.some(b => tags.includes(b)))
        ).slice(0, 3);
      }
      
      if (type === 'course') {
        const items = await base44.entities.LearningCourse.filter({ is_active: true });
        return items.filter(item => 
          item.id !== currentId && 
          (item.category === category || item.tags?.some(t => tags.includes(t)))
        ).slice(0, 3);
      }

      return [];
    },
    enabled: !!currentId
  });

  if (relatedItems.length === 0) return null;

  return (
    <div className="mt-12">
      <h3 className="text-xl font-bold mb-6 text-gray-900">You Might Also Like</h3>
      <div className="grid md:grid-cols-3 gap-6">
        {relatedItems.map(item => (
          <Link key={item.id} to={type === 'service' ? `/booking?service=${item.id}` : `/learning-center`}>
            <Card className="h-full hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer bg-white/50">
              <CardContent className="p-6">
                <h4 className="font-semibold text-lg mb-2">{item.name || item.title}</h4>
                <p className="text-sm text-gray-600 line-clamp-2 mb-4">{item.description}</p>
                <div className="flex items-center text-purple-600 text-sm font-medium">
                  View Details <ArrowRight className="w-4 h-4 ml-1" />
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}