import React, { useState, useRef, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageCircle, X, Send, Sparkles, Loader2, Book, Calendar } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import ReactMarkdown from "react-markdown";

const CHATBOT_CONTEXT = `You are a compassionate healing assistant for Sacred Healing distance healing practice.

KEY INFO:
- All sessions remote (video/email/text) - equally powerful
- Muscle testing releases emotions WITHOUT revisiting trauma
- Specialties: addiction, depression, anxiety, PTSD, pain, abandonment
- Services: Reiki, tarot, crystals, chakras, cord cutting, inner child, manifestation
- Energy exchange by arrangement (donation, barter, pay-what-you-can)
- No fixed pricing - healing accessible to all

Be warm, supportive, concise (2-3 paragraphs). Guide users to book sessions, browse services, or learn more.`;

const quickActions = [
  { label: "Browse Services", icon: Sparkles, page: "Services" },
  { label: "Book a Session", icon: Calendar, page: "Booking" },
  { label: "Get Tarot Reading", icon: Sparkles, page: "Tarot" },
  { label: "Learning Resources", icon: Book, page: "Learning" }
];

export default function HealingChatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content: "Welcome to Sacred Healing! 🌟 I'm here to help you explore our distance healing services. How can I support you today?"
    }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput("");
    setMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setIsLoading(true);

    try {
      const conversationHistory = messages
        .slice(-6)
        .map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`)
        .join('\n\n');

      const prompt = `${CHATBOT_CONTEXT}

CONVERSATION:
${conversationHistory}

User: ${userMessage}

Respond helpfully and concisely. Guide them to relevant pages if needed.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        add_context_from_internet: false
      });

      setMessages(prev => [...prev, { role: "assistant", content: response }]);
    } catch (error) {
      setMessages(prev => [...prev, { 
        role: "assistant", 
        content: "I apologize, I'm having trouble connecting right now. Please try asking your question again, or feel free to explore our services directly!" 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickAction = (page) => {
    const message = `Tell me about ${page === 'Services' ? 'your healing services' : page === 'Booking' ? 'how to book a session' : page === 'Tarot' ? 'tarot readings' : 'learning resources'}`;
    setInput(message);
    handleSend();
  };

  return (
    <>
      {/* Floating Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            className="fixed bottom-6 right-6 z-50"
          >
            <Button
              onClick={() => setIsOpen(true)}
              size="lg"
              className="rounded-full w-16 h-16 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 shadow-2xl hover:shadow-purple-500/50 transition-all duration-300"
            >
              <MessageCircle className="w-7 h-7" />
            </Button>
            <div className="absolute -top-2 -right-2 w-4 h-4 bg-green-500 rounded-full animate-pulse border-2 border-white"></div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 right-6 z-50 w-[400px] max-w-[calc(100vw-3rem)] h-[600px] max-h-[calc(100vh-3rem)]"
          >
            <div className="bg-white rounded-2xl shadow-2xl flex flex-col h-full overflow-hidden border-2 border-purple-200">
              {/* Header */}
              <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Healing Assistant</h3>
                    <p className="text-xs text-purple-100">Here to support you</p>
                  </div>
                </div>
                <Button
                  onClick={() => setIsOpen(false)}
                  size="icon"
                  variant="ghost"
                  className="text-white hover:bg-white/20"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-purple-50/30 to-white">
                {messages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                        message.role === 'user'
                          ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white'
                          : 'bg-white border border-purple-200 text-gray-800'
                      }`}
                    >
                      {message.role === 'assistant' ? (
                        <ReactMarkdown
                          className="text-sm prose prose-sm prose-purple max-w-none"
                          components={{
                            p: ({ children }) => <p className="mb-2 last:mb-0">{children}</p>,
                            a: ({ href, children }) => {
                              // Check if it's an internal link
                              if (href?.startsWith('/')) {
                                return (
                                  <Link
                                    to={href}
                                    className="text-purple-600 hover:text-purple-700 underline font-medium"
                                    onClick={() => setIsOpen(false)}
                                  >
                                    {children}
                                  </Link>
                                );
                              }
                              return (
                                <a href={href} target="_blank" rel="noopener noreferrer" className="text-purple-600 hover:text-purple-700 underline">
                                  {children}
                                </a>
                              );
                            }
                          }}
                        >
                          {message.content}
                        </ReactMarkdown>
                      ) : (
                        <p className="text-sm">{message.content}</p>
                      )}
                    </div>
                  </div>
                ))}
                
                {isLoading && (
                  <div className="flex justify-start">
                    <div className="bg-white border border-purple-200 rounded-2xl px-4 py-3">
                      <Loader2 className="w-5 h-5 animate-spin text-purple-600" />
                    </div>
                  </div>
                )}
                
                <div ref={messagesEndRef} />
              </div>

              {/* Quick Actions */}
              {messages.length === 1 && (
                <div className="px-4 py-2 border-t border-purple-100">
                  <p className="text-xs text-gray-600 mb-2">Quick actions:</p>
                  <div className="flex flex-wrap gap-2">
                    {quickActions.map((action) => (
                      <Link
                        key={action.page}
                        to={createPageUrl(action.page)}
                        onClick={() => setIsOpen(false)}
                        className="text-xs px-3 py-1.5 bg-purple-100 text-purple-700 rounded-full hover:bg-purple-200 transition-colors flex items-center gap-1"
                      >
                        <action.icon className="w-3 h-3" />
                        {action.label}
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {/* Input */}
              <div className="p-4 border-t border-purple-100 bg-white">
                <div className="flex gap-2">
                  <Input
                    ref={inputRef}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
                    placeholder="Ask me anything..."
                    disabled={isLoading}
                    className="flex-1 border-purple-200 focus:border-purple-400"
                  />
                  <Button
                    onClick={handleSend}
                    disabled={isLoading || !input.trim()}
                    size="icon"
                    className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                  >
                    {isLoading ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </Button>
                </div>
                <p className="text-xs text-gray-500 mt-2 text-center">
                  Ask about services, booking, or energy exchange
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}