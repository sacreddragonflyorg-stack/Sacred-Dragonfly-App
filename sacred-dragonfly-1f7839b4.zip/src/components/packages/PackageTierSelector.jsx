import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Sparkles } from "lucide-react";

export default function PackageTierSelector({ pkg, onSelectTier }) {
  const [selectedTier, setSelectedTier] = useState(null);

  const handleSelect = (tier) => {
    setSelectedTier(tier);
    onSelectTier(tier);
  };

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-bold text-gray-900">Choose Your Tier</h3>
      <div className="grid md:grid-cols-3 gap-4">
        {pkg.pricing_tiers.map((tier, index) => (
          <Card
            key={index}
            onClick={() => handleSelect(tier)}
            className={`cursor-pointer transition-all duration-300 ${
              selectedTier?.tier_name === tier.tier_name
                ? 'border-2 border-purple-600 shadow-xl'
                : 'border hover:border-purple-300 hover:shadow-lg'
            }`}
          >
            <CardHeader className="text-center pb-3">
              <div className="flex justify-center mb-2">
                {index === pkg.pricing_tiers.length - 1 && (
                  <Badge className="bg-gradient-to-r from-yellow-500 to-amber-600">
                    <Sparkles className="w-3 h-3 mr-1" />
                    Best Value
                  </Badge>
                )}
              </div>
              <CardTitle className="text-2xl">{tier.tier_name}</CardTitle>
              <p className="text-3xl font-bold text-purple-600 mt-2">${tier.price.toFixed(2)}</p>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="text-center space-y-1">
                <p className="font-semibold">{tier.sessions_included} Sessions</p>
                <p className="text-sm text-gray-600">Valid for {tier.validity_days} days</p>
              </div>
              {tier.description && (
                <p className="text-sm text-gray-700 text-center">{tier.description}</p>
              )}
              {selectedTier?.tier_name === tier.tier_name && (
                <div className="flex items-center justify-center gap-2 text-green-700 font-medium">
                  <CheckCircle2 className="w-5 h-5" />
                  <span>Selected</span>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}