import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Sparkles, ArrowRight } from "lucide-react";

export default function WelcomeStep({ onNext, user }) {
  return (
    <div className="text-center space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-center">
        <div className="w-24 h-24 bg-purple-100 rounded-full flex items-center justify-center animate-bounce-slow">
          <Sparkles className="w-12 h-12 text-purple-600" />
        </div>
      </div>
      
      <div className="space-y-4">
        <h2 className="text-3xl font-bold text-gray-900">
          Welcome to Sacred Healing, {user?.full_name?.split(' ')[0] || 'Friend'}!
        </h2>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          We are honored to be part of your healing journey. This brief onboarding will help us tailor your experience and ensure we can support you fully.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto text-left">
        <Card className="bg-purple-50 border-purple-100">
          <CardContent className="pt-6">
            <h3 className="font-semibold text-purple-900 mb-2">Personalized Care</h3>
            <p className="text-sm text-purple-700">Tell us about your needs so we can match you with the right practitioners and services.</p>
          </CardContent>
        </Card>
        <Card className="bg-pink-50 border-pink-100">
          <CardContent className="pt-6">
            <h3 className="font-semibold text-pink-900 mb-2">Safe Space</h3>
            <p className="text-sm text-pink-700">Your information is secure and helps us create a safe, supportive environment for your healing.</p>
          </CardContent>
        </Card>
        <Card className="bg-amber-50 border-amber-100">
          <CardContent className="pt-6">
            <h3 className="font-semibold text-amber-900 mb-2">Journey Tracking</h3>
            <p className="text-sm text-amber-700">Set intentions and track your progress as you move through your healing path.</p>
          </CardContent>
        </Card>
      </div>

      <div className="pt-8">
        <Button 
          onClick={onNext} 
          size="lg" 
          className="bg-gradient-to-r from-purple-600 to-pink-600 text-lg px-8 py-6 rounded-full shadow-lg hover:shadow-xl transition-all"
        >
          Begin Your Journey <ArrowRight className="ml-2 w-5 h-5" />
        </Button>
      </div>
    </div>
  );
}