import React from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle2, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function CompletionStep() {
  return (
    <div className="text-center space-y-8 animate-in zoom-in duration-500">
      <div className="flex justify-center">
        <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center">
          <CheckCircle2 className="w-12 h-12 text-green-600" />
        </div>
      </div>
      
      <div className="space-y-4">
        <h2 className="text-3xl font-bold text-gray-900">
          You're All Set!
        </h2>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Your profile is live and you're ready to accept bookings.
        </p>
      </div>

      <div className="flex justify-center pt-8">
         <Link to={createPageUrl("PractitionerDashboard")}>
            <Button size="lg" className="bg-gradient-to-r from-purple-600 to-pink-600 text-lg px-8 py-6 rounded-full shadow-lg hover:shadow-xl transition-all">
                Go to Dashboard <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
         </Link>
      </div>
    </div>
  );
}