import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, ArrowLeft, DollarSign, CheckCircle2, AlertCircle, Building, Loader2 } from "lucide-react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";

export default function StripeStep({ practitioner, onNext, onBack }) {
  // Check Stripe Status
  const { data: stripeStatus, isLoading: statusLoading } = useQuery({
    queryKey: ['stripe-status', practitioner?.stripe_account_id],
    queryFn: async () => {
        if (!practitioner?.stripe_account_id) return null;
        const { data } = await base44.functions.invoke('stripeConnectManager', { 
            action: 'checkStatus', 
            stripeAccountId: practitioner.stripe_account_id 
        });
        return data;
    },
    enabled: !!practitioner?.stripe_account_id
  });

  const createAccountMutation = useMutation({
    mutationFn: async () => {
      const { data } = await base44.functions.invoke('stripeConnectManager', { 
          action: 'createAccount',
          origin: window.location.origin,
          returnUrl: `${window.location.origin}${window.location.pathname}`
      });
      return data;
    },
    onSuccess: (data) => {
      if (data.url) {
          window.location.href = data.url;
      }
    },
    onError: () => toast.error("Failed to start Stripe setup")
  });

  const isConnected = stripeStatus?.payouts_enabled;

  return (
    <div className="space-y-6 animate-in slide-in-from-right duration-500">
      <div className="bg-blue-50 border-l-4 border-blue-600 p-4 rounded">
        <div className="flex gap-3">
          <Building className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-gray-700">
            <p className="font-semibold mb-1">Set Up Payouts</p>
            <p>Connect your bank account via Stripe to receive payments for your services securely.</p>
          </div>
        </div>
      </div>

      <div className="max-w-md mx-auto">
        <Card className={`border-2 ${isConnected ? 'border-green-200' : 'border-purple-100'}`}>
            <CardHeader className="text-center">
                <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${isConnected ? 'bg-green-100' : 'bg-purple-100'}`}>
                    <DollarSign className={`w-8 h-8 ${isConnected ? 'text-green-600' : 'text-purple-600'}`} />
                </div>
                <CardTitle>Stripe Connect</CardTitle>
                <CardDescription>Secure payments & automated payouts</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                {statusLoading ? (
                    <div className="flex justify-center py-4">
                        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
                    </div>
                ) : isConnected ? (
                    <div className="text-center space-y-4">
                         <Badge className="bg-green-100 text-green-800 text-lg py-1 px-4">
                            <CheckCircle2 className="w-5 h-5 mr-2" /> Connected
                        </Badge>
                        <p className="text-sm text-gray-600">Your account is ready to receive payouts.</p>
                    </div>
                ) : (
                    <div className="space-y-4">
                        <Button 
                            onClick={() => createAccountMutation.mutate()}
                            disabled={createAccountMutation.isPending}
                            className="w-full bg-purple-600 hover:bg-purple-700 h-12 text-lg"
                        >
                            {createAccountMutation.isPending ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : null}
                            {practitioner?.stripe_account_id ? "Complete Stripe Setup" : "Connect Bank Account"}
                        </Button>
                        <p className="text-xs text-center text-gray-500">
                            You'll be redirected to Stripe to verify your identity and add bank details.
                        </p>
                    </div>
                )}
            </CardContent>
        </Card>
      </div>

      <div className="flex justify-between pt-6">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="mr-2 w-4 h-4" /> Back
        </Button>
        <Button 
            onClick={onNext} 
            className="bg-purple-600 hover:bg-purple-700"
        >
            {isConnected ? "Finish Setup" : "Skip for Now"} <ArrowRight className="ml-2 w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}