import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Sparkles, ArrowRight, Heart, DollarSign, Users } from "lucide-react";

export default function WelcomeStep({ onNext, user }) {
  return (
    <div className="text-center space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-center">
        <div className="w-24 h-24 bg-purple-100 rounded-full flex items-center justify-center animate-bounce-slow">
          <Sparkles className="w-12 h-12 text-purple-600" />
        </div>
      </div>
      
      <div className="space-y-4">
        <h2 className="text-3xl font-bold text-gray-900">
          Welcome to Your Practice, {user?.full_name?.split(' ')[0] || 'Healer'}!
        </h2>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          We're excited to help you share your gifts. Let's get your profile set up so you can start accepting clients and earning.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto text-left">
        <Card className="bg-purple-50 border-purple-100">
          <CardContent className="pt-6">
            <div className="bg-purple-100 w-10 h-10 rounded-full flex items-center justify-center mb-3">
              <Users className="w-5 h-5 text-purple-600" />
            </div>
            <h3 className="font-semibold text-purple-900 mb-2">Build Your Client Base</h3>
            <p className="text-sm text-purple-700">Create a professional profile that attracts clients looking for your specific healing modalities.</p>
          </CardContent>
        </Card>
        <Card className="bg-pink-50 border-pink-100">
          <CardContent className="pt-6">
            <div className="bg-pink-100 w-10 h-10 rounded-full flex items-center justify-center mb-3">
              <Heart className="w-5 h-5 text-pink-600" />
            </div>
            <h3 className="font-semibold text-pink-900 mb-2">Manage Services</h3>
            <p className="text-sm text-pink-700">Easily list your services, set prices, and manage your availability in one place.</p>
          </CardContent>
        </Card>
        <Card className="bg-green-50 border-green-100">
          <CardContent className="pt-6">
            <div className="bg-green-100 w-10 h-10 rounded-full flex items-center justify-center mb-3">
              <DollarSign className="w-5 h-5 text-green-600" />
            </div>
            <h3 className="font-semibold text-green-900 mb-2">Seamless Payments</h3>
            <p className="text-sm text-green-700">Connect Stripe to receive payouts directly to your bank account securely and quickly.</p>
          </CardContent>
        </Card>
      </div>

      <div className="pt-8">
        <Button 
          onClick={onNext} 
          size="lg" 
          className="bg-gradient-to-r from-purple-600 to-pink-600 text-lg px-8 py-6 rounded-full shadow-lg hover:shadow-xl transition-all"
        >
          Start Setup <ArrowRight className="ml-2 w-5 h-5" />
        </Button>
      </div>
    </div>
  );
}