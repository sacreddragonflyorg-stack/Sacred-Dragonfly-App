import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowRight, Info } from "lucide-react";

export default function ProfileStep({ profileData, setProfileData, agreementAccepted, setAgreementAccepted, onNext }) {
  const isValid = profileData.full_name && profileData.bio && agreementAccepted;

  return (
    <div className="space-y-6 animate-in slide-in-from-right duration-500">
      <div className="bg-purple-50 border-l-4 border-purple-600 p-4 rounded">
        <div className="flex gap-3">
          <Info className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-gray-700">
            <p className="font-semibold mb-1">Create Your Healing Identity</p>
            <p>Share your background, experience, and what makes your healing approach unique.</p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
                <Label htmlFor="full_name">Full Name *</Label>
                <Input
                    id="full_name"
                    value={profileData.full_name}
                    onChange={(e) => setProfileData(prev => ({ ...prev, full_name: e.target.value }))}
                    placeholder="Your professional name"
                    required
                />
            </div>
             <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                    id="phone"
                    type="tel"
                    value={profileData.phone}
                    onChange={(e) => setProfileData(prev => ({ ...prev, phone: e.target.value }))}
                    placeholder="+1 (555) 123-4567"
                />
            </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="tagline">Professional Tagline</Label>
          <Input
            id="tagline"
            value={profileData.tagline}
            onChange={(e) => setProfileData(prev => ({ ...prev, tagline: e.target.value }))}
            placeholder="E.g., 'Transforming Lives Through Energy Healing'"
            maxLength={100}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="bio">Professional Bio *</Label>
          <Textarea
            id="bio"
            value={profileData.bio}
            onChange={(e) => setProfileData(prev => ({ ...prev, bio: e.target.value }))}
            placeholder="Share your healing philosophy, journey, and experience..."
            rows={6}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="specialties">Specialties & Modalities</Label>
          <Textarea
            id="specialties"
            value={profileData.specialties}
            onChange={(e) => setProfileData(prev => ({ ...prev, specialties: e.target.value }))}
            placeholder="E.g., Reiki Master, Tarot Reader, Crystal Healing..."
            rows={3}
          />
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="certifications">Certifications</Label>
            <Input
              id="certifications"
              value={profileData.certifications}
              onChange={(e) => setProfileData(prev => ({ ...prev, certifications: e.target.value }))}
              placeholder="List your credentials"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="years_experience">Years of Experience</Label>
            <Input
              id="years_experience"
              type="number"
              value={profileData.years_experience}
              onChange={(e) => setProfileData(prev => ({ ...prev, years_experience: e.target.value }))}
              placeholder="e.g., 10"
            />
          </div>
        </div>

        <div className="pt-6 border-t">
            <div className="flex items-start gap-2 bg-gray-50 p-4 rounded border">
                <input
                    type="checkbox"
                    id="agreement"
                    checked={agreementAccepted}
                    onChange={(e) => setAgreementAccepted(e.target.checked)}
                    className="mt-1"
                />
                <label htmlFor="agreement" className="text-sm text-gray-700 cursor-pointer">
                    I agree to act as a <strong>Subcontractor</strong> for Sacred Healing. I understand that I am an independent contractor and not an employee.
                </label>
            </div>
        </div>
      </div>

      <div className="flex justify-end pt-4">
        <Button 
          onClick={onNext} 
          disabled={!isValid}
          className="bg-purple-600 hover:bg-purple-700"
        >
          Next: Services <ArrowRight className="ml-2 w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}