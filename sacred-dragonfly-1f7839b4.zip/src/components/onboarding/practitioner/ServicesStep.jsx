import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowRight, ArrowLeft, Sparkles } from "lucide-react";

export default function ServicesStep({ serviceData, setServiceData, onNext, onBack }) {
  const isValid = serviceData.name && serviceData.description && (serviceData.price || serviceData.pricing_model === 'energy_exchange');

  const paymentMethods = [
    { value: 'credit_card', label: 'Credit Card (Stripe)' },
    { value: 'paypal', label: 'PayPal' },
    { value: 'venmo', label: 'Venmo' },
    { value: 'cashapp', label: 'Cash App' },
    { value: 'chime_bank', label: 'Chime Bank' },
    { value: 'dave_bank', label: 'Dave Bank' },
    { value: 'one_bank', label: 'One Bank' },
    { value: 'google_pay', label: 'Google Pay' },
    { value: 'bank_transfer', label: 'Bank Transfer' },
    { value: 'cash', label: 'Cash' }
  ];

  return (
    <div className="space-y-6 animate-in slide-in-from-right duration-500">
      <div className="bg-pink-50 border-l-4 border-pink-600 p-4 rounded">
        <div className="flex gap-3">
          <Sparkles className="w-5 h-5 text-pink-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-gray-700">
            <p className="font-semibold mb-1">Create Your First Service</p>
            <p>Define what you offer, your pricing model, and accepted payment methods. You can add more later.</p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="service_name">Service Name *</Label>
          <Input
            id="service_name"
            value={serviceData.name}
            onChange={(e) => setServiceData(prev => ({ ...prev, name: e.target.value }))}
            placeholder="E.g., Distance Reiki Healing Session"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="service_description">Description *</Label>
          <Textarea
            id="service_description"
            value={serviceData.description}
            onChange={(e) => setServiceData(prev => ({ ...prev, description: e.target.value }))}
            placeholder="Describe what clients can expect..."
            rows={4}
            required
          />
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="service_type">Service Type</Label>
            <Select 
              value={serviceData.type} 
              onValueChange={(val) => setServiceData(prev => ({ ...prev, type: val }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="energy_healing">Energy Healing</SelectItem>
                <SelectItem value="reiki_healing">Reiki Healing</SelectItem>
                <SelectItem value="tarot_reading">Tarot Reading</SelectItem>
                <SelectItem value="chakra_balancing">Chakra Balancing</SelectItem>
                <SelectItem value="crystal_healing">Crystal Healing</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="duration">Duration (minutes) *</Label>
            <Input
              id="duration"
              type="number"
              value={serviceData.duration_minutes}
              onChange={(e) => setServiceData(prev => ({ ...prev, duration_minutes: parseInt(e.target.value) || 0 }))}
              required
            />
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="pricing_model">Pricing Model</Label>
            <Select 
              value={serviceData.pricing_model} 
              onValueChange={(val) => setServiceData(prev => ({ ...prev, pricing_model: val }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="fixed">Fixed Price</SelectItem>
                <SelectItem value="sliding_scale">Sliding Scale</SelectItem>
                <SelectItem value="donation">Donation Based</SelectItem>
                <SelectItem value="energy_exchange">Energy Exchange</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {serviceData.pricing_model !== 'energy_exchange' && (
            <div className="space-y-2">
              <Label htmlFor="price">Price (USD) *</Label>
              <Input
                id="price"
                type="number"
                step="0.01"
                value={serviceData.price}
                onChange={(e) => setServiceData(prev => ({ ...prev, price: parseFloat(e.target.value) || 0 }))}
                placeholder="0.00"
                required
              />
            </div>
          )}
        </div>

        <div className="space-y-2">
            <Label>Accepted Payment Methods</Label>
            <div className="grid grid-cols-2 gap-2 border p-3 rounded-lg bg-gray-50/50">
            {paymentMethods.map((method) => (
                <div key={method.value} className="flex items-center space-x-2">
                <Checkbox 
                    id={`pm-${method.value}`}
                    checked={serviceData.payment_methods?.includes(method.value)}
                    onCheckedChange={(checked) => {
                    const current = serviceData.payment_methods || [];
                    setServiceData(prev => ({
                        ...prev,
                        payment_methods: checked ? [...current, method.value] : current.filter(m => m !== method.value)
                    }));
                    }}
                />
                <label htmlFor={`pm-${method.value}`} className="text-sm cursor-pointer">
                    {method.label}
                </label>
                </div>
            ))}
            </div>
        </div>

      </div>

      <div className="flex justify-between pt-6">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="mr-2 w-4 h-4" /> Back
        </Button>
        <Button 
          onClick={onNext} 
          disabled={!isValid}
          className="bg-purple-600 hover:bg-purple-700"
        >
          Next: Availability <ArrowRight className="ml-2 w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}