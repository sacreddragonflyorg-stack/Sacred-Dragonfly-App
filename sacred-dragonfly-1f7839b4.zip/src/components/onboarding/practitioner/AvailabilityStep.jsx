import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar, ArrowRight, ArrowLeft } from "lucide-react";

export default function AvailabilityStep({ availability, setAvailability, onNext, onBack }) {
  const DAYS_OF_WEEK = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

  const handleDayToggle = (day) => {
    setAvailability(prev => ({
      ...prev,
      [day]: { ...prev[day], enabled: !prev[day]?.enabled }
    }));
  };

  const handleTimeChange = (day, type, value) => {
    setAvailability(prev => ({
      ...prev,
      [day]: { ...prev[day], [type]: value }
    }));
  };

  return (
    <div className="space-y-6 animate-in slide-in-from-right duration-500">
      <div className="bg-green-50 border-l-4 border-green-600 p-4 rounded">
        <div className="flex gap-3">
          <Calendar className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-gray-700">
            <p className="font-semibold mb-1">Set Your Weekly Schedule</p>
            <p>Define when you're typically available for healing sessions. You can adjust this later.</p>
          </div>
        </div>
      </div>

      <div className="space-y-2 bg-white rounded-lg border p-4">
        {DAYS_OF_WEEK.map((day) => (
          <div key={day} className="flex items-center gap-4 p-3 border-b last:border-0 hover:bg-gray-50 rounded-lg transition-colors">
            <div className="flex items-center gap-3 w-32">
              <Checkbox
                id={`day-${day}`}
                checked={availability[day]?.enabled || false}
                onCheckedChange={() => handleDayToggle(day)}
              />
              <label htmlFor={`day-${day}`} className="font-medium capitalize cursor-pointer">{day}</label>
            </div>
            {availability[day]?.enabled ? (
              <div className="flex items-center gap-3 flex-1">
                <Input
                  type="time"
                  value={availability[day]?.start || '09:00'}
                  onChange={(e) => handleTimeChange(day, 'start', e.target.value)}
                  className="w-32"
                />
                <span className="text-gray-500 font-medium text-sm">to</span>
                <Input
                  type="time"
                  value={availability[day]?.end || '17:00'}
                  onChange={(e) => handleTimeChange(day, 'end', e.target.value)}
                  className="w-32"
                />
              </div>
            ) : (
              <span className="text-gray-400 text-sm italic ml-4">Unavailable</span>
            )}
          </div>
        ))}
      </div>

      <div className="flex justify-between pt-6">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="mr-2 w-4 h-4" /> Back
        </Button>
        <Button 
          onClick={onNext} 
          className="bg-purple-600 hover:bg-purple-700"
        >
          Next: Payouts <ArrowRight className="ml-2 w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}