import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowRight, ArrowLeft } from "lucide-react";

export default function HealthIntakeStep({ formData, updateFormData, onNext, onBack }) {
  const handleChange = (field, value) => {
    updateFormData({ [field]: value });
  };

  return (
    <div className="space-y-6 animate-in slide-in-from-right duration-500">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900">Health & Intentions</h2>
        <p className="text-gray-600">Help us understand your needs and goals</p>
      </div>

      <div className="space-y-6 max-w-2xl mx-auto">
        <div className="space-y-2">
          <Label htmlFor="healing_intentions" className="text-lg text-purple-900">
            What are your main intentions for seeking healing?
          </Label>
          <Textarea
            id="healing_intentions"
            value={formData.healing_intentions || ''}
            onChange={(e) => handleChange('healing_intentions', e.target.value)}
            placeholder="e.g., Reducing stress, emotional balance, physical pain relief, spiritual growth..."
            rows={4}
            className="bg-white"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="medical_conditions">Medical Conditions (Optional)</Label>
          <p className="text-xs text-gray-500">Please list any relevant medical conditions we should be aware of.</p>
          <Textarea
            id="medical_conditions"
            value={formData.medical_conditions || ''}
            onChange={(e) => handleChange('medical_conditions', e.target.value)}
            rows={2}
          />
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="current_medications">Current Medications</Label>
            <Input
              id="current_medications"
              value={formData.current_medications || ''}
              onChange={(e) => handleChange('current_medications', e.target.value)}
              placeholder="List any medications"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="allergies">Allergies</Label>
            <Input
              id="allergies"
              value={formData.allergies || ''}
              onChange={(e) => handleChange('allergies', e.target.value)}
              placeholder="Any known allergies"
            />
          </div>
        </div>

        <div className="pt-4 border-t">
          <h3 className="font-semibold mb-3">Emergency Contact (Optional)</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Name</Label>
              <Input
                value={formData.emergency_contact_name || ''}
                onChange={(e) => handleChange('emergency_contact_name', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Phone</Label>
              <Input
                value={formData.emergency_contact_phone || ''}
                onChange={(e) => handleChange('emergency_contact_phone', e.target.value)}
              />
            </div>
          </div>
        </div>

        <div className="flex justify-between pt-6">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="mr-2 w-4 h-4" /> Back
          </Button>
          <Button 
            onClick={onNext}
            className="bg-purple-600 hover:bg-purple-700"
          >
            Continue <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}