import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, ArrowLeft, Heart, Shield, Clock, Smile } from "lucide-react";

export default function ExpectationsStep({ onNext, onBack }) {
  return (
    <div className="space-y-6 animate-in slide-in-from-right duration-500">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900">What to Expect</h2>
        <p className="text-gray-600">Setting the stage for your healing journey</p>
      </div>

      <div className="max-w-3xl mx-auto grid md:grid-cols-2 gap-6">
        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="pt-6">
            <div className="w-10 h-10 bg-pink-100 rounded-full flex items-center justify-center mb-4">
              <Heart className="w-5 h-5 text-pink-600" />
            </div>
            <h3 className="font-semibold text-lg mb-2">Safe & Supportive</h3>
            <p className="text-gray-600 text-sm">
              Our sessions are held in a non-judgmental, confidential space. Your comfort and safety are our top priorities.
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="pt-6">
            <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center mb-4">
              <Shield className="w-5 h-5 text-purple-600" />
            </div>
            <h3 className="font-semibold text-lg mb-2">Energy & Emotion</h3>
            <p className="text-gray-600 text-sm">
              You may experience physical sensations or emotional releases. This is normal and part of the healing process.
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="pt-6">
            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mb-4">
              <Clock className="w-5 h-5 text-blue-600" />
            </div>
            <h3 className="font-semibold text-lg mb-2">Time for Integration</h3>
            <p className="text-gray-600 text-sm">
              Healing often continues after the session. We recommend rest and hydration to allow the energy to integrate.
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="pt-6">
            <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center mb-4">
              <Smile className="w-5 h-5 text-amber-600" />
            </div>
            <h3 className="font-semibold text-lg mb-2">Open Communication</h3>
            <p className="text-gray-600 text-sm">
              Feel free to ask questions or share feedback at any time. This is your journey, and we are here to guide you.
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="max-w-2xl mx-auto bg-gray-50 p-4 rounded-lg border text-sm text-gray-700 text-center">
        By continuing, you acknowledge that our services are complementary holistic practices and do not replace professional medical advice or treatment.
      </div>

      <div className="flex justify-between pt-6 max-w-2xl mx-auto">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="mr-2 w-4 h-4" /> Back
        </Button>
        <Button 
          onClick={onNext}
          className="bg-purple-600 hover:bg-purple-700"
        >
          I Understand & Agree <ArrowRight className="ml-2 w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}