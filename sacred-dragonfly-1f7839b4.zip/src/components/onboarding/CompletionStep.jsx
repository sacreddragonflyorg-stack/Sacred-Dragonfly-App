import React from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Calendar, BookOpen, LayoutDashboard } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function CompletionStep({ user }) {
  return (
    <div className="text-center space-y-8 animate-in zoom-in duration-500">
      <div className="flex justify-center">
        <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center">
          <CheckCircle2 className="w-12 h-12 text-green-600" />
        </div>
      </div>
      
      <div className="space-y-4">
        <h2 className="text-3xl font-bold text-gray-900">
          You're All Set!
        </h2>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Thank you for completing your profile. Your healing journey begins now.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
        <Link to={createPageUrl("Booking")} className="block">
          <div className="bg-white p-6 rounded-xl border-2 border-transparent hover:border-purple-300 hover:shadow-lg transition-all group h-full">
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mb-4 mx-auto group-hover:scale-110 transition-transform">
              <Calendar className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="font-semibold text-lg mb-2">Book a Session</h3>
            <p className="text-sm text-gray-600">Schedule your first healing session with one of our practitioners.</p>
          </div>
        </Link>

        <Link to={createPageUrl("LearningCenter")} className="block">
          <div className="bg-white p-6 rounded-xl border-2 border-transparent hover:border-pink-300 hover:shadow-lg transition-all group h-full">
            <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center mb-4 mx-auto group-hover:scale-110 transition-transform">
              <BookOpen className="w-6 h-6 text-pink-600" />
            </div>
            <h3 className="font-semibold text-lg mb-2">Explore Learning</h3>
            <p className="text-sm text-gray-600">Discover courses and resources to support your growth.</p>
          </div>
        </Link>

        <Link to={createPageUrl("ClientDashboard")} className="block">
          <div className="bg-white p-6 rounded-xl border-2 border-transparent hover:border-amber-300 hover:shadow-lg transition-all group h-full">
            <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mb-4 mx-auto group-hover:scale-110 transition-transform">
              <LayoutDashboard className="w-6 h-6 text-amber-600" />
            </div>
            <h3 className="font-semibold text-lg mb-2">Go to Dashboard</h3>
            <p className="text-sm text-gray-600">View your overview, upcoming appointments, and progress.</p>
          </div>
        </Link>
      </div>
    </div>
  );
}