import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowRight, ArrowLeft } from "lucide-react";

export default function PersonalDetailsStep({ formData, updateFormData, onNext, onBack }) {
  const handleChange = (field, value) => {
    updateFormData({ [field]: value });
  };

  const isValid = formData.full_name && formData.phone;

  return (
    <div className="space-y-6 animate-in slide-in-from-right duration-500">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900">Personal Details</h2>
        <p className="text-gray-600">Let's get to know you better</p>
      </div>

      <div className="space-y-4 max-w-2xl mx-auto">
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="full_name">Full Name *</Label>
            <Input
              id="full_name"
              value={formData.full_name || ''}
              onChange={(e) => handleChange('full_name', e.target.value)}
              placeholder="Your name"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="date_of_birth">Date of Birth</Label>
            <Input
              id="date_of_birth"
              type="date"
              value={formData.date_of_birth || ''}
              onChange={(e) => handleChange('date_of_birth', e.target.value)}
            />
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="phone">Phone Number *</Label>
            <Input
              id="phone"
              type="tel"
              value={formData.phone || ''}
              onChange={(e) => handleChange('phone', e.target.value)}
              placeholder="+1 (555) 000-0000"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="preferred_contact">Preferred Contact Method</Label>
            <Select 
              value={formData.preferred_contact_method || 'email'} 
              onValueChange={(val) => handleChange('preferred_contact_method', val)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select method" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="email">Email</SelectItem>
                <SelectItem value="phone">Phone Call</SelectItem>
                <SelectItem value="text">Text Message</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2 pt-4 border-t">
          <Label>Address (Optional)</Label>
          <Input
            value={formData.address_street || ''}
            onChange={(e) => handleChange('address_street', e.target.value)}
            placeholder="Street Address"
            className="mb-2"
          />
          <div className="grid grid-cols-2 gap-2">
            <Input
              value={formData.address_city || ''}
              onChange={(e) => handleChange('address_city', e.target.value)}
              placeholder="City"
            />
            <Input
              value={formData.address_state || ''}
              onChange={(e) => handleChange('address_state', e.target.value)}
              placeholder="State/Province"
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Input
              value={formData.address_zip || ''}
              onChange={(e) => handleChange('address_zip', e.target.value)}
              placeholder="ZIP/Postal Code"
            />
            <Input
              value={formData.address_country || ''}
              onChange={(e) => handleChange('address_country', e.target.value)}
              placeholder="Country"
            />
          </div>
        </div>

        <div className="flex justify-between pt-6">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="mr-2 w-4 h-4" /> Back
          </Button>
          <Button 
            onClick={onNext} 
            disabled={!isValid}
            className="bg-purple-600 hover:bg-purple-700"
          >
            Continue <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}