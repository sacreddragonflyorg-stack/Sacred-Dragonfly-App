import React, { useEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Video, VideoOff, Mic, MicOff, PhoneOff, Maximize2, Minimize2 } from "lucide-react";

export default function VideoCall({ roomName, displayName, onEnd, sessionData }) {
  const jitsiContainerRef = useRef(null);
  const [api, setApi] = useState(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);

  useEffect(() => {
    if (!window.JitsiMeetExternalAPI) {
      const script = document.createElement('script');
      script.src = 'https://meet.jit.si/external_api.js';
      script.async = true;
      script.onload = () => initJitsi();
      document.body.appendChild(script);
    } else {
      initJitsi();
    }

    return () => {
      if (api) {
        api.dispose();
      }
    };
  }, []);

  const initJitsi = () => {
    const domain = 'meet.jit.si';
    const options = {
      roomName: roomName,
      width: '100%',
      height: '100%',
      parentNode: jitsiContainerRef.current,
      userInfo: {
        displayName: displayName
      },
      configOverwrite: {
        startWithAudioMuted: false,
        startWithVideoMuted: false,
        enableWelcomePage: false,
        prejoinPageEnabled: false,
        disableDeepLinking: true,
      },
      interfaceConfigOverwrite: {
        TOOLBAR_BUTTONS: [
          'microphone', 'camera', 'closedcaptions', 'desktop', 'fullscreen',
          'fodeviceselection', 'hangup', 'chat', 'recording',
          'livestreaming', 'etherpad', 'settings', 'raisehand',
          'videoquality', 'filmstrip', 'feedback', 'stats', 'shortcuts',
          'tileview', 'download', 'help', 'mute-everyone'
        ],
      }
    };

    const jitsiApi = new window.JitsiMeetExternalAPI(domain, options);
    setApi(jitsiApi);

    jitsiApi.addEventListener('audioMuteStatusChanged', ({ muted }) => {
      setIsMuted(muted);
    });

    jitsiApi.addEventListener('videoMuteStatusChanged', ({ muted }) => {
      setIsVideoOff(muted);
    });

    jitsiApi.addEventListener('readyToClose', () => {
      if (onEnd) onEnd();
    });
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      jitsiContainerRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const toggleAudio = () => {
    if (api) {
      api.executeCommand('toggleAudio');
    }
  };

  const toggleVideo = () => {
    if (api) {
      api.executeCommand('toggleVideo');
    }
  };

  const endCall = () => {
    if (api) {
      api.executeCommand('hangup');
    }
    if (onEnd) onEnd();
  };

  return (
    <div className="flex flex-col h-full">
      {/* Session Info Bar */}
      {sessionData && (
        <Card className="mb-4 bg-gradient-to-r from-purple-50 to-pink-50">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-gray-900">{sessionData.service_name}</p>
                <p className="text-sm text-gray-600">with {sessionData.client_name}</p>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                <span className="text-sm font-medium text-gray-700">Live Session</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Video Container */}
      <Card className="flex-1 overflow-hidden">
        <CardContent className="p-0 h-full relative">
          <div ref={jitsiContainerRef} className="w-full h-full bg-gray-900" />
          
          {/* Custom Control Bar */}
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-gray-800/90 backdrop-blur-sm rounded-full px-6 py-3 flex items-center gap-4">
            <Button
              size="icon"
              variant="ghost"
              onClick={toggleAudio}
              className={`rounded-full ${isMuted ? 'bg-red-500 hover:bg-red-600' : 'hover:bg-gray-700'} text-white`}
            >
              {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </Button>

            <Button
              size="icon"
              variant="ghost"
              onClick={toggleVideo}
              className={`rounded-full ${isVideoOff ? 'bg-red-500 hover:bg-red-600' : 'hover:bg-gray-700'} text-white`}
            >
              {isVideoOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
            </Button>

            <Button
              size="icon"
              onClick={endCall}
              className="rounded-full bg-red-500 hover:bg-red-600 text-white"
            >
              <PhoneOff className="w-5 h-5" />
            </Button>

            <Button
              size="icon"
              variant="ghost"
              onClick={toggleFullscreen}
              className="rounded-full hover:bg-gray-700 text-white"
            >
              {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}