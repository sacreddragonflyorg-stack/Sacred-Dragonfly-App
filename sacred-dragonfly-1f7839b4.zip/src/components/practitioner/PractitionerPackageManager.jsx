import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Plus, Edit, Trash2, Package, Check, X, Info } from "lucide-react";
import { toast } from "sonner";

export default function PractitionerPackageManager({ user }) {
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingPackage, setEditingPackage] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    package_type: "one_time",
    subscription_interval: "monthly",
    subscription_sessions_per_interval: 1,
    auto_renew: true,
    price: "",
    validity_days: 90,
    service_selections: [] // [{ service_id: "...", count: 1 }]
  });

  // Fetch Practitioner's Services
  const { data: services = [] } = useQuery({
    queryKey: ['my-services', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      // Assuming services are linked by practitioner_email or created_by
      const allServices = await base44.entities.Service.filter({});
      return allServices.filter(s => s.practitioner_email === user.email || s.created_by === user.email);
    },
    enabled: !!user?.email
  });

  // Fetch Practitioner's Packages
  const { data: packages = [], isLoading } = useQuery({
    queryKey: ['my-packages', user?.email],
    queryFn: () => user ? base44.entities.ServicePackage.filter({ practitioner_email: user.email }) : [],
    enabled: !!user?.email
  });

  const savePackageMutation = useMutation({
    mutationFn: async (data) => {
      // Calculate total value and construct payload
      let totalValue = 0;
      let totalSessions = 0;
      const serviceIds = [];
      const serviceNames = [];
      const serviceConfigs = [];

      data.service_selections.forEach(sel => {
        const service = services.find(s => s.id === sel.service_id);
        if (service) {
          totalValue += (service.price || 0) * sel.count;
          totalSessions += sel.count;
          for (let i = 0; i < sel.count; i++) {
            serviceIds.push(service.id);
            serviceNames.push(service.name);
            serviceConfigs.push({
              service_id: service.id,
              service_name: service.name,
              session_count: 1, // Individual session config
              custom_duration_minutes: service.duration_minutes
            });
          }
        }
      });

      const payload = {
        name: data.name,
        description: data.description,
        practitioner_email: user.email,
        package_type: data.package_type,
        package_price: parseFloat(data.price),
        regular_price: totalValue,
        savings: totalValue - parseFloat(data.price),
        total_sessions: data.package_type === 'subscription' ? parseInt(data.subscription_sessions_per_interval) : totalSessions,
        subscription_interval: data.package_type === 'subscription' ? data.subscription_interval : null,
        subscription_sessions_per_interval: data.package_type === 'subscription' ? parseInt(data.subscription_sessions_per_interval) : null,
        auto_renew: data.package_type === 'subscription' ? data.auto_renew : null,
        validity_days: parseInt(data.validity_days),
        service_ids: serviceIds,
        service_names: serviceNames,
        // Collapsing configs for storage if needed, but individual items work for mapping
        service_configs: data.service_selections.map(sel => ({
            service_id: sel.service_id,
            service_name: services.find(s => s.id === sel.service_id)?.name,
            session_count: sel.count
        })), 
        is_active: true
      };

      if (editingPackage) {
        return base44.entities.ServicePackage.update(editingPackage.id, payload);
      }
      return base44.entities.ServicePackage.create(payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['my-packages']);
      setIsDialogOpen(false);
      resetForm();
      toast.success(editingPackage ? "Package updated successfully" : "Package created successfully");
    },
    onError: (err) => toast.error("Failed to save package: " + err.message)
  });

  const deletePackageMutation = useMutation({
    mutationFn: (id) => base44.entities.ServicePackage.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['my-packages']);
      toast.success("Package deleted");
    }
  });

  const handleEdit = (pkg) => {
    setEditingPackage(pkg);
    // Reconstruct service selections from configs or ids
    // Using service_configs if available, else infer from counts
    const selections = pkg.service_configs ? pkg.service_configs.map(c => ({
        service_id: c.service_id,
        count: c.session_count || 1
    })) : [];

    setFormData({
      name: pkg.name,
      description: pkg.description,
      package_type: pkg.package_type || "one_time",
      subscription_interval: pkg.subscription_interval || "monthly",
      subscription_sessions_per_interval: pkg.subscription_sessions_per_interval || 1,
      auto_renew: pkg.auto_renew !== false,
      price: pkg.package_price,
      validity_days: pkg.validity_days,
      service_selections: selections
    });
    setIsDialogOpen(true);
  };

  const resetForm = () => {
    setEditingPackage(null);
    setFormData({
      name: "",
      description: "",
      package_type: "one_time",
      subscription_interval: "monthly",
      subscription_sessions_per_interval: 1,
      auto_renew: true,
      price: "",
      validity_days: 90,
      service_selections: []
    });
  };

  const handleServiceSelectionChange = (serviceId, count) => {
    setFormData(prev => {
      const existing = prev.service_selections.find(s => s.service_id === serviceId);
      let newSelections;
      if (count <= 0) {
        newSelections = prev.service_selections.filter(s => s.service_id !== serviceId);
      } else {
        if (existing) {
          newSelections = prev.service_selections.map(s => s.service_id === serviceId ? { ...s, count } : s);
        } else {
          newSelections = [...prev.service_selections, { service_id: serviceId, count }];
        }
      }
      return { ...prev, service_selections: newSelections };
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold">My Service Packages</h2>
          <p className="text-gray-500">Bundle services to encourage client commitment</p>
        </div>
        <Button onClick={() => { resetForm(); setIsDialogOpen(true); }} className="bg-purple-600">
          <Plus className="w-4 h-4 mr-2" /> Create Package
        </Button>
      </div>

      {isLoading ? (
        <div className="text-center py-8">Loading packages...</div>
      ) : packages.length === 0 ? (
        <Card className="border-dashed border-2 bg-gray-50/50">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Package className="w-12 h-12 text-gray-300 mb-4" />
            <p className="text-gray-500 font-medium">No packages created yet</p>
            <p className="text-gray-400 text-sm mb-4">Create bundles like "5 Session Pack" to increase retention</p>
            <Button variant="outline" onClick={() => { resetForm(); setIsDialogOpen(true); }}>
              Create Your First Package
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 gap-6">
          {packages.map(pkg => (
            <Card key={pkg.id} className="relative group">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{pkg.name}</CardTitle>
                    <CardDescription className="line-clamp-2 mt-1">{pkg.description}</CardDescription>
                  </div>
                  <Badge variant={pkg.is_active ? "default" : "secondary"}>
                    {pkg.is_active ? "Active" : "Draft"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Price:</span>
                  <span className="font-bold text-purple-700">${pkg.package_price}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Value:</span>
                  <span className="text-gray-700 line-through">${pkg.regular_price}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Sessions:</span>
                  <span className="font-medium">{pkg.total_sessions}</span>
                </div>
                <div className="text-xs text-gray-500 bg-gray-50 p-2 rounded mt-2">
                  <span className="font-semibold">Includes: </span>
                  {pkg.service_names?.join(", ")}
                </div>
              </CardContent>
              <CardFooter className="border-t pt-4 flex justify-end gap-2">
                <Button variant="ghost" size="sm" onClick={() => handleEdit(pkg)}>
                  <Edit className="w-4 h-4 mr-2" /> Edit
                </Button>
                <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-600" onClick={() => {
                    if(confirm("Delete this package?")) deletePackageMutation.mutate(pkg.id);
                }}>
                  <Trash2 className="w-4 h-4 mr-2" /> Delete
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingPackage ? "Edit Package" : "Create New Package"}</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Package Name</Label>
                <Input 
                  value={formData.name} 
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  placeholder="e.g., Healing Journey Pack"
                />
              </div>
              <div className="space-y-2">
                <Label>Type</Label>
                <Select 
                    value={formData.package_type} 
                    onValueChange={v => setFormData({...formData, package_type: v})}
                >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="one_time">One-Time Bundle</SelectItem>
                        <SelectItem value="subscription">Recurring Subscription</SelectItem>
                    </SelectContent>
                </Select>
              </div>

              {formData.package_type === 'subscription' ? (
                  <>
                      <div className="space-y-2">
                        <Label>Billing Interval</Label>
                        <Select 
                            value={formData.subscription_interval} 
                            onValueChange={v => setFormData({...formData, subscription_interval: v})}
                        >
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="weekly">Weekly</SelectItem>
                                <SelectItem value="monthly">Monthly</SelectItem>
                                <SelectItem value="quarterly">Quarterly</SelectItem>
                                <SelectItem value="yearly">Yearly</SelectItem>
                            </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Sessions per Interval</Label>
                        <Input 
                          type="number"
                          value={formData.subscription_sessions_per_interval} 
                          onChange={e => setFormData({...formData, subscription_sessions_per_interval: e.target.value})}
                        />
                      </div>
                      <div className="space-y-2 flex items-center gap-2 pt-6">
                        <Switch 
                            checked={formData.auto_renew} 
                            onCheckedChange={c => setFormData({...formData, auto_renew: c})}
                        />
                        <Label>Auto-renew by default</Label>
                      </div>
                  </>
              ) : (
                  <div className="space-y-2">
                    <Label>Validity (Days)</Label>
                    <Input 
                      type="number"
                      value={formData.validity_days} 
                      onChange={e => setFormData({...formData, validity_days: e.target.value})}
                    />
                  </div>
              )}
            </div>

            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea 
                value={formData.description}
                onChange={e => setFormData({...formData, description: e.target.value})}
                placeholder="Describe the benefits of this package..."
              />
            </div>

            <div className="space-y-4 border rounded-lg p-4 bg-gray-50">
              <Label className="flex items-center gap-2">
                <Package className="w-4 h-4" /> Include Services
              </Label>
              
              {services.length === 0 ? (
                <p className="text-sm text-red-500">You need to create services before creating a package.</p>
              ) : (
                <div className="space-y-3">
                  {services.map(service => {
                    const selection = formData.service_selections.find(s => s.service_id === service.id);
                    const count = selection ? selection.count : 0;
                    
                    return (
                      <div key={service.id} className="flex items-center justify-between bg-white p-2 rounded border">
                        <div className="text-sm">
                          <p className="font-medium">{service.name}</p>
                          <p className="text-gray-500">${service.price} / session</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button 
                            variant="outline" size="icon" className="h-8 w-8"
                            onClick={() => handleServiceSelectionChange(service.id, count - 1)}
                            disabled={count <= 0}
                          >
                            -
                          </Button>
                          <span className="w-8 text-center font-medium">{count}</span>
                          <Button 
                            variant="outline" size="icon" className="h-8 w-8"
                            onClick={() => handleServiceSelectionChange(service.id, count + 1)}
                          >
                            +
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                  {formData.package_type === 'subscription' && (
                      <p className="text-xs text-gray-500 italic mt-2">
                          Note: For subscriptions, selected services will be available each billing cycle.
                          Ensure "Sessions per Interval" matches the total services selected if they are meant to be used up.
                      </p>
                  )}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label>Package Price ($)</Label>
              <div className="flex gap-4 items-center">
                <Input 
                  type="number"
                  value={formData.price}
                  onChange={e => setFormData({...formData, price: e.target.value})}
                  placeholder="0.00"
                  className="text-lg font-bold"
                />
                <div className="text-sm text-gray-500">
                  Calculated Value: <span className="font-semibold text-gray-900">
                    ${formData.service_selections.reduce((acc, sel) => {
                      const s = services.find(srv => srv.id === sel.service_id);
                      return acc + ((s?.price || 0) * sel.count);
                    }, 0).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
            <Button 
              onClick={() => savePackageMutation.mutate(formData)}
              disabled={savePackageMutation.isPending || !formData.name || !formData.price || formData.service_selections.length === 0}
              className="bg-purple-600"
            >
              {savePackageMutation.isPending ? "Saving..." : "Save Package"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}