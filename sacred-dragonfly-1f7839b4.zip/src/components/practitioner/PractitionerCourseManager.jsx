import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Edit, Trash2, X, ChevronRight, ChevronDown, Sparkles, BookOpen, Lightbulb } from "lucide-react";
import { toast } from "sonner";
import AIContentGenerator from "../dashboard/AIContentGenerator";
import QuizManager from "../cms/QuizManager";

export default function PractitionerCourseManager() {
  const [expandedCourse, setExpandedCourse] = useState(null);
  const [showCourseForm, setShowCourseForm] = useState(false);
  const [showModuleForm, setShowModuleForm] = useState(false);
  const [editingCourse, setEditingCourse] = useState(null);
  const [editingModule, setEditingModule] = useState(null);

  const [courseForm, setCourseForm] = useState({
    title: "", description: "", category: "meditation", 
    difficulty_level: "beginner", estimated_hours: 1, 
    points_reward: 100, is_premium: false, points_required: 0, image_url: "",
    tags: []
  });

  const [moduleForm, setModuleForm] = useState({
    title: "", description: "", content: "", 
    video_url: "", duration_minutes: 15, points_reward: 10
  });

  const queryClient = useQueryClient();

  // Queries
  const { data: courses = [], isLoading } = useQuery({
    queryKey: ['practitioner-courses'],
    queryFn: async () => {
       const user = await base44.auth.me();
       if (!user) return [];
       // Filter mainly by created_by
       // We'll fetch all and filter client side for now to catch everything relevant
       const all = await base44.entities.LearningCourse.list('order');
       return all.filter(c => c.created_by === user.email || c.practitioner_email === user.email);
    }
  });

  const { data: modules = [] } = useQuery({
    queryKey: ['practitioner-modules', expandedCourse],
    queryFn: () => expandedCourse ? base44.entities.LearningModule.filter({ course_id: expandedCourse }, 'order') : [],
    enabled: !!expandedCourse,
  });

  // Mutations
  const saveCourseMutation = useMutation({
    mutationFn: async (data) => {
      const user = await base44.auth.me();
      const courseData = { ...data, practitioner_email: user.email };
      return editingCourse 
        ? base44.entities.LearningCourse.update(editingCourse.id, courseData)
        : base44.entities.LearningCourse.create(courseData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['practitioner-courses']);
      toast.success(editingCourse ? "Course updated" : "Course created");
      closeCourseForm();
    },
  });

  const deleteCourseMutation = useMutation({
    mutationFn: (id) => base44.entities.LearningCourse.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['practitioner-courses']);
      toast.success("Course deleted");
    },
  });

  const saveModuleMutation = useMutation({
    mutationFn: (data) => editingModule
      ? base44.entities.LearningModule.update(editingModule.id, data)
      : base44.entities.LearningModule.create({ ...data, course_id: expandedCourse }),
    onSuccess: () => {
      queryClient.invalidateQueries(['practitioner-modules']);
      toast.success(editingModule ? "Module updated" : "Module created");
      closeModuleForm();
    },
  });

  const deleteModuleMutation = useMutation({
    mutationFn: (id) => base44.entities.LearningModule.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['practitioner-modules']);
      toast.success("Module deleted");
    },
  });

  const createModulesFromOutline = useMutation({
    mutationFn: async (outline) => {
      const course = await base44.entities.LearningCourse.create({
        title: outline.title,
        description: outline.description,
        category: 'self_healing',
        is_active: false
      });

      for (let i = 0; i < outline.modules.length; i++) {
        const mod = outline.modules[i];
        await base44.entities.LearningModule.create({
          course_id: course.id,
          title: mod.title,
          description: mod.description,
          content: "# " + mod.title + "\n\nContent coming soon...",
          order: i + 1
        });
      }
      return course;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['practitioner-courses']);
      toast.success("Course created from outline!");
    }
  });

  // Handlers
  const handleEditCourse = (course) => {
    setEditingCourse(course);
    setCourseForm(course);
    setShowCourseForm(true);
  };

  const closeCourseForm = () => {
    setShowCourseForm(false);
    setEditingCourse(null);
    setCourseForm({
      title: "", description: "", category: "meditation", 
      difficulty_level: "beginner", estimated_hours: 1, 
      points_reward: 100, is_premium: false, points_required: 0, image_url: "",
      tags: []
    });
  };

  const handleEditModule = (module) => {
    setEditingModule(module);
    setModuleForm(module);
    setShowModuleForm(true);
  };

  const closeModuleForm = () => {
    setShowModuleForm(false);
    setEditingModule(null);
    setModuleForm({
      title: "", description: "", content: "", 
      video_url: "", audio_url: "", duration_minutes: 15, points_reward: 10, prerequisite_module_id: ""
    });
  };

  // State for Quiz Manager Modal
  const [showQuizManager, setShowQuizManager] = useState(false);

  // AI Handlers
  const handleAICourseIdeas = (data) => {
    // Show ideas in a toast or modal? For simplicity, let's just use the first one to pre-fill the form, 
    // or ideally, we'd list them. Let's list them in a toast for now or just log.
    // Better: Show a selection dialog? 
    // Let's keep it simple: "Ideas generated! Check the console or we can pick one."
    // Actually, let's pick the first one to start a draft.
    if (data.ideas && data.ideas.length > 0) {
      const idea = data.ideas[0];
      setCourseForm(prev => ({
        ...prev,
        title: idea.title,
        description: idea.description
      }));
      setShowCourseForm(true);
      toast.success("Draft started from AI idea: " + idea.title);
    }
  };

  const handleAIOutline = (data) => {
    if (showCourseForm) {
      setCourseForm(prev => ({ ...prev, title: data.title, description: data.description }));
      toast.info("Course details filled from outline.");
    } else {
      createModulesFromOutline.mutate(data);
    }
  };

  const handleAIDescription = (data) => {
    setCourseForm(prev => ({ ...prev, description: data.short_description }));
  };

  const handleAIModuleContent = (data) => {
    setModuleForm(prev => ({ ...prev, content: data.content }));
  };

  const handleAIExercises = (data) => {
    const exercisesText = data.exercises.map(ex => `### ${ex.title}\n${ex.instruction}\n*Time: ${ex.estimated_time}*`).join('\n\n');
    setModuleForm(prev => ({
      ...prev,
      content: prev.content + "\n\n## Practice Exercises\n\n" + exercisesText
    }));
  };

  const handleAIHashtags = (data) => {
    if (data.tags) {
      setCourseForm(prev => ({
        ...prev,
        tags: [...new Set([...(prev.tags || []), ...data.tags])]
      }));
      toast.success(`Added ${data.tags.length} hashtags!`);
    }
  };

  const handleAddTag = (e) => {
    if (e.key === 'Enter' && e.target.value.trim()) {
      e.preventDefault();
      const newTag = e.target.value.trim().replace(/^#/, '');
      if (!courseForm.tags?.includes(newTag)) {
        setCourseForm(prev => ({ ...prev, tags: [...(prev.tags || []), newTag] }));
      }
      e.target.value = '';
    }
  };

  const removeTag = (tag) => {
    setCourseForm(prev => ({ ...prev, tags: prev.tags.filter(t => t !== tag) }));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold">My Courses</h2>
          <p className="text-gray-500">Create and manage your healing courses</p>
        </div>
        <div className="flex gap-2">
          <AIContentGenerator 
            mode="course_ideas" 
            onGenerate={handleAICourseIdeas}
            buttonLabel="Get Course Ideas"
          />
          <AIContentGenerator 
            mode="outline" 
            onGenerate={handleAIOutline}
            buttonLabel="Generate from Outline"
          />
          <Button onClick={() => setShowCourseForm(true)} className="bg-purple-600">
            <Plus className="w-4 h-4 mr-2" /> New Course
          </Button>
          <Button variant="outline" onClick={() => setShowQuizManager(true)}>
            <Sparkles className="w-4 h-4 mr-2" /> Manage Quizzes
          </Button>
        </div>
      </div>

      {showQuizManager && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto p-6 relative animate-in fade-in zoom-in-95">
            <Button 
              variant="ghost" 
              size="icon" 
              className="absolute right-4 top-4" 
              onClick={() => setShowQuizManager(false)}
            >
              <X className="w-4 h-4" />
            </Button>
            <QuizManager />
          </div>
        </div>
      )}

      {showCourseForm && (
        <Card className="border-2 border-purple-200 animate-in slide-in-from-top-4">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>{editingCourse ? "Edit Course" : "New Course"}</CardTitle>
            <Button variant="ghost" size="sm" onClick={closeCourseForm}><X className="w-4 h-4" /></Button>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-end">
              <AIContentGenerator 
                mode="description" 
                initialData={{ topic: courseForm.title, course_title: courseForm.title }}
                onGenerate={handleAIDescription}
                buttonLabel="AI Description"
              />
            </div>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Title</Label>
                <Input value={courseForm.title} onChange={e => setCourseForm({...courseForm, title: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Category</Label>
                <Select value={courseForm.category} onValueChange={v => setCourseForm({...courseForm, category: v})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["meditation", "chakra_work", "energy_techniques", "self_healing", "reiki_basics", "tarot_guidance", "crystal_healing", "manifestation"].map(c => (
                      <SelectItem key={c} value={c}>{c.replace('_', ' ')}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea value={courseForm.description} onChange={e => setCourseForm({...courseForm, description: e.target.value})} rows={3} />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label>Hashtags (Press Enter to add)</Label>
                <AIContentGenerator 
                  mode="hashtags" 
                  initialData={{ topic: courseForm.description, course_title: courseForm.title }}
                  onGenerate={handleAIHashtags}
                  buttonLabel="AI Hashtags"
                />
              </div>
              <div className="flex flex-wrap gap-2 mb-2 p-2 bg-gray-50 rounded-md min-h-[40px]">
                {(courseForm.tags || []).map(tag => (
                  <div key={tag} className="bg-purple-100 text-purple-700 px-2 py-1 rounded-full text-sm flex items-center gap-1">
                    #{tag}
                    <button onClick={() => removeTag(tag)} className="hover:text-purple-900"><X className="w-3 h-3" /></button>
                  </div>
                ))}
                <input 
                  className="bg-transparent border-none focus:ring-0 text-sm min-w-[100px] outline-none"
                  placeholder="Add tag..."
                  onKeyDown={handleAddTag}
                />
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Difficulty</Label>
                <Select value={courseForm.difficulty_level} onValueChange={v => setCourseForm({...courseForm, difficulty_level: v})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="beginner">Beginner</SelectItem>
                    <SelectItem value="intermediate">Intermediate</SelectItem>
                    <SelectItem value="advanced">Advanced</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Est. Hours</Label>
                <Input type="number" value={courseForm.estimated_hours} onChange={e => setCourseForm({...courseForm, estimated_hours: +e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Points Reward</Label>
                <Input type="number" value={courseForm.points_reward} onChange={e => setCourseForm({...courseForm, points_reward: +e.target.value})} />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Prerequisite Course (Optional)</Label>
              <Select value={courseForm.prerequisite_course_id || "none"} onValueChange={v => setCourseForm({...courseForm, prerequisite_course_id: v === "none" ? null : v})}>
                <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {courses.filter(c => c.id !== courseForm.id).map(c => (
                    <SelectItem key={c.id} value={c.id}>{c.title}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button onClick={() => saveCourseMutation.mutate(courseForm)} className="w-full bg-purple-600">
              {editingCourse ? "Update Course" : "Create Course"}
            </Button>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4">
        {courses.length === 0 && !isLoading && (
          <Card className="text-center py-12">
            <CardContent>
              <Lightbulb className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
              <p className="text-gray-600">No courses yet. Use the AI tools above to get started!</p>
            </CardContent>
          </Card>
        )}
        
        {courses.map(course => (
          <Card key={course.id} className="overflow-hidden">
            <div className="p-4 flex items-center justify-between bg-white">
              <div className="flex items-center gap-4">
                 <div className="bg-purple-100 p-2 rounded-lg">
                   <BookOpen className="w-5 h-5 text-purple-600" />
                 </div>
                 <div>
                   <h3 className="font-bold text-lg">{course.title}</h3>
                   <p className="text-sm text-gray-500">{course.modules_count || 0} modules • {course.category?.replace('_', ' ')}</p>
                 </div>
              </div>
              <div className="flex items-center gap-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setExpandedCourse(expandedCourse === course.id ? null : course.id)}
                >
                  {expandedCourse === course.id ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                  Modules
                </Button>
                <Button variant="ghost" size="icon" onClick={() => handleEditCourse(course)}>
                  <Edit className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="text-red-500" onClick={() => deleteCourseMutation.mutate(course.id)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {expandedCourse === course.id && (
              <div className="bg-gray-50 p-4 border-t">
                <div className="flex justify-between items-center mb-4">
                  <h4 className="font-semibold text-gray-700">Course Modules</h4>
                  <Button size="sm" variant="outline" onClick={() => setShowModuleForm(true)}>
                    <Plus className="w-3 h-3 mr-2" /> Add Module
                  </Button>
                </div>

                {showModuleForm && (
                  <Card className="mb-4 border-purple-200">
                    <CardHeader className="flex flex-row items-center justify-between py-3">
                      <CardTitle className="text-sm">{editingModule ? "Edit Module" : "New Module"}</CardTitle>
                      <Button variant="ghost" size="sm" onClick={closeModuleForm}><X className="w-3 h-3" /></Button>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex gap-2 justify-end">
                        <AIContentGenerator 
                          mode="module_content"
                          initialData={{ topic: moduleForm.title, course_title: course.title, module_title: moduleForm.title }}
                          onGenerate={handleAIModuleContent}
                          buttonLabel="AI Content"
                        />
                      </div>
                      <Input placeholder="Module Title" value={moduleForm.title} onChange={e => setModuleForm({...moduleForm, title: e.target.value})} />
                      <Textarea placeholder="Content (Markdown)" value={moduleForm.content} onChange={e => setModuleForm({...moduleForm, content: e.target.value})} rows={8} />
                      <Textarea placeholder="Brief Description" value={moduleForm.description} onChange={e => setModuleForm({...moduleForm, description: e.target.value})} rows={2} />
                      
                      <div className="grid grid-cols-2 gap-4">
                        <Input placeholder="Video URL (optional)" value={moduleForm.video_url} onChange={e => setModuleForm({...moduleForm, video_url: e.target.value})} />
                        <Input placeholder="Audio URL (optional)" value={moduleForm.audio_url} onChange={e => setModuleForm({...moduleForm, audio_url: e.target.value})} />
                      </div>

                      <div className="space-y-2">
                        <Label>Prerequisite Module</Label>
                        <Select value={moduleForm.prerequisite_module_id || "none"} onValueChange={v => setModuleForm({...moduleForm, prerequisite_module_id: v === "none" ? null : v})}>
                          <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">None</SelectItem>
                            {modules.filter(m => m.id !== moduleForm.id).map(m => (
                              <SelectItem key={m.id} value={m.id}>{m.title}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="flex justify-between items-center">
                         <div className="flex gap-2">
                           <Input className="w-24" type="number" placeholder="Mins" value={moduleForm.duration_minutes} onChange={e => setModuleForm({...moduleForm, duration_minutes: +e.target.value})} />
                           <Input className="w-24" type="number" placeholder="Pts" value={moduleForm.points_reward} onChange={e => setModuleForm({...moduleForm, points_reward: +e.target.value})} />
                         </div>
                         <AIContentGenerator 
                            mode="exercises"
                            initialData={{ content: moduleForm.content }}
                            onGenerate={handleAIExercises}
                            buttonLabel="Add Exercises"
                          />
                      </div>

                      <Button size="sm" onClick={() => saveModuleMutation.mutate(moduleForm)} className="w-full bg-purple-600">Save Module</Button>
                    </CardContent>
                  </Card>
                )}

                <div className="space-y-2">
                  {modules.map((mod, idx) => (
                    <div key={mod.id} className="flex items-center justify-between p-3 bg-white rounded border">
                      <div className="flex items-center gap-3">
                        <span className="w-6 h-6 flex items-center justify-center bg-gray-100 rounded-full text-xs font-medium">{idx + 1}</span>
                        <span className="font-medium">{mod.title}</span>
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="sm" onClick={() => handleEditModule(mod)}><Edit className="w-3 h-3" /></Button>
                        <Button variant="ghost" size="sm" className="text-red-500" onClick={() => deleteModuleMutation.mutate(mod.id)}><Trash2 className="w-3 h-3" /></Button>
                      </div>
                    </div>
                  ))}
                  {modules.length === 0 && !showModuleForm && (
                    <p className="text-center text-sm text-gray-500 py-2">No modules yet.</p>
                  )}
                </div>
              </div>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}