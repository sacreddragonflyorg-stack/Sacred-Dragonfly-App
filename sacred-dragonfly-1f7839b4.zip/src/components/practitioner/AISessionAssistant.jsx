import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sparkles, Copy, Check, Loader2, FileText, Send, BarChart2 } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

export default function AISessionAssistant() {
  const [activeTab, setActiveTab] = useState("notes");

  return (
    <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-purple-100">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-purple-800">
          <Sparkles className="w-5 h-5 text-purple-600" />
          AI Practice Assistant
        </CardTitle>
        <CardDescription>
          Tools to enhance your workflow and client care
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="notes">
              <FileText className="w-4 h-4 mr-2" /> Session Notes
            </TabsTrigger>
            <TabsTrigger value="followup">
              <Send className="w-4 h-4 mr-2" /> Follow-Up
            </TabsTrigger>
            <TabsTrigger value="feedback">
              <BarChart2 className="w-4 h-4 mr-2" /> Feedback Analysis
            </TabsTrigger>
          </TabsList>

          <TabsContent value="notes">
            <NotesGenerator />
          </TabsContent>

          <TabsContent value="followup">
            <FollowUpSuggester />
          </TabsContent>

          <TabsContent value="feedback">
            <FeedbackAnalyzer />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

function NotesGenerator() {
  const [input, setInput] = useState({ client_name: "", service_type: "", key_themes: "", raw_notes: "" });
  const [result, setResult] = useState(null);

  const generateMutation = useMutation({
    mutationFn: async () => {
      const { data } = await base44.functions.invoke('generateSessionNotes', input);
      return data;
    },
    onSuccess: (data) => {
      setResult(data);
      toast.success("Notes generated successfully!");
    }
  });

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard");
  };

  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Client Name</Label>
          <Input value={input.client_name} onChange={e => setInput({...input, client_name: e.target.value})} placeholder="Jane Doe" />
        </div>
        <div className="space-y-2">
          <Label>Service Type</Label>
          <Input value={input.service_type} onChange={e => setInput({...input, service_type: e.target.value})} placeholder="Reiki Healing" />
        </div>
      </div>
      <div className="space-y-2">
        <Label>Key Themes / Keywords</Label>
        <Input value={input.key_themes} onChange={e => setInput({...input, key_themes: e.target.value})} placeholder="Anxiety, Root Chakra, Career Change" />
      </div>
      <div className="space-y-2">
        <Label>Rough Notes / Observations</Label>
        <Textarea 
          value={input.raw_notes} 
          onChange={e => setInput({...input, raw_notes: e.target.value})} 
          placeholder="Client felt blocked in lower back. Mentioned stress at work. Visualization of green light helped..." 
          rows={5}
        />
      </div>
      <Button 
        onClick={() => generateMutation.mutate()} 
        disabled={generateMutation.isPending || !input.raw_notes}
        className="w-full bg-gradient-to-r from-purple-600 to-pink-600"
      >
        {generateMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Sparkles className="w-4 h-4 mr-2" />}
        Generate Structured Notes
      </Button>

      {result && (
        <div className="mt-6 space-y-4 bg-purple-50 p-4 rounded-lg border border-purple-100">
          <div>
            <div className="flex justify-between items-center mb-1">
              <h4 className="font-semibold text-purple-900">Summary</h4>
              <Button variant="ghost" size="sm" onClick={() => copyToClipboard(result.summary)}><Copy className="w-3 h-3" /></Button>
            </div>
            <p className="text-sm text-gray-700">{result.summary}</p>
          </div>
          <div>
            <h4 className="font-semibold text-purple-900 mb-1">Key Insights</h4>
            <ul className="list-disc list-inside text-sm text-gray-700">
              {result.insights?.map((item, i) => <li key={i}>{item}</li>)}
            </ul>
          </div>
          <div>
             <h4 className="font-semibold text-purple-900 mb-1">Recommendations</h4>
             <ul className="list-disc list-inside text-sm text-gray-700">
               {result.recommendations?.map((item, i) => <li key={i}>{item}</li>)}
             </ul>
          </div>
          {result.private_notes && (
            <div className="border-t border-purple-200 pt-2 mt-2">
              <h4 className="font-semibold text-gray-600 text-xs uppercase mb-1">Private Practitioner Notes</h4>
              <p className="text-sm text-gray-600 italic">{result.private_notes}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function FollowUpSuggester() {
  const [input, setInput] = useState({ session_summary: "", client_goals: "", service_type: "" });
  const [result, setResult] = useState(null);

  const generateMutation = useMutation({
    mutationFn: async () => {
      const { data } = await base44.functions.invoke('suggestFollowUp', input);
      return data;
    },
    onSuccess: (data) => {
      setResult(data);
      toast.success("Suggestions generated!");
    }
  });

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Service Type</Label>
        <Input value={input.service_type} onChange={e => setInput({...input, service_type: e.target.value})} placeholder="Tarot Reading" />
      </div>
      <div className="space-y-2">
        <Label>Session Summary</Label>
        <Textarea 
          value={input.session_summary} 
          onChange={e => setInput({...input, session_summary: e.target.value})} 
          placeholder="We discussed the client's new relationship and fears of abandonment..." 
          rows={3}
        />
      </div>
      <div className="space-y-2">
        <Label>Client Goals</Label>
        <Input value={input.client_goals} onChange={e => setInput({...input, client_goals: e.target.value})} placeholder="Build confidence, find clarity" />
      </div>
      <Button 
        onClick={() => generateMutation.mutate()} 
        disabled={generateMutation.isPending || !input.session_summary}
        className="w-full bg-gradient-to-r from-blue-600 to-indigo-600"
      >
        {generateMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Sparkles className="w-4 h-4 mr-2" />}
        Suggest Follow-Up
      </Button>

      {result && (
        <div className="mt-6 space-y-6">
          <Card className="border-blue-100 bg-blue-50/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-blue-900">Suggested Exercises</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {result.exercises?.map((ex, i) => (
                  <div key={i} className="bg-white p-3 rounded border border-blue-100">
                    <p className="font-semibold text-blue-800 text-sm">{ex.title}</p>
                    <p className="text-sm text-gray-600 mt-1">{ex.instruction}</p>
                    <p className="text-xs text-gray-400 mt-1 flex items-center gap-1"><ClockIcon className="w-3 h-3" /> {ex.duration}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-purple-100 bg-purple-50/50">
             <CardHeader className="pb-2">
               <CardTitle className="text-sm font-medium text-purple-900">Recommended Resources</CardTitle>
             </CardHeader>
             <CardContent>
               <ul className="space-y-2">
                 {result.recommended_resources?.map((res, i) => (
                   <li key={i} className="flex items-start gap-2 text-sm">
                     <BookOpen className="w-4 h-4 text-purple-600 mt-0.5 shrink-0" />
                     <div>
                       <span className="font-medium text-gray-900">{res.title}</span>
                       <p className="text-gray-500 text-xs">{res.reason}</p>
                     </div>
                   </li>
                 ))}
               </ul>
             </CardContent>
          </Card>

          <div className="space-y-2">
            <Label>Draft Message to Client</Label>
            <div className="relative">
              <Textarea readOnly value={result.message} rows={4} className="bg-gray-50" />
              <Button 
                size="sm" 
                variant="outline" 
                className="absolute top-2 right-2 h-7"
                onClick={() => { navigator.clipboard.writeText(result.message); toast.success("Copied"); }}
              >
                <Copy className="w-3 h-3" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function FeedbackAnalyzer() {
  const [analysis, setAnalysis] = useState(null);

  const analyzeMutation = useMutation({
    mutationFn: async () => {
      const { data } = await base44.functions.invoke('analyzeFeedback');
      return data;
    },
    onSuccess: (data) => {
      setAnalysis(data);
    }
  });

  // Load on mount or button click? Let's do button to save tokens.
  
  return (
    <div className="space-y-6">
      {!analysis ? (
        <div className="text-center py-12">
          <p className="text-gray-600 mb-4">Analyze your client reviews to discover trends and insights.</p>
          <Button onClick={() => analyzeMutation.mutate()} disabled={analyzeMutation.isPending}>
            {analyzeMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <BarChart2 className="w-4 h-4 mr-2" />}
            Analyze My Reviews
          </Button>
        </div>
      ) : (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
          <div className="grid md:grid-cols-2 gap-4">
            <Card className="bg-green-50 border-green-100">
              <CardHeader className="pb-2">
                <CardTitle className="text-green-800 text-lg">Strengths</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-1">
                  {analysis.key_strengths?.map((s, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-green-700">
                      <Check className="w-4 h-4 mt-0.5 shrink-0" /> {s}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
            <Card className="bg-amber-50 border-amber-100">
              <CardHeader className="pb-2">
                <CardTitle className="text-amber-800 text-lg">Areas for Growth</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-1">
                  {analysis.areas_for_improvement?.map((s, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-amber-700">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" /> {s}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Trend Summary</CardTitle>
              <CardDescription className="text-purple-600 font-medium">{analysis.overall_sentiment}</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700">{analysis.trend_summary}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {analysis.keywords?.map((k, i) => (
                  <span key={i} className="bg-gray-100 text-gray-600 px-2 py-1 rounded-full text-xs">#{k}</span>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <div className="flex justify-end">
            <Button variant="outline" size="sm" onClick={() => analyzeMutation.mutate()} disabled={analyzeMutation.isPending}>
              <Loader2 className={`w-3 h-3 mr-2 ${analyzeMutation.isPending ? 'animate-spin' : ''}`} />
              Refresh Analysis
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

function ClockIcon({ className }) {
  return (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10"/>
      <polyline points="12 6 12 12 16 14"/>
    </svg>
  );
}