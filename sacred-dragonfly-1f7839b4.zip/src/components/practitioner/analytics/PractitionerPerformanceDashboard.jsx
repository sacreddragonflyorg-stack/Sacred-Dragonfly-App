import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Loader2, TrendingUp, Users, Lightbulb, Calendar, RefreshCw, Star, BarChart3, Package, DollarSign } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell, Legend } from 'recharts';
import { format, subMonths, isSameMonth, startOfMonth, endOfMonth, eachMonthOfInterval } from "date-fns";

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#a4de6c'];

export default function PractitionerPerformanceDashboard() {
  const [activeTab, setActiveTab] = useState("overview");

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Performance Dashboard</h2>
          <p className="text-gray-500">Comprehensive insights into your practice</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-white p-1 rounded-lg shadow overflow-x-auto justify-start md:justify-center">
          <TabsTrigger value="overview" className="gap-2"><BarChart3 className="w-4 h-4" /> Overview</TabsTrigger>
          <TabsTrigger value="appointments" className="gap-2"><Calendar className="w-4 h-4" /> Appointments</TabsTrigger>
          <TabsTrigger value="services" className="gap-2"><Star className="w-4 h-4" /> Services</TabsTrigger>
          <TabsTrigger value="financials" className="gap-2"><DollarSign className="w-4 h-4" /> Earnings</TabsTrigger>
          <TabsTrigger value="clients" className="gap-2"><Users className="w-4 h-4" /> Clients</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <OverviewPanel />
        </TabsContent>

        <TabsContent value="appointments">
          <AppointmentTrendsPanel />
        </TabsContent>

        <TabsContent value="services">
          <ServicesPerformancePanel />
        </TabsContent>

        <TabsContent value="financials">
          <FinancialsPanel />
        </TabsContent>

        <TabsContent value="clients">
          <ClientRetentionPanel />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function OverviewPanel() {
    const { data: metrics, isLoading } = useQuery({
        queryKey: ['practitioner-overview-metrics'],
        queryFn: async () => {
            const user = await base44.auth.me();
            const practitioner = (await base44.entities.Practitioner.filter({ user_email: user.email }))[0];
            if (!practitioner) return null;

            // Fetch basic data
            const appointments = await base44.entities.Appointment.filter({ practitioner_id: practitioner.id });
            const completedApts = appointments.filter(a => a.status === 'completed');
            
            // Calculate total earnings
            const totalEarnings = completedApts.reduce((sum, a) => sum + (a.practitioner_earnings || a.price || 0), 0);
            
            // Unique clients
            const uniqueClients = new Set(appointments.map(a => a.client_email)).size;

            return {
                totalAppointments: appointments.length,
                completedAppointments: completedApts.length,
                totalEarnings,
                uniqueClients,
                rating: practitioner.average_rating || 0
            };
        }
    });

    if (isLoading) return <LoadingState />;
    if (!metrics) return <EmptyState message="No data available yet." />;

    return (
        <div className="grid md:grid-cols-4 gap-6">
            <MetricCard title="Total Appointments" value={metrics.totalAppointments} icon={Calendar} color="blue" />
            <MetricCard title="Unique Clients" value={metrics.uniqueClients} icon={Users} color="purple" />
            <MetricCard title="Total Earnings" value={`$${metrics.totalEarnings.toFixed(2)}`} icon={DollarSign} color="green" />
            <MetricCard title="Avg Rating" value={metrics.rating} icon={Star} color="yellow" />
            
            <div className="md:col-span-2">
                <Card>
                    <CardHeader><CardTitle>Recent Activity</CardTitle></CardHeader>
                    <CardContent>
                        <AppointmentTrendsPanel mini />
                    </CardContent>
                </Card>
            </div>
            <div className="md:col-span-2">
                <Card>
                    <CardHeader><CardTitle>Top Services</CardTitle></CardHeader>
                    <CardContent>
                        <ServicesPerformancePanel mini />
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}

function MetricCard({ title, value, icon: Icon, color }) {
    const colorClasses = {
        blue: "bg-blue-100 text-blue-600",
        purple: "bg-purple-100 text-purple-600",
        green: "bg-green-100 text-green-600",
        yellow: "bg-yellow-100 text-yellow-600"
    };

    return (
        <Card>
            <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                    <div>
                        <p className="text-sm font-medium text-gray-500">{title}</p>
                        <h3 className="text-2xl font-bold mt-1">{value}</h3>
                    </div>
                    <div className={`p-3 rounded-full ${colorClasses[color]}`}>
                        <Icon className="w-6 h-6" />
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}

function AppointmentTrendsPanel({ mini = false }) {
    const { data: chartData, isLoading } = useQuery({
        queryKey: ['appointment-trends'],
        queryFn: async () => {
            const user = await base44.auth.me();
            const practitioner = (await base44.entities.Practitioner.filter({ user_email: user.email }))[0];
            if (!practitioner) return [];

            const appointments = await base44.entities.Appointment.filter({ practitioner_id: practitioner.id });
            
            // Group by month for last 6 months
            const end = new Date();
            const start = subMonths(end, 5);
            const months = eachMonthOfInterval({ start, end });

            return months.map(month => {
                const count = appointments.filter(a => isSameMonth(new Date(a.appointment_date), month)).length;
                return {
                    name: format(month, 'MMM'),
                    appointments: count
                };
            });
        }
    });

    if (isLoading) return <LoadingState />;

    return (
        <div className={mini ? "h-[200px]" : "h-[400px]"}>
            {!mini && <h3 className="text-lg font-semibold mb-4">Monthly Appointment Volume</h3>}
            <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="name" />
                    <YAxis allowDecimals={false} />
                    <Tooltip />
                    <Bar dataKey="appointments" fill="#8884d8" radius={[4, 4, 0, 0]} />
                </BarChart>
            </ResponsiveContainer>
        </div>
    );
}

function ServicesPerformancePanel({ mini = false }) {
    const { data: serviceData, isLoading } = useQuery({
        queryKey: ['service-performance'],
        queryFn: async () => {
            const user = await base44.auth.me();
            const practitioner = (await base44.entities.Practitioner.filter({ user_email: user.email }))[0];
            if (!practitioner) return [];

            const appointments = await base44.entities.Appointment.filter({ practitioner_id: practitioner.id });
            
            // Count per service
            const counts = {};
            appointments.forEach(a => {
                counts[a.service_name] = (counts[a.service_name] || 0) + 1;
            });

            return Object.entries(counts)
                .map(([name, value]) => ({ name, value }))
                .sort((a, b) => b.value - a.value)
                .slice(0, 5); // Top 5
        }
    });

    if (isLoading) return <LoadingState />;

    return (
        <div className={mini ? "h-[200px]" : "h-[400px]"}>
            {!mini && <h3 className="text-lg font-semibold mb-4">Most Popular Services</h3>}
            <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                    <Pie
                        data={serviceData}
                        cx="50%"
                        cy="50%"
                        innerRadius={mini ? 40 : 60}
                        outerRadius={mini ? 60 : 80}
                        paddingAngle={5}
                        dataKey="value"
                    >
                        {serviceData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                    </Pie>
                    <Tooltip />
                    <Legend verticalAlign="bottom" height={36} />
                </PieChart>
            </ResponsiveContainer>
        </div>
    );
}

function FinancialsPanel() {
    const { data: revenueData, isLoading } = useQuery({
        queryKey: ['revenue-trends'],
        queryFn: async () => {
            const user = await base44.auth.me();
            const practitioner = (await base44.entities.Practitioner.filter({ user_email: user.email }))[0];
            if (!practitioner) return [];

            const appointments = await base44.entities.Appointment.filter({ practitioner_id: practitioner.id });
            
            // Group earnings by month
            const end = new Date();
            const start = subMonths(end, 5);
            const months = eachMonthOfInterval({ start, end });

            return months.map(month => {
                const monthlyApts = appointments.filter(a => 
                    isSameMonth(new Date(a.appointment_date), month) && 
                    a.status === 'completed'
                );
                const earnings = monthlyApts.reduce((sum, a) => sum + (a.practitioner_earnings || 0), 0);
                return {
                    name: format(month, 'MMM'),
                    earnings: earnings
                };
            });
        }
    });

    if (isLoading) return <LoadingState />;

    return (
        <Card>
            <CardHeader><CardTitle>Earnings Overview</CardTitle></CardHeader>
            <CardContent>
                <div className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={revenueData}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" />
                            <YAxis />
                            <Tooltip formatter={(value) => `$${value.toFixed(2)}`} />
                            <Area type="monotone" dataKey="earnings" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.3} />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </CardContent>
        </Card>
    );
}

function ClientRetentionPanel() {
    const { data: retentionData, isLoading } = useQuery({
        queryKey: ['client-retention'],
        queryFn: async () => {
            const user = await base44.auth.me();
            const practitioner = (await base44.entities.Practitioner.filter({ user_email: user.email }))[0];
            if (!practitioner) return null;

            const appointments = await base44.entities.Appointment.filter({ practitioner_id: practitioner.id });
            
            const clientCounts = {};
            appointments.forEach(a => {
                clientCounts[a.client_email] = (clientCounts[a.client_email] || 0) + 1;
            });

            const totalClients = Object.keys(clientCounts).length;
            const returningClients = Object.values(clientCounts).filter(count => count > 1).length;
            const oneTimeClients = totalClients - returningClients;

            return [
                { name: 'Returning Clients', value: returningClients },
                { name: 'One-time Clients', value: oneTimeClients }
            ];
        }
    });

    if (isLoading) return <LoadingState />;

    return (
        <div className="grid md:grid-cols-2 gap-6">
            <Card>
                <CardHeader><CardTitle>Client Retention Rate</CardTitle></CardHeader>
                <CardContent>
                    <div className="h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie
                                    data={retentionData}
                                    cx="50%"
                                    cy="50%"
                                    outerRadius={80}
                                    dataKey="value"
                                    label={({name, percent}) => `${name} ${(percent * 100).toFixed(0)}%`}
                                >
                                    <Cell fill="#82ca9d" />
                                    <Cell fill="#8884d8" />
                                </Pie>
                                <Tooltip />
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                </CardContent>
            </Card>
            
            <Card>
                <CardHeader><CardTitle>Insights</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                    <div className="bg-purple-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-purple-900 mb-2">Retention Strategy</h4>
                        <p className="text-purple-800 text-sm">
                            Consider creating service packages for your one-time clients. Offering a discount on a bundle of 3-5 sessions can significantly increase your returning client rate.
                        </p>
                    </div>
                    <div className="bg-blue-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-blue-900 mb-2">Client Engagement</h4>
                        <p className="text-blue-800 text-sm">
                            Send follow-up messages 2 weeks after an appointment to check in. This simple touchpoint often leads to rebooking.
                        </p>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}

function LoadingState() {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-gray-500">
      <Loader2 className="w-8 h-8 animate-spin mb-4 text-purple-600" />
      <p>Loading analytics data...</p>
    </div>
  );
}

function EmptyState({ message }) {
  return (
    <div className="text-center py-12 text-gray-500">
      <p>{message}</p>
    </div>
  );
}