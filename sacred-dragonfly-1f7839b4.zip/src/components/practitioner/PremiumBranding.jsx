import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Crown, Upload, Loader2, Save, Palette, Star, Video } from "lucide-react";
import { toast } from "sonner";

export default function PremiumBranding({ user, onUpdate }) {
  const [formData, setFormData] = useState({
    brand_primary_color: user?.brand_primary_color || "#8B5CF6",
    brand_secondary_color: user?.brand_secondary_color || "#EC4899",
    custom_tagline: user?.custom_tagline || "",
    video_intro_url: user?.video_intro_url || "",
    logo_url: user?.logo_url || "",
    testimonials: user?.testimonials || []
  });
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [newTestimonial, setNewTestimonial] = useState({
    client_name: "",
    content: "",
    rating: 5
  });

  const { data: subscription } = useQuery({
    queryKey: ['my-subscription', user?.email],
    queryFn: () => {
      if (!user) return [];
      // Grant free premium access to Carol L Andrews
      if (user.email === 'carol.andrews@example.com') {
        return [{
          plan_tier: 'premium',
          status: 'active'
        }];
      }
      return base44.entities.PractitionerSubscription.filter({ practitioner_email: user.email });
    },
    enabled: !!user,
    select: (data) => data[0]
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data) => base44.auth.updateMe(data),
    onSuccess: (updatedUser) => {
      toast.success("Branding updated!");
      onUpdate?.(updatedUser);
    },
    onError: () => {
      toast.error("Failed to update branding");
    }
  });

  const isPremium = subscription?.plan_tier === 'premium';
  const isBasic = subscription?.plan_tier === 'basic';

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleLogoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingLogo(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData(prev => ({ ...prev, logo_url: file_url }));
      toast.success("Logo uploaded!");
    } catch (error) {
      toast.error("Failed to upload logo");
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleAddTestimonial = () => {
    if (!newTestimonial.client_name || !newTestimonial.content) {
      toast.error("Please fill in all testimonial fields");
      return;
    }
    const testimonial = {
      ...newTestimonial,
      date: new Date().toISOString()
    };
    setFormData(prev => ({
      ...prev,
      testimonials: [...prev.testimonials, testimonial]
    }));
    setNewTestimonial({ client_name: "", content: "", rating: 5 });
    toast.success("Testimonial added!");
  };

  const handleRemoveTestimonial = (index) => {
    setFormData(prev => ({
      ...prev,
      testimonials: prev.testimonials.filter((_, i) => i !== index)
    }));
  };

  const handleSave = () => {
    updateProfileMutation.mutate(formData);
  };

  if (!isPremium && !isBasic) {
    return (
      <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
        <CardContent className="pt-6">
          <div className="text-center py-8">
            <Crown className="w-16 h-16 text-purple-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Premium Feature</h3>
            <p className="text-gray-600 mb-6">
              Upgrade to Basic or Premium to customize your practitioner profile
            </p>
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600">
              Upgrade Now
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Basic Tier Features */}
      {isBasic && (
        <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5" />
              Enhanced Profile (Basic Tier)
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="custom_tagline">Professional Tagline</Label>
              <Input
                id="custom_tagline"
                value={formData.custom_tagline}
                onChange={(e) => handleChange('custom_tagline', e.target.value)}
                placeholder="e.g., Certified Reiki Master & Energy Healer"
                maxLength={100}
              />
              <p className="text-xs text-gray-500">Displayed prominently on your profile</p>
            </div>

            <Button onClick={handleSave} disabled={updateProfileMutation.isPending} className="w-full">
              {updateProfileMutation.isPending ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</>
              ) : (
                <><Save className="w-4 h-4 mr-2" /> Save Changes</>
              )}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Premium Tier Features */}
      {isPremium && (
        <>
          <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
            <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
              <CardTitle className="flex items-center gap-2">
                <Crown className="w-5 h-5" />
                Premium Branding
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6 space-y-6">
              {/* Colors */}
              <div className="space-y-4">
                <h4 className="font-semibold flex items-center gap-2">
                  <Palette className="w-4 h-4" />
                  Brand Colors
                </h4>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="primary_color">Primary Color</Label>
                    <div className="flex gap-2">
                      <Input
                        id="primary_color"
                        type="color"
                        value={formData.brand_primary_color}
                        onChange={(e) => handleChange('brand_primary_color', e.target.value)}
                        className="w-20 h-10"
                      />
                      <Input
                        value={formData.brand_primary_color}
                        onChange={(e) => handleChange('brand_primary_color', e.target.value)}
                        placeholder="#8B5CF6"
                        className="flex-1"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="secondary_color">Secondary Color</Label>
                    <div className="flex gap-2">
                      <Input
                        id="secondary_color"
                        type="color"
                        value={formData.brand_secondary_color}
                        onChange={(e) => handleChange('brand_secondary_color', e.target.value)}
                        className="w-20 h-10"
                      />
                      <Input
                        value={formData.brand_secondary_color}
                        onChange={(e) => handleChange('brand_secondary_color', e.target.value)}
                        placeholder="#EC4899"
                        className="flex-1"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Logo */}
              <div className="space-y-2">
                <Label>Custom Logo</Label>
                <div className="flex items-center gap-4">
                  {formData.logo_url && (
                    <img src={formData.logo_url} alt="Logo" className="w-20 h-20 object-contain rounded-lg border" />
                  )}
                  <div>
                    <Input
                      type="file"
                      id="logo_upload"
                      className="hidden"
                      accept="image/*"
                      onChange={handleLogoUpload}
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => document.getElementById('logo_upload').click()}
                      disabled={uploadingLogo}
                    >
                      {uploadingLogo ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
                      Upload Logo
                    </Button>
                  </div>
                </div>
              </div>

              {/* Tagline */}
              <div className="space-y-2">
                <Label htmlFor="tagline">Professional Tagline</Label>
                <Input
                  id="tagline"
                  value={formData.custom_tagline}
                  onChange={(e) => handleChange('custom_tagline', e.target.value)}
                  placeholder="e.g., Certified Reiki Master & Energy Healer"
                  maxLength={100}
                />
              </div>

              {/* Video Intro */}
              <div className="space-y-2">
                <Label htmlFor="video_intro">Video Introduction URL</Label>
                <div className="flex items-center gap-2">
                  <Video className="w-4 h-4 text-gray-400" />
                  <Input
                    id="video_intro"
                    value={formData.video_intro_url}
                    onChange={(e) => handleChange('video_intro_url', e.target.value)}
                    placeholder="https://youtube.com/watch?v=..."
                  />
                </div>
                <p className="text-xs text-gray-500">YouTube, Vimeo, or direct video URL</p>
              </div>
            </CardContent>
          </Card>

          {/* Testimonials */}
          <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="w-5 h-5 text-amber-500" />
                Client Testimonials
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Existing Testimonials */}
              {formData.testimonials.length > 0 && (
                <div className="space-y-2">
                  {formData.testimonials.map((testimonial, index) => (
                    <div key={index} className="p-3 bg-amber-50 rounded-lg border border-amber-200">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <p className="font-semibold">{testimonial.client_name}</p>
                          <div className="flex gap-0.5">
                            {[...Array(testimonial.rating)].map((_, i) => (
                              <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                            ))}
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveTestimonial(index)}
                          className="text-red-600 hover:text-red-700"
                        >
                          Remove
                        </Button>
                      </div>
                      <p className="text-sm text-gray-700">{testimonial.content}</p>
                    </div>
                  ))}
                </div>
              )}

              {/* Add New Testimonial */}
              <div className="border-t pt-4 space-y-3">
                <h4 className="font-semibold text-sm">Add New Testimonial</h4>
                <Input
                  placeholder="Client name (or initials)"
                  value={newTestimonial.client_name}
                  onChange={(e) => setNewTestimonial(prev => ({ ...prev, client_name: e.target.value }))}
                />
                <Textarea
                  placeholder="Testimonial content..."
                  value={newTestimonial.content}
                  onChange={(e) => setNewTestimonial(prev => ({ ...prev, content: e.target.value }))}
                  rows={3}
                />
                <div className="flex items-center gap-2">
                  <Label>Rating:</Label>
                  <Select value={newTestimonial.rating.toString()} onValueChange={(v) => setNewTestimonial(prev => ({ ...prev, rating: parseInt(v) }))}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[5, 4, 3, 2, 1].map(n => (
                        <SelectItem key={n} value={n.toString()}>{n} Stars</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={handleAddTestimonial} variant="outline" className="w-full">
                  <Star className="w-4 h-4 mr-2" />
                  Add Testimonial
                </Button>
              </div>
            </CardContent>
          </Card>

          <Button onClick={handleSave} disabled={updateProfileMutation.isPending} size="lg" className="w-full bg-gradient-to-r from-purple-600 to-pink-600">
            {updateProfileMutation.isPending ? (
              <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Saving...</>
            ) : (
              <><Save className="w-5 h-5 mr-2" /> Save All Changes</>
            )}
          </Button>
        </>
      )}
    </div>
  );
}