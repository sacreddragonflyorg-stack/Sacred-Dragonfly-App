import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, X, Sparkles, Clock, DollarSign, Calendar } from "lucide-react";
import { toast } from "sonner";
import AIContentGenerator from "../dashboard/AIContentGenerator";

export default function PractitionerServiceManager() {
  const [user, setUser] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editingService, setEditingService] = useState(null);
  const [formData, setFormData] = useState({
    name: "", description: "", type: "energy_healing", 
    duration_minutes: 60, price: 100, pricing_model: "fixed",
    sliding_scale_min: 50, sliding_scale_max: 150,
    availability_config: { mode: "all_open", days: [] }
  });

  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser);
  }, []);

  const { data: services = [], isLoading } = useQuery({
    queryKey: ['practitioner-services', user?.email],
    queryFn: async () => {
      if (!user) return [];
      // Filter by practitioner email OR created_by. 
      // Since created_by is auto-handled, we can filter by practitioner_email if we set it, or just client-side filter for robustness
      const allServices = await base44.entities.Service.filter({}); // Fetch all then filter client side if backend filter is limited or just use created_by
      // Ideally: base44.entities.Service.filter({ practitioner_email: user.email })
      // For now, let's filter client side to be safe with mixed data
      return allServices.filter(s => s.practitioner_email === user.email || s.created_by === user.email);
    },
    enabled: !!user
  });

  const { data: practitioner } = useQuery({
    queryKey: ['practitioner-profile', user?.email],
    queryFn: () => user ? base44.entities.Practitioner.filter({ user_email: user.email }).then(res => res[0]) : null,
    enabled: !!user
  });

  const saveServiceMutation = useMutation({
    mutationFn: async (data) => {
      const serviceData = {
        ...data,
        practitioner_email: user.email,
      };
      
      let savedService;
      if (editingService) {
        savedService = await base44.entities.Service.update(editingService.id, serviceData);
      } else {
        savedService = await base44.entities.Service.create(serviceData);
      }

      // Link to practitioner profile if not already linked
      if (practitioner && !practitioner.service_ids?.includes(savedService.id)) {
        await base44.entities.Practitioner.update(practitioner.id, {
          service_ids: [...(practitioner.service_ids || []), savedService.id]
        });
      }
      return savedService;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['practitioner-services']);
      toast.success(editingService ? "Service updated" : "Service created");
      closeForm();
    },
  });

  const deleteServiceMutation = useMutation({
    mutationFn: async (id) => {
      // Unlink from practitioner first
      if (practitioner && practitioner.service_ids?.includes(id)) {
        await base44.entities.Practitioner.update(practitioner.id, {
          service_ids: practitioner.service_ids.filter(sid => sid !== id)
        });
      }
      return base44.entities.Service.delete(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['practitioner-services']);
      toast.success("Service deleted");
    },
  });

  const handleEdit = (service) => {
    setEditingService(service);
    setFormData({
      ...service,
      availability_config: service.availability_config || { mode: "all_open", days: [] }
    });
    setShowForm(true);
  };

  const closeForm = () => {
    setShowForm(false);
    setEditingService(null);
    setFormData({
      name: "", description: "", type: "energy_healing", 
      duration_minutes: 60, price: 100, pricing_model: "fixed",
      sliding_scale_min: 50, sliding_scale_max: 150,
      availability_config: { mode: "all_open", days: [] }
    });
  };

  const handleAIDescription = (data) => {
    setFormData(prev => ({ ...prev, description: data.short_description }));
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold">My Services</h2>
          <p className="text-gray-500">Manage your healing offerings</p>
        </div>
        <Button onClick={() => setShowForm(true)} className="bg-purple-600">
          <Plus className="w-4 h-4 mr-2" /> New Service
        </Button>
      </div>

      {showForm && (
        <Card className="border-2 border-purple-200 animate-in slide-in-from-top-4">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>{editingService ? "Edit Service" : "New Service"}</CardTitle>
            <Button variant="ghost" size="sm" onClick={closeForm}><X className="w-4 h-4" /></Button>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-end">
               <AIContentGenerator 
                  mode="description" 
                  initialData={{ topic: formData.name, course_title: formData.name }}
                  onGenerate={handleAIDescription}
                  buttonLabel="AI Description"
                />
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Service Name</Label>
                <Input value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="e.g. 60-Minute Reiki" />
              </div>
              <div className="space-y-2">
                <Label>Type</Label>
                <Select value={formData.type} onValueChange={v => setFormData({...formData, type: v})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="reiki_healing">Reiki Healing</SelectItem>
                    <SelectItem value="tarot_reading">Tarot Reading</SelectItem>
                    <SelectItem value="energy_healing">Energy Healing</SelectItem>
                    <SelectItem value="chakra_balancing">Chakra Balancing</SelectItem>
                    <SelectItem value="crystal_healing">Crystal Healing</SelectItem>
                    <SelectItem value="mentorship">Mentorship</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} rows={3} />
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Duration (min)</Label>
                <div className="relative">
                  <Clock className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
                  <Input type="number" className="pl-9" value={formData.duration_minutes} onChange={e => setFormData({...formData, duration_minutes: +e.target.value})} />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Pricing Model</Label>
                <Select value={formData.pricing_model} onValueChange={v => setFormData({...formData, pricing_model: v})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fixed">Fixed Price</SelectItem>
                    <SelectItem value="sliding_scale">Sliding Scale</SelectItem>
                    <SelectItem value="donation">Donation</SelectItem>
                    <SelectItem value="energy_exchange">Energy Exchange</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>{formData.pricing_model === 'sliding_scale' ? 'Min Price ($)' : 'Price ($)'}</Label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
                  <Input 
                    type="number" 
                    className="pl-9" 
                    value={formData.pricing_model === 'sliding_scale' ? formData.sliding_scale_min : formData.price} 
                    onChange={e => setFormData({
                      ...formData, 
                      [formData.pricing_model === 'sliding_scale' ? 'sliding_scale_min' : 'price']: +e.target.value
                    })} 
                  />
                </div>
              </div>
            </div>

            {formData.pricing_model === 'sliding_scale' && (
              <div className="space-y-2">
                <Label>Max Price ($)</Label>
                <Input type="number" value={formData.sliding_scale_max} onChange={e => setFormData({...formData, sliding_scale_max: +e.target.value})} />
              </div>
            )}

            <div className="space-y-2">
              <Label>Accepted Payment Methods</Label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { value: 'credit_card', label: 'Credit Card (Stripe)' },
                  { value: 'paypal', label: 'PayPal' },
                  { value: 'venmo', label: 'Venmo' },
                  { value: 'cashapp', label: 'Cash App' },
                  { value: 'chime_bank', label: 'Chime Bank' },
                  { value: 'dave_bank', label: 'Dave Bank' },
                  { value: 'one_bank', label: 'One Bank' },
                  { value: 'google_pay', label: 'Google Pay' },
                  { value: 'bank_transfer', label: 'Bank Transfer' },
                  { value: 'cash', label: 'Cash' }
                ].map((method) => (
                  <div key={method.value} className="flex items-center space-x-2">
                    <Checkbox 
                      id={`pm-${method.value}`}
                      checked={formData.payment_methods?.includes(method.value)}
                      onCheckedChange={(checked) => {
                        const current = formData.payment_methods || [];
                        setFormData({
                          ...formData,
                          payment_methods: checked ? [...current, method.value] : current.filter(m => m !== method.value)
                        });
                      }}
                    />
                    <label htmlFor={`pm-${method.value}`} className="text-sm font-medium leading-none cursor-pointer">
                      {method.label}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-4 pt-4 border-t">
              <h4 className="font-medium flex items-center gap-2">
                <Calendar className="w-4 h-4" /> Service Availability
              </h4>
              <div className="space-y-2">
                <Label>Availability Mode</Label>
                <Select 
                  value={formData.availability_config?.mode || "all_open"} 
                  onValueChange={v => setFormData({
                    ...formData, 
                    availability_config: { ...formData.availability_config, mode: v }
                  })}
                >
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all_open">Follow General Schedule</SelectItem>
                    <SelectItem value="specific_days">Specific Days Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {formData.availability_config?.mode === 'specific_days' && (
                <div className="flex flex-wrap gap-2">
                  {['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'].map(day => (
                    <div key={day} className="flex items-center space-x-2">
                      <Checkbox 
                        id={`day-${day}`} 
                        checked={formData.availability_config.days?.includes(day)}
                        onCheckedChange={(checked) => {
                          const currentDays = formData.availability_config.days || [];
                          setFormData({
                            ...formData,
                            availability_config: {
                              ...formData.availability_config,
                              days: checked ? [...currentDays, day] : currentDays.filter(d => d !== day)
                            }
                          });
                        }}
                      />
                      <label htmlFor={`day-${day}`} className="capitalize text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                        {day.slice(0, 3)}
                      </label>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <Button onClick={() => saveServiceMutation.mutate(formData)} className="w-full bg-purple-600">
              {editingService ? "Update Service" : "Create Service"}
            </Button>
          </CardContent>
        </Card>
      )}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {services.map(service => (
          <Card key={service.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                   <Badge variant="outline" className="mb-2">{service.type?.replace('_', ' ')}</Badge>
                   <CardTitle className="text-lg">{service.name}</CardTitle>
                </div>
                <div className="flex gap-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleEdit(service)}><Edit className="w-4 h-4" /></Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500" onClick={() => deleteServiceMutation.mutate(service.id)}><Trash2 className="w-4 h-4" /></Button>
                </div>
              </div>
              <CardDescription className="line-clamp-2">{service.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center text-sm text-gray-600 mt-2">
                <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {service.duration_minutes}m</span>
                <span className="font-semibold text-purple-700">
                  {service.pricing_model === 'fixed' ? `$${service.price}` : 
                   service.pricing_model === 'sliding_scale' ? `$${service.sliding_scale_min}-$${service.sliding_scale_max}` : 
                   service.pricing_model === 'donation' ? 'Donation' : 'Energy Exchange'}
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
        {services.length === 0 && !isLoading && (
          <div className="col-span-full text-center py-12 bg-gray-50 rounded-lg border border-dashed border-gray-300">
             <Sparkles className="w-12 h-12 text-purple-300 mx-auto mb-3" />
             <p className="text-gray-500">No services yet. Create your first offering!</p>
          </div>
        )}
      </div>
    </div>
  );
}