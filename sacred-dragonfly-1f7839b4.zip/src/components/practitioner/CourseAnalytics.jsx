import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Loader2, BookOpen, Users, CheckCircle, Award, BarChart3, TrendingUp, Search, AlertCircle, ArrowUp, ArrowDown } from "lucide-react";
import { Input } from "@/components/ui/input";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';

export default function CourseAnalytics({ practitionerEmail }) {
  const [selectedCourseId, setSelectedCourseId] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  const { data: courses = [], isLoading: coursesLoading } = useQuery({
    queryKey: ['practitioner-courses-analytics', practitionerEmail],
    queryFn: async () => {
      const allCourses = await base44.entities.LearningCourse.list();
      return allCourses.filter(c => c.practitioner_email === practitionerEmail || c.created_by === practitionerEmail);
    },
    enabled: !!practitionerEmail
  });

  const { data: studentProgress = [], isLoading: progressLoading } = useQuery({
    queryKey: ['practitioner-student-progress', practitionerEmail],
    queryFn: async () => {
      const allProgress = await base44.entities.UserCourseProgress.list('-started_at');
      const myCourseIds = new Set(courses.map(c => c.id));
      return allProgress.filter(p => myCourseIds.has(p.course_id));
    },
    enabled: courses.length > 0
  });

  const { data: modules = [] } = useQuery({
    queryKey: ['practitioner-modules-analytics', practitionerEmail],
    queryFn: async () => {
      const allModules = await base44.entities.LearningModule.list('order');
      const courseIds = new Set(courses.map(c => c.id));
      return allModules.filter(m => courseIds.has(m.course_id));
    },
    enabled: courses.length > 0
  });

  const { data: quizzes = [] } = useQuery({
    queryKey: ['practitioner-quizzes-analytics', practitionerEmail],
    queryFn: async () => {
       const allQuizzes = await base44.entities.LearningQuiz.list();
       const courseIds = new Set(courses.map(c => c.id));
       return allQuizzes.filter(q => courseIds.has(q.course_id));
    },
    enabled: courses.length > 0
  });

  // Calculate detailed stats for selected course
  const detailedStats = useMemo(() => {
    if (selectedCourseId === 'all') return null;

    const courseModules = modules.filter(m => m.course_id === selectedCourseId).sort((a,b) => a.order - b.order);
    const courseQuizzes = quizzes.filter(q => q.course_id === selectedCourseId);
    const courseStudents = studentProgress.filter(p => p.course_id === selectedCourseId);
    
    if (courseModules.length === 0) return null;

    // Module stats
    const moduleMetrics = courseModules.map(m => {
        const completedCount = courseStudents.filter(p => p.completed_modules?.includes(m.id)).length;
        return {
            name: m.title.length > 20 ? m.title.substring(0, 20) + '...' : m.title,
            fullName: m.title,
            completedCount,
            completedPercentage: courseStudents.length > 0 ? Math.round((completedCount / courseStudents.length) * 100) : 0
        };
    });

    // Sort to find most/least successful
    const sortedModules = [...moduleMetrics].sort((a,b) => b.completedPercentage - a.completedPercentage);
    const mostSuccessful = sortedModules[0];
    const leastSuccessful = sortedModules[sortedModules.length - 1];

    // Quiz stats
    const quizMetrics = courseQuizzes.map(q => {
        let totalScore = 0;
        let attemptCount = 0;
        
        courseStudents.forEach(p => {
            const scoreEntry = p.quiz_scores?.find(s => s.quiz_id === q.id);
            if (scoreEntry) {
                totalScore += scoreEntry.score || 0;
                attemptCount++;
            }
        });
        
        return {
            name: q.title.length > 20 ? q.title.substring(0, 20) + '...' : q.title,
            fullName: q.title,
            avgScore: attemptCount > 0 ? Math.round(totalScore / attemptCount) : 0,
            attempts: attemptCount
        };
    });

    return {
        moduleMetrics,
        quizMetrics,
        mostSuccessful,
        leastSuccessful,
        enrollmentCount: courseStudents.length,
        avgCompletion: courseStudents.length > 0 
            ? Math.round(courseStudents.reduce((sum, p) => sum + (p.progress_percentage || 0), 0) / courseStudents.length) 
            : 0
    };
  }, [selectedCourseId, modules, quizzes, studentProgress]);


  if (coursesLoading || progressLoading) {
    return (
      <div className="flex justify-center p-12">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  const totalStudents = new Set(studentProgress.map(p => p.user_email)).size;
  const totalCompletions = studentProgress.filter(p => p.status === 'completed').length;
  const overallAvgProgress = studentProgress.length > 0
    ? Math.round(studentProgress.reduce((sum, p) => sum + (p.progress_percentage || 0), 0) / studentProgress.length)
    : 0;

  const courseStats = courses.map(course => {
    const courseStudents = studentProgress.filter(p => p.course_id === course.id);
    const completions = courseStudents.filter(p => p.status === 'completed').length;
    const avg = courseStudents.length > 0
      ? Math.round(courseStudents.reduce((sum, p) => sum + (p.progress_percentage || 0), 0) / courseStudents.length)
      : 0;
    
    return {
      ...course,
      studentCount: courseStudents.length,
      completionCount: completions,
      avgProgress: avg,
      completionRate: courseStudents.length > 0 ? Math.round((completions / courseStudents.length) * 100) : 0
    };
  });

  const filteredProgress = studentProgress.filter(p => {
    const matchesCourse = selectedCourseId === 'all' || p.course_id === selectedCourseId;
    const matchesSearch = p.user_email.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.course_title?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCourse && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card className="bg-purple-50 border-purple-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-purple-900">Total Courses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-purple-600" />
              <span className="text-2xl font-bold text-purple-700">{courses.length}</span>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-blue-50 border-blue-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-blue-900">Active Students</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-600" />
              <span className="text-2xl font-bold text-blue-700">{totalStudents}</span>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-green-50 border-green-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-900">Course Completions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-green-600" />
              <span className="text-2xl font-bold text-green-700">{totalCompletions}</span>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-amber-50 border-amber-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-amber-900">Avg. Engagement</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-amber-600" />
              <span className="text-2xl font-bold text-amber-700">{overallAvgProgress}%</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {detailedStats && selectedCourseId !== 'all' && (
        <div className="grid md:grid-cols-2 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <Card className="md:col-span-2 bg-gradient-to-r from-gray-50 to-white">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <BarChart3 className="w-5 h-5 text-purple-600" />
                        Detailed Performance: {courses.find(c => c.id === selectedCourseId)?.title}
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-3 gap-6 mb-8">
                        <div className="p-4 bg-white rounded-lg border shadow-sm">
                            <p className="text-sm text-gray-500">Enrollment</p>
                            <p className="text-2xl font-bold text-purple-600">{detailedStats.enrollmentCount}</p>
                        </div>
                        <div className="p-4 bg-white rounded-lg border shadow-sm">
                            <p className="text-sm text-gray-500">Avg Completion</p>
                            <p className="text-2xl font-bold text-blue-600">{detailedStats.avgCompletion}%</p>
                        </div>
                        {detailedStats.quizMetrics.length > 0 && (
                            <div className="p-4 bg-white rounded-lg border shadow-sm">
                                <p className="text-sm text-gray-500">Avg Quiz Score</p>
                                <p className="text-2xl font-bold text-amber-600">
                                    {Math.round(detailedStats.quizMetrics.reduce((a,b) => a + b.avgScore, 0) / detailedStats.quizMetrics.length)}%
                                </p>
                            </div>
                        )}
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-8">
                        <div>
                            <h4 className="font-semibold mb-4 text-gray-700 flex items-center gap-2">
                                <TrendingUp className="w-4 h-4" /> Module Completion Rates
                            </h4>
                            <div className="h-64 w-full">
                                <ResponsiveContainer width="100%" height="100%">
                                    <BarChart data={detailedStats.moduleMetrics} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                                        <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                        <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
                                        <YAxis unit="%" fontSize={12} tickLine={false} axisLine={false} />
                                        <Tooltip 
                                            content={({ active, payload }) => {
                                                if (active && payload && payload.length) {
                                                    const data = payload[0].payload;
                                                    return (
                                                        <div className="bg-white p-2 border rounded shadow-lg text-xs">
                                                            <p className="font-bold">{data.fullName}</p>
                                                            <p>Completed by: {data.completedCount} students ({data.completedPercentage}%)</p>
                                                        </div>
                                                    );
                                                }
                                                return null;
                                            }}
                                        />
                                        <Bar dataKey="completedPercentage" fill="#8884d8" radius={[4, 4, 0, 0]}>
                                            {detailedStats.moduleMetrics.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#8b5cf6' : '#a78bfa'} />
                                            ))}
                                        </Bar>
                                    </BarChart>
                                </ResponsiveContainer>
                            </div>
                            <div className="mt-4 space-y-2">
                                <div className="flex items-center gap-2 text-sm text-green-700 bg-green-50 p-2 rounded">
                                    <ArrowUp className="w-4 h-4" />
                                    <span className="font-semibold">Most Successful:</span>
                                    <span>{detailedStats.mostSuccessful?.fullName} ({detailedStats.mostSuccessful?.completedPercentage}%)</span>
                                </div>
                                <div className="flex items-center gap-2 text-sm text-red-700 bg-red-50 p-2 rounded">
                                    <ArrowDown className="w-4 h-4" />
                                    <span className="font-semibold">Needs Attention:</span>
                                    <span>{detailedStats.leastSuccessful?.fullName} ({detailedStats.leastSuccessful?.completedPercentage}%)</span>
                                </div>
                            </div>
                        </div>

                        <div>
                            <h4 className="font-semibold mb-4 text-gray-700 flex items-center gap-2">
                                <Award className="w-4 h-4" /> Quiz Performance
                            </h4>
                            {detailedStats.quizMetrics.length > 0 ? (
                                <div className="h-64 w-full">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <BarChart data={detailedStats.quizMetrics} layout="vertical" margin={{ top: 5, right: 30, left: 40, bottom: 5 }}>
                                            <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                                            <XAxis type="number" unit="%" fontSize={12} tickLine={false} axisLine={false} domain={[0, 100]} />
                                            <YAxis dataKey="name" type="category" fontSize={12} tickLine={false} axisLine={false} width={100} />
                                            <Tooltip
                                                cursor={{fill: 'transparent'}}
                                                content={({ active, payload }) => {
                                                    if (active && payload && payload.length) {
                                                        const data = payload[0].payload;
                                                        return (
                                                            <div className="bg-white p-2 border rounded shadow-lg text-xs">
                                                                <p className="font-bold">{data.fullName}</p>
                                                                <p>Avg Score: {data.avgScore}%</p>
                                                                <p>Attempts: {data.attempts}</p>
                                                            </div>
                                                        );
                                                    }
                                                    return null;
                                                }}
                                            />
                                            <Bar dataKey="avgScore" fill="#f59e0b" radius={[0, 4, 4, 0]} barSize={20} />
                                        </BarChart>
                                    </ResponsiveContainer>
                                </div>
                            ) : (
                                <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg border border-dashed">
                                    <p className="text-gray-500 text-sm">No quizzes in this course</p>
                                </div>
                            )}
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Course Performance List */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-gray-500" />
              Course Overview
            </CardTitle>
            <CardDescription>Select a course for deep dive</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 max-h-[600px] overflow-y-auto">
            <div 
                className={`p-3 rounded-lg border cursor-pointer transition-colors ${selectedCourseId === 'all' ? 'bg-purple-50 border-purple-300' : 'hover:bg-gray-50'}`}
                onClick={() => setSelectedCourseId('all')}
            >
                <div className="flex justify-between items-center">
                    <span className="font-semibold text-sm">All Courses Summary</span>
                    {selectedCourseId === 'all' && <CheckCircle className="w-4 h-4 text-purple-600" />}
                </div>
            </div>
            {courseStats.map(course => (
              <div 
                key={course.id} 
                className={`p-3 rounded-lg border cursor-pointer transition-colors ${selectedCourseId === course.id ? 'bg-purple-50 border-purple-300' : 'hover:bg-gray-50'}`}
                onClick={() => setSelectedCourseId(selectedCourseId === course.id ? 'all' : course.id)}
              >
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-semibold text-sm line-clamp-1">{course.title}</h4>
                  {selectedCourseId === course.id && <CheckCircle className="w-4 h-4 text-purple-600" />}
                </div>
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Students</span>
                    <span className="font-medium">{course.studentCount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Completion Rate</span>
                    <span className="font-medium">{course.completionRate}%</span>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Avg Progress</span>
                      <span className="font-medium">{course.avgProgress}%</span>
                    </div>
                    <Progress value={course.avgProgress} className="h-1.5" />
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Student Progress Table */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <CardTitle>Student Progress</CardTitle>
                <CardDescription>
                  {selectedCourseId === 'all' ? 'All courses' : courses.find(c => c.id === selectedCourseId)?.title}
                </CardDescription>
              </div>
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search student or course..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="border rounded-md">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Course</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Progress</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredProgress.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-8 text-gray-500">
                        No students found matching filters.
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredProgress.map(p => (
                      <TableRow key={p.id}>
                        <TableCell className="font-medium">
                          {p.user_email}
                        </TableCell>
                        <TableCell className="max-w-[150px] truncate" title={p.course_title}>
                          {p.course_title}
                        </TableCell>
                        <TableCell>
                          <Badge variant={p.status === 'completed' ? 'default' : 'secondary'} className={p.status === 'completed' ? 'bg-green-500' : ''}>
                            {p.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="w-[180px]">
                          <div className="flex items-center gap-2">
                            <Progress value={p.progress_percentage} className="h-2" />
                            <span className="text-xs w-8 text-right">{p.progress_percentage}%</span>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}