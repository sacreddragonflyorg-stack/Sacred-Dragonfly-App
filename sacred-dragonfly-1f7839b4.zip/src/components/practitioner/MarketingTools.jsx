import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Package, Tag, Megaphone, Loader2, Plus, Trash, Crown, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

export default function MarketingTools({ practitioner }) {
  const queryClient = useQueryClient();
  const [showPackageForm, setShowPackageForm] = useState(false);
  const [showNominationForm, setShowNominationForm] = useState(false);

  // Fetch Services for Package Creation
  const { data: services = [] } = useQuery({
    queryKey: ['practitioner-services-marketing', practitioner?.service_ids],
    queryFn: () => base44.entities.Service.filter({ is_active: true }),
    enabled: !!practitioner
  });

  const myServices = services.filter(s => practitioner?.service_ids?.includes(s.id));

  // Fetch Practitioner Packages
  const { data: myPackages = [] } = useQuery({
    queryKey: ['my-packages', practitioner?.user_email],
    queryFn: () => base44.entities.ServicePackage.filter({ practitioner_email: practitioner.user_email }),
    enabled: !!practitioner
  });

  // Fetch Nomination Status
  const { data: nominations = [] } = useQuery({
    queryKey: ['my-nominations', practitioner?.user_email],
    queryFn: () => base44.entities.FeaturedNomination.filter({ practitioner_email: practitioner.user_email }),
    enabled: !!practitioner
  });

  const latestNomination = nominations.sort((a,b) => new Date(b.submission_date) - new Date(a.submission_date))[0];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Marketing Tools</h2>
        <p className="text-gray-500">Attract more clients and grow your practice</p>
      </div>

      <Tabs defaultValue="packages" className="space-y-6">
        <TabsList>
          <TabsTrigger value="packages" className="gap-2"><Package className="w-4 h-4" /> Service Packages</TabsTrigger>
          <TabsTrigger value="promotions" className="gap-2"><Tag className="w-4 h-4" /> Promotions</TabsTrigger>
          <TabsTrigger value="featured" className="gap-2"><Crown className="w-4 h-4" /> Featured Status</TabsTrigger>
        </TabsList>

        {/* Packages Tab */}
        <TabsContent value="packages" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Your Bundles</CardTitle>
                <CardDescription>Create custom packages combining your services</CardDescription>
              </div>
              <Button onClick={() => setShowPackageForm(true)}>
                <Plus className="w-4 h-4 mr-2" /> Create Bundle
              </Button>
            </CardHeader>
            <CardContent>
              {myPackages.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Package className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                  <p>You haven't created any packages yet.</p>
                </div>
              ) : (
                <div className="grid md:grid-cols-2 gap-4">
                  {myPackages.map(pkg => (
                    <Card key={pkg.id} className="border bg-gray-50">
                      <CardHeader className="pb-2">
                        <div className="flex justify-between">
                          <CardTitle className="text-lg">{pkg.name}</CardTitle>
                          <Badge variant="outline">${pkg.package_price}</Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-2">{pkg.total_sessions} sessions included</p>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" className="w-full">Edit</Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="text-red-500 hover:text-red-700"
                            onClick={() => {
                                if(confirm('Delete this package?')) {
                                    base44.entities.ServicePackage.delete(pkg.id)
                                    .then(() => queryClient.invalidateQueries(['my-packages']));
                                }
                            }}
                          >
                            <Trash className="w-4 h-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Promotions Tab */}
        <TabsContent value="promotions">
          <Card>
            <CardHeader>
              <CardTitle>Introductory Offers</CardTitle>
              <CardDescription>Set special pricing for first-time clients</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {myServices.map(service => (
                  <ServicePromotionItem key={service.id} service={service} />
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Featured Tab */}
        <TabsContent value="featured">
          <Card className="bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Crown className="w-6 h-6 text-amber-500" />
                <CardTitle>Featured Practitioner Program</CardTitle>
              </div>
              <CardDescription>Get highlighted on the homepage and top of search results</CardDescription>
            </CardHeader>
            <CardContent>
              {practitioner.is_featured ? (
                <div className="flex items-center gap-2 text-green-700 bg-green-100 p-4 rounded-lg">
                  <CheckCircle2 className="w-5 h-5" />
                  <p className="font-semibold">You are currently a Featured Practitioner!</p>
                </div>
              ) : latestNomination && latestNomination.status === 'pending' ? (
                <div className="bg-blue-100 text-blue-700 p-4 rounded-lg">
                  <p className="font-semibold">Application Pending</p>
                  <p className="text-sm mt-1">Submitted on {new Date(latestNomination.submission_date).toLocaleDateString()}</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <p className="text-gray-700">
                    Featured practitioners receive up to 3x more profile views. Apply to be featured if you have consistent high ratings and active availability.
                  </p>
                  <Button onClick={() => setShowNominationForm(true)} className="bg-amber-500 hover:bg-amber-600 text-white">
                    Apply for Featured Status
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Package Form Dialog */}
      <PackageFormDialog 
        open={showPackageForm} 
        onOpenChange={setShowPackageForm} 
        services={myServices}
        practitioner={practitioner}
        onSuccess={() => {
            setShowPackageForm(false);
            queryClient.invalidateQueries(['my-packages']);
        }}
      />

      {/* Nomination Dialog */}
      <NominationDialog
        open={showNominationForm}
        onOpenChange={setShowNominationForm}
        practitioner={practitioner}
        onSuccess={() => {
            setShowNominationForm(false);
            queryClient.invalidateQueries(['my-nominations']);
        }}
      />
    </div>
  );
}

function ServicePromotionItem({ service }) {
    const queryClient = useQueryClient();
    const [enabled, setEnabled] = useState(service.intro_offer_active || false);
    const [price, setPrice] = useState(service.intro_price || service.price * 0.8); // Default 20% off
    
    const updateMutation = useMutation({
        mutationFn: async () => {
            return base44.entities.Service.update(service.id, {
                intro_offer_active: enabled,
                intro_price: enabled ? parseFloat(price) : null
            });
        },
        onSuccess: () => {
            toast.success("Promotion updated");
            queryClient.invalidateQueries(['practitioner-services-marketing']);
        }
    });

    return (
        <div className="flex items-center justify-between p-4 border rounded-lg bg-white">
            <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-semibold">{service.name}</h4>
                    <Badge variant="outline">Regular: ${service.price}</Badge>
                </div>
                {enabled && (
                    <div className="flex items-center gap-2 mt-2">
                        <Label className="text-sm text-gray-500">Intro Price:</Label>
                        <Input 
                            type="number" 
                            className="w-24 h-8" 
                            value={price}
                            onChange={(e) => setPrice(e.target.value)}
                        />
                        <Button size="sm" variant="ghost" onClick={() => updateMutation.mutate()}>Save</Button>
                    </div>
                )}
            </div>
            <div className="flex items-center gap-2">
                <Label htmlFor={`promo-${service.id}`} className={enabled ? "text-green-600 font-medium" : "text-gray-500"}>
                    {enabled ? "Active" : "Inactive"}
                </Label>
                <Switch 
                    id={`promo-${service.id}`}
                    checked={enabled}
                    onCheckedChange={(checked) => {
                        setEnabled(checked);
                        // Auto-save on toggle if disabling, else wait for price confirm
                        if (!checked) setTimeout(() => updateMutation.mutate(), 100); 
                    }}
                />
            </div>
        </div>
    );
}

function PackageFormDialog({ open, onOpenChange, services, practitioner, onSuccess }) {
    const [formData, setFormData] = useState({
        name: "",
        description: "",
        price: "",
        session_count: 3,
        validity_days: 90,
        selected_service: ""
    });

    const createMutation = useMutation({
        mutationFn: async () => {
            const service = services.find(s => s.id === formData.selected_service);
            if (!service) throw new Error("Select a service");

            return base44.entities.ServicePackage.create({
                name: formData.name,
                description: formData.description,
                practitioner_email: practitioner.user_email,
                package_type: "one_time",
                package_price: parseFloat(formData.price),
                total_sessions: parseInt(formData.session_count),
                validity_days: parseInt(formData.validity_days),
                service_ids: [service.id],
                service_names: [service.name],
                is_active: true,
                regular_price: service.price * parseInt(formData.session_count),
                savings: (service.price * parseInt(formData.session_count)) - parseFloat(formData.price)
            });
        },
        onSuccess: () => {
            toast.success("Package created");
            onSuccess();
            setFormData({ name: "", description: "", price: "", session_count: 3, validity_days: 90, selected_service: "" });
        }
    });

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Create Service Bundle</DialogTitle>
                    <DialogDescription>Bundle sessions for a specific service to offer value to clients.</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                    <div className="space-y-2">
                        <Label>Service to Bundle</Label>
                        <Select 
                            value={formData.selected_service} 
                            onValueChange={(val) => setFormData({...formData, selected_service: val})}
                        >
                            <SelectTrigger><SelectValue placeholder="Select Service" /></SelectTrigger>
                            <SelectContent>
                                {services.map(s => <SelectItem key={s.id} value={s.id}>{s.name} (${s.price})</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2">
                        <Label>Package Name</Label>
                        <Input value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="e.g. 3-Session Healing Pack" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label>Number of Sessions</Label>
                            <Input type="number" value={formData.session_count} onChange={e => setFormData({...formData, session_count: e.target.value})} />
                        </div>
                        <div className="space-y-2">
                            <Label>Total Price ($)</Label>
                            <Input type="number" value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} />
                        </div>
                    </div>
                    <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
                    </div>
                </div>
                <DialogFooter>
                    <Button onClick={() => createMutation.mutate()} disabled={createMutation.isPending}>
                        {createMutation.isPending ? <Loader2 className="animate-spin" /> : "Create Bundle"}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

function NominationDialog({ open, onOpenChange, practitioner, onSuccess }) {
    const [reason, setReason] = useState("");

    const submitMutation = useMutation({
        mutationFn: async () => {
            return base44.entities.FeaturedNomination.create({
                practitioner_email: practitioner.user_email,
                practitioner_name: practitioner.display_name,
                reason: reason,
                status: 'pending',
                submission_date: new Date().toISOString()
            });
        },
        onSuccess: () => {
            toast.success("Application submitted!");
            onSuccess();
        }
    });

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Apply for Featured Status</DialogTitle>
                    <DialogDescription>Tell us why you should be featured on the homepage.</DialogDescription>
                </DialogHeader>
                <div className="py-4">
                    <Label>Reason / Pitch</Label>
                    <Textarea 
                        value={reason} 
                        onChange={e => setReason(e.target.value)} 
                        placeholder="I have received 5-star ratings consistently and..."
                        className="h-32"
                    />
                </div>
                <DialogFooter>
                    <Button onClick={() => submitMutation.mutate()} disabled={submitMutation.isPending}>
                        Submit Application
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}