import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar, Clock, Plus, Trash2, Loader2, Save } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import InteractiveBookingCalendar from "../dashboard/InteractiveBookingCalendar";

const DAYS_OF_WEEK = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

export default function AvailabilityManager() {
  const [user, setUser] = useState(null);
  const [availability, setAvailability] = useState({});
  
  // Use query for blocked times instead of user property
  const { data: blockedTimes = [] } = useQuery({
    queryKey: ['blocked-times'],
    queryFn: () => base44.entities.BlockedTime.list(),
    initialData: []
  });

  // Use query for appointments for the calendar view
  const { data: appointments = [] } = useQuery({
    queryKey: ['practitioner-appointments-cal'],
    queryFn: () => base44.entities.Appointment.filter({ 
      // practitioner_id: user?.id  // Assuming filtering by practitioner if needed, or all for admin
    }),
    enabled: !!user
  });

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      setAvailability(u.availability || {});
    });
  }, []);

  const updateAvailabilityMutation = useMutation({
    mutationFn: async (data) => {
      return base44.auth.updateMe(data);
    },
    onSuccess: (updatedUser) => {
      setUser(updatedUser);
      toast.success("Availability updated!");
    },
    onError: () => {
      toast.error("Failed to update availability");
    }
  });

  const handleTimeChange = (day, type, value) => {
    setAvailability(prev => ({
      ...prev,
      [day]: {
        ...prev[day],
        [type]: value
      }
    }));
  };

  const toggleDayAvailability = (day) => {
    setAvailability(prev => ({
      ...prev,
      [day]: prev[day]?.enabled ? { ...prev[day], enabled: false } : { enabled: true, start: '09:00', end: '17:00' }
    }));
  };

  const saveAvailability = () => {
    updateAvailabilityMutation.mutate({ availability });
  };

  // Removed old blockout functions as we now use the interactive calendar and dedicated entity

  if (!user) {
    return <Loader2 className="w-12 h-12 animate-spin text-purple-600 mx-auto" />;
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="calendar" className="space-y-6">
        <TabsList>
          <TabsTrigger value="calendar">Interactive Calendar</TabsTrigger>
          <TabsTrigger value="weekly">Weekly Schedule Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="calendar">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold text-gray-900">Availability Calendar</h2>
              <p className="text-sm text-gray-500">Click on empty slots to block time instantly.</p>
            </div>
            <InteractiveBookingCalendar 
              appointments={appointments}
              blockedTimes={blockedTimes}
              userEmail={user.email}
            />
          </div>
        </TabsContent>

        <TabsContent value="weekly">
          {/* Weekly Schedule */}
          <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-6 h-6" />
            Weekly Availability
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {DAYS_OF_WEEK.map((day) => (
            <div key={day} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-2 w-32">
                <input
                  type="checkbox"
                  checked={availability[day]?.enabled || false}
                  onChange={() => toggleDayAvailability(day)}
                  className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
                />
                <label className="font-medium text-gray-900 capitalize">{day}</label>
              </div>
              {availability[day]?.enabled && (
                <div className="flex items-center gap-4 flex-1">
                  <div className="flex items-center gap-2">
                    <Label className="text-sm">From</Label>
                    <Input
                      type="time"
                      value={availability[day]?.start || '09:00'}
                      onChange={(e) => handleTimeChange(day, 'start', e.target.value)}
                      className="w-32"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Label className="text-sm">To</Label>
                    <Input
                      type="time"
                      value={availability[day]?.end || '17:00'}
                      onChange={(e) => handleTimeChange(day, 'end', e.target.value)}
                      className="w-32"
                    />
                  </div>
                </div>
              )}
            </div>
          ))}
          <Button
            onClick={saveAvailability}
            disabled={updateAvailabilityMutation.isPending}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600"
          >
            {updateAvailabilityMutation.isPending ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</>
            ) : (
              <><Save className="w-4 h-4 mr-2" /> Save Weekly Schedule</>
            )}
          </Button>
        </CardContent>
      </Card>

      </TabsContent>
      </Tabs>

      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <Clock className="w-5 h-5 text-blue-600 mt-0.5" />
            <div className="text-sm text-gray-700">
              <p className="font-semibold mb-1">About Availability</p>
              <p>Your availability settings help clients know when to book sessions. Blocked periods will prevent new bookings during those times.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}