import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, ExternalLink, DollarSign, CheckCircle2, AlertCircle, Building, Wallet, TrendingUp } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

export default function PractitionerPayouts({ practitioner }) {
  const [loading, setLoading] = useState(false);
  const queryClient = useQueryClient();

  // Fetch Payout History
  const { data: payouts = [] } = useQuery({
    queryKey: ['practitioner-payouts', practitioner?.id],
    queryFn: () => practitioner ? base44.entities.PractitionerPayout.filter({ practitioner_id: practitioner.id }, '-payout_date') : [],
    enabled: !!practitioner
  });

  // Fetch Pending Earnings (Completed appointments pending payout)
  const { data: pendingAppointments = [] } = useQuery({
      queryKey: ['pending-earnings', practitioner?.id],
      queryFn: async () => {
          if (!practitioner) return [];
          // Note: Filtering by two fields isn't always direct in client SDK depending on backend, but let's try or filter client side
          const all = await base44.entities.Appointment.filter({ practitioner_id: practitioner.id });
          return all.filter(a => a.status === 'completed' && a.payout_status === 'pending');
      },
      enabled: !!practitioner
  });

  const pendingBalance = pendingAppointments.reduce((sum, a) => sum + (a.practitioner_earnings || 0), 0);

  // Check Stripe Status if account exists
  const { data: stripeStatus } = useQuery({
      queryKey: ['stripe-status', practitioner?.stripe_account_id],
      queryFn: async () => {
          if (!practitioner?.stripe_account_id) return null;
          const { data } = await base44.functions.invoke('stripeConnectManager', { 
              action: 'checkStatus', 
              stripeAccountId: practitioner.stripe_account_id 
          });
          return data;
      },
      enabled: !!practitioner?.stripe_account_id
  });

  const createAccountMutation = useMutation({
    mutationFn: async () => {
      const { data } = await base44.functions.invoke('stripeConnectManager', { 
          action: 'createAccount',
          origin: window.location.origin
      });
      return data;
    },
    onSuccess: (data) => {
      if (data.url) {
          window.location.href = data.url;
      }
    },
    onError: () => toast.error("Failed to start onboarding")
  });

  const getLoginLinkMutation = useMutation({
      mutationFn: async () => {
          const { data } = await base44.functions.invoke('stripeConnectManager', { 
              action: 'getLoginLink',
              stripeAccountId: practitioner.stripe_account_id
          });
          return data;
      },
      onSuccess: (data) => {
          if (data.url) window.open(data.url, '_blank');
      }
  });

  if (!practitioner) return <Loader2 className="animate-spin" />;

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        {/* Account Status Card */}
        <Card className="border-2 border-purple-100">
            <CardHeader>
            <CardTitle className="flex items-center gap-2">
                <Building className="w-5 h-5 text-purple-600" />
                Payout Account
            </CardTitle>
            <CardDescription>Manage your banking details</CardDescription>
            </CardHeader>
            <CardContent>
            {!practitioner.stripe_account_id ? (
                <div className="text-center py-6 space-y-4">
                <div className="bg-purple-50 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                    <DollarSign className="w-8 h-8 text-purple-600" />
                </div>
                <div>
                    <h3 className="font-semibold text-lg">Setup Payouts</h3>
                    <p className="text-gray-500 max-w-md mx-auto text-sm">
                    Connect your bank account via Stripe to receive payouts.
                    </p>
                </div>
                <Button 
                    onClick={() => createAccountMutation.mutate()} 
                    disabled={createAccountMutation.isPending}
                    className="bg-purple-600 hover:bg-purple-700 w-full"
                >
                    {createAccountMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                    Connect Stripe Account
                </Button>
                </div>
            ) : (
                <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="font-medium text-gray-900 text-sm">Status</span>
                    {stripeStatus?.payouts_enabled ? (
                        <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                        <CheckCircle2 className="w-3 h-3 mr-1" /> Active
                        </Badge>
                    ) : (
                        <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
                        <AlertCircle className="w-3 h-3 mr-1" /> Pending
                        </Badge>
                    )}
                </div>
                <div className="flex flex-col gap-2">
                    {!stripeStatus?.payouts_enabled && (
                    <Button 
                        variant="outline" 
                        onClick={() => createAccountMutation.mutate()}
                        disabled={createAccountMutation.isPending}
                        className="w-full"
                    >
                        Complete Setup
                    </Button>
                    )}
                    <Button 
                        variant="outline"
                        onClick={() => getLoginLinkMutation.mutate()}
                        disabled={getLoginLinkMutation.isPending}
                        className="w-full"
                    >
                        Stripe Dashboard <ExternalLink className="w-4 h-4 ml-2" />
                    </Button>
                </div>
                </div>
            )}
            </CardContent>
        </Card>

        {/* Pending Balance Card */}
        <Card className="border-2 border-green-100 bg-green-50/50">
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Wallet className="w-5 h-5 text-green-600" />
                    Pending Balance
                </CardTitle>
                <CardDescription>Earnings scheduled for next payout</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-4xl font-bold text-gray-900">${pendingBalance.toFixed(2)}</span>
                    <span className="text-gray-500">USD</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-green-700 bg-green-100 p-2 rounded">
                    <TrendingUp className="w-4 h-4" />
                    <span>{pendingAppointments.length} sessions completed</span>
                </div>
                <p className="text-xs text-gray-500 mt-4">
                    Payouts are processed weekly. Ensure your Stripe account is active to receive funds.
                </p>
            </CardContent>
        </Card>
      </div>

      {/* Session Earnings Breakdown */}
      {pendingAppointments.length > 0 && (
          <Card>
              <CardHeader>
                  <CardTitle>Recent Session Earnings</CardTitle>
              </CardHeader>
              <CardContent>
                  <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                          <thead className="bg-gray-50 text-gray-600 font-medium">
                              <tr>
                                  <th className="p-3">Date</th>
                                  <th className="p-3">Service</th>
                                  <th className="p-3 text-right">Price</th>
                                  <th className="p-3 text-right">Fee</th>
                                  <th className="p-3 text-right">Net</th>
                              </tr>
                          </thead>
                          <tbody className="divide-y">
                              {pendingAppointments.map(apt => (
                                  <tr key={apt.id}>
                                      <td className="p-3">{format(new Date(apt.appointment_date), 'MMM d')}</td>
                                      <td className="p-3">{apt.service_name}</td>
                                      <td className="p-3 text-right text-gray-500">${apt.price?.toFixed(2)}</td>
                                      <td className="p-3 text-right text-red-400">-${apt.platform_fee_amount?.toFixed(2)}</td>
                                      <td className="p-3 text-right font-bold text-green-600">${apt.practitioner_earnings?.toFixed(2)}</td>
                                  </tr>
                              ))}
                          </tbody>
                      </table>
                  </div>
              </CardContent>
          </Card>
      )}

      {/* Payout History */}
      <Card>
        <CardHeader>
          <CardTitle>Payout History</CardTitle>
        </CardHeader>
        <CardContent>
          {payouts.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No payouts processed yet.
            </div>
          ) : (
            <div className="space-y-4">
              {payouts.map((payout) => (
                <div key={payout.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                  <div className="flex items-center gap-4">
                    <div className="bg-green-100 p-2 rounded-full">
                      <DollarSign className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{payout.description || 'Payout'}</p>
                      <p className="text-sm text-gray-500">
                        {format(new Date(payout.payout_date), 'MMM d, yyyy • h:mm a')}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-gray-900">${payout.amount.toFixed(2)}</p>
                    <Badge className={
                      payout.status === 'paid' ? 'bg-green-100 text-green-800' : 
                      payout.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                      'bg-red-100 text-red-800'
                    }>
                      {payout.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}