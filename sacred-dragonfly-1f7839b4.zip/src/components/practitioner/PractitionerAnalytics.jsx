import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Loader2, TrendingUp, Users, Lightbulb, Calendar, RefreshCw, Star, BarChart3 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function PractitionerAnalytics() {
  const [activeTab, setActiveTab] = useState("trends");

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Practice Analytics</h2>
          <p className="text-gray-500">AI-powered insights to grow your business</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-white p-1 rounded-lg shadow">
          <TabsTrigger value="trends" className="gap-2"><TrendingUp className="w-4 h-4" /> Booking Trends</TabsTrigger>
          <TabsTrigger value="performance" className="gap-2"><Users className="w-4 h-4" /> Performance</TabsTrigger>
          <TabsTrigger value="growth" className="gap-2"><Lightbulb className="w-4 h-4" /> Growth Opportunities</TabsTrigger>
        </TabsList>

        <TabsContent value="trends">
          <BookingTrendsPanel />
        </TabsContent>

        <TabsContent value="performance">
          <PerformancePanel />
        </TabsContent>

        <TabsContent value="growth">
          <GrowthOpportunitiesPanel />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function BookingTrendsPanel() {
  const { data, isLoading, refetch } = useQuery({
    queryKey: ['booking-trends'],
    queryFn: async () => {
      const { data } = await base44.functions.invoke('analyzeBookingTrends');
      return data;
    },
    staleTime: 1000 * 60 * 60, // 1 hour
  });

  if (isLoading) return <LoadingState />;

  if (!data || data.message) return <EmptyState message={data?.message || "No data available"} />;

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <Card className="bg-gradient-to-br from-indigo-50 to-blue-50 border-indigo-100">
        <CardHeader>
          <CardTitle className="text-indigo-900 flex items-center gap-2">
            <Calendar className="w-5 h-5" /> Peak Times
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-indigo-800 text-lg font-medium">{data.peak_times}</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Popular Services</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {data.popular_services?.map((s, i) => (
              <Badge key={i} variant="secondary" className="bg-purple-100 text-purple-800 hover:bg-purple-200">
                {s}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="md:col-span-2">
        <CardHeader>
          <CardTitle>Insights & Patterns</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="font-semibold text-gray-700 mb-1">Service Bundling Trends</h4>
            <p className="text-gray-600">{data.bundling_trends}</p>
          </div>
          <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-100">
            <h4 className="font-semibold text-yellow-800 mb-1 flex items-center gap-2">
              <Lightbulb className="w-4 h-4" /> Actionable Insight
            </h4>
            <p className="text-yellow-900">{data.actionable_insight}</p>
          </div>
        </CardContent>
      </Card>
      
      <div className="md:col-span-2 flex justify-end">
        <Button variant="ghost" size="sm" onClick={refetch}>
          <RefreshCw className="w-4 h-4 mr-2" /> Refresh Data
        </Button>
      </div>
    </div>
  );
}

function PerformancePanel() {
  const { data, isLoading, refetch } = useQuery({
    queryKey: ['practitioner-performance'],
    queryFn: async () => {
      const { data } = await base44.functions.invoke('analyzePractitionerPerformance');
      return data;
    },
    staleTime: 1000 * 60 * 60,
  });

  if (isLoading) return <LoadingState />;

  return (
    <div className="space-y-6">
      <EnrollmentChart />

      <div className="grid md:grid-cols-3 gap-6">
        <Card className="bg-white shadow-sm border-purple-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-500 uppercase tracking-wide">Performance Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <span className="text-5xl font-bold text-purple-600">{data?.performance_score || '-'}</span>
              <span className="text-gray-400">/100</span>
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2 bg-white shadow-sm border-purple-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-500 uppercase tracking-wide">Executive Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700">{data?.executive_summary}</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="border-green-100 bg-green-50/50">
          <CardHeader>
            <CardTitle className="text-green-800 flex items-center gap-2">
              <Star className="w-5 h-5" /> Key Strengths
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {data?.key_strengths?.map((s, i) => (
                <li key={i} className="flex items-start gap-2 text-green-700">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-500 mt-2 shrink-0" />
                  {s}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card className="border-amber-100 bg-amber-50/50">
          <CardHeader>
            <CardTitle className="text-amber-800 flex items-center gap-2">
              <TrendingUp className="w-5 h-5" /> Areas for Growth
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {data?.areas_for_growth?.map((s, i) => (
                <li key={i} className="flex items-start gap-2 text-amber-700">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-2 shrink-0" />
                  {s}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader><CardTitle>Client Retention Insight</CardTitle></CardHeader>
        <CardContent>
          <p className="text-gray-600">{data?.retention_insight}</p>
        </CardContent>
      </Card>
      
      <div className="flex justify-end">
        <Button variant="ghost" size="sm" onClick={refetch}>
          <RefreshCw className="w-4 h-4 mr-2" /> Refresh Analysis
        </Button>
      </div>
    </div>
  );
}

function GrowthOpportunitiesPanel() {
  const { data, isLoading, refetch } = useQuery({
    queryKey: ['growth-opportunities'],
    queryFn: async () => {
      const { data } = await base44.functions.invoke('suggestNewOfferings');
      return data;
    },
    staleTime: 1000 * 60 * 60 * 24, // 24 hours
  });

  if (isLoading) return <LoadingState />;

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-pink-50 to-purple-50 border-none">
        <CardContent className="pt-6">
          <h3 className="font-semibold text-purple-900 mb-2 flex items-center gap-2">
            <TrendingUp className="w-5 h-5" /> Market Insight
          </h3>
          <p className="text-purple-800">{data?.market_insight}</p>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <h3 className="text-lg font-semibold mb-4 text-gray-800">Suggested Services</h3>
          <div className="space-y-4">
            {data?.suggested_services?.map((service, i) => (
              <Card key={i} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-base font-bold text-gray-900">{service.name}</CardTitle>
                    <Badge className={service.expected_demand === 'High' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}>
                      {service.expected_demand} Demand
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-4 text-gray-800">Course Ideas</h3>
          <div className="space-y-4">
            {data?.suggested_courses?.map((course, i) => (
              <Card key={i} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base font-bold text-gray-900">{course.title}</CardTitle>
                  <CardDescription>{course.topic}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 italic">"{course.reason}"</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
      
      <div className="flex justify-end">
        <Button variant="ghost" size="sm" onClick={refetch}>
          <RefreshCw className="w-4 h-4 mr-2" /> Refresh Suggestions
        </Button>
      </div>
    </div>
  );
}

function EnrollmentChart() {
    const { data: courses = [] } = useQuery({
        queryKey: ['practitioner-courses-list-analytics'],
        queryFn: async () => {
            // Fetch courses created by this practitioner (assuming filtered in backend or we fetch all and filter by context)
            // Simplified here: fetching all for overview visualization
            const user = await base44.auth.me();
            const allCourses = await base44.entities.LearningCourse.list();
            return allCourses.filter(c => c.practitioner_email === user.email || c.created_by === user.email);
        }
    });

    const { data: progress = [] } = useQuery({
        queryKey: ['practitioner-progress-analytics-overview'],
        queryFn: () => base44.entities.UserCourseProgress.list(),
        enabled: courses.length > 0
    });

    if (courses.length === 0) return null;

    const data = courses.map(c => ({
        name: c.title.length > 15 ? c.title.substring(0, 15) + '...' : c.title,
        students: progress.filter(p => p.course_id === c.id).length
    })).sort((a,b) => b.students - a.students).slice(0, 5); // Top 5

    return (
        <Card>
            <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-purple-600" /> Top Courses by Enrollment
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="h-[200px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={data} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                            <XAxis type="number" hide />
                            <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 12}} interval={0} />
                            <Tooltip />
                            <Bar dataKey="students" fill="#8b5cf6" radius={[0, 4, 4, 0]} barSize={20} />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </CardContent>
        </Card>
    );
}

function LoadingState() {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-gray-500">
      <Loader2 className="w-8 h-8 animate-spin mb-4 text-purple-600" />
      <p>Analyzing data...</p>
    </div>
  );
}

function EmptyState({ message }) {
  return (
    <div className="text-center py-12 text-gray-500">
      <p>{message}</p>
    </div>
  );
}