import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Eye, MessageCircle } from "lucide-react";
import { format } from "date-fns";
import { motion } from "framer-motion";

const spreadColors = {
  single_card: "from-purple-500 to-pink-500",
  three_card: "from-blue-500 to-purple-500",
  celtic_cross: "from-indigo-500 to-purple-500",
  relationship: "from-pink-500 to-red-500",
  career: "from-amber-500 to-orange-500",
  spiritual_guidance: "from-purple-500 to-indigo-500"
};

export default function ReadingHistory({ readings, onBack, onViewReading }) {
  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex items-center gap-4 mb-8">
        <Button
          onClick={onBack}
          variant="outline"
          className="border-white/30 text-white hover:bg-white/10 backdrop-blur-sm"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <h2 className="text-3xl font-bold text-white">Your Tarot Journey</h2>
      </div>

      {readings.length === 0 ? (
        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-center py-16">
          <CardContent>
            <div className="text-6xl mb-4">🔮</div>
            <h3 className="text-2xl font-semibold text-white mb-2">No Readings Yet</h3>
            <p className="text-purple-200">Start your journey with your first tarot reading</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {readings.map((reading, index) => (
            <motion.div
              key={reading.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card className="group bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/20 transition-all duration-300 hover:scale-[1.02] cursor-pointer">
                <CardContent className="pt-6" onClick={() => onViewReading(reading)}>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      {/* Spread Type Badge */}
                      <div className="mb-3">
                        <Badge className={`bg-gradient-to-r ${spreadColors[reading.spread_type]} text-white border-none`}>
                          {reading.spread_type.replace(/_/g, ' ').toUpperCase()}
                        </Badge>
                      </div>

                      {/* Question */}
                      <h3 className="text-white text-lg font-semibold mb-2 line-clamp-2">
                        {reading.user_question}
                      </h3>

                      {/* Date and Cards */}
                      <div className="flex flex-wrap gap-3 text-sm text-purple-200 mb-3">
                        <span>{format(new Date(reading.created_date), 'MMM d, yyyy')}</span>
                        <span>•</span>
                        <span>{reading.cards_drawn.length} cards</span>
                        {reading.conversation_history && reading.conversation_history.length > 0 && (
                          <>
                            <span>•</span>
                            <span className="flex items-center gap-1">
                              <MessageCircle className="w-3 h-3" />
                              {Math.ceil(reading.conversation_history.length / 2)} follow-ups
                            </span>
                          </>
                        )}
                      </div>

                      {/* Cards Preview */}
                      <div className="flex flex-wrap gap-2">
                        {reading.cards_drawn.slice(0, 5).map((card, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs border-purple-400/50 text-purple-200">
                            {card.card_name}
                            {card.reversed && " (R)"}
                          </Badge>
                        ))}
                        {reading.cards_drawn.length > 5 && (
                          <Badge variant="outline" className="text-xs border-purple-400/50 text-purple-200">
                            +{reading.cards_drawn.length - 5} more
                          </Badge>
                        )}
                      </div>

                      {/* Interpretation Preview */}
                      <p className="text-purple-100 text-sm mt-3 line-clamp-2 opacity-80">
                        {reading.interpretation}
                      </p>
                    </div>

                    {/* View Button */}
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-white/30 text-white hover:bg-white/10 backdrop-blur-sm group-hover:scale-110 transition-transform"
                      onClick={(e) => {
                        e.stopPropagation();
                        onViewReading(reading);
                      }}
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}