import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Sparkles, MessageCircle, Send, Plus, Home, Loader2, Share2 } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import TarotCard from "./TarotCard";

export default function ReadingResult({ reading, onNewReading, onBackToHome, refetchReadings }) {
  const [followUpQuestion, setFollowUpQuestion] = useState("");
  const [conversationHistory, setConversationHistory] = useState(reading.conversation_history || []);
  const [isAsking, setIsAsking] = useState(false);

  const askFollowUpMutation = useMutation({
    mutationFn: async (question) => {
      // Prepare context for AI
      const cardContext = reading.cards_drawn.map(c => 
        `${c.card_name} ${c.reversed ? '(Reversed)' : '(Upright)'} in position: ${c.position}`
      ).join(', ');

      const conversationContext = conversationHistory.length > 0
        ? conversationHistory.map(msg => `${msg.role}: ${msg.content}`).join('\n')
        : '';

      const prompt = `You are a compassionate tarot reader providing follow-up guidance.

Original Question: "${reading.user_question}"
Cards Drawn: ${cardContext}
Original Reading: ${reading.interpretation}

${conversationContext ? `Previous Conversation:\n${conversationContext}\n` : ''}

The querent has a follow-up question: "${question}"

Please provide a thoughtful response that:
1. References the original cards and reading
2. Addresses their specific follow-up question
3. Offers additional insight or clarification
4. Maintains a warm, supportive tone
5. Is 150-250 words

Provide your response as a natural continuation of the conversation.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: prompt
      });

      return result;
    },
    onSuccess: async (answer) => {
      const newHistory = [
        ...conversationHistory,
        {
          role: "user",
          content: followUpQuestion,
          timestamp: new Date().toISOString()
        },
        {
          role: "assistant",
          content: answer,
          timestamp: new Date().toISOString()
        }
      ];

      setConversationHistory(newHistory);

      // Update the reading in database
      await base44.entities.TarotReading.update(reading.id, {
        conversation_history: newHistory
      });

      setFollowUpQuestion("");
      refetchReadings();
      toast.success("Guidance received");
    },
    onError: () => {
      toast.error("Failed to get response. Please try again.");
    }
  });

  const handleAskFollowUp = async () => {
    if (!followUpQuestion.trim()) {
      toast.error("Please enter a question");
      return;
    }

    setIsAsking(true);
    await askFollowUpMutation.mutateAsync(followUpQuestion);
    setIsAsking(false);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header Actions */}
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold text-white">Your Reading</h2>
        <div className="flex gap-3">
          <Button
            onClick={onNewReading}
            variant="outline"
            className="border-white/30 text-white hover:bg-white/10 backdrop-blur-sm"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Reading
          </Button>
          <Button
            onClick={onBackToHome}
            variant="outline"
            className="border-white/30 text-white hover:bg-white/10 backdrop-blur-sm"
          >
            <Home className="w-4 h-4 mr-2" />
            Home
          </Button>
        </div>
      </div>

      {/* Question */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-purple-300 mt-1 flex-shrink-0" />
            <div>
              <div className="text-purple-200 text-sm mb-1">Your Question:</div>
              <div className="text-white text-lg font-medium">{reading.user_question}</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Cards */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardHeader>
          <CardTitle className="text-white">Cards Drawn</CardTitle>
        </CardHeader>
        <CardContent>
          <div className={`grid ${
            reading.cards_drawn.length <= 3 ? 'grid-cols-3' :
            reading.cards_drawn.length <= 5 ? 'md:grid-cols-5' :
            'md:grid-cols-5 lg:grid-cols-5'
          } gap-4`}>
            {reading.cards_drawn.map((cardData, index) => {
              // Find full card data from deck
              const fullCard = { 
                name: cardData.card_name, 
                position: cardData.position,
                reversed: cardData.reversed,
                symbol: "✨",
                arcana: cardData.card_name.includes("Ace") || cardData.card_name.includes("of") ? "Minor" : "Major"
              };
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <TarotCard card={fullCard} />
                </motion.div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Interpretation */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-300" />
            Reading Interpretation
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-purple-100 leading-relaxed whitespace-pre-wrap text-lg">
            {reading.interpretation}
          </div>

          {reading.key_themes && reading.key_themes.length > 0 && (
            <div className="mt-6">
              <div className="text-purple-200 text-sm mb-3">Key Themes:</div>
              <div className="flex flex-wrap gap-2">
                {reading.key_themes.map((theme, idx) => (
                  <Badge key={idx} className="bg-purple-600/50 text-white border-purple-400/50">
                    {theme}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Guidance */}
      {reading.guidance && (
        <Card className="bg-gradient-to-br from-purple-600/20 to-pink-600/20 backdrop-blur-md border-purple-400/30">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-pink-300" />
              Guidance & Next Steps
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-purple-100 leading-relaxed whitespace-pre-wrap">
              {reading.guidance}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Conversation History */}
      {conversationHistory.length > 0 && (
        <Card className="bg-white/10 backdrop-blur-md border-white/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-purple-300" />
              Follow-up Conversation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {conversationHistory.map((message, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg ${
                    message.role === 'user'
                      ? 'bg-purple-600/30 ml-8'
                      : 'bg-pink-600/30 mr-8'
                  }`}
                >
                  <div className="text-xs text-purple-200 mb-1">
                    {message.role === 'user' ? 'Your Question:' : 'Guidance:'}
                  </div>
                  <div className="text-white leading-relaxed">{message.content}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Follow-up Question */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <MessageCircle className="w-5 h-5 text-purple-300" />
            Ask a Follow-up Question
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Textarea
              value={followUpQuestion}
              onChange={(e) => setFollowUpQuestion(e.target.value)}
              placeholder="Ask for clarification or deeper insight about your reading..."
              rows={3}
              className="bg-white/10 border-white/20 text-white placeholder:text-purple-300 resize-none"
            />
            <Button
              onClick={handleAskFollowUp}
              disabled={isAsking || !followUpQuestion.trim()}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              {isAsking ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Receiving Guidance...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Ask Question
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}