import React from "react";
import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";

export default function TarotCard({ card, onClick, showBack = false }) {
  return (
    <motion.div
      whileHover={{ scale: 1.05, y: -10 }}
      className="cursor-pointer"
      onClick={onClick}
    >
      <Card className={`relative overflow-hidden bg-gradient-to-br from-purple-900 to-indigo-900 border-2 border-purple-400/50 shadow-2xl ${
        card.reversed ? 'transform rotate-180' : ''
      }`}>
        <div className="aspect-[2/3] p-4 flex flex-col">
          {showBack ? (
            // Card Back
            <div className="flex-1 flex items-center justify-center bg-gradient-to-br from-purple-600 via-pink-600 to-indigo-600 rounded-lg">
              <div className="text-center">
                <div className="text-6xl mb-2">✨</div>
                <div className="text-white font-serif text-sm">TAROT</div>
              </div>
            </div>
          ) : (
            // Card Front
            <>
              {/* Arcana Type */}
              <div className="text-xs text-purple-300 mb-2 font-medium uppercase tracking-wider">
                {card.arcana}
              </div>

              {/* Card Image/Icon Area */}
              <div className="flex-1 flex items-center justify-center bg-gradient-to-br from-purple-800/50 to-pink-800/50 rounded-lg mb-3 relative overflow-hidden">
                <div className="absolute inset-0 opacity-20">
                  <div className="w-full h-full bg-gradient-to-br from-white to-transparent"></div>
                </div>
                <div className="relative text-center">
                  <div className="text-5xl mb-2">{card.symbol}</div>
                  {card.number !== null && (
                    <div className="text-purple-200 font-serif text-lg">{card.number}</div>
                  )}
                </div>
              </div>

              {/* Card Name */}
              <div className="text-center">
                <div className="text-white font-serif text-sm font-bold mb-1">
                  {card.name}
                </div>
                <div className="text-xs text-purple-300">
                  {card.position}
                </div>
                {card.reversed && (
                  <div className="text-xs text-pink-400 mt-1 font-medium">
                    (Reversed)
                  </div>
                )}
              </div>

              {/* Decorative Elements */}
              <div className="absolute top-2 left-2 text-purple-400">✦</div>
              <div className="absolute top-2 right-2 text-purple-400">✦</div>
              <div className="absolute bottom-2 left-2 text-purple-400">✦</div>
              <div className="absolute bottom-2 right-2 text-purple-400">✦</div>
            </>
          )}
        </div>
      </Card>

      {/* Position Label Below Card */}
      {card.position && !showBack && (
        <div className="text-center mt-2">
          <div className="text-purple-200 text-xs font-medium">{card.position}</div>
        </div>
      )}
    </motion.div>
  );
}