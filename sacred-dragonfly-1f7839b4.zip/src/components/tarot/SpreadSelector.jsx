import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Sparkles, Heart, Briefcase, Compass } from "lucide-react";
import { motion } from "framer-motion";

const spreads = [
  {
    id: "single_card",
    name: "Single Card",
    icon: Sparkles,
    description: "Quick insight or daily guidance",
    positions: ["Your Message"],
    cardCount: 1,
    color: "from-purple-500 to-pink-500"
  },
  {
    id: "three_card",
    name: "Three Card Spread",
    icon: Compass,
    description: "Past, Present, Future or Situation, Action, Outcome",
    positions: ["Past/Situation", "Present/Action", "Future/Outcome"],
    cardCount: 3,
    color: "from-blue-500 to-purple-500"
  },
  {
    id: "celtic_cross",
    name: "Celtic Cross",
    icon: Sparkles,
    description: "Comprehensive 10-card spread for deep insight",
    positions: [
      "Present", "Challenge", "Past", "Future", "Above",
      "Below", "Advice", "External", "Hopes/Fears", "Outcome"
    ],
    cardCount: 10,
    color: "from-indigo-500 to-purple-500"
  },
  {
    id: "relationship",
    name: "Relationship Spread",
    icon: Heart,
    description: "Insights into love, partnership, and connections",
    positions: ["You", "Them", "Connection", "Challenge", "Outcome"],
    cardCount: 5,
    color: "from-pink-500 to-red-500"
  },
  {
    id: "career",
    name: "Career Path",
    icon: Briefcase,
    description: "Guidance on professional matters and ambitions",
    positions: ["Current Situation", "Obstacles", "Strengths", "Action", "Outcome"],
    cardCount: 5,
    color: "from-amber-500 to-orange-500"
  },
  {
    id: "spiritual_guidance",
    name: "Spiritual Guidance",
    icon: Compass,
    description: "Connection to higher self and spiritual path",
    positions: ["Current State", "Blockage", "Lesson", "Path Forward", "Higher Guidance"],
    cardCount: 5,
    color: "from-purple-500 to-indigo-500"
  }
];

export default function SpreadSelector({ onSelectSpread, onBack }) {
  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex items-center gap-4 mb-8">
        <Button
          onClick={onBack}
          variant="outline"
          className="border-white/30 text-white hover:bg-white/10 backdrop-blur-sm"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <h2 className="text-3xl font-bold text-white">Choose Your Spread</h2>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {spreads.map((spread, index) => (
          <motion.div
            key={spread.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card
              className="group cursor-pointer bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/20 transition-all duration-300 hover:scale-105 hover:shadow-2xl"
              onClick={() => onSelectSpread(spread)}
            >
              <CardHeader>
                <div className={`w-16 h-16 bg-gradient-to-br ${spread.color} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <spread.icon className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-white text-xl">{spread.name}</CardTitle>
                <p className="text-purple-200 text-sm">{spread.description}</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="text-xs text-purple-300 font-medium">
                    {spread.cardCount} {spread.cardCount === 1 ? 'Card' : 'Cards'}
                  </div>
                  <div className="text-xs text-purple-200">
                    Positions: {spread.positions.slice(0, 3).join(", ")}
                    {spread.positions.length > 3 && "..."}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}