import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Sparkles, Shuffle, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

import TarotCard from "./TarotCard";
import { TAROT_DECK } from "./TarotDeck";

export default function CardSpread({ spread, user, onReadingComplete, onBack }) {
  const [question, setQuestion] = useState("");
  const [drawnCards, setDrawnCards] = useState([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentStep, setCurrentStep] = useState('question'); // question, drawing, complete

  const handleDrawCards = () => {
    if (!question.trim()) {
      toast.error("Please enter your question first");
      return;
    }

    setIsDrawing(true);
    setCurrentStep('drawing');

    // Shuffle and draw cards
    const shuffled = [...TAROT_DECK].sort(() => Math.random() - 0.5);
    const drawn = shuffled.slice(0, spread.cardCount).map((card, index) => ({
      ...card,
      position: spread.positions[index],
      reversed: Math.random() > 0.5,
      index
    }));

    // Animate card drawing
    setTimeout(() => {
      setDrawnCards(drawn);
      setIsDrawing(false);
    }, 1500);
  };

  const handleGenerateReading = async () => {
    setIsGenerating(true);

    try {
      // Prepare card details for AI
      const cardDetails = drawnCards.map(card => ({
        name: card.name,
        position: card.position,
        reversed: card.reversed,
        keywords: card.keywords,
        meaning: card.reversed ? card.reversed_meaning : card.upright_meaning
      }));

      // Generate interpretation using AI
      const prompt = `You are a wise and compassionate tarot reader with deep knowledge of tarot symbolism and interpretation.

User's Question: "${question}"

Spread Type: ${spread.name}
Cards Drawn:
${cardDetails.map((card, i) => `
${i + 1}. Position: ${card.position}
   Card: ${card.name} ${card.reversed ? '(Reversed)' : '(Upright)'}
   Keywords: ${card.keywords.join(', ')}
   Core Meaning: ${card.meaning}
`).join('\n')}

Please provide a comprehensive, insightful tarot reading that:
1. Addresses the user's specific question
2. Interprets each card in its position and how it relates to the question
3. Weaves the cards together into a cohesive narrative
4. Offers practical guidance and wisdom
5. Maintains a warm, supportive, and mystical tone
6. Is between 300-500 words

Structure your response as:
- Opening: Acknowledge their question
- Card Interpretations: Explain each card's meaning in context
- Overall Message: Synthesize the reading
- Guidance: Practical advice moving forward`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            interpretation: {
              type: "string",
              description: "The full tarot reading interpretation"
            },
            guidance: {
              type: "string",
              description: "Practical guidance and next steps"
            },
            key_themes: {
              type: "array",
              items: { type: "string" },
              description: "3-5 key themes from the reading"
            }
          }
        }
      });

      // Save the reading
      const reading = await base44.entities.TarotReading.create({
        user_question: question,
        spread_type: spread.id,
        cards_drawn: drawnCards.map(c => ({
          card_name: c.name,
          position: c.position,
          reversed: c.reversed
        })),
        interpretation: result.interpretation,
        guidance: result.guidance,
        conversation_history: [],
        is_public: false
      });

      onReadingComplete({ ...reading, key_themes: result.key_themes });
    } catch (error) {
      toast.error("Failed to generate reading. Please try again.");
      console.error(error);
    }

    setIsGenerating(false);
  };

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Button
          onClick={onBack}
          variant="outline"
          className="border-white/30 text-white hover:bg-white/10 backdrop-blur-sm"
          disabled={isDrawing || isGenerating}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <div>
          <h2 className="text-3xl font-bold text-white">{spread.name}</h2>
          <p className="text-purple-200">{spread.description}</p>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {/* Step 1: Question Input */}
        {currentStep === 'question' && (
          <motion.div
            key="question"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <Card className="bg-white/10 backdrop-blur-md border-white/20 max-w-2xl mx-auto">
              <CardHeader>
                <CardTitle className="text-white text-2xl flex items-center gap-2">
                  <Sparkles className="w-6 h-6 text-purple-300" />
                  Set Your Intention
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label className="text-purple-200">What question brings you to the cards today?</Label>
                  <Textarea
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    placeholder="Ask a question or state your intention... (e.g., 'What do I need to know about my career path?' or 'Guide me through this decision')"
                    rows={4}
                    className="bg-white/10 border-white/20 text-white placeholder:text-purple-300 resize-none"
                  />
                </div>

                <Button
                  onClick={handleDrawCards}
                  disabled={!question.trim()}
                  size="lg"
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  <Shuffle className="w-5 h-5 mr-2" />
                  Draw Cards
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Step 2: Card Drawing */}
        {currentStep === 'drawing' && (
          <motion.div
            key="drawing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="text-center py-20"
          >
            {isDrawing ? (
              <>
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  className="w-24 h-24 mx-auto mb-6"
                >
                  <Sparkles className="w-24 h-24 text-purple-300" />
                </motion.div>
                <h3 className="text-2xl font-bold text-white mb-2">Shuffling the Cards...</h3>
                <p className="text-purple-200">The universe is aligning your cards</p>
              </>
            ) : (
              <div className="space-y-8">
                <div>
                  <h3 className="text-3xl font-bold text-white mb-4">Your Cards Have Been Drawn</h3>
                  <p className="text-purple-200 mb-2">Question: {question}</p>
                </div>

                {/* Card Display */}
                <div className={`grid ${
                  spread.cardCount === 1 ? 'grid-cols-1 max-w-xs mx-auto' :
                  spread.cardCount <= 3 ? 'grid-cols-3 max-w-3xl mx-auto' :
                  spread.cardCount <= 5 ? 'md:grid-cols-5 max-w-5xl mx-auto' :
                  'md:grid-cols-5 lg:grid-cols-5 max-w-6xl mx-auto'
                } gap-6`}>
                  {drawnCards.map((card, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, scale: 0.8, rotateY: 180 }}
                      animate={{ opacity: 1, scale: 1, rotateY: 0 }}
                      transition={{ delay: index * 0.2, duration: 0.5 }}
                    >
                      <TarotCard card={card} />
                    </motion.div>
                  ))}
                </div>

                <Button
                  onClick={handleGenerateReading}
                  disabled={isGenerating}
                  size="lg"
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 px-12"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Channeling Divine Wisdom...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5 mr-2" />
                      Generate Reading
                    </>
                  )}
                </Button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}