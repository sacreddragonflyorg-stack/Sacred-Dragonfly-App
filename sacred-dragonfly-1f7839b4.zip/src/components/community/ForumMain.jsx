import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  MessageCircle, HelpCircle, Trophy, Crown, UserCheck, 
  Lock, ArrowLeft, Plus, MessageSquare, Clock, User, Search
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import ThreadView from "./ThreadView";

const ICONS = {
  MessageCircle, HelpCircle, Trophy, Crown, UserCheck
};

export default function ForumMain({ user, redemptions = [] }) {
  const [currentView, setCurrentView] = useState('categories'); // categories, threads, create, thread_detail
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedThreadId, setSelectedThreadId] = useState(null);
  const queryClient = useQueryClient();

  const { data: categories = [], isLoading: catsLoading } = useQuery({
    queryKey: ['forum-categories'],
    queryFn: () => base44.entities.ForumCategory.list('order'),
  });

  const { data: threads = [], isLoading: threadsLoading } = useQuery({
    queryKey: ['forum-threads', selectedCategory?.id],
    queryFn: () => selectedCategory ? base44.entities.ForumThread.filter({ category_id: selectedCategory.id }, '-last_reply_at') : [],
    enabled: !!selectedCategory,
  });

  const createThreadMutation = useMutation({
    mutationFn: async (data) => {
      const thread = await base44.entities.ForumThread.create({
        category_id: selectedCategory.id,
        title: data.title,
        content: data.content,
        author_email: user.email,
        author_name: user.full_name,
        last_reply_at: new Date().toISOString(),
        reply_count: 0,
        views: 0
      });
      return thread;
    },
    onSuccess: (thread) => {
      queryClient.invalidateQueries(['forum-threads']);
      setSelectedThreadId(thread.id);
      setCurrentView('thread_detail');
      toast.success("Discussion started!");
    }
  });

  const canAccessCategory = (category) => {
    if (category.access_level === 'public') return true;
    if (user.role === 'admin') return true;
    
    // Check for required perk in active redemptions
    // Note: In PointRedemption entity, item_id stores the perk ID (e.g. 'private_group')
    return redemptions.some(r => 
      r.status === 'active' && 
      (r.redemption_type === 'community_perk' || r.redemption_type === 'content_unlock') && 
      r.item_id === category.required_perk_id
    );
  };

  const handleCategoryClick = (category) => {
    if (!canAccessCategory(category)) {
      toast.error("This section requires a specific reward to access. Check the Rewards tab!");
      return;
    }
    setSelectedCategory(category);
    setCurrentView('threads');
  };

  const handleThreadClick = (threadId) => {
    setSelectedThreadId(threadId);
    setCurrentView('thread_detail');
  };

  // Views
  if (currentView === 'thread_detail') {
    return (
      <ThreadView 
        threadId={selectedThreadId} 
        onBack={() => setCurrentView('threads')}
        user={user}
      />
    );
  }

  if (currentView === 'create') {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" onClick={() => setCurrentView('threads')}>
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to {selectedCategory?.name}
          </Button>
          <h2 className="text-2xl font-bold">Start New Discussion</h2>
        </div>

        <Card>
          <CardContent className="pt-6 space-y-4">
            <form onSubmit={(e) => {
              e.preventDefault();
              const formData = new FormData(e.target);
              createThreadMutation.mutate({
                title: formData.get('title'),
                content: formData.get('content')
              });
            }}>
              <div className="space-y-2">
                <label className="font-medium">Title</label>
                <Input name="title" required placeholder="What's on your mind?" />
              </div>
              <div className="space-y-2">
                <label className="font-medium">Content</label>
                <Textarea name="content" required placeholder="Share your thoughts, questions, or progress..." rows={6} />
              </div>
              <div className="pt-4 flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setCurrentView('threads')}>Cancel</Button>
                <Button type="submit" className="bg-purple-600" disabled={createThreadMutation.isPending}>
                  {createThreadMutation.isPending ? 'Posting...' : 'Post Discussion'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (currentView === 'threads') {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => setCurrentView('categories')}>
              <ArrowLeft className="w-4 h-4 mr-2" /> Categories
            </Button>
            <div>
              <h2 className="text-2xl font-bold flex items-center gap-2">
                {selectedCategory?.name}
                {selectedCategory?.access_level !== 'public' && <Badge variant="secondary"><Lock className="w-3 h-3 mr-1" /> Exclusive</Badge>}
              </h2>
              <p className="text-gray-600">{selectedCategory?.description}</p>
            </div>
          </div>
          <Button onClick={() => setCurrentView('create')} className="bg-purple-600">
            <Plus className="w-4 h-4 mr-2" /> New Discussion
          </Button>
        </div>

        {threadsLoading ? (
          <div className="text-center py-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600 mx-auto"></div></div>
        ) : threads.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900">No discussions yet</h3>
              <p className="text-gray-500 mb-4">Be the first to start a conversation in this category!</p>
              <Button onClick={() => setCurrentView('create')} variant="outline">Start Discussion</Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {threads.map(thread => (
              <Card key={thread.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleThreadClick(thread.id)}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1 min-w-0 mr-4">
                      <div className="flex items-center gap-2 mb-1">
                        {thread.is_pinned && <Badge variant="secondary">Pinned</Badge>}
                        <h3 className="font-semibold text-lg text-gray-900 truncate">{thread.title}</h3>
                      </div>
                      <p className="text-sm text-gray-500 line-clamp-2 mb-2">{thread.content}</p>
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        <span className="flex items-center gap-1"><User className="w-3 h-3" /> {thread.author_name}</span>
                        <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {format(new Date(thread.last_reply_at || thread.created_date), 'MMM d')}</span>
                      </div>
                    </div>
                    <div className="flex flex-col items-end text-sm text-gray-500 gap-1">
                      <span className="flex items-center gap-1"><MessageSquare className="w-4 h-4" /> {thread.reply_count}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    );
  }

  // Categories View
  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
      {catsLoading ? (
        <p>Loading...</p>
      ) : categories.map(category => {
        const Icon = ICONS[category.icon] || MessageCircle;
        const locked = !canAccessCategory(category);
        
        return (
          <Card 
            key={category.id} 
            className={`hover:shadow-lg transition-all cursor-pointer ${locked ? 'opacity-75 bg-gray-50' : 'bg-white'}`}
            onClick={() => handleCategoryClick(category)}
          >
            <CardContent className="pt-6">
              <div className="flex items-start justify-between mb-4">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${locked ? 'bg-gray-200' : 'bg-purple-100'}`}>
                  {locked ? <Lock className="w-6 h-6 text-gray-500" /> : <Icon className="w-6 h-6 text-purple-600" />}
                </div>
                {category.access_level !== 'public' && (
                  <Badge variant={locked ? "outline" : "secondary"}>
                    {category.access_level === 'vip' ? 'VIP Only' : 'Exclusive'}
                  </Badge>
                )}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{category.name}</h3>
              <p className="text-sm text-gray-600 mb-4 h-10 line-clamp-2">{category.description}</p>
              
              <div className="flex items-center justify-between text-sm">
                <span className="text-purple-600 font-medium group-hover:underline">
                  {locked ? 'Unlock Access' : 'Enter Forum'}
                </span>
                {!locked && <ArrowLeft className="w-4 h-4 text-purple-600 rotate-180" />}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}