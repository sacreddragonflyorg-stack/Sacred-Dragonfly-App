import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ArrowLeft, Clock, MessageSquare, ThumbsUp, Reply, User } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";

export default function ThreadView({ threadId, onBack, user }) {
  const queryClient = useQueryClient();
  const [replyContent, setReplyContent] = useState("");

  const { data: thread, isLoading: threadLoading } = useQuery({
    queryKey: ['forum-thread', threadId],
    queryFn: () => base44.entities.ForumThread.get(threadId),
  });

  const { data: posts = [], isLoading: postsLoading } = useQuery({
    queryKey: ['forum-posts', threadId],
    queryFn: () => base44.entities.ForumPost.filter({ thread_id: threadId }, 'created_date'),
  });

  const replyMutation = useMutation({
    mutationFn: async () => {
      const post = await base44.entities.ForumPost.create({
        thread_id: threadId,
        content: replyContent,
        author_email: user.email,
        author_name: user.full_name,
        likes: 0
      });

      // Update thread stats
      await base44.entities.ForumThread.update(threadId, {
        reply_count: (thread.reply_count || 0) + 1,
        last_reply_at: new Date().toISOString()
      });

      return post;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['forum-posts']);
      queryClient.invalidateQueries(['forum-thread']); // to update count
      setReplyContent("");
      toast.success("Reply posted!");
    }
  });

  if (threadLoading) return <div className="p-8 text-center">Loading discussion...</div>;

  return (
    <div className="space-y-6">
      <Button variant="ghost" onClick={onBack} className="mb-4">
        <ArrowLeft className="w-4 h-4 mr-2" /> Back to Threads
      </Button>

      {/* Main Thread Post */}
      <Card className="border-purple-100 shadow-sm">
        <CardHeader className="pb-3">
          <div className="flex justify-between items-start gap-4">
            <h1 className="text-2xl font-bold text-gray-900">{thread.title}</h1>
            <div className="text-xs text-gray-500 whitespace-nowrap">
              {format(new Date(thread.created_date), 'MMM d, yyyy h:mm a')}
            </div>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600 mt-2">
            <Avatar className="w-6 h-6">
              <AvatarFallback className="bg-purple-100 text-purple-700 text-xs">
                {thread.author_name?.[0]}
              </AvatarFallback>
            </Avatar>
            <span className="font-medium">{thread.author_name}</span>
            <span>•</span>
            <span>Original Poster</span>
          </div>
        </CardHeader>
        <CardContent>
          <div className="prose prose-purple max-w-none text-gray-700">
            <ReactMarkdown>{thread.content}</ReactMarkdown>
          </div>
          <div className="flex items-center gap-4 mt-6 pt-4 border-t text-sm text-gray-500">
            <span className="flex items-center gap-1"><MessageSquare className="w-4 h-4" /> {posts.length} replies</span>
            <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> Last active {thread.last_reply_at ? format(new Date(thread.last_reply_at), 'MMM d') : 'Now'}</span>
          </div>
        </CardContent>
      </Card>

      {/* Replies */}
      <div className="space-y-4">
        <h3 className="font-semibold text-gray-900 ml-1">Replies</h3>
        {postsLoading ? (
          <p className="text-center text-gray-500">Loading replies...</p>
        ) : posts.length === 0 ? (
          <p className="text-center text-gray-500 italic py-4">No replies yet. Be the first to share your thoughts!</p>
        ) : (
          posts.map(post => (
            <Card key={post.id} className="bg-gray-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-4">
                  <Avatar className="w-8 h-8 mt-1">
                    <AvatarFallback className="bg-blue-100 text-blue-700 text-xs">
                      {post.author_name?.[0]}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-semibold text-sm">{post.author_name}</span>
                      <span className="text-xs text-gray-500">{format(new Date(post.created_date), 'MMM d, h:mm a')}</span>
                    </div>
                    <div className="prose prose-sm max-w-none text-gray-700">
                      <ReactMarkdown>{post.content}</ReactMarkdown>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Reply Input */}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle className="text-lg">Leave a Reply</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Textarea 
              value={replyContent}
              onChange={(e) => setReplyContent(e.target.value)}
              placeholder="Join the conversation..."
              rows={4}
            />
            <div className="flex justify-end">
              <Button 
                onClick={() => replyMutation.mutate()} 
                disabled={!replyContent.trim() || replyMutation.isPending}
                className="bg-purple-600"
              >
                {replyMutation.isPending ? 'Posting...' : 'Post Reply'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}