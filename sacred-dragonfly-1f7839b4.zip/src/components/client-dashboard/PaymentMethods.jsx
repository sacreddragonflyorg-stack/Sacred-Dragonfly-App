import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CreditCard, Trash2, Check, Plus, Loader2 } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';

// Setup Form Component
const SetupForm = ({ clientSecret, onSuccess, onCancel }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!stripe || !elements) return;

    setLoading(true);
    const result = await stripe.confirmSetup({
      elements,
      confirmParams: {
        return_url: window.location.href, // Not actually redirected if redirect: 'if_required' is default, but needed
      },
      redirect: "if_required"
    });

    if (result.error) {
      toast.error(result.error.message);
      setLoading(false);
    } else {
      onSuccess();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <PaymentElement />
      <div className="flex justify-end gap-2">
        <Button type="button" variant="ghost" onClick={onCancel} disabled={loading}>Cancel</Button>
        <Button type="submit" disabled={!stripe || loading} className="bg-purple-600 text-white">
          {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
          Save Card
        </Button>
      </div>
    </form>
  );
};

export default function PaymentMethods() {
  const queryClient = useQueryClient();
  const [showAddForm, setShowAddForm] = useState(false);
  const [clientSecret, setClientSecret] = useState(null);
  
  // Use public key from secret or env if available, usually passed from backend or env. 
  // For now assuming we can get it from somewhere or hardcoded if user provided it. 
  // Actually, standard way is to have it in env variables in frontend but Base44 provides secrets.
  // I'll assume STRIPE_PUBLISHABLE_KEY is available in frontend env or passed.
  // Wait, frontend env vars are not automatically exposed unless prefixed or using set_secrets?
  // The prompt says "STRIPE_PUBLISHABLE_KEY" is set. 
  // I will assume it's available via process.env or I need to fetch it.
  // In Base44, secrets are backend only. I might need a backend function to get the publishable key?
  // Or usually it is safe to expose publishable key.
  // I'll create a small helper function to get config if needed, or assume user put it in a global const.
  // Actually, best practice: `base44.functions.invoke('getConfig')`?
  // Let's assume for now I can get it. If not, I'll need to ask user or use a backend function to return it.
  // I'll verify if I can read `STRIPE_PUBLISHABLE_KEY` from `process.env` in frontend code? No, usually backend only.
  // I will add a backend function to return public config.
  
  const [stripePromise, setStripePromise] = useState(null);

  const { data: config } = useQuery({
      queryKey: ['stripe-config'],
      queryFn: async () => {
          const { data } = await base44.functions.invoke('getStripeConfig');
          return data;
      }
  });

  useEffect(() => {
      if (config?.publishableKey) {
          setStripePromise(loadStripe(config.publishableKey));
      }
  }, [config]);

  const { data, isLoading } = useQuery({
    queryKey: ['payment-methods'],
    queryFn: async () => {
      const { data } = await base44.functions.invoke('stripeSubscriptionManager', { action: 'listPaymentMethods' });
      return data;
    },
  });

  const createSetupIntentMutation = useMutation({
    mutationFn: async () => {
      const { data } = await base44.functions.invoke('stripeSubscriptionManager', { action: 'createSetupIntent' });
      return data;
    },
    onSuccess: (data) => {
      setClientSecret(data.client_secret);
      setShowAddForm(true);
    }
  });

  const deleteMethodMutation = useMutation({
    mutationFn: async (id) => {
      await base44.functions.invoke('stripeSubscriptionManager', { action: 'detachPaymentMethod', paymentMethodId: id });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['payment-methods']);
      toast.success("Payment method removed");
    }
  });

  const setDefaultMethodMutation = useMutation({
    mutationFn: async (id) => {
      await base44.functions.invoke('stripeSubscriptionManager', { action: 'setDefaultPaymentMethod', paymentMethodId: id });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['payment-methods']);
      toast.success("Default payment method updated");
    }
  });

  const handleAddCard = () => {
      createSetupIntentMutation.mutate();
  };

  const methods = data?.methods || [];
  const defaultMethodId = data?.defaultPaymentMethod;

  if (!stripePromise) return null; // Wait for config

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-purple-600" />
            Payment Methods
          </CardTitle>
          {!showAddForm && (
            <Button size="sm" onClick={handleAddCard}>
              <Plus className="w-4 h-4 mr-2" /> Add Card
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {showAddForm && clientSecret ? (
          <div className="mb-6 p-4 border rounded-lg bg-gray-50">
            <h4 className="font-semibold mb-4">Add New Card</h4>
            <Elements stripe={stripePromise} options={{ clientSecret }}>
              <SetupForm 
                clientSecret={clientSecret} 
                onSuccess={() => {
                  setShowAddForm(false);
                  queryClient.invalidateQueries(['payment-methods']);
                  toast.success("Card added successfully");
                }}
                onCancel={() => setShowAddForm(false)}
              />
            </Elements>
          </div>
        ) : null}

        {isLoading ? (
          <div className="flex justify-center py-8"><Loader2 className="animate-spin text-purple-600" /></div>
        ) : methods.length === 0 ? (
          <p className="text-gray-500 text-center py-4">No payment methods saved.</p>
        ) : (
          <div className="space-y-4">
            {methods.map((method) => (
              <div key={method.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex items-center gap-4">
                  <div className="p-2 bg-gray-100 rounded">
                    <CreditCard className="w-6 h-6 text-gray-600" />
                  </div>
                  <div>
                    <p className="font-semibold capitalize">{method.card.brand} •••• {method.card.last4}</p>
                    <p className="text-sm text-gray-500">Expires {method.card.exp_month}/{method.card.exp_year}</p>
                  </div>
                  {method.id === defaultMethodId && (
                    <Badge className="bg-purple-100 text-purple-700 hover:bg-purple-200">Default</Badge>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {method.id !== defaultMethodId && (
                    <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => setDefaultMethodMutation.mutate(method.id)}
                        title="Set as Default"
                    >
                        Make Default
                    </Button>
                  )}
                  <Button 
                    variant="ghost" 
                    size="icon"
                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                    onClick={() => deleteMethodMutation.mutate(method.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}