import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, Clock, CheckCircle2, XCircle, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format, isFuture, isPast } from "date-fns";

export default function DashboardAppointmentHistory({ appointments = [] }) {
  const upcoming = appointments.filter(apt => 
    isFuture(new Date(apt.appointment_date)) && apt.status !== 'cancelled'
  );
  const past = appointments.filter(apt => 
    isPast(new Date(apt.appointment_date)) || apt.status === 'completed'
  );
  const cancelled = appointments.filter(apt => apt.status === 'cancelled');

  const statusColors = {
    pending: 'bg-yellow-100 text-yellow-800',
    confirmed: 'bg-blue-100 text-blue-800',
    completed: 'bg-green-100 text-green-800',
    cancelled: 'bg-red-100 text-red-800'
  };

  const renderAppointmentList = (list, emptyMessage) => {
    if (list.length === 0) {
      return (
        <div className="text-center py-6">
          <Calendar className="w-10 h-10 text-gray-300 mx-auto mb-2" />
          <p className="text-sm text-gray-500">{emptyMessage}</p>
        </div>
      );
    }

    return (
      <div className="space-y-2 max-h-64 overflow-y-auto">
        {list.slice(0, 5).map((apt) => (
          <div key={apt.id} className="p-3 bg-gray-50 rounded-lg flex items-center justify-between">
            <div className="flex-1">
              <p className="font-medium text-sm text-gray-900">{apt.service_name}</p>
              <p className="text-xs text-gray-600 flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {format(new Date(apt.appointment_date), 'MMM d, yyyy • h:mm a')}
              </p>
            </div>
            <Badge className={statusColors[apt.status] || statusColors.pending}>
              {apt.status}
            </Badge>
          </div>
        ))}
      </div>
    );
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-6 h-6 text-blue-600" />
            Appointments
          </CardTitle>
          <Link to={createPageUrl("MyAppointments")}>
            <Button variant="outline" size="sm">
              View All <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="upcoming" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-4">
            <TabsTrigger value="upcoming" className="text-xs">
              Upcoming ({upcoming.length})
            </TabsTrigger>
            <TabsTrigger value="past" className="text-xs">
              Past ({past.length})
            </TabsTrigger>
            <TabsTrigger value="cancelled" className="text-xs">
              Cancelled ({cancelled.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming">
            {renderAppointmentList(upcoming, "No upcoming appointments")}
            {upcoming.length === 0 && (
              <Link to={createPageUrl("Booking")} className="block mt-3">
                <Button size="sm" className="w-full">Book a Session</Button>
              </Link>
            )}
          </TabsContent>

          <TabsContent value="past">
            {renderAppointmentList(past, "No past appointments")}
          </TabsContent>

          <TabsContent value="cancelled">
            {renderAppointmentList(cancelled, "No cancelled appointments")}
          </TabsContent>
        </Tabs>

        {/* Summary Stats */}
        <div className="grid grid-cols-3 gap-2 mt-4 pt-4 border-t">
          <div className="text-center">
            <p className="text-xl font-bold text-blue-600">{upcoming.length}</p>
            <p className="text-xs text-gray-500">Upcoming</p>
          </div>
          <div className="text-center">
            <p className="text-xl font-bold text-green-600">{past.filter(a => a.status === 'completed').length}</p>
            <p className="text-xs text-gray-500">Completed</p>
          </div>
          <div className="text-center">
            <p className="text-xl font-bold text-gray-600">{appointments.length}</p>
            <p className="text-xs text-gray-500">Total</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}