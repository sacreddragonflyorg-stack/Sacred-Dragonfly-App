import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Settings, User, Mail, Phone, Heart, MapPin, ArrowRight, Edit } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function DashboardPreferences({ user }) {
  if (!user) return null;

  const hasProfile = user.phone || user.address_city || user.healing_intentions;

  return (
    <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-6 h-6 text-gray-600" />
            My Profile & Preferences
          </CardTitle>
          <Link to={createPageUrl("ClientProfile")}>
            <Button variant="outline" size="sm">
              <Edit className="w-4 h-4 mr-2" />
              Edit Profile
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Basic Info */}
        <div className="p-4 bg-gray-50 rounded-lg space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
              <User className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <p className="font-semibold text-gray-900">{user.full_name || 'Not set'}</p>
              <p className="text-sm text-gray-600">{user.email}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-3 border-t">
            <div className="flex items-center gap-2 text-sm">
              <Phone className="w-4 h-4 text-gray-400" />
              <span className={user.phone ? 'text-gray-700' : 'text-gray-400'}>
                {user.phone || 'No phone'}
              </span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Mail className="w-4 h-4 text-gray-400" />
              <span className="text-gray-700">
                {user.preferred_contact_method || 'Email'}
              </span>
            </div>
          </div>

          {user.address_city && (
            <div className="flex items-center gap-2 text-sm pt-2">
              <MapPin className="w-4 h-4 text-gray-400" />
              <span className="text-gray-700">
                {[user.address_city, user.address_state].filter(Boolean).join(', ')}
              </span>
            </div>
          )}
        </div>

        {/* Healing Intentions */}
        {user.healing_intentions ? (
          <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
            <div className="flex items-center gap-2 mb-2">
              <Heart className="w-4 h-4 text-purple-600" />
              <span className="font-medium text-gray-900">Healing Intentions</span>
            </div>
            <p className="text-sm text-gray-700 line-clamp-3">{user.healing_intentions}</p>
          </div>
        ) : (
          <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
            <p className="text-sm text-yellow-800">
              <strong>Complete your profile!</strong> Add your healing intentions to help your practitioner understand your goals.
            </p>
            <Link to={createPageUrl("ClientProfile")}>
              <Button size="sm" variant="outline" className="mt-2">
                Add Intentions
              </Button>
            </Link>
          </div>
        )}

        {/* Quick Links */}
        <div className="grid grid-cols-2 gap-2">
          <Link to={createPageUrl("ReferralProgram")}>
            <Button variant="outline" size="sm" className="w-full text-xs">
              Referral Program
            </Button>
          </Link>
          <Link to={createPageUrl("ClientChat")}>
            <Button variant="outline" size="sm" className="w-full text-xs">
              Messages
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}