import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Package, Calendar, CheckCircle2, ArrowRight, Repeat, Settings, CreditCard, History, AlertTriangle } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format, differenceInDays } from "date-fns";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import PaymentMethods from "./PaymentMethods";
import BillingHistory from "./BillingHistory";

export default function DashboardPackages({ purchases = [], subscriptions = [] }) {
  const queryClient = useQueryClient();
  
  const handleManageSubscription = async () => {
    try {
      toast.loading("Opening billing portal...");
      const { data } = await base44.functions.invoke('createStripeCustomerPortalSession', {
        return_url: window.location.href
      });
      if (data.url) {
        window.location.href = data.url;
      } else {
        toast.error(data.error || "Failed to open portal");
      }
    } catch (error) {
      toast.error("Failed to open billing portal");
    } finally {
      toast.dismiss();
    }
  };

  const cancelSubscriptionMutation = useMutation({
    mutationFn: async (subId) => {
        const { data } = await base44.functions.invoke('stripeSubscriptionManager', { 
            action: 'cancelSubscription', 
            subscriptionId: subId 
        });
        return data;
    },
    onSuccess: () => {
        toast.success("Subscription set to cancel at period end");
        queryClient.invalidateQueries(['client-subscriptions']);
    },
    onError: () => toast.error("Failed to cancel subscription")
  });

  const reactivateSubscriptionMutation = useMutation({
    mutationFn: async (subId) => {
        const { data } = await base44.functions.invoke('stripeSubscriptionManager', { 
            action: 'reactivateSubscription', 
            subscriptionId: subId 
        });
        return data;
    },
    onSuccess: () => {
        toast.success("Subscription reactivated!");
        queryClient.invalidateQueries(['client-subscriptions']);
    },
    onError: () => toast.error("Failed to reactivate subscription")
  });

  const activePackages = purchases.filter(p => p.status === 'active');
  const activeSubscriptions = subscriptions.filter(s => s.status === 'active' || s.status === 'past_due' || (s.status === 'canceled' && new Date(s.current_period_end) > new Date()));
  const pastSubscriptions = subscriptions.filter(s => s.status === 'canceled' && new Date(s.current_period_end) < new Date());

  if (activePackages.length === 0 && activeSubscriptions.length === 0 && pastSubscriptions.length === 0) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="w-6 h-6 text-amber-600" />
            My Packages & Subscriptions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <Package className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 mb-4">No active packages or subscriptions</p>
            <div className="flex gap-3 justify-center">
              <Link to={createPageUrl("Packages")}>
                <Button size="sm" variant="outline">Browse Packages</Button>
              </Link>
              <Link to={createPageUrl("Subscriptions")}>
                <Button size="sm">View Subscriptions</Button>
              </Link>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Package className="w-6 h-6 text-amber-600" />
            My Packages & Subscriptions
          </CardTitle>
          <div className="flex gap-2">
            {activeSubscriptions.length > 0 && (
              <Button variant="ghost" size="sm" onClick={handleManageSubscription}>
                <Settings className="w-4 h-4 mr-2" /> Manage Billing
              </Button>
            )}
            <Link to={createPageUrl("Packages")}>
              <Button variant="outline" size="sm">
                View All <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Active Packages */}
        {activePackages.map((purchase) => {
          const sessionsUsed = purchase.sessions_used || 0;
          const sessionsTotal = purchase.sessions_total || 1;
          const progress = (sessionsUsed / sessionsTotal) * 100;
          const daysLeft = purchase.expiry_date ? differenceInDays(new Date(purchase.expiry_date), new Date()) : null;

          return (
            <div key={purchase.id} className="p-4 bg-amber-50 rounded-lg border border-amber-200">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h4 className="font-semibold text-gray-900">{purchase.package_name}</h4>
                  {purchase.selected_tier && (
                    <Badge variant="outline" className="mt-1">{purchase.selected_tier}</Badge>
                  )}
                </div>
                <Badge className={
                  daysLeft && daysLeft < 7 ? 'bg-red-100 text-red-800' :
                  daysLeft && daysLeft < 30 ? 'bg-yellow-100 text-yellow-800' :
                  'bg-green-100 text-green-800'
                }>
                  {daysLeft ? `${daysLeft} days left` : 'Active'}
                </Badge>
              </div>
              
              <div className="mb-2">
                <div className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>Sessions Used</span>
                  <span>{sessionsUsed} / {sessionsTotal}</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>
              
              {purchase.expiry_date && (
                <p className="text-xs text-gray-500 flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  Expires: {format(new Date(purchase.expiry_date), 'MMM d, yyyy')}
                </p>
              )}
            </div>
          );
        })}

        {/* Active Subscriptions */}
        {activeSubscriptions.map((sub) => (
          <div key={sub.id} className="p-4 bg-purple-50 rounded-lg border border-purple-200">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h4 className="font-semibold text-gray-900 flex items-center gap-2">
                  <Repeat className="w-4 h-4 text-purple-600" />
                  {sub.plan_name}
                </h4>
                <p className="text-sm text-gray-600">${sub.price}/{sub.billing_interval}</p>
              </div>
              <div className="flex gap-2">
                {sub.cancel_at_period_end ? (
                    <Badge className="bg-yellow-100 text-yellow-800">Cancels Soon</Badge>
                ) : (
                    <Badge className="bg-purple-100 text-purple-800">Active</Badge>
                )}
              </div>
            </div>
            
            <div className="mb-4">
              <div className="flex justify-between text-sm text-gray-600 mb-1">
                <span>Sessions This Period</span>
                <span>{sub.sessions_used || 0} / {sub.sessions_total}</span>
              </div>
              <Progress value={((sub.sessions_used || 0) / sub.sessions_total) * 100} className="h-2" />
            </div>
            
            <div className="flex flex-wrap justify-between items-center mt-3 gap-2">
              {sub.current_period_end && (
                <p className="text-xs text-gray-500 flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {sub.cancel_at_period_end ? 'Expires' : 'Renews'}: {format(new Date(sub.current_period_end), 'MMM d, yyyy')}
                </p>
              )}
              <div className="flex gap-2">
                  {sub.cancel_at_period_end ? (
                    <Button 
                        variant="outline" 
                        size="sm" 
                        className="h-8 text-xs text-green-600 border-green-200 hover:bg-green-50"
                        onClick={() => reactivateSubscriptionMutation.mutate(sub.stripe_subscription_id)}
                    >
                        Reactivate
                    </Button>
                  ) : (
                    <Button 
                        variant="outline" 
                        size="sm" 
                        className="h-8 text-xs text-red-600 border-red-200 hover:bg-red-50"
                        onClick={() => {
                            if (window.confirm("Are you sure you want to cancel? You will retain access until the end of the billing period.")) {
                                cancelSubscriptionMutation.mutate(sub.stripe_subscription_id);
                            }
                        }}
                    >
                        Cancel
                    </Button>
                  )}
                  {/* Keep the manage button for advanced stuff (portal) */}
                  <Button variant="ghost" size="sm" className="h-8 text-xs" onClick={handleManageSubscription}>
                    More Options
                  </Button>
              </div>
            </div>
          </div>
        ))}
        
        {/* Past Subscriptions */}
        {pastSubscriptions.length > 0 && (
            <div className="pt-6 border-t">
                <h3 className="font-semibold text-gray-600 mb-4 flex items-center gap-2">
                    <History className="w-4 h-4" /> Past Subscriptions
                </h3>
                <div className="space-y-3">
                    {pastSubscriptions.map(sub => (
                        <div key={sub.id} className="p-3 bg-gray-50 rounded-lg border border-gray-200 flex justify-between items-center opacity-75">
                             <div>
                                <h4 className="font-medium text-gray-700">{sub.plan_name}</h4>
                                <p className="text-xs text-gray-500">Ended on {format(new Date(sub.current_period_end), 'MMM d, yyyy')}</p>
                             </div>
                             <Badge variant="outline">Expired</Badge>
                        </div>
                    ))}
                </div>
            </div>
        )}

        {/* Billing & Payment Methods Sections */}
        <div className="grid lg:grid-cols-2 gap-6 pt-6 border-t">
            <PaymentMethods />
            <BillingHistory />
        </div>

      </CardContent>
    </Card>
  );
}