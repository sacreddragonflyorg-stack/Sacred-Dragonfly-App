import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Download, ExternalLink, Loader2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { format } from "date-fns";

export default function BillingHistory() {
  const { data: invoices, isLoading } = useQuery({
    queryKey: ['billing-history'],
    queryFn: async () => {
      const { data } = await base44.functions.invoke('stripeSubscriptionManager', { action: 'listInvoices' });
      return data.invoices || [];
    },
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl flex items-center gap-2">
          <FileText className="w-5 h-5 text-purple-600" />
          Billing History
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center py-8"><Loader2 className="animate-spin text-purple-600" /></div>
        ) : invoices.length === 0 ? (
          <p className="text-gray-500 text-center py-4">No billing history found.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-gray-500 border-b">
                <tr>
                  <th className="pb-3 pl-2">Date</th>
                  <th className="pb-3">Amount</th>
                  <th className="pb-3">Status</th>
                  <th className="pb-3 text-right pr-2">Receipt</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {invoices.map((invoice) => (
                  <tr key={invoice.id} className="hover:bg-gray-50">
                    <td className="py-3 pl-2 font-medium">
                      {format(new Date(invoice.created * 1000), 'MMM d, yyyy')}
                    </td>
                    <td className="py-3">
                      ${(invoice.amount_paid / 100).toFixed(2)}
                    </td>
                    <td className="py-3">
                      <Badge className={
                        invoice.status === 'paid' ? 'bg-green-100 text-green-800' : 
                        invoice.status === 'open' ? 'bg-yellow-100 text-yellow-800' : 
                        'bg-red-100 text-red-800'
                      }>
                        {invoice.status}
                      </Badge>
                    </td>
                    <td className="py-3 text-right pr-2">
                      {invoice.hosted_invoice_url && (
                        <a href={invoice.hosted_invoice_url} target="_blank" rel="noopener noreferrer">
                          <Button variant="ghost" size="sm" className="h-8">
                            View <ExternalLink className="w-3 h-3 ml-2" />
                          </Button>
                        </a>
                      )}
                      {invoice.invoice_pdf && (
                        <a href={invoice.invoice_pdf} target="_blank" rel="noopener noreferrer">
                          <Button variant="ghost" size="icon" className="h-8 w-8 ml-1">
                            <Download className="w-4 h-4" />
                          </Button>
                        </a>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}