import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { BookOpen, Award, ArrowRight, Lock, Sparkles, Gift } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function DashboardLearning({ user, resources = [] }) {
  const points = user?.learning_points || 0;
  const unlockedIds = user?.unlocked_resources || [];
  
  // Beginner resources are always unlocked
  const unlockedResources = resources.filter(r => 
    r.difficulty_level === 'beginner' || unlockedIds.includes(r.id)
  );
  const lockedResources = resources.filter(r => 
    r.difficulty_level !== 'beginner' && !unlockedIds.includes(r.id)
  );

  const pointTiers = [
    { name: "Beginner", min: 0, color: "bg-gray-100 text-gray-700" },
    { name: "Explorer", min: 50, color: "bg-blue-100 text-blue-700" },
    { name: "Seeker", min: 150, color: "bg-purple-100 text-purple-700" },
    { name: "Master", min: 300, color: "bg-amber-100 text-amber-700" }
  ];

  const currentTier = [...pointTiers].reverse().find(tier => points >= tier.min) || pointTiers[0];
  const nextTier = pointTiers[pointTiers.indexOf(currentTier) + 1];

  return (
    <Card className="bg-white/80 backdrop-blur-sm shadow-xl">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-emerald-600" />
            Learning Progress
          </CardTitle>
          <Link to={createPageUrl("Learning")}>
            <Button variant="outline" size="sm">
              Browse Resources <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Points Overview */}
        <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border border-purple-200">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-purple-600" />
              <span className="font-semibold text-gray-900">Learning Points</span>
            </div>
            <Badge className={currentTier.color}>{currentTier.name}</Badge>
          </div>
          
          <div className="flex items-baseline gap-2 mb-3">
            <span className="text-3xl font-bold text-purple-600">{points}</span>
            <span className="text-sm text-gray-600">points earned</span>
          </div>

          {nextTier && (
            <div>
              <div className="flex justify-between text-sm text-gray-600 mb-1">
                <span>Progress to {nextTier.name}</span>
                <span>{points} / {nextTier.min}</span>
              </div>
              <Progress value={(points / nextTier.min) * 100} className="h-2" />
            </div>
          )}

          <div className="flex gap-2 mt-3">
            <Link to={createPageUrl("PointsRedemption")}>
              <Button size="sm" variant="outline" className="text-xs">
                <Gift className="w-3 h-3 mr-1" />
                Redeem Points
              </Button>
            </Link>
          </div>
        </div>

        {/* Resource Stats */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 bg-green-50 rounded-lg text-center">
            <Sparkles className="w-5 h-5 text-green-600 mx-auto mb-1" />
            <p className="text-2xl font-bold text-gray-900">{unlockedResources.length}</p>
            <p className="text-xs text-gray-600">Resources Unlocked</p>
          </div>
          <div className="p-3 bg-gray-50 rounded-lg text-center">
            <Lock className="w-5 h-5 text-gray-400 mx-auto mb-1" />
            <p className="text-2xl font-bold text-gray-900">{lockedResources.length}</p>
            <p className="text-xs text-gray-600">To Unlock</p>
          </div>
        </div>

        {/* Quick Tip */}
        <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
          <p className="text-sm text-blue-800">
            <strong>Tip:</strong> Complete learning resources to earn points. Redeem 100 points for a $10 session discount!
          </p>
        </div>
      </CardContent>
    </Card>
  );
}