import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Award, Star, Zap, Target, Trophy, Flame, BookOpen, Crown } from "lucide-react";
import { format } from "date-fns";

const BADGE_DEFINITIONS = {
  first_module: { name: "First Steps", icon: "🌱", color: "bg-green-500", description: "Complete your first module" },
  five_modules: { name: "Knowledge Seeker", icon: "📚", color: "bg-blue-500", description: "Complete 5 modules" },
  ten_modules: { name: "Dedicated Learner", icon: "🎓", color: "bg-purple-500", description: "Complete 10 modules" },
  first_course: { name: "Course Graduate", icon: "🏆", color: "bg-amber-500", description: "Complete your first course" },
  three_courses: { name: "Scholar", icon: "👨‍🎓", color: "bg-indigo-500", description: "Complete 3 courses" },
  quiz_master: { name: "Quiz Master", icon: "🧠", color: "bg-pink-500", description: "Pass 5 quizzes with 90%+" },
  perfect_score: { name: "Perfectionist", icon: "💯", color: "bg-yellow-500", description: "Get 100% on any quiz" },
  points_100: { name: "Point Collector", icon: "⭐", color: "bg-cyan-500", description: "Earn 100 points" },
  points_500: { name: "Point Master", icon: "🌟", color: "bg-orange-500", description: "Earn 500 points" },
  points_1000: { name: "Point Legend", icon: "✨", color: "bg-red-500", description: "Earn 1000 points" },
  streak_3: { name: "On Fire", icon: "🔥", color: "bg-orange-600", description: "3-day learning streak" },
  streak_7: { name: "Week Warrior", icon: "⚡", color: "bg-yellow-600", description: "7-day learning streak" },
  streak_30: { name: "Monthly Master", icon: "👑", color: "bg-purple-600", description: "30-day learning streak" },
  early_bird: { name: "Early Bird", icon: "🌅", color: "bg-amber-400", description: "Complete a module before 7am" },
  night_owl: { name: "Night Owl", icon: "🦉", color: "bg-indigo-600", description: "Complete a module after 10pm" },
  challenge_complete: { name: "Challenger", icon: "🎯", color: "bg-teal-500", description: "Complete a challenge" },
  five_challenges: { name: "Challenge Champion", icon: "🏅", color: "bg-rose-500", description: "Complete 5 challenges" },
};

export function BadgeIcon({ badgeId, size = "md" }) {
  const badge = BADGE_DEFINITIONS[badgeId];
  const sizeClasses = {
    sm: "w-8 h-8 text-lg",
    md: "w-12 h-12 text-2xl",
    lg: "w-16 h-16 text-3xl"
  };
  
  return (
    <div className={`${sizeClasses[size]} ${badge?.color || 'bg-gray-400'} rounded-full flex items-center justify-center shadow-lg`}>
      <span>{badge?.icon || '🏅'}</span>
    </div>
  );
}

export default function BadgeDisplay({ badges = [], showAll = false }) {
  const allBadgeIds = Object.keys(BADGE_DEFINITIONS);
  const earnedIds = badges.map(b => b.badge_id);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Award className="w-5 h-5 text-amber-500" />
          Your Badges ({badges.length}/{allBadgeIds.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        {badges.length === 0 ? (
          <p className="text-center text-gray-500 py-4">Complete modules and challenges to earn badges!</p>
        ) : (
          <div className="grid grid-cols-4 md:grid-cols-6 gap-3">
            {badges.map((badge) => (
              <Dialog key={badge.id}>
                <DialogTrigger asChild>
                  <button className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-gray-50 transition-colors">
                    <BadgeIcon badgeId={badge.badge_id} size="md" />
                    <span className="text-xs text-gray-600 text-center line-clamp-1">{badge.badge_name}</span>
                  </button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-3">
                      <BadgeIcon badgeId={badge.badge_id} size="lg" />
                      <div>
                        <p className="text-xl">{badge.badge_name}</p>
                        <p className="text-sm font-normal text-gray-500">{badge.description}</p>
                      </div>
                    </DialogTitle>
                  </DialogHeader>
                  <div className="text-center py-4">
                    <p className="text-sm text-gray-600">
                      Earned on {format(new Date(badge.earned_at), 'MMMM d, yyyy')}
                    </p>
                  </div>
                </DialogContent>
              </Dialog>
            ))}
          </div>
        )}

        {showAll && (
          <div className="mt-6 pt-6 border-t">
            <p className="text-sm font-medium text-gray-700 mb-3">Badges to Earn</p>
            <div className="grid grid-cols-4 md:grid-cols-6 gap-3">
              {allBadgeIds.filter(id => !earnedIds.includes(id)).map(badgeId => {
                const def = BADGE_DEFINITIONS[badgeId];
                return (
                  <div key={badgeId} className="flex flex-col items-center gap-1 p-2 opacity-40">
                    <div className="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center text-2xl grayscale">
                      {def.icon}
                    </div>
                    <span className="text-xs text-gray-500 text-center line-clamp-1">{def.name}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export { BADGE_DEFINITIONS };