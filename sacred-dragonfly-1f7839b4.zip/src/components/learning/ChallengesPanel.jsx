import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Target, Zap, Calendar, Clock, CheckCircle2, Award, Flame } from "lucide-react";
import { format, differenceInHours, differenceInDays } from "date-fns";

export default function ChallengesPanel({ challenges = [], userProgress = [], onJoinChallenge }) {
  const getProgressForChallenge = (challengeId) => 
    userProgress.find(p => p.challenge_id === challengeId);

  const getTimeRemaining = (endDate) => {
    if (!endDate) return null;
    const end = new Date(endDate);
    const now = new Date();
    const hours = differenceInHours(end, now);
    const days = differenceInDays(end, now);
    if (days > 0) return `${days}d left`;
    if (hours > 0) return `${hours}h left`;
    return 'Ending soon';
  };

  const getChallengeIcon = (type) => {
    switch (type) {
      case 'daily': return <Zap className="w-4 h-4 text-amber-500" />;
      case 'weekly': return <Calendar className="w-4 h-4 text-blue-500" />;
      case 'special': return <Flame className="w-4 h-4 text-red-500" />;
      default: return <Target className="w-4 h-4 text-purple-500" />;
    }
  };

  const activeChallenges = challenges.filter(c => c.is_active);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Target className="w-5 h-5 text-purple-600" />
          Learning Challenges
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {activeChallenges.length === 0 ? (
          <p className="text-center text-gray-500 py-6">No active challenges. Check back soon!</p>
        ) : (
          activeChallenges.map(challenge => {
            const progress = getProgressForChallenge(challenge.id);
            const isJoined = !!progress;
            const isCompleted = progress?.status === 'completed';
            const progressPercent = progress 
              ? Math.min(100, (progress.current_progress / challenge.requirement_count) * 100) 
              : 0;
            const timeLeft = getTimeRemaining(challenge.end_date);

            return (
              <div 
                key={challenge.id} 
                className={`p-4 rounded-lg border-2 ${
                  isCompleted ? 'bg-green-50 border-green-300' : 
                  isJoined ? 'bg-purple-50 border-purple-300' : 
                  'bg-white border-gray-200'
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {getChallengeIcon(challenge.challenge_type)}
                    <Badge variant="outline" className="text-xs capitalize">
                      {challenge.challenge_type}
                    </Badge>
                    {timeLeft && (
                      <Badge variant="outline" className="text-xs">
                        <Clock className="w-3 h-3 mr-1" /> {timeLeft}
                      </Badge>
                    )}
                  </div>
                  {isCompleted && (
                    <Badge className="bg-green-500">
                      <CheckCircle2 className="w-3 h-3 mr-1" /> Complete
                    </Badge>
                  )}
                </div>

                <h4 className="font-semibold text-gray-900 mb-1">{challenge.title}</h4>
                <p className="text-sm text-gray-600 mb-3">{challenge.description}</p>

                {isJoined && !isCompleted && (
                  <div className="mb-3">
                    <div className="flex justify-between text-xs text-gray-600 mb-1">
                      <span>Progress</span>
                      <span>{progress.current_progress} / {challenge.requirement_count}</span>
                    </div>
                    <Progress value={progressPercent} className="h-2" />
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4 text-amber-500" />
                    <span className="text-sm font-medium text-amber-700">+{challenge.points_reward} pts</span>
                    {challenge.badge_reward && (
                      <Badge variant="outline" className="text-xs">+Badge</Badge>
                    )}
                  </div>
                  {!isJoined && (
                    <Button size="sm" onClick={() => onJoinChallenge(challenge)}>
                      Join Challenge
                    </Button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}