import React, { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Lock, CheckCircle, PlayCircle, BookOpen, ArrowRight } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

export default function SkillTree({ courses = [], userProgress = [], onStartCourse }) {
  // 1. Build the tree structure
  const treeNodes = useMemo(() => {
    // Map courses by ID for easy access
    const courseMap = new Map(courses.map(c => [c.id, { ...c, children: [], level: 0 }]));
    const roots = [];

    // Identify levels and parent/child relationships
    courses.forEach(course => {
      if (course.prerequisite_course_id && courseMap.has(course.prerequisite_course_id)) {
        courseMap.get(course.prerequisite_course_id).children.push(courseMap.get(course.id));
      } else {
        roots.push(courseMap.get(course.id));
      }
    });

    // Helper to assign levels (BFS)
    const assignLevels = (nodes, currentLevel) => {
      nodes.forEach(node => {
        node.level = currentLevel;
        if (node.children.length > 0) {
          assignLevels(node.children, currentLevel + 1);
        }
      });
    };
    assignLevels(roots, 0);

    // Group by level for rendering
    const levels = [];
    courseMap.forEach(node => {
      if (!levels[node.level]) levels[node.level] = [];
      levels[node.level].push(node);
    });

    return levels;
  }, [courses]);

  // 2. Helper to check status
  const getStatus = (courseId, prerequisiteId) => {
    const progress = userProgress.find(p => p.course_id === courseId);
    if (progress?.status === 'completed') return 'completed';
    if (progress?.status === 'in_progress') return 'in_progress';
    
    // Check prerequisite
    if (prerequisiteId) {
      const prereqProgress = userProgress.find(p => p.course_id === prerequisiteId);
      if (!prereqProgress || prereqProgress.status !== 'completed') return 'locked';
    }
    
    return 'unlocked';
  };

  return (
    <Card className="bg-gradient-to-br from-slate-50 to-purple-50 border-none shadow-none">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-purple-600" />
          Skill Tree
        </CardTitle>
      </CardHeader>
      <CardContent className="p-8 overflow-x-auto">
        <div className="flex flex-col gap-12 min-w-[600px] items-center">
          {treeNodes.map((levelCourses, levelIndex) => (
            <div key={levelIndex} className="relative flex justify-center gap-8 md:gap-16 w-full">
              
              {/* Connector Lines (Vertical) - purely visual decoration for now, can be complex SVG later */}
              {levelIndex > 0 && (
                <div className="absolute -top-8 left-0 right-0 h-8 pointer-events-none" aria-hidden="true">
                  {/* Ideally SVG lines connecting parents to children, simplified here */}
                </div>
              )}

              {levelCourses.map(course => {
                const status = getStatus(course.id, course.prerequisite_course_id);
                const isLocked = status === 'locked';
                const isCompleted = status === 'completed';
                const isInProgress = status === 'in_progress';

                return (
                  <div key={course.id} className="relative flex flex-col items-center group z-10">
                    {/* Node Circle */}
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button
                            onClick={() => !isLocked && onStartCourse(course)}
                            disabled={isLocked}
                            className={`w-16 h-16 md:w-20 md:h-20 rounded-full flex items-center justify-center border-4 transition-all duration-300 shadow-lg ${
                              isCompleted ? "bg-green-100 border-green-500 text-green-600 scale-105" :
                              isInProgress ? "bg-blue-100 border-blue-500 text-blue-600 animate-pulse" :
                              isLocked ? "bg-gray-200 border-gray-300 text-gray-400 cursor-not-allowed grayscale" :
                              "bg-white border-purple-400 text-purple-600 hover:scale-110 hover:border-purple-600"
                            }`}
                          >
                            {isCompleted ? <CheckCircle className="w-8 h-8" /> :
                             isLocked ? <Lock className="w-6 h-6" /> :
                             isInProgress ? <PlayCircle className="w-8 h-8" /> :
                             <BookOpen className="w-6 h-6" />}
                          </button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="font-bold">{course.title}</p>
                          <p className="text-xs text-gray-500">{isLocked ? "Complete prerequisite to unlock" : "Click to view"}</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>

                    {/* Label */}
                    <div className="mt-3 text-center w-32">
                      <p className={`text-sm font-bold leading-tight ${isLocked ? "text-gray-400" : "text-gray-800"}`}>
                        {course.title}
                      </p>
                      {status !== 'locked' && (
                        <Badge variant="outline" className="mt-1 text-[10px] h-5 px-1.5 bg-white/50 backdrop-blur-sm">
                          {status.replace('_', ' ')}
                        </Badge>
                      )}
                    </div>

                    {/* Arrow to next level if it has children (simplified visual) */}
                    {course.children.length > 0 && (
                      <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-gray-300">
                        <ArrowRight className="w-4 h-4 rotate-90" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}