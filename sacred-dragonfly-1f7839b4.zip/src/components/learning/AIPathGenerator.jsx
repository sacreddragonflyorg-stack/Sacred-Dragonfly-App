import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Brain, Sparkles, Target, ArrowRight, RefreshCw, Compass, BookOpen, CheckCircle2, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

export default function AIPathGenerator({ user, courses = [] }) {
  const queryClient = useQueryClient();
  const [isEditing, setIsEditing] = useState(!user.interests || user.interests.length === 0);
  const [formData, setFormData] = useState({
    interests: user.interests || [],
    learning_goals: user.learning_goals || ""
  });

  // Parse existing path if available
  const currentPath = user.ai_learning_path ? JSON.parse(user.ai_learning_path) : null;

  const updateProfileMutation = useMutation({
    mutationFn: async (data) => {
      return base44.auth.updateMe(data);
    },
    onSuccess: () => {
      setIsEditing(false);
      toast.success("Profile updated!");
      // Automatically generate path if none exists
      if (!currentPath) generatePathMutation.mutate();
    }
  });

  const generatePathMutation = useMutation({
    mutationFn: async () => {
      const { data } = await base44.functions.invoke('generateLearningPath');
      return data;
    },
    onSuccess: (data) => {
      // User updates automatically via query invalidation if parent handles it, 
      // but we can also manually update the local user object if needed.
      // Assuming parent component refetches user or we rely on re-render.
      window.location.reload(); // Simple reload to refresh user data for now or use query invalidation
    },
    onError: () => {
      toast.error("Failed to generate path. Please try again.");
    }
  });

  const toggleInterest = (interest) => {
    setFormData(prev => {
      const exists = prev.interests.includes(interest);
      return {
        ...prev,
        interests: exists 
          ? prev.interests.filter(i => i !== interest)
          : [...prev.interests, interest]
      };
    });
  };

  const INTEREST_OPTIONS = [
    "Meditation", "Reiki", "Crystals", "Tarot", "Chakras", 
    "Energy Healing", "Spirituality", "Self-Care", "Manifestation"
  ];

  if (isEditing) {
    return (
      <Card className="bg-gradient-to-br from-indigo-50 to-purple-50 border-indigo-100">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-indigo-900">
            <Compass className="w-5 h-5" />
            Personalize Your Journey
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-700">What topics interest you?</label>
            <div className="flex flex-wrap gap-2">
              {INTEREST_OPTIONS.map(interest => (
                <Badge
                  key={interest}
                  variant={formData.interests.includes(interest) ? "default" : "outline"}
                  className={`cursor-pointer px-3 py-1 ${
                    formData.interests.includes(interest) 
                      ? "bg-indigo-600 hover:bg-indigo-700" 
                      : "bg-white hover:bg-indigo-50 border-indigo-200"
                  }`}
                  onClick={() => toggleInterest(interest)}
                >
                  {interest}
                </Badge>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">What is your main learning goal?</label>
            <Input 
              value={formData.learning_goals}
              onChange={(e) => setFormData(prev => ({ ...prev, learning_goals: e.target.value }))}
              placeholder="e.g., To become a certified healer, to reduce stress..."
              className="bg-white"
            />
          </div>

          <div className="flex justify-end gap-2">
            {user.interests && (
              <Button variant="ghost" onClick={() => setIsEditing(false)}>Cancel</Button>
            )}
            <Button 
              onClick={() => updateProfileMutation.mutate(formData)}
              disabled={updateProfileMutation.isPending}
              className="bg-indigo-600"
            >
              {updateProfileMutation.isPending ? 'Saving...' : 'Save & Generate Path'}
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-indigo-500" />
          Your AI Learning Path
        </h2>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
            Edit Preferences
          </Button>
          <Button 
            size="sm" 
            onClick={() => generatePathMutation.mutate()}
            disabled={generatePathMutation.isPending}
            className="bg-indigo-600"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${generatePathMutation.isPending ? 'animate-spin' : ''}`} />
            {generatePathMutation.isPending ? 'Analyzing...' : 'Refresh Path'}
          </Button>
        </div>
      </div>

      {!currentPath ? (
        <Card className="border-dashed py-12 text-center">
          <CardContent>
            <Brain className="w-12 h-12 text-indigo-200 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900">No path generated yet</h3>
            <p className="text-gray-500 mb-6">Let our AI analyze your profile and suggest the best next steps.</p>
            <Button onClick={() => generatePathMutation.mutate()} className="bg-indigo-600">
              Generate My Path
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-3 gap-6">
          {/* Main Focus */}
          <Card className="md:col-span-2 bg-gradient-to-br from-white to-indigo-50 border-indigo-100 shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-indigo-900">
                <Target className="w-5 h-5" />
                Current Focus: {currentPath.theme}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-gray-700">{currentPath.theme_description}</p>
              
              <div>
                <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-indigo-500" /> Recommended Courses
                </h4>
                <div className="space-y-3">
                  {currentPath.recommended_courses?.map((rec, idx) => {
                    const course = courses.find(c => c.id === rec.course_id);
                    return (
                      <div key={idx} className="bg-white p-4 rounded-lg border border-indigo-100 shadow-sm flex justify-between items-center group hover:shadow-md transition-all">
                        <div>
                          <p className="font-medium text-indigo-900">{course?.title || "Recommended Course"}</p>
                          <p className="text-sm text-gray-600">{rec.reason}</p>
                        </div>
                        <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-indigo-500 transition-colors" />
                      </div>
                    );
                  })}
                </div>
              </div>

              {currentPath.suggested_challenge && (
                <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
                  <h4 className="font-semibold text-amber-900 mb-1 flex items-center gap-2">
                    <Sparkles className="w-4 h-4" /> Challenge: {currentPath.suggested_challenge.title}
                  </h4>
                  <p className="text-sm text-amber-800">{currentPath.suggested_challenge.description}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Insights Column */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Brain className="w-5 h-5 text-purple-500" />
                  Skill Insights
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {currentPath.skill_insights?.map((insight, idx) => (
                  <div key={idx} className="text-sm">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium text-gray-700 capitalize">{insight.area}</span>
                      <Badge variant={
                        insight.status === 'strong' ? 'default' : 
                        insight.status === 'developing' ? 'secondary' : 'outline'
                      } className={
                        insight.status === 'strong' ? 'bg-green-100 text-green-800' :
                        insight.status === 'developing' ? 'bg-blue-100 text-blue-800' :
                        'bg-orange-100 text-orange-800'
                      }>
                        {insight.status}
                      </Badge>
                    </div>
                    <p className="text-gray-500 text-xs">{insight.advice}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            <div className="text-center">
              <p className="text-xs text-gray-400">
                Last updated: {user.last_path_generated ? format(new Date(user.last_path_generated), 'MMM d, h:mm a') : 'Never'}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}