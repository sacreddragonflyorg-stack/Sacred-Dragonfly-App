import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { CheckCircle2, XCircle, Award, Clock, ArrowRight, RotateCcw, Trophy, GripVertical } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';

// Helper function for reordering
const reorder = (list, startIndex, endIndex) => {
  const result = Array.from(list);
  const [removed] = result.splice(startIndex, 1);
  result.splice(endIndex, 0, removed);
  return result;
};

export default function QuizComponent({ quiz, onComplete, onClose }) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [showResults, setShowResults] = useState(false);
  const [timeLeft, setTimeLeft] = useState(quiz.time_limit_minutes ? quiz.time_limit_minutes * 60 : null);

  // Timer
  useEffect(() => {
    if (timeLeft === null || timeLeft <= 0 || showResults) return;
    const timer = setInterval(() => setTimeLeft(t => t - 1), 1000);
    return () => clearInterval(timer);
  }, [timeLeft, showResults]);

  useEffect(() => {
    if (timeLeft === 0) handleSubmit();
  }, [timeLeft]);

  const question = quiz.questions[currentQuestion];
  const totalQuestions = quiz.questions.length;
  const progress = ((currentQuestion + 1) / totalQuestions) * 100;

  const handleAnswer = (value) => {
    setAnswers({ ...answers, [currentQuestion]: value });
  };

  const handleNext = () => {
    if (currentQuestion < totalQuestions - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const handleSubmit = () => {
    setShowResults(true);
  };

  const calculateScore = () => {
    let correct = 0;
    let total = 0;
    quiz.questions.forEach((q, idx) => {
      if (q.type !== 'reflection') {
        total++;
        const userAnswer = answers[idx];
        
        if (q.type === 'multiple_choice' || q.type === 'true_false') {
          if (userAnswer === q.correct_answer) correct++;
        } else if (q.type === 'fill_in_the_blank') {
          // Check if all blanks are correct (case insensitive)
          const isCorrect = q.correct_answers.every((ans, i) => 
            userAnswer?.[i]?.trim().toLowerCase() === ans.trim().toLowerCase()
          );
          if (isCorrect) correct++;
        } else if (q.type === 'matching') {
            // Check if user's right-side order matches the pairs
            const correctOrder = q.pairs.map(p => p.right);
            const isCorrect = JSON.stringify(userAnswer) === JSON.stringify(correctOrder);
            if (isCorrect) correct++;
        }
      }
    });
    return { correct, total, percentage: total > 0 ? Math.round((correct / total) * 100) : 100 };
  };

  const score = calculateScore();
  const passed = score.percentage >= quiz.passing_score;

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const onDragEnd = (result) => {
    if (!result.destination) return;

    const currentItems = answers[currentQuestion] || question.pairs.map(p => p.right); // Fallback if not set yet
    const items = reorder(
      currentItems,
      result.source.index,
      result.destination.index
    );

    handleAnswer(items);
  };

  // Initialize matching items randomly if not set
  useEffect(() => {
    if (question.type === 'matching' && !answers[currentQuestion]) {
        // Shuffle right side items
        const shuffled = [...question.pairs.map(p => p.right)].sort(() => Math.random() - 0.5);
        handleAnswer(shuffled);
    }
  }, [currentQuestion, question]);


  if (showResults) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardContent className="pt-8 text-center space-y-6">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className={`w-24 h-24 mx-auto rounded-full flex items-center justify-center ${passed ? 'bg-green-100' : 'bg-red-100'}`}
          >
            {passed ? (
              <Trophy className="w-12 h-12 text-green-600" />
            ) : (
              <XCircle className="w-12 h-12 text-red-600" />
            )}
          </motion.div>

          <div>
            <h2 className="text-3xl font-bold text-gray-900">
              {passed ? 'Congratulations!' : 'Keep Learning!'}
            </h2>
            <p className="text-gray-600 mt-2">
              {passed ? 'You passed the quiz!' : `You need ${quiz.passing_score}% to pass.`}
            </p>
          </div>

          <div className="text-5xl font-bold text-purple-600">
            {score.percentage}%
          </div>
          <p className="text-gray-600">
            {score.correct} out of {score.total} correct
          </p>

          {passed && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <Award className="w-8 h-8 text-amber-500 mx-auto mb-2" />
              <p className="font-semibold text-amber-800">+{quiz.points_reward} Points Earned!</p>
            </div>
          )}

          <div className="flex gap-3 pt-4">
            {!passed && (
              <Button onClick={() => { setShowResults(false); setCurrentQuestion(0); setAnswers({}); }} variant="outline" className="flex-1">
                <RotateCcw className="w-4 h-4 mr-2" /> Try Again
              </Button>
            )}
            <Button onClick={() => onComplete(score.percentage, passed)} className="flex-1 bg-purple-600">
              {passed ? 'Continue' : 'Close'}
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>{quiz.title}</CardTitle>
          {timeLeft !== null && (
            <Badge variant={timeLeft < 60 ? "destructive" : "outline"} className="flex items-center gap-1">
              <Clock className="w-3 h-3" /> {formatTime(timeLeft)}
            </Badge>
          )}
        </div>
        <div className="space-y-2 mt-4">
          <div className="flex justify-between text-sm text-gray-600">
            <span>Question {currentQuestion + 1} of {totalQuestions}</span>
            <span>{Math.round(progress)}% complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestion}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
          >
            {/* Question */}
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <Badge className="bg-purple-100 text-purple-800">{question.type?.replace('_', ' ')}</Badge>
                {question.points && <Badge variant="outline">+{question.points} pts</Badge>}
              </div>
              <h3 className="text-xl font-semibold text-gray-900">{question.question}</h3>

              {/* Answer Options */}
              {question.type === 'multiple_choice' && (
                <RadioGroup value={answers[currentQuestion]?.toString()} onValueChange={(v) => handleAnswer(parseInt(v))}>
                  <div className="space-y-3">
                    {question.options?.map((option, idx) => (
                      <div key={idx} className={`flex items-center space-x-3 p-4 rounded-lg border-2 transition-all cursor-pointer ${
                        answers[currentQuestion] === idx ? 'border-purple-500 bg-purple-50' : 'border-gray-200 hover:border-purple-300'
                      }`}>
                        <RadioGroupItem value={idx.toString()} id={`option-${idx}`} />
                        <Label htmlFor={`option-${idx}`} className="flex-1 cursor-pointer">{option}</Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              )}

              {question.type === 'true_false' && (
                <RadioGroup value={answers[currentQuestion]?.toString()} onValueChange={(v) => handleAnswer(parseInt(v))}>
                  <div className="grid grid-cols-2 gap-4">
                    {['True', 'False'].map((option, idx) => (
                      <div key={idx} className={`flex items-center justify-center p-6 rounded-lg border-2 transition-all cursor-pointer ${
                        answers[currentQuestion] === idx ? 'border-purple-500 bg-purple-50' : 'border-gray-200 hover:border-purple-300'
                      }`}>
                        <RadioGroupItem value={idx.toString()} id={`tf-${idx}`} className="hidden" />
                        <Label htmlFor={`tf-${idx}`} className="text-lg font-medium cursor-pointer">{option}</Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              )}

              {question.type === 'reflection' && (
                <Textarea
                  value={answers[currentQuestion] || ''}
                  onChange={(e) => handleAnswer(e.target.value)}
                  placeholder="Share your thoughts and reflections..."
                  rows={5}
                  className="w-full"
                />
              )}

              {question.type === 'fill_in_the_blank' && (
                <div className="p-4 bg-gray-50 rounded-lg border leading-loose text-lg">
                  {question.question.split(/\[blank\]/i).map((part, idx, arr) => (
                    <React.Fragment key={idx}>
                      <span>{part}</span>
                      {idx < arr.length - 1 && (
                        <Input 
                            className="inline-block w-32 mx-1 h-8"
                            value={answers[currentQuestion]?.[idx] || ''}
                            onChange={(e) => {
                                const newAns = {...(answers[currentQuestion] || {})};
                                newAns[idx] = e.target.value;
                                handleAnswer(newAns);
                            }}
                        />
                      )}
                    </React.Fragment>
                  ))}
                </div>
              )}

              {question.type === 'matching' && answers[currentQuestion] && (
                <div className="grid grid-cols-2 gap-8">
                    <div className="space-y-2">
                        <Label className="text-gray-500">Items</Label>
                        {question.pairs.map((pair, idx) => (
                            <div key={idx} className="p-3 bg-gray-50 border rounded h-[50px] flex items-center">
                                {pair.left}
                            </div>
                        ))}
                    </div>
                    <div className="space-y-2">
                        <Label className="text-gray-500">Matches (Drag to reorder)</Label>
                        <DragDropContext onDragEnd={onDragEnd}>
                            <Droppable droppableId="matching-right">
                                {(provided) => (
                                    <div 
                                        {...provided.droppableProps} 
                                        ref={provided.innerRef}
                                        className="space-y-2"
                                    >
                                        {answers[currentQuestion].map((item, index) => (
                                            <Draggable key={item} draggableId={item} index={index}>
                                                {(provided, snapshot) => (
                                                    <div
                                                        ref={provided.innerRef}
                                                        {...provided.draggableProps}
                                                        {...provided.dragHandleProps}
                                                        className={`p-3 bg-white border rounded h-[50px] flex items-center gap-2 shadow-sm ${snapshot.isDragging ? 'shadow-lg ring-2 ring-purple-500' : ''}`}
                                                        style={provided.draggableProps.style}
                                                    >
                                                        <GripVertical className="w-4 h-4 text-gray-400 cursor-grab" />
                                                        {item}
                                                    </div>
                                                )}
                                            </Draggable>
                                        ))}
                                        {provided.placeholder}
                                    </div>
                                )}
                            </Droppable>
                        </DragDropContext>
                    </div>
                </div>
              )}
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Navigation */}
        <div className="flex justify-between pt-4">
          <Button onClick={handlePrevious} disabled={currentQuestion === 0} variant="outline">
            Previous
          </Button>
          {currentQuestion === totalQuestions - 1 ? (
            <Button onClick={handleSubmit} className="bg-green-600 hover:bg-green-700">
              <CheckCircle2 className="w-4 h-4 mr-2" /> Submit Quiz
            </Button>
          ) : (
            <Button onClick={handleNext} disabled={!answers[currentQuestion] && question.type !== 'reflection'}>
              Next <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}