import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Medal, Award, TrendingUp, Crown } from "lucide-react";

import { useState } from "react";

export default function Leaderboard({ users = [], currentUserEmail, period = "all" }) {
  const [metric, setMetric] = useState("points"); // 'points' or 'courses'

  // Sort by metric
  const sortedUsers = [...users].sort((a, b) => {
    if (metric === 'courses') {
      return (b.courses_completed || 0) - (a.courses_completed || 0);
    }
    return (b.learning_points || 0) - (a.learning_points || 0);
  }).slice(0, 10);

  const getRankIcon = (rank) => {
    if (rank === 1) return <Crown className="w-6 h-6 text-yellow-500" />;
    if (rank === 2) return <Medal className="w-6 h-6 text-gray-400" />;
    if (rank === 3) return <Medal className="w-6 h-6 text-amber-600" />;
    return <span className="w-6 h-6 flex items-center justify-center text-gray-500 font-bold">{rank}</span>;
  };

  const getRankBg = (rank) => {
    if (rank === 1) return "bg-gradient-to-r from-yellow-50 to-amber-50 border-yellow-300";
    if (rank === 2) return "bg-gradient-to-r from-gray-50 to-slate-50 border-gray-300";
    if (rank === 3) return "bg-gradient-to-r from-amber-50 to-orange-50 border-amber-300";
    return "bg-white";
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-500" />
            Leaderboard
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => setMetric('points')}
              className={`text-xs px-2 py-1 rounded-md transition-colors ${metric === 'points' ? 'bg-purple-100 text-purple-700 font-medium' : 'text-gray-500 hover:bg-gray-100'}`}
            >
              Points
            </button>
            <button 
              onClick={() => setMetric('courses')}
              className={`text-xs px-2 py-1 rounded-md transition-colors ${metric === 'courses' ? 'bg-purple-100 text-purple-700 font-medium' : 'text-gray-500 hover:bg-gray-100'}`}
            >
              Courses
            </button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {sortedUsers.length === 0 ? (
          <p className="text-center text-gray-500 py-8">No learners yet. Be the first!</p>
        ) : (
          sortedUsers.map((user, idx) => {
            const rank = idx + 1;
            const isCurrentUser = user.email === currentUserEmail;
            return (
              <div
                key={user.id || user.email}
                className={`flex items-center gap-3 p-3 rounded-lg border ${getRankBg(rank)} ${isCurrentUser ? 'ring-2 ring-purple-400' : ''}`}
              >
                <div className="flex-shrink-0">
                  {getRankIcon(rank)}
                </div>
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center text-white font-bold">
                  {user.full_name?.charAt(0) || user.email?.charAt(0) || '?'}
                </div>
                <div className="flex-1 min-w-0">
                  <p className={`font-medium truncate ${isCurrentUser ? 'text-purple-700' : 'text-gray-900'}`}>
                    {user.full_name || 'Anonymous Learner'}
                    {isCurrentUser && <span className="text-xs text-purple-500 ml-2">(You)</span>}
                  </p>
                  <p className="text-xs text-gray-500">{user.courses_completed || 0} courses completed</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-purple-600">
                    {metric === 'points' ? (user.learning_points || 0) : (user.courses_completed || 0)}
                  </p>
                  <p className="text-xs text-gray-500">{metric === 'points' ? 'points' : 'courses'}</p>
                </div>
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}