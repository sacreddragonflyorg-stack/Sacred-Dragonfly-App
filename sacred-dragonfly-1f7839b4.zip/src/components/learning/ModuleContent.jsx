import React from "react";
import ReactMarkdown from "react-markdown";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Clock, Award, PlayCircle, ArrowRight, User } from "lucide-react";

export default function ModuleContent({ module, practitioner, isCompleted, onComplete, onStartQuiz }) {
  return (
    <div className="space-y-6">
      {/* Module Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">{module.title}</h2>
          <div className="flex items-center gap-3 mt-2">
            {module.duration_minutes && (
              <Badge variant="outline" className="flex items-center gap-1">
                <Clock className="w-3 h-3" /> {module.duration_minutes} min
              </Badge>
            )}
            <Badge variant="outline" className="flex items-center gap-1">
              <Award className="w-3 h-3 text-amber-500" /> +{module.points_reward} pts
            </Badge>
            {isCompleted && (
              <Badge className="bg-green-100 text-green-800">
                <CheckCircle2 className="w-3 h-3 mr-1" /> Completed
              </Badge>
            )}
          </div>
        </div>
        {practitioner && (
          <div className="flex items-center gap-2 bg-purple-50 px-3 py-1.5 rounded-full">
             <div className="w-6 h-6 rounded-full bg-purple-200 flex items-center justify-center overflow-hidden">
               {practitioner.photo_url ? (
                 <img src={practitioner.photo_url} alt={practitioner.display_name} className="w-full h-full object-cover" />
               ) : (
                 <User className="w-4 h-4 text-purple-600" />
               )}
            </div>
            <div className="text-sm">
               <span className="text-gray-500">Instructor:</span> <span className="font-medium text-gray-900">{practitioner.display_name}</span>
            </div>
          </div>
        )}
      </div>

      {/* Video if available */}
      {module.video_url && (
        <Card className="overflow-hidden">
          <div className="aspect-video bg-black">
            <iframe
              src={module.video_url}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
        </Card>
      )}

      {/* Audio if available */}
      {module.audio_url && (
        <Card className="p-4 bg-purple-50">
          <div className="flex items-center gap-4">
            <div className="bg-purple-200 p-2 rounded-full">
              <PlayCircle className="w-6 h-6 text-purple-700" />
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-purple-900 mb-1">Audio Lesson</h4>
              <audio controls className="w-full h-8">
                <source src={module.audio_url} type="audio/mpeg" />
                Your browser does not support the audio element.
              </audio>
            </div>
          </div>
        </Card>
      )}

      {/* Module Content */}
      <Card>
        <CardContent className="pt-6">
          <div className="prose prose-purple max-w-none">
            <ReactMarkdown
              components={{
                h1: ({ children }) => <h1 className="text-2xl font-bold text-gray-900 mb-4">{children}</h1>,
                h2: ({ children }) => <h2 className="text-xl font-semibold text-gray-900 mt-6 mb-3">{children}</h2>,
                h3: ({ children }) => <h3 className="text-lg font-semibold text-gray-800 mt-4 mb-2">{children}</h3>,
                p: ({ children }) => <p className="text-gray-700 leading-relaxed mb-4">{children}</p>,
                ul: ({ children }) => <ul className="list-disc pl-6 mb-4 space-y-2">{children}</ul>,
                ol: ({ children }) => <ol className="list-decimal pl-6 mb-4 space-y-2">{children}</ol>,
                li: ({ children }) => <li className="text-gray-700">{children}</li>,
                blockquote: ({ children }) => (
                  <blockquote className="border-l-4 border-purple-400 pl-4 py-2 my-4 bg-purple-50 rounded-r-lg italic text-gray-700">
                    {children}
                  </blockquote>
                ),
                strong: ({ children }) => <strong className="font-semibold text-purple-700">{children}</strong>,
              }}
            >
              {module.content}
            </ReactMarkdown>
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex gap-3">
        {!isCompleted && (
          <Button onClick={onComplete} className="bg-green-600 hover:bg-green-700">
            <CheckCircle2 className="w-4 h-4 mr-2" /> Mark as Complete
          </Button>
        )}
        {module.has_quiz && (
          <Button onClick={onStartQuiz} variant={isCompleted ? "default" : "outline"} className={isCompleted ? "bg-purple-600" : ""}>
            <PlayCircle className="w-4 h-4 mr-2" /> {isCompleted ? 'Take Quiz' : 'Take Quiz After Completing'}
          </Button>
        )}
      </div>
    </div>
  );
}