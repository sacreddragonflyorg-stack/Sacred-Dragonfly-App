import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { BookOpen, Clock, Award, Lock, CheckCircle2, Play, User } from "lucide-react";

export default function CourseCard({ course, practitioner, progress, userPoints = 0, onStart, onContinue, onUnlock }) {
  const isLocked = course.points_required > 0 && !progress && userPoints < course.points_required;
  const canUnlock = course.points_required > 0 && !progress && userPoints >= course.points_required;
  const isStarted = progress?.status === 'in_progress';
  const isCompleted = progress?.status === 'completed';

  const difficultyColors = {
    beginner: "bg-green-100 text-green-800",
    intermediate: "bg-amber-100 text-amber-800",
    advanced: "bg-red-100 text-red-800"
  };

  return (
    <Card className={`overflow-hidden hover:shadow-xl transition-all duration-300 ${isLocked ? 'opacity-75' : ''}`}>
      {/* Cover Image */}
      <div className="relative h-40 overflow-hidden">
        {course.image_url ? (
          <img src={course.image_url} alt={course.title} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center">
            <BookOpen className="w-12 h-12 text-white/80" />
          </div>
        )}
        {isLocked && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <div className="text-center text-white">
              <Lock className="w-8 h-8 mx-auto mb-2" />
              <p className="text-sm font-medium">{course.points_required} points to unlock</p>
            </div>
          </div>
        )}
        {isCompleted && (
          <div className="absolute top-3 right-3">
            <Badge className="bg-green-500"><CheckCircle2 className="w-3 h-3 mr-1" /> Completed</Badge>
          </div>
        )}
        {course.is_premium && !isLocked && (
          <div className="absolute top-3 left-3">
            <Badge className="bg-amber-500"><Award className="w-3 h-3 mr-1" /> Premium</Badge>
          </div>
        )}
      </div>

      <CardContent className="pt-4 space-y-3">
        {/* Title & Badges */}
        <div>
          <h3 className="font-bold text-lg text-gray-900 line-clamp-1">{course.title}</h3>
          <div className="flex items-center gap-2 mt-1">
            <Badge variant="outline" className={difficultyColors[course.difficulty_level]}>
              {course.difficulty_level}
            </Badge>
            <Badge variant="outline" className="text-xs">
              {course.category?.replace(/_/g, ' ')}
            </Badge>
          </div>
        </div>

        {/* Description */}
        <p className="text-sm text-gray-600 line-clamp-2">{course.description}</p>

        {/* Practitioner Info */}
        {practitioner && (
          <div className="flex items-center gap-2 text-xs text-gray-600">
            <div className="w-5 h-5 rounded-full bg-purple-100 flex items-center justify-center overflow-hidden">
               {practitioner.photo_url ? (
                 <img src={practitioner.photo_url} alt={practitioner.display_name} className="w-full h-full object-cover" />
               ) : (
                 <User className="w-3 h-3 text-purple-600" />
               )}
            </div>
            <span>By {practitioner.display_name}</span>
          </div>
        )}

        {/* Stats */}
        <div className="flex items-center gap-4 text-xs text-gray-500">
          {course.estimated_hours && (
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" /> {course.estimated_hours}h
            </span>
          )}
          <span className="flex items-center gap-1">
            <Award className="w-3 h-3 text-amber-500" /> +{course.points_reward} pts
          </span>
        </div>

        {/* Progress Bar */}
        {isStarted && (
          <div className="space-y-1">
            <div className="flex justify-between text-xs text-gray-600">
              <span>Progress</span>
              <span>{progress.progress_percentage}%</span>
            </div>
            <Progress value={progress.progress_percentage} className="h-2" />
          </div>
        )}

        {/* Action Button */}
        {isLocked ? (
          <Button disabled className="w-full" variant="outline">
            <Lock className="w-4 h-4 mr-2" /> {course.points_required} Points Required
          </Button>
        ) : canUnlock ? (
          <Button onClick={() => onUnlock(course)} className="w-full bg-amber-500 hover:bg-amber-600">
            <Award className="w-4 h-4 mr-2" /> Unlock for {course.points_required} pts
          </Button>
        ) : isCompleted ? (
          <Button onClick={() => onContinue(course)} variant="outline" className="w-full">
            <BookOpen className="w-4 h-4 mr-2" /> Review Course
          </Button>
        ) : isStarted ? (
          <Button onClick={() => onContinue(course)} className="w-full bg-purple-600 hover:bg-purple-700">
            <Play className="w-4 h-4 mr-2" /> Continue Learning
          </Button>
        ) : (
          <Button onClick={() => onStart(course)} className="w-full bg-gradient-to-r from-purple-600 to-pink-600">
            <Play className="w-4 h-4 mr-2" /> Start Course
          </Button>
        )}
      </CardContent>
    </Card>
  );
}