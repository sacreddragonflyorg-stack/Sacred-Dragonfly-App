import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Play, Pause, Clock, Headphones, Wind, Heart, Sparkles, Volume2 } from "lucide-react";

export default function MeditationLibrary() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [playingId, setPlayingId] = useState(null);

  const { data: resources = [], isLoading } = useQuery({
    queryKey: ['meditation-resources'],
    queryFn: async () => {
      const all = await base44.entities.LearningResource.filter({ category: 'meditation' });
      return all;
    }
  });

  const categories = [
    { id: "all", label: "All Meditations", icon: Sparkles },
    { id: "before_care", label: "Before Care", icon: Wind },
    { id: "after_care", label: "After Care", icon: Heart },
    { id: "stress", label: "Stress Relief", icon: Headphones },
  ];

  const filteredResources = activeCategory === "all" 
    ? resources 
    : resources.filter(r => r.tags && r.tags.includes(activeCategory));

  const togglePlay = (id) => {
    if (playingId === id) {
      setPlayingId(null);
      // Logic to stop audio would go here if using a global player
    } else {
      setPlayingId(id);
    }
  };

  return (
    <div className="space-y-8">
      <div className="text-center max-w-2xl mx-auto space-y-4">
        <h2 className="text-3xl font-bold text-purple-900">Mindfulness Sanctuary</h2>
        <p className="text-gray-600">
          Find your center with our curated collection of guided meditations. 
          Perfect for preparing for a session, integrating healing, or finding calm in stressful moments.
        </p>
      </div>

      <Tabs defaultValue="all" value={activeCategory} onValueChange={setActiveCategory} className="w-full">
        <div className="flex justify-center mb-8">
          <TabsList className="bg-white/50 backdrop-blur-sm p-1 rounded-full border border-purple-100">
            {categories.map(cat => (
              <TabsTrigger 
                key={cat.id} 
                value={cat.id}
                className="rounded-full px-6 py-2 data-[state=active]:bg-purple-600 data-[state=active]:text-white"
              >
                <cat.icon className="w-4 h-4 mr-2" />
                {cat.label}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            <p className="text-center col-span-full text-gray-500">Loading meditations...</p>
          ) : filteredResources.length === 0 ? (
            <div className="col-span-full text-center py-12 bg-white/50 rounded-2xl border border-purple-100">
              <Headphones className="w-12 h-12 text-purple-200 mx-auto mb-4" />
              <p className="text-gray-500">No meditations found for this category yet.</p>
            </div>
          ) : (
            filteredResources.map(resource => (
              <Card key={resource.id} className="group hover:shadow-lg transition-all duration-300 border-purple-100 bg-white/80 backdrop-blur-sm overflow-hidden">
                <div className="relative h-48 bg-purple-100 overflow-hidden">
                  {resource.image_url ? (
                    <img 
                      src={resource.image_url} 
                      alt={resource.title} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-purple-200 to-pink-200">
                      <Headphones className="w-12 h-12 text-white/50" />
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <Button 
                      size="icon" 
                      className="rounded-full w-12 h-12 bg-white/20 hover:bg-white/40 backdrop-blur-md text-white border-none"
                      onClick={() => togglePlay(resource.id)}
                    >
                      {playingId === resource.id ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-1" />}
                    </Button>
                  </div>
                  {resource.duration_minutes && (
                    <div className="absolute bottom-3 right-3 bg-black/50 backdrop-blur-sm text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {resource.duration_minutes} min
                    </div>
                  )}
                </div>
                
                <CardContent className="p-5 space-y-3">
                  <div className="space-y-1">
                    <h3 className="font-semibold text-lg text-gray-900 line-clamp-1">{resource.title}</h3>
                    <p className="text-sm text-gray-500 line-clamp-2">{resource.description}</p>
                  </div>
                  
                  {resource.audio_url && (
                    <div className="pt-2">
                      <audio controls className="w-full h-8 opacity-70 hover:opacity-100 transition-opacity">
                        <source src={resource.audio_url} type="audio/mpeg" />
                        Your browser does not support the audio element.
                      </audio>
                    </div>
                  )}

                  <div className="flex flex-wrap gap-2 pt-2">
                    {resource.tags?.map(tag => (
                      <Badge key={tag} variant="secondary" className="bg-purple-50 text-purple-700 hover:bg-purple-100 border-none">
                        #{tag.replace('_', ' ')}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </Tabs>
    </div>
  );
}