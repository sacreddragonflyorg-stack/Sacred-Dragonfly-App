import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Award, Gift, DollarSign, BookOpen, Sparkles, ArrowRight, Users, Star, Lock, Crown, MessageSquare } from "lucide-react";

const redemptionOptions = {
  discounts: [
    { id: 'discount_10', type: 'session_discount', title: '$10 Session Discount', description: 'Get $10 off your next healing session', points: 100, discount: 10, icon: DollarSign, color: 'bg-green-500' },
    { id: 'discount_25', type: 'session_discount', title: '$25 Session Discount', description: 'Get $25 off your next healing session', points: 225, discount: 25, icon: DollarSign, color: 'bg-green-600' },
    { id: 'discount_50', type: 'session_discount', title: '$50 Session Discount', description: 'Get $50 off your next healing session', points: 400, discount: 50, icon: Gift, color: 'bg-purple-500' },
    { id: 'free_session', type: 'free_session', title: 'Free 30-min Session', description: 'Redeem a free introductory healing session', points: 750, icon: Sparkles, color: 'bg-pink-500' }
  ],
  content: [
    { id: 'exclusive_meditation', type: 'content_unlock', title: 'Exclusive Meditation Pack', description: 'Access 5 premium guided meditations', points: 150, icon: BookOpen, color: 'bg-indigo-500' },
    { id: 'advanced_course', type: 'content_unlock', title: 'Advanced Course Access', description: 'Unlock one premium advanced course', points: 300, icon: Star, color: 'bg-amber-500' },
    { id: 'masterclass', type: 'content_unlock', title: 'Live Masterclass Access', description: 'Join an exclusive live masterclass session', points: 500, icon: Crown, color: 'bg-purple-600' }
  ],
  community: [
    { id: 'private_group', type: 'community_perk', title: 'Private Community Access', description: 'Join the exclusive healers community for 1 month', points: 200, icon: Users, color: 'bg-blue-500' },
    { id: 'qa_session', type: 'community_perk', title: 'Q&A with Practitioner', description: 'Get a 15-min private Q&A session', points: 350, icon: MessageSquare, color: 'bg-teal-500' },
    { id: 'vip_badge', type: 'community_perk', title: 'VIP Learner Badge', description: 'Display exclusive VIP badge on your profile', points: 600, icon: Crown, color: 'bg-rose-500' }
  ]
};

export default function PointsRedemptionPanel({ userPoints = 0, onRedeem, existingRedemptions = [] }) {
  const [selectedCategory, setSelectedCategory] = useState('discounts');
  
  const activeDiscounts = existingRedemptions.filter(r => 
    r.status === 'active' && r.redemption_type === 'session_discount'
  );

  const renderOption = (option) => {
    const canAfford = userPoints >= option.points;
    return (
      <Card key={option.id} className={`transition-all ${canAfford ? 'hover:shadow-lg cursor-pointer' : 'opacity-60'}`}>
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            <div className={`w-12 h-12 ${option.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
              <option.icon className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold text-gray-900">{option.title}</h4>
              <p className="text-sm text-gray-600 mb-3">{option.description}</p>
              <div className="flex items-center justify-between">
                <Badge variant="outline" className="flex items-center gap-1">
                  <Award className="w-3 h-3 text-amber-500" /> {option.points} pts
                </Badge>
                <Button
                  size="sm"
                  disabled={!canAfford}
                  onClick={() => onRedeem(option)}
                  className={canAfford ? 'bg-purple-600' : ''}
                >
                  {canAfford ? (
                    <>Redeem <ArrowRight className="w-3 h-3 ml-1" /></>
                  ) : (
                    <><Lock className="w-3 h-3 mr-1" /> Locked</>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      {/* Points Balance */}
      <Card className="bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100 text-sm">Your Points Balance</p>
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-bold">{userPoints}</span>
                <span className="text-purple-200">points</span>
              </div>
            </div>
            <Award className="w-16 h-16 text-purple-200" />
          </div>
        </CardContent>
      </Card>

      {/* Active Discounts */}
      {activeDiscounts.length > 0 && (
        <Card className="border-2 border-green-200 bg-green-50">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg text-green-800 flex items-center gap-2">
              <Gift className="w-5 h-5" /> Your Active Rewards
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {activeDiscounts.map(discount => (
              <div key={discount.id} className="flex items-center justify-between p-3 bg-white rounded-lg border border-green-200">
                <div>
                  <p className="font-medium text-gray-900">${discount.discount_amount} Discount</p>
                  <p className="text-xs text-gray-500">Code: {discount.discount_code}</p>
                </div>
                <Badge className="bg-green-600">Active</Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Redemption Options */}
      <Card>
        <CardHeader>
          <CardTitle>Redeem Your Points</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
            <TabsList className="grid grid-cols-3 mb-6">
              <TabsTrigger value="discounts">
                <DollarSign className="w-4 h-4 mr-1" /> Discounts
              </TabsTrigger>
              <TabsTrigger value="content">
                <BookOpen className="w-4 h-4 mr-1" /> Content
              </TabsTrigger>
              <TabsTrigger value="community">
                <Users className="w-4 h-4 mr-1" /> Community
              </TabsTrigger>
            </TabsList>

            <TabsContent value="discounts" className="space-y-4">
              {redemptionOptions.discounts.map(renderOption)}
            </TabsContent>

            <TabsContent value="content" className="space-y-4">
              {redemptionOptions.content.map(renderOption)}
            </TabsContent>

            <TabsContent value="community" className="space-y-4">
              {redemptionOptions.community.map(renderOption)}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* How to Earn */}
      <Card className="bg-amber-50 border-amber-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg text-amber-800 flex items-center gap-2">
            <BookOpen className="w-5 h-5" /> How to Earn Points
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm text-amber-900">
            <li className="flex items-center gap-2"><span className="w-1.5 h-1.5 bg-amber-500 rounded-full" />Complete modules: 10-25 pts</li>
            <li className="flex items-center gap-2"><span className="w-1.5 h-1.5 bg-amber-500 rounded-full" />Pass quizzes: 25-50 pts</li>
            <li className="flex items-center gap-2"><span className="w-1.5 h-1.5 bg-amber-500 rounded-full" />Complete courses: 100-300 pts bonus</li>
            <li className="flex items-center gap-2"><span className="w-1.5 h-1.5 bg-amber-500 rounded-full" />Complete challenges: 50-200 pts</li>
            <li className="flex items-center gap-2"><span className="w-1.5 h-1.5 bg-amber-500 rounded-full" />Daily login streak: 10 pts/day</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}