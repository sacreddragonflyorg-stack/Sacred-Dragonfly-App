import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, TrendingUp, Gift, Award } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function PointsDisplay({ user, onUsePoints }) {
  const points = user?.learning_points || 0;

  const pointTiers = [
    { name: "Beginner", min: 0, color: "bg-gray-100 text-gray-700" },
    { name: "Explorer", min: 50, color: "bg-blue-100 text-blue-700" },
    { name: "Seeker", min: 150, color: "bg-purple-100 text-purple-700" },
    { name: "Master", min: 300, color: "bg-amber-100 text-amber-700" }
  ];

  const currentTier = [...pointTiers].reverse().find(tier => points >= tier.min) || pointTiers[0];
  const nextTier = pointTiers[pointTiers.indexOf(currentTier) + 1];

  return (
    <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200">
      <CardContent className="pt-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Award className="w-5 h-5 text-purple-600" />
              <h3 className="text-lg font-bold text-gray-900">Your Learning Points</h3>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-bold text-purple-600">{points}</span>
              <span className="text-sm text-gray-600">points</span>
            </div>
          </div>
          <Badge className={`${currentTier.color} text-sm`}>
            {currentTier.name}
          </Badge>
        </div>

        {nextTier && (
          <div className="mb-4">
            <div className="flex justify-between text-sm text-gray-600 mb-1">
              <span>Progress to {nextTier.name}</span>
              <span>{points} / {nextTier.min}</span>
            </div>
            <div className="h-2 bg-white rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-purple-600 to-pink-600 transition-all duration-300"
                style={{ width: `${Math.min((points / nextTier.min) * 100, 100)}%` }}
              />
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="bg-white rounded-lg p-3 text-center">
            <Sparkles className="w-5 h-5 text-purple-600 mx-auto mb-1" />
            <p className="text-xs text-gray-600 mb-1">Unlock Resources</p>
            <p className="text-sm font-bold text-gray-900">10-50 pts</p>
          </div>
          <div className="bg-white rounded-lg p-3 text-center">
            <Gift className="w-5 h-5 text-pink-600 mx-auto mb-1" />
            <p className="text-xs text-gray-600 mb-1">Session Discount</p>
            <p className="text-sm font-bold text-gray-900">100 pts = $10</p>
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-xs text-gray-600 font-medium">How to earn points:</p>
          <ul className="text-xs text-gray-600 space-y-1">
            <li className="flex items-start gap-2">
              <span className="text-green-600">•</span>
              <span>Complete learning resources (+10-30 pts)</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-600">•</span>
              <span>Book and complete sessions (+20 pts)</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-600">•</span>
              <span>Refer friends (+50 pts per referral)</span>
            </li>
          </ul>
        </div>

        <Link to={createPageUrl("PointsRedemption")} className="block mt-4">
          <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600">
            <TrendingUp className="w-4 h-4 mr-2" />
            Redeem Points
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}