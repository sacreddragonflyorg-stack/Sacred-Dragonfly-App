import React, { useState, useEffect } from "react";
import { loadStripe } from "@stripe/stripe-js";
import { Elements, PaymentElement, useStripe, useElements } from "@stripe/react-stripe-js";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Lock, AlertCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

// Internal Form Component
const CheckoutForm = ({ clientSecret, onSuccess, onCancel, mode }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [message, setMessage] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!stripe) return;

    const clientSecretParam = new URLSearchParams(window.location.search).get("payment_intent_client_secret");
    if (!clientSecretParam) return;

    stripe.retrievePaymentIntent(clientSecretParam).then(({ paymentIntent }) => {
      switch (paymentIntent.status) {
        case "succeeded":
          setMessage("Payment succeeded!");
          break;
        case "processing":
          setMessage("Your payment is processing.");
          break;
        case "requires_payment_method":
          setMessage("Your payment was not successful, please try again.");
          break;
        default:
          setMessage("Something went wrong.");
          break;
      }
    });
  }, [stripe]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!stripe || !elements) return;

    setIsLoading(true);

    const { error, paymentIntent } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: window.location.href, // This handles 3D secure redirects
      },
      redirect: "if_required",
    });

    if (error) {
      if (error.type === "card_error" || error.type === "validation_error") {
        setMessage(error.message);
      } else {
        setMessage("An unexpected error occurred.");
      }
      setIsLoading(false);
    } else {
      if (paymentIntent && paymentIntent.status === 'succeeded') {
          // Payment succeeded immediately
          onSuccess({ 
              payment_intent_id: paymentIntent.id, 
              status: 'succeeded',
              amount: paymentIntent.amount / 100 
          });
      } else {
          // It might be processing or required redirect (handled by redirect option above if setup correctly)
          // Since we used redirect: 'if_required', success usually means it's done or processing
          // For subscriptions, default_incomplete means we just paid the first invoice.
          onSuccess({
              payment_intent_id: paymentIntent?.id,
              status: paymentIntent?.status
          });
      }
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement id="payment-element" options={{ layout: "tabs" }} />
      
      {message && (
        <div className="p-3 bg-red-50 text-red-600 rounded-md text-sm flex items-center gap-2">
            <AlertCircle className="w-4 h-4" /> {message}
        </div>
      )}

      <div className="flex gap-3">
        <Button 
            disabled={isLoading || !stripe || !elements} 
            type="submit"
            className="flex-1 bg-purple-600 hover:bg-purple-700"
        >
          {isLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Lock className="w-4 h-4 mr-2" />}
          {mode === 'subscription' ? 'Subscribe' : 'Pay Now'}
        </Button>
        {onCancel && (
            <Button type="button" variant="outline" onClick={onCancel} disabled={isLoading}>
                Cancel
            </Button>
        )}
      </div>
      
      <div className="text-center text-xs text-gray-500 flex items-center justify-center gap-1">
        <Lock className="w-3 h-3" /> Payments secured by Stripe
      </div>
    </form>
  );
};

export default function StripePaymentForm({ amount, description, metadata, onSuccess, onCancel, mode = "payment", planDetails }) {
  const [stripePromise, setStripePromise] = useState(null);
  const [clientSecret, setClientSecret] = useState("");
  const [subscriptionId, setSubscriptionId] = useState(null);

  // Fetch Config
  useEffect(() => {
      base44.functions.invoke('getStripeConfig').then(({ data }) => {
          if (data.publishableKey) {
              setStripePromise(loadStripe(data.publishableKey));
          }
      });
  }, []);

  // Create Intent/Subscription
  useEffect(() => {
      const init = async () => {
          if (mode === 'subscription' && planDetails) {
              try {
                  const { data } = await base44.functions.invoke('createStripeSubscription', {
                      planId: planDetails.id,
                      price: amount, // Monthly/Yearly price
                      interval: planDetails.billing_interval,
                      planName: planDetails.name
                  });
                  setClientSecret(data.clientSecret);
                  setSubscriptionId(data.subscriptionId);
              } catch (err) {
                  toast.error("Failed to initialize subscription");
              }
          } else {
              // One-time payment
              try {
                  const { data } = await base44.functions.invoke('createStripePaymentIntent', {
                      amount,
                      description,
                      metadata
                  });
                  setClientSecret(data.client_secret);
              } catch (err) {
                  toast.error("Failed to initialize payment");
              }
          }
      };
      
      if (amount || (mode === 'subscription' && planDetails)) {
          init();
      }
  }, [amount, mode, planDetails]);

  const handleSuccess = (result) => {
      // Pass subscription ID back if it exists
      onSuccess({ ...result, subscriptionId });
  };

  if (!clientSecret || !stripePromise) {
      return (
          <div className="flex items-center justify-center p-8">
              <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
          </div>
      );
  }

  const appearance = {
    theme: 'stripe',
    variables: {
      colorPrimary: '#7c3aed',
    },
  };

  return (
    <Card className="border-none shadow-none">
      <CardContent className="p-0">
        <Elements options={{ clientSecret, appearance }} stripe={stripePromise}>
          <CheckoutForm 
            clientSecret={clientSecret} 
            onSuccess={handleSuccess} 
            onCancel={onCancel}
            mode={mode} 
          />
        </Elements>
      </CardContent>
    </Card>
  );
}