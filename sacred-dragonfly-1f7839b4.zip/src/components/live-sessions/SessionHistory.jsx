import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, Calendar, Eye, Star } from "lucide-react";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function SessionHistory({ sessions, user }) {
  const [viewingSession, setViewingSession] = useState(null);
  const isPractitioner = user.role === 'admin';

  if (sessions.length === 0) {
    return (
      <Card>
        <CardContent className="text-center py-16">
          <Clock className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-700 mb-2">No Session History</h3>
          <p className="text-gray-500">Completed sessions will appear here</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <div className="space-y-4">
        {sessions.map((session) => {
          const duration = session.actual_start && session.actual_end
            ? Math.round((new Date(session.actual_end) - new Date(session.actual_start)) / (1000 * 60))
            : null;

          return (
            <Card key={session.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-semibold text-lg">{session.service_name}</h3>
                      <Badge className={
                        session.status === 'completed' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-red-100 text-red-800'
                      }>
                        {session.status}
                      </Badge>
                      {session.practitioner_rating && (
                        <div className="flex items-center gap-1 text-amber-600">
                          <Star className="w-4 h-4 fill-current" />
                          <span className="text-sm font-medium">{session.practitioner_rating}</span>
                        </div>
                      )}
                    </div>

                    <div className="space-y-1 text-sm text-gray-600">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        <span>{format(new Date(session.scheduled_start), 'MMMM d, yyyy')}</span>
                      </div>
                      {duration && (
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4" />
                          <span>{duration} minutes</span>
                        </div>
                      )}
                      <div>
                        <span className="font-medium">
                          {isPractitioner ? `Client: ${session.client_name}` : 'With Practitioner'}
                        </span>
                      </div>
                    </div>

                    {session.session_outcome && (
                      <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                        <p className="text-sm font-medium text-gray-700">Session Outcome:</p>
                        <p className="text-sm text-gray-600 mt-1 line-clamp-2">{session.session_outcome}</p>
                      </div>
                    )}
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setViewingSession(session)}
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Session Details Dialog */}
      <Dialog open={!!viewingSession} onOpenChange={() => setViewingSession(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          {viewingSession && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl">Session Details</DialogTitle>
              </DialogHeader>

              <div className="space-y-6">
                {/* Basic Info */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Service</p>
                    <p className="font-semibold">{viewingSession.service_name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Date</p>
                    <p className="font-semibold">
                      {format(new Date(viewingSession.scheduled_start), 'MMMM d, yyyy')}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Duration</p>
                    <p className="font-semibold">
                      {viewingSession.actual_start && viewingSession.actual_end
                        ? `${Math.round((new Date(viewingSession.actual_end) - new Date(viewingSession.actual_start)) / (1000 * 60))} minutes`
                        : 'N/A'}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Status</p>
                    <Badge className={
                      viewingSession.status === 'completed' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }>
                      {viewingSession.status}
                    </Badge>
                  </div>
                </div>

                {/* Session Focus */}
                {viewingSession.client_concerns && (
                  <div>
                    <h4 className="font-semibold mb-2">Session Focus</h4>
                    <p className="text-gray-700 bg-purple-50 p-4 rounded-lg">
                      {viewingSession.client_concerns}
                    </p>
                  </div>
                )}

                {/* Session Notes */}
                {isPractitioner && viewingSession.session_notes && (
                  <div>
                    <h4 className="font-semibold mb-2">Session Notes</h4>
                    <p className="text-gray-700 bg-gray-50 p-4 rounded-lg whitespace-pre-wrap">
                      {viewingSession.session_notes}
                    </p>
                  </div>
                )}

                {/* Outcome */}
                {viewingSession.session_outcome && (
                  <div>
                    <h4 className="font-semibold mb-2">Session Outcome</h4>
                    <p className="text-gray-700 bg-green-50 p-4 rounded-lg">
                      {viewingSession.session_outcome}
                    </p>
                  </div>
                )}

                {/* Recommendations */}
                {viewingSession.follow_up_recommendations && (
                  <div>
                    <h4 className="font-semibold mb-2">Follow-up Recommendations</h4>
                    <p className="text-gray-700 bg-amber-50 p-4 rounded-lg">
                      {viewingSession.follow_up_recommendations}
                    </p>
                  </div>
                )}

                {/* Chat History */}
                {viewingSession.chat_messages && viewingSession.chat_messages.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2">Chat History</h4>
                    <div className="bg-gray-50 rounded-lg p-4 max-h-64 overflow-y-auto space-y-3">
                      {viewingSession.chat_messages.map((msg, idx) => (
                        <div key={idx} className="text-sm">
                          <span className="font-medium text-purple-600">
                            {msg.sender_role === 'practitioner' ? 'Practitioner' : 'Client'}:
                          </span>
                          <span className="ml-2 text-gray-700">{msg.message}</span>
                          <span className="ml-2 text-xs text-gray-500">
                            {format(new Date(msg.timestamp), 'h:mm a')}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Rating & Feedback */}
                {viewingSession.practitioner_rating && (
                  <div>
                    <h4 className="font-semibold mb-2">Client Feedback</h4>
                    <div className="bg-amber-50 p-4 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              className={`w-5 h-5 ${
                                star <= viewingSession.practitioner_rating
                                  ? 'fill-amber-400 text-amber-400'
                                  : 'text-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                        <span className="font-medium">
                          {viewingSession.practitioner_rating}/5
                        </span>
                      </div>
                      {viewingSession.client_feedback && (
                        <p className="text-gray-700">{viewingSession.client_feedback}</p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}