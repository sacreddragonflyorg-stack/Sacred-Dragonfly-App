import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Video, 
  MessageCircle, 
  FileText, 
  X, 
  Send, 
  ExternalLink,
  Maximize2,
  Minimize2,
  Phone
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function ActiveSession({ session, user, onEndSession, refetchSessions }) {
  const [sessionNotes, setSessionNotes] = useState(session.session_notes || "");
  const [chatMessage, setChatMessage] = useState("");
  const [chatMessages, setChatMessages] = useState(session.chat_messages || []);
  const [sessionTimer, setSessionTimer] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const isPractitioner = user.role === 'admin';

  // Timer
  useEffect(() => {
    const interval = setInterval(() => {
      if (session.actual_start) {
        const elapsed = Math.floor((new Date() - new Date(session.actual_start)) / 1000);
        setSessionTimer(elapsed);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [session.actual_start]);

  const formatTime = (seconds) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const updateNotesMutation = useMutation({
    mutationFn: (notes) => {
      return base44.entities.LiveSession.update(session.id, {
        session_notes: notes
      });
    },
    onSuccess: () => {
      toast.success("Notes saved");
      refetchSessions();
    },
  });

  const sendMessageMutation = useMutation({
    mutationFn: (message) => {
      const newMessage = {
        sender: user.email,
        sender_role: isPractitioner ? 'practitioner' : 'client',
        message: message,
        timestamp: new Date().toISOString()
      };
      
      const updatedMessages = [...chatMessages, newMessage];
      setChatMessages(updatedMessages);
      
      return base44.entities.LiveSession.update(session.id, {
        chat_messages: updatedMessages
      });
    },
    onSuccess: () => {
      setChatMessage("");
      refetchSessions();
    },
  });

  const endSessionMutation = useMutation({
    mutationFn: async (data) => {
      return base44.entities.LiveSession.update(session.id, {
        status: 'completed',
        actual_end: new Date().toISOString(),
        ...data
      });
    },
    onSuccess: () => {
      toast.success("Session completed");
      onEndSession();
    },
  });

  const handleSendMessage = () => {
    if (!chatMessage.trim()) return;
    sendMessageMutation.mutate(chatMessage);
  };

  const handleEndSession = () => {
    if (isPractitioner) {
      endSessionMutation.mutate({
        session_notes: sessionNotes
      });
    } else {
      onEndSession();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800">
      {/* Top Bar */}
      <div className="bg-gray-800 border-b border-gray-700 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
              <span className="text-white font-medium">LIVE</span>
            </div>
            <div className="text-gray-300">
              <span className="font-semibold">{session.service_name}</span>
              <span className="mx-2">•</span>
              <span>{isPractitioner ? session.client_name : 'Practitioner Session'}</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Badge className="bg-gray-700 text-white text-lg px-4 py-1">
              {formatTime(sessionTimer)}
            </Badge>
            <Button
              onClick={handleEndSession}
              variant="destructive"
              className="bg-red-600 hover:bg-red-700"
            >
              <Phone className="w-4 h-4 mr-2 transform rotate-135" />
              End Session
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-6">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Video Area */}
          <div className="lg:col-span-2 space-y-6">
            {/* Video Frame */}
            <Card className={`bg-gray-900 border-gray-700 overflow-hidden ${
              isFullscreen ? 'fixed inset-0 z-50 rounded-none' : ''
            }`}>
              <CardContent className="p-0">
                <div className="relative aspect-video bg-gradient-to-br from-purple-900/20 to-pink-900/20">
                  {session.meeting_link ? (
                    <iframe
                      src={session.meeting_link}
                      className="w-full h-full"
                      allow="camera; microphone; fullscreen; display-capture"
                    />
                  ) : (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-400">
                      <Video className="w-24 h-24 mb-4" />
                      <p className="text-xl font-medium mb-2">Video Call</p>
                      <p className="text-sm">Waiting for video connection...</p>
                    </div>
                  )}

                  {/* Video Controls Overlay */}
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge className="bg-red-600 text-white">
                          ● LIVE - {formatTime(sessionTimer)}
                        </Badge>
                      </div>
                      <div className="flex gap-2">
                        {session.meeting_link && (
                          <a
                            href={session.meeting_link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-2 bg-gray-800/50 hover:bg-gray-700 rounded-full text-white transition-colors"
                          >
                            <ExternalLink className="w-5 h-5" />
                          </a>
                        )}
                        <button
                          onClick={() => setIsFullscreen(!isFullscreen)}
                          className="p-2 bg-gray-800/50 hover:bg-gray-700 rounded-full text-white transition-colors"
                        >
                          {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Session Info */}
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Session Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-gray-300">
                <div className="flex justify-between">
                  <span>Service:</span>
                  <span className="font-medium text-white">{session.service_name}</span>
                </div>
                <div className="flex justify-between">
                  <span>Scheduled:</span>
                  <span className="font-medium text-white">
                    {format(new Date(session.scheduled_start), 'h:mm a')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Started:</span>
                  <span className="font-medium text-white">
                    {session.actual_start ? format(new Date(session.actual_start), 'h:mm a') : '-'}
                  </span>
                </div>
                {session.client_concerns && (
                  <div className="pt-3 border-t border-gray-700">
                    <p className="text-sm font-medium mb-1">Session Focus:</p>
                    <p className="text-sm text-gray-400">{session.client_concerns}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            {/* Chat */}
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <MessageCircle className="w-5 h-5" />
                  Session Chat
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Messages */}
                  <div className="h-64 overflow-y-auto space-y-3 bg-gray-900 rounded-lg p-4">
                    {chatMessages.length === 0 ? (
                      <p className="text-gray-500 text-center text-sm">No messages yet</p>
                    ) : (
                      chatMessages.map((msg, idx) => (
                        <div
                          key={idx}
                          className={`flex ${
                            msg.sender === user.email ? 'justify-end' : 'justify-start'
                          }`}
                        >
                          <div
                            className={`max-w-xs rounded-lg p-3 ${
                              msg.sender === user.email
                                ? 'bg-purple-600 text-white'
                                : 'bg-gray-700 text-gray-100'
                            }`}
                          >
                            <p className="text-xs opacity-70 mb-1">
                              {msg.sender_role === 'practitioner' ? 'Practitioner' : 'Client'}
                            </p>
                            <p className="text-sm">{msg.message}</p>
                            <p className="text-xs opacity-70 mt-1">
                              {format(new Date(msg.timestamp), 'h:mm a')}
                            </p>
                          </div>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Message Input */}
                  <div className="flex gap-2">
                    <Input
                      value={chatMessage}
                      onChange={(e) => setChatMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      placeholder="Type a message..."
                      className="bg-gray-900 border-gray-700 text-white"
                    />
                    <Button
                      onClick={handleSendMessage}
                      disabled={!chatMessage.trim()}
                      size="icon"
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Practitioner Notes */}
            {isPractitioner && (
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <FileText className="w-5 h-5" />
                    Session Notes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Textarea
                      value={sessionNotes}
                      onChange={(e) => setSessionNotes(e.target.value)}
                      placeholder="Take notes during the session..."
                      rows={8}
                      className="bg-gray-900 border-gray-700 text-white resize-none"
                    />
                    <Button
                      onClick={() => updateNotesMutation.mutate(sessionNotes)}
                      variant="outline"
                      className="w-full border-gray-700 text-white hover:bg-gray-700"
                    >
                      Save Notes
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}