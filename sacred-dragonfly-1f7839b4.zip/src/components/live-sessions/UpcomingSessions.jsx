import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Video, Plus, Edit } from "lucide-react";
import { format, differenceInMinutes } from "date-fns";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function UpcomingSessions({ sessions, user, onStartSession, refetchSessions }) {
  const [editingSession, setEditingSession] = useState(null);
  const [meetingLink, setMeetingLink] = useState("");

  const isPractitioner = user.role === 'admin';

  const startSessionMutation = useMutation({
    mutationFn: async (sessionId) => {
      const session = sessions.find(s => s.id === sessionId);
      return base44.entities.LiveSession.update(sessionId, {
        status: 'in_progress',
        actual_start: new Date().toISOString(),
        meeting_link: session.meeting_link || meetingLink
      });
    },
    onSuccess: () => {
      refetchSessions();
      toast.success("Session started!");
    },
  });

  const updateMeetingLinkMutation = useMutation({
    mutationFn: ({ sessionId, link }) => {
      return base44.entities.LiveSession.update(sessionId, {
        meeting_link: link
      });
    },
    onSuccess: () => {
      refetchSessions();
      setEditingSession(null);
      setMeetingLink("");
      toast.success("Meeting link updated");
    },
  });

  const handleStartSession = (session) => {
    if (!session.meeting_link && !meetingLink) {
      toast.error("Please add a meeting link first");
      setEditingSession(session);
      return;
    }
    startSessionMutation.mutate(session.id);
    onStartSession(session.id);
  };

  const canStartSession = (session) => {
    const minutesUntilStart = differenceInMinutes(new Date(session.scheduled_start), new Date());
    return minutesUntilStart <= 15; // Can start 15 minutes before
  };

  if (sessions.length === 0) {
    return (
      <Card>
        <CardContent className="text-center py-16">
          <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-700 mb-2">No Upcoming Sessions</h3>
          <p className="text-gray-500">
            {isPractitioner 
              ? "Sessions from appointments will appear here"
              : "Book a session to get started"}
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <div className="grid gap-4">
        {sessions.map((session) => {
          const minutesUntilStart = differenceInMinutes(new Date(session.scheduled_start), new Date());
          const isStartingSoon = minutesUntilStart <= 15 && minutesUntilStart >= 0;

          return (
            <Card key={session.id} className={`hover:shadow-lg transition-shadow ${
              isStartingSoon ? 'border-l-4 border-l-amber-600' : ''
            }`}>
              <CardContent className="pt-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-semibold text-lg">{session.service_name}</h3>
                      {isStartingSoon && (
                        <Badge className="bg-amber-100 text-amber-800">Starting Soon</Badge>
                      )}
                    </div>
                    
                    <div className="space-y-1 text-sm text-gray-600">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        <span>{format(new Date(session.scheduled_start), 'EEEE, MMMM d, yyyy')}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        <span>{format(new Date(session.scheduled_start), 'h:mm a')}</span>
                        {minutesUntilStart > 0 && (
                          <span className="text-purple-600 font-medium">
                            (in {minutesUntilStart} minutes)
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">
                          {isPractitioner ? `Client: ${session.client_name}` : 'With Practitioner'}
                        </span>
                      </div>
                      {session.client_concerns && (
                        <div className="mt-2 p-3 bg-purple-50 rounded-lg">
                          <p className="text-sm font-medium text-purple-900">Session Focus:</p>
                          <p className="text-sm text-gray-700 mt-1">{session.client_concerns}</p>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    {isPractitioner && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setEditingSession(session);
                          setMeetingLink(session.meeting_link || "");
                        }}
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        {session.meeting_link ? 'Edit Link' : 'Add Link'}
                      </Button>
                    )}
                    
                    {session.meeting_link && (
                      <a
                        href={session.meeting_link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-purple-600 hover:text-purple-700 flex items-center gap-1"
                      >
                        <Video className="w-4 h-4" />
                        Meeting Link
                      </a>
                    )}

                    {canStartSession(session) && isPractitioner && (
                      <Button
                        onClick={() => handleStartSession(session)}
                        className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                      >
                        <Video className="w-4 h-4 mr-2" />
                        Start Session
                      </Button>
                    )}

                    {!isPractitioner && isStartingSoon && session.meeting_link && (
                      <Button
                        onClick={() => onStartSession(session.id)}
                        className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                      >
                        <Video className="w-4 h-4 mr-2" />
                        Join Session
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Edit Meeting Link Dialog */}
      <Dialog open={!!editingSession} onOpenChange={() => setEditingSession(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Meeting Link</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Video Meeting Link</Label>
              <Input
                value={meetingLink}
                onChange={(e) => setMeetingLink(e.target.value)}
                placeholder="https://zoom.us/j/... or https://meet.google.com/..."
              />
              <p className="text-xs text-gray-500">
                Add a Zoom, Google Meet, or other video conferencing link
              </p>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() => updateMeetingLinkMutation.mutate({
                  sessionId: editingSession?.id,
                  link: meetingLink
                })}
                disabled={!meetingLink.trim()}
                className="flex-1 bg-purple-600 hover:bg-purple-700"
              >
                Save Link
              </Button>
              <Button
                variant="outline"
                onClick={() => setEditingSession(null)}
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}